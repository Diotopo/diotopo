Diotopo 1.0 - Topology optimization
======================================================================

THE "DIOTOPO" FOLDER CONTAINS FIVE VERSIONS
  Browser Version    runs in the browser - on this PC or for other devices in the home network.
                     Needs an installed Python (Windows, Linux, macOS). Also contains the
                     program code from which all other versions are built.
  Portable Version   for USB sticks (Windows): starts directly without installation, leaves
                     nothing behind on the PC. Is created once on a Windows PC with Python
                     (one double-click, a wizard guides you).
  Windows Installer  ready-to-use installation wizard for Windows 10/11:
                     double-click "Install Diotopo.cmd".
  Linux Installer    ready-to-use installation wizard for Linux: "Install Diotopo.sh".
  Mac Installer      ready-to-use installation wizard for macOS: "Install Diotopo.command".
  All three installers first ask where to install, then set up everything needed by
  themselves (Python and computing packages - an internet connection is required), then ask
  about a desktop shortcut and whether Diotopo should be started right away. Every installer
  folder is complete and can be passed on on its own.
  Details: README in each folder.

CREATING THE PORTABLE VERSION (once, on a Windows PC with Python)
  1. Install Python 3.10 or newer (tick "Add python.exe to PATH").
  2. Double-click "Create portable version.pyw". A wizard window builds the program
     Diotopo.exe from the "Browser Version" folder directly into this folder (plus the
     subfolder _internal). Takes a few minutes and needs internet once.
  The "Browser Version" folder must be next to this folder.

USING IT ON A USB STICK
  Copy the whole "Portable Version" folder to the USB stick (or anywhere else) and start
  Diotopo.exe there - no installation, no Python needed (Windows 10/11, 64 bit).
  All settings, the log and the window profile stay in the "Data" subfolder on the stick
  (controlled by the file portable.txt) - nothing is left behind on the PC.
  Tip: on a fast stick (USB 3) Diotopo starts considerably faster.

LICENSE AND THIRD-PARTY COMPONENTS
  Diotopo: see LICENSE.txt (in the "Browser Version" folder; shipped with the installer and the
  portable version and shown in the installation wizard).
  Third-party components (Python, NumPy, SciPy, OpenCASCADE, PyOpenCL ...): "Licenses"
  folder - the license texts are placed next to Diotopo.exe automatically when building.
  Before publishing, fill in the placeholders [enter name or company] and
  [enter e-mail address] in LICENSE.txt and Licenses\Third-party licenses.txt.
  The copyright holder then appears automatically in the file properties of Diotopo.exe.
  Note: the "Browser Version" folder contains the source code - for a closed-source release
  only pass on the generated setup file or the portable version.
