Diotopo 1.0 - Topology optimization
======================================================================

THE "DIOTOPO" FOLDER CONTAINS FIVE VERSIONS
  Browser Version    runs in the browser - on this PC or for other devices in the home network.
                     Needs an installed Python (Windows, Linux, macOS). Also contains the
                     program code from which all other versions are built.
  Portable Version   for USB sticks (Windows): starts directly without installation, leaves
                     nothing behind on the PC. Is created once on a Windows PC with Python
                     (one double-click, a wizard guides you).
  Windows Installer  ready-to-use installation wizard for Windows 10/11:
                     double-click "Install Diotopo.cmd".
  Linux Installer    ready-to-use installation wizard for Linux: "Install Diotopo.sh".
  Mac Installer      ready-to-use installation wizard for macOS: "Install Diotopo.command".
  All three installers first ask where to install, then set up everything needed by
  themselves (Python and computing packages - an internet connection is required), then ask
  about a desktop shortcut and whether Diotopo should be started right away. Every installer
  folder is complete and can be passed on on its own.
  Details: README in each folder.

SETTING UP THE WEB VERSION (once)
  1. Install Python 3.10 or newer from https://www.python.org/downloads/
     and tick "Add python.exe to PATH".
  2. Double-click "Install packages.bat" (numpy, scipy; optionally cadquery-ocp-novtk
     (OpenCASCADE) for STEP and pyopencl for graphics cards).
  Linux/macOS:  python3 -m pip install -r requirements.txt cadquery-ocp-novtk pyopencl

STARTING
  "Start Diotopo in browser.bat"    Diotopo opens in the default browser
                                    (http://127.0.0.1:8765/). Only reachable on this PC.
  "Share on network.bat"            additionally for other devices on the same network (tablet,
                                    second PC): open the displayed address in the browser there.
                                    CAUTION: no password - anyone on the network can use Diotopo.
                                    Only in trusted networks, not on public Wi-Fi.
                                    Windows may ask for a firewall permission.
  Linux/macOS:  ./start.sh   or  ./start.sh --network
  Quit: close the black window (or press Ctrl+C).
  In Task Manager the browser version appears as "Diotopo Web".
  Everything is computed on the PC the browser version runs on - nothing goes to the internet.

WORKFLOW
  1 Prepare       Open STEP/STL/3MF/OBJ/PLY/ZIP, choose the material,
                  click faces (Ctrl+click = several) and assign them as support,
                  load, solid/empty zone; create load cases.
  2 Simulate      Analyze the solid part (stress, displacement, safety factor)
                  and optimize the topology (objective volume or mass) - optionally
                  suited to the manufacturing method (see below).
                  All numeric values of the optimization can be set with sliders from the
                  smallest to the largest possible value (target mass up to the solid
                  mass, wall thicknesses up to half the part thickness, milling depth up to
                  the part height in tool direction); type exact values into the field next to it.
  3 Export        Print check (overhang, thin walls), export STL/3MF/OBJ.
                  In Fusion 360: Insert > Insert Mesh.

MANUFACTURING METHODS (tab 2, "Manufacturing & Symmetry")
  Unrestricted            free shape (e.g. for 3D printing with supports).
  3D printing w/o supports  no overhangs flatter than 45 or 63 degrees in build direction.
  Casting                 one demolding direction, no undercuts.
  3-axis milling          the result can be produced on a 3-axis milling machine:
    Tool comes from       direction from which the cutter engages (e.g. z+ = from above).
    Setups                1 = only from this side; 2 = the part is flipped and also milled
                          from the opposite side. Regions the cutter cannot reach
                          (undercuts) stay material.
    Cutter diameter       smallest cutter: pockets and slots do not get narrower,
                          inner corners get at least this radius.
    Max. milling depth    stick-out length from the stock surface (bounding box of the
                          part); deeper material remains. 0 = unlimited.
  Tip: the cutter diameter only takes effect once it is at least about 1.5 voxels -
  increase the resolution for fine cutters. The minimum wall thickness (webs) is set
  as usual via "Minimum wall thickness".

LIMITATIONS
  Voxel FEM, linear elastic: results are guide values and should be verified in
  Fusion 360 (Simulation). The result is a mesh, not a parametric body.
  No thermal, flow or nonlinear FEM.

PROBLEMS
  Error messages are written to %LOCALAPPDATA%\Diotopo\diotopo.log
  (Linux: ~/.local/share/Diotopo/diotopo.log, macOS: ~/Library/Application Support/Diotopo/diotopo.log)

COMBINED COMPUTING: CPU + GRAPHICS CARD(S) + MEMORY
  The equation solver does not pick a single compute unit but lets all of them compute
  at the same time (equation solver "Combined", default):
  - Every level of the multigrid method is split into sections: every graphics card
    (NVIDIA, AMD, Intel, also integrated graphics - also several at once) and the CPU with
    all cores compute their section at the same time. Only the boundary values between the
    sections are exchanged (a few percent).
  - The section sizes follow the measured wall time (incl. waiting and data exchange) and
    are readjusted after every solve so that all finish as simultaneously as possible. The
    current split and the actual CPU utilization (average threads) are shown in the log
    ("Solver: ...").
  - If the share of a graphics card does not fit into its memory, it gets as much as fits;
    the rest stays in RAM and is computed by the CPU. Large models therefore keep using the
    graphics card instead of switching completely to the CPU.
  - Coarse levels and very small models (below approx. 30,000 unknowns) are computed by the
    CPU, where the data exchange would cost more than the computation.
  - Without a graphics card the same solver runs on all CPU cores.
  - Everything around the solver also uses all cores: assembly of the stiffness matrix,
    coarse-grid matrices (Galerkin products), density filter. The live 3D view is created
    on the side; the optimization does not wait for it.
  - Processors with cores of different speeds (e.g. Intel Core Ultra / 12th-14th gen. with
    P, E and LP cores) are fully used: the work is split into many small pieces, every free
    core takes the next one.
  Accuracy: the outer method computes in double precision on all CPU cores, the
  preconditioner (most of the work) in single precision distributed over all compute
  units. Results and step count as with the pure CPU solver.
  Note on integrated graphics: it shares the memory with the CPU. The computation is mainly
  limited by its speed, so integrated graphics in addition to the CPU usually gives only a
  smaller gain. A dedicated graphics card gives much more.
  Selectable by hand: "Graphics card only", "CPU only (all cores)", "Direct (small)".
  Setup: "Install packages.bat" (package pyopencl; already included in the installer/portable
  version; the graphics driver provides OpenCL).
  "Test GPU.bat" (in the "Browser Version" folder) shows the graphics cards found and compares
  combined / GPU only / CPU only.
  Environment variables: DIOTOPO_OPENCL_DEVICE=<number or part of name>[,...] limits the
  graphics cards used, DIOTOPO_THREADS=<number> the CPU threads, DIOTOPO_NO_GPU=1 turns the
  graphics cards off.

RESOLUTION, MEMORY AND COMPUTING TIME
  The highest resolution depends on the free memory (approx. 15 KB per voxel element).
  Under "Simulate & Optimize" the element count, memory requirement, estimated computing
  time and the highest possible resolution are shown before starting.
  During every computation a progress bar in the 3D view shows phase, progress, elapsed
  and remaining time, below it the current utilization of CPU, graphics card and memory as
  bars 0-100 % (system-wide, as in Task Manager; RAM turns orange from 80 %, red from 92 %).
  The time estimate learns the speed of this computer (stored in
  %LOCALAPPDATA%\Diotopo\speed.json).

PART VOLUME AFTER THE OPTIMIZATION
  In the "Optimization result" box the "Part volume" slider sets the volume of the
  finished part: live preview while dragging, final mesh + analysis on release.
  The result is always one connected part: floating regions, broken struts and unloaded
  appendages are removed or prevented.

LICENSE AND THIRD-PARTY COMPONENTS
  Diotopo: see LICENSE.txt (in the "Browser Version" folder; shipped with the installer and the
  portable version and shown in the installation wizard).
  Third-party components (Python, NumPy, SciPy, OpenCASCADE, PyOpenCL ...): "Licenses"
  folder - the license texts are placed next to Diotopo.exe automatically when building.
  Before publishing, fill in the placeholders [enter name or company] and
  [enter e-mail address] in LICENSE.txt and Licenses\Third-party licenses.txt.
  The copyright holder then appears automatically in the file properties of Diotopo.exe.
  Note: the "Browser Version" folder contains the source code - for a closed-source release
  only pass on the generated setup file or the portable version.
