# -*- coding: utf-8 -*-
"""
Lagerungsprüfung und Reparatur der Voxel-Konnektivität.

* bridge_hinges: Voxel, die sich nur an Kanten oder Ecken berühren, sind im FE-Modell
  Gelenke (Scharniere). Hier werden sie durch einzelne Brückenvoxel flächig verbunden.
* rigid_modes: prüft lastunabhängig, ob die Lager alle sechs Starrkörperbewegungen
  (3 Verschiebungen, 3 Drehungen) je zusammenhängendem Bereich verhindern, und beschreibt
  die noch freien Bewegungen im Klartext.
"""

import math

import numpy as np
from scipy.ndimage import label

S26 = np.ones((3, 3, 3), dtype=bool)
FACE = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
EDGE = [(a, b, 0) for a in (-1, 1) for b in (-1, 1)] + [(a, 0, b) for a in (-1, 1) for b in (-1, 1)] + \
       [(0, a, b) for a in (-1, 1) for b in (-1, 1)]
BIG = np.iinfo(np.int32).max


def _nb_minmax(labp, offs, shape):
    """Minimum/Maximum der Nachbarlabels (0 = leer, ignoriert) für alle Zellen."""
    mn = np.full(shape, BIG, dtype=np.int32)
    mx = np.zeros(shape, dtype=np.int32)
    for dx, dy, dz in offs:
        v = labp[1 + dx:1 + dx + shape[0], 1 + dy:1 + dy + shape[1], 1 + dz:1 + dz + shape[2]]
        mx = np.maximum(mx, v)
        mn = np.minimum(mn, np.where(v > 0, v, BIG))
    return mn, mx


def bridge_hinges(mask, allowed, max_pass=8):
    """Verbindet Bereiche, die sich nur an Kanten/Ecken berühren, durch Brückenvoxel.
    mask, allowed: bool-Gitter. Gibt (neue Maske, Anzahl ergänzter Voxel) zurück."""
    mask = mask.copy()
    shape = mask.shape
    added = 0
    for _ in range(max_pass):
        lab, n = label(mask)
        if n <= 1:
            break
        l26, n26 = label(mask, structure=S26)
        if n26 >= n:                     # keine Gruppe aus mehreren 6-Komponenten
            break
        pairs = np.unique(np.stack([l26[mask], lab[mask]], 1), axis=0)
        multi = np.zeros(n26 + 1, dtype=bool)
        multi[np.flatnonzero(np.bincount(pairs[:, 0], minlength=n26 + 1) > 1)] = True
        labp = np.pad(lab.astype(np.int32), 1)
        gp = np.pad(l26.astype(np.int32), 1)
        cand = allowed & ~mask
        fmn, fmx = _nb_minmax(labp, FACE, shape)
        gmn_f, gmx_f = _nb_minmax(gp, FACE, shape)
        gmn_e, gmx_e = _nb_minmax(gp, EDGE, shape)
        gmn, gmx = np.minimum(gmn_f, gmn_e), np.maximum(gmx_f, gmx_e)
        same_group = (gmx > 0) & (gmn == gmx) & multi[np.minimum(gmx, n26)]
        new = cand & same_group & (fmx > 0) & (fmn < fmx)            # Kantenkontakt überbrücken
        if not new.any():
            emn, emx = _nb_minmax(labp, EDGE, shape)
            new = cand & same_group & (fmx > 0) & (np.minimum(fmn, emn) < np.maximum(fmx, emx))  # Eckkontakt
        if not new.any():
            break
        mask |= new
        added += int(new.sum())
    return mask, added


AX = "XYZ"


def _axis_name(v):
    v = np.asarray(v, float)
    v = v / max(np.linalg.norm(v), 1e-300)
    i = int(np.argmax(np.abs(v)))
    if abs(v[i]) > 0.97:
        return AX[i]
    return "(" + ", ".join(f"{x:.2f}" for x in v) + ")"


def rigid_modes(npos, nodes, elim_mask, Kp_free, free_index, kpen, center=None):
    """Freie Starrkörperbewegungen eines Bereichs.
    npos: Knotenpositionen (Modelleinheit), nodes: Knoten des Bereichs, elim_mask: gesperrte
    Freiheitsgrade (ndof, bool), Kp_free: Strafsteifigkeit (freie FHG) oder None,
    free_index: ndof -> Index der freien FHG (-1 = gesperrt).
    Gibt Liste von (Art, Achse/Richtung, Punkt) und den Nullraum (6×k) zurück."""
    p = npos[nodes]
    c = p.mean(0) if center is None else center
    Lc = max(float(np.linalg.norm(p.max(0) - p.min(0))), 1e-12)
    d = (p - c) / Lc
    n = len(nodes)
    modes = np.zeros((n, 3, 6))
    for a in range(3):
        modes[:, a, a] = 1.0
    # Drehung um Achse e_a: u = e_a × d
    modes[:, 1, 3], modes[:, 2, 3] = -d[:, 2], d[:, 1]
    modes[:, 0, 4], modes[:, 2, 4] = d[:, 2], -d[:, 0]
    modes[:, 0, 5], modes[:, 1, 5] = -d[:, 1], d[:, 0]
    dofs = (nodes[:, None] * 3 + np.arange(3)).ravel()
    Mr = modes.reshape(n * 3, 6)
    G = np.zeros((6, 6))
    em = elim_mask[dofs]
    if em.any():
        G += Mr[em].T @ Mr[em]
    if Kp_free is not None:
        fi = free_index[dofs]
        ok = fi >= 0
        if ok.any():
            nf = Kp_free.shape[0]
            U = np.zeros((nf, 6))
            U[fi[ok]] = Mr[ok]
            G += (U.T @ (Kp_free @ U)) / kpen
    w, V = np.linalg.eigh(0.5 * (G + G.T))
    top = max(float(w.max()), 0.0)
    null = V[:, w <= 1e-9 * top] if top > 0 else np.eye(6)
    out = []
    if null.shape[1] == 0:
        return out, null
    Pn = null @ null.T
    canon_free = [i for i in range(6) if np.linalg.norm(Pn[:, i]) > 0.999]
    for i in canon_free:
        out.append(("shift" if i < 3 else "rot", AX[i % 3], c))
    rest = null.shape[1] - len(canon_free)
    if rest > 0:
        # nicht achsparallele freie Bewegungen: Basis des Restraums beschreiben
        E = np.eye(6)[:, canon_free]
        R = null - E @ (E.T @ null) if canon_free else null
        u, s, _ = np.linalg.svd(R, full_matrices=False)
        for k in range(rest):
            v = u[:, k]
            t, r = v[:3], v[3:] / Lc
            if np.linalg.norm(r) * Lc < 1e-3 * np.linalg.norm(t):
                out.append(("shift", _axis_name(t), c))
            else:
                pt = c + np.cross(r, t) / float(r @ r)
                out.append(("rot", _axis_name(r), pt))
    return out, null


def describe(modes, scale, unit="mm"):
    parts = []
    for kind, ax, pt in modes:
        if kind == "shift":
            parts.append(f"verschieben in {ax}-Richtung" if len(ax) == 1 else f"verschieben in Richtung {ax}")
        else:
            q = ", ".join(f"{x * scale:.1f}" for x in pt)
            a = f"die {ax}-Achse" if len(ax) == 1 else f"die Achse {ax}"
            parts.append(f"drehen um {a} durch ({q}) {unit}")
    return ", ".join(parts)


# ================================================================ Druckprüfung (Export)

def check_mesh(verts, faces, solid, S):
    """Markiert Überhänge (je Dreieck) und dünne Wände (je Punkt).
    solid = (Maske, lo, h) des Voxelfeldes, aus dem das Netz stammt (oder None)."""
    scale = float(S["scale"])
    mm = 1.0 / scale
    t = verts[faces].astype(np.float64)
    cr = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
    area = 0.5 * np.linalg.norm(cr, axis=1)
    nrm = cr / np.maximum(2 * area, 1e-300)[:, None]
    bdir = np.zeros(3)
    bdir["xyz".index(S.get("build_dir", "z+")[0])] = 1 if S.get("build_dir", "z+")[1] == "+" else -1
    ang = math.radians(float(S.get("overhang_deg", 45)))
    hgt = t.mean(1) @ bdir
    base = hgt.min() if len(hgt) else 0
    over = (nrm @ bdir < -math.cos(ang)) & (hgt > base + 0.6 * mm)
    flag = np.zeros(len(verts), dtype=np.uint8)
    flag[faces[over].ravel()] = 1
    thin_frac = 0.0
    tmin = float(S.get("min_wall_mm", 0.6)) * mm
    if solid is not None and tmin > 0:
        mask, lo, h = solid
        if mask.dtype != bool:
            mask = mask > 0
        vn = np.zeros_like(verts, dtype=np.float64)
        for k in range(3):
            np.add.at(vn, faces[:, k], cr)
        vn /= np.maximum(np.linalg.norm(vn, axis=1, keepdims=True), 1e-300)
        ok = np.ones(len(verts), dtype=bool)
        for f in (0.5, 0.8):
            p = verts - vn * (tmin * f)
            idx = np.floor((p - lo) / h).astype(int)
            idx = np.clip(idx, 0, np.array(mask.shape) - 1)
            ok &= mask[idx[:, 0], idx[:, 1], idx[:, 2]]
        thin = ~ok
        flag[thin] |= 2
        thin_frac = float(thin.mean())
    tot = float(area.sum())
    return flag, dict(overhang_area_pct=100 * float(area[over].sum()) / tot if tot else 0.0,
                      thin_pct=100 * thin_frac, min_wall_mm=tmin / mm,
                      overhang_deg=float(S.get("overhang_deg", 45)))
