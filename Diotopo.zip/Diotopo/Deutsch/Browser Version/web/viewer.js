// Kleiner WebGL2-Renderer für Bauteile, Ergebnisse und Hilfslinien (keine externen Bibliotheken).

const VS = `#version 300 es
in vec3 aPos; in vec3 aNor; in float aScal; in vec3 aCol; in vec3 aDisp;
uniform mat4 uP, uV; uniform float uDisp;
out vec3 vNor; out vec3 vPos; out float vScal; out vec3 vCol; out vec3 vW;
void main(){
  vec3 p = aPos + aDisp * uDisp; vW = p;
  vec4 vp = uV * vec4(p, 1.0);
  vPos = vp.xyz; vNor = mat3(uV) * aNor; vScal = aScal; vCol = aCol;
  gl_Position = uP * vp;
}`;
const FS = `#version 300 es
precision highp float;
in vec3 vNor; in vec3 vPos; in float vScal; in vec3 vCol; in vec3 vW;
uniform vec4 uClip; uniform int uClipOn;
uniform vec3 uColor; uniform float uAlpha; uniform int uMode; uniform int uLit;
uniform float uMin, uMax; uniform int uRev;
out vec4 o;
vec3 cmap(float t){
  t = clamp(t, 0.0, 1.0);
  vec3 c0=vec3(0.18,0.30,0.78), c1=vec3(0.10,0.72,0.90), c2=vec3(0.30,0.80,0.35), c3=vec3(0.98,0.85,0.20), c4=vec3(0.88,0.18,0.15);
  if(t<0.25) return mix(c0,c1,t/0.25);
  if(t<0.5) return mix(c1,c2,(t-0.25)/0.25);
  if(t<0.75) return mix(c2,c3,(t-0.5)/0.25);
  return mix(c3,c4,(t-0.75)/0.25);
}
void main(){
  if(uClipOn==1 && dot(vW, uClip.xyz) > uClip.w) discard;
  vec3 base = uColor;
  if(uMode==1){ float t=(vScal-uMin)/max(uMax-uMin,1e-30); if(uRev==1) t=1.0-t; base=cmap(t); }
  else if(uMode==2){ base = vCol; }
  if(uLit==0){ o = vec4(base, uAlpha); return; }
  vec3 n = normalize(vNor); vec3 v = normalize(-vPos);
  if(dot(n,v) < 0.0) n = -n;
  float d = max(dot(n, v), 0.0);
  vec3 l2 = normalize(vec3(0.4, 0.8, 0.5));
  float d2 = max(dot(n, l2), 0.0);
  vec3 h = normalize(v + l2);
  float s = pow(max(dot(n, h), 0.0), 40.0);
  vec3 c = base * (0.28 + 0.55*d + 0.25*d2) + vec3(0.10*s);
  if(uClipOn==1 && !gl_FrontFacing) c = c * 0.55 + vec3(0.25, 0.08, 0.05);
  o = vec4(c, uAlpha);
}`;

function m4() { return new Float32Array(16); }
function persp(fov, asp, n, f) {
  const t = 1 / Math.tan(fov / 2), m = m4();
  m[0] = t / asp; m[5] = t; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f); return m;
}
function ortho(w, h, n, f) {
  const m = m4(); m[0] = 2 / w; m[5] = 2 / h; m[10] = -2 / (f - n); m[14] = -(f + n) / (f - n); m[15] = 1; return m;
}
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const mul = (a, s) => [a[0] * s, a[1] * s, a[2] * s];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
export { sub, add, mul, dot, cross, norm };

function lookAt(e, c, up) {
  const z = norm(sub(e, c)), x = norm(cross(up, z)), y = cross(z, x), m = m4();
  m[0] = x[0]; m[4] = x[1]; m[8] = x[2]; m[12] = -dot(x, e);
  m[1] = y[0]; m[5] = y[1]; m[9] = y[2]; m[13] = -dot(y, e);
  m[2] = z[0]; m[6] = z[1]; m[10] = z[2]; m[14] = -dot(z, e);
  m[15] = 1; return m;
}

export function faceNormals(pos) {
  const n = new Float32Array(pos.length);
  for (let i = 0; i < pos.length; i += 9) {
    const ax = pos[i + 3] - pos[i], ay = pos[i + 4] - pos[i + 1], az = pos[i + 5] - pos[i + 2];
    const bx = pos[i + 6] - pos[i], by = pos[i + 7] - pos[i + 1], bz = pos[i + 8] - pos[i + 2];
    let x = ay * bz - az * by, y = az * bx - ax * bz, z = ax * by - ay * bx;
    const l = Math.hypot(x, y, z) || 1; x /= l; y /= l; z /= l;
    for (let k = 0; k < 9; k += 3) { n[i + k] = x; n[i + k + 1] = y; n[i + k + 2] = z; }
  }
  return n;
}
export function vertexNormals(pos, idx) {
  const n = new Float32Array(pos.length);
  for (let t = 0; t < idx.length; t += 3) {
    const a = idx[t] * 3, b = idx[t + 1] * 3, c = idx[t + 2] * 3;
    const ax = pos[b] - pos[a], ay = pos[b + 1] - pos[a + 1], az = pos[b + 2] - pos[a + 2];
    const bx = pos[c] - pos[a], by = pos[c + 1] - pos[a + 1], bz = pos[c + 2] - pos[a + 2];
    const x = ay * bz - az * by, y = az * bx - ax * bz, z = ax * by - ay * bx;
    for (const v of [a, b, c]) { n[v] += x; n[v + 1] += y; n[v + 2] += z; }
  }
  for (let i = 0; i < n.length; i += 3) {
    const l = Math.hypot(n[i], n[i + 1], n[i + 2]) || 1; n[i] /= l; n[i + 1] /= l; n[i + 2] /= l;
  }
  return n;
}

export class Viewer {
  constructor(canvas, overlay) {
    this.canvas = canvas; this.overlay = overlay;
    const gl = canvas.getContext('webgl2', { antialias: true, preserveDrawingBuffer: true, premultipliedAlpha: false });
    if (!gl) throw new Error('WebGL2 wird von diesem Fenster nicht unterstützt.');
    this.gl = gl;
    this.prog = this._program(VS, FS);
    this.loc = {};
    for (const a of ['aPos', 'aNor', 'aScal', 'aCol', 'aDisp']) this.loc[a] = gl.getAttribLocation(this.prog, a);
    for (const u of ['uP', 'uV', 'uDisp', 'uColor', 'uAlpha', 'uMode', 'uLit', 'uMin', 'uMax', 'uRev', 'uClip', 'uClipOn'])
      this.loc[u] = gl.getUniformLocation(this.prog, u);
    this.objs = new Map();
    this.up = 'z';
    this.target = [0, 0, 0]; this.dist = 100; this.yaw = -0.8; this.pitch = 0.55; this.radius = 50;
    this.ortho = false; this.dispScale = 0; this.clip = null; this.bg = [0.86, 0.88, 0.91];
    this._dirty = true;
    this._bindInput();
    this._axes();
    const loop = () => { if (this._dirty) { this._dirty = false; this._draw(); } requestAnimationFrame(loop); };
    requestAnimationFrame(loop);
    new ResizeObserver(() => this.redraw()).observe(canvas.parentElement);
  }
  redraw() { this._dirty = true; }

  _program(vs, fs) {
    const gl = this.gl, mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh);
      if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); return sh; };
    const p = gl.createProgram();
    gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    return p;
  }
  _buf(target, data) { const gl = this.gl, b = gl.createBuffer(); gl.bindBuffer(target, b); gl.bufferData(target, data, gl.STATIC_DRAW); return b; }

  // ------------------------------------------------------------------ Objekte
  setMesh(id, o) {
    this.remove(id);
    const gl = this.gl;
    const pos = o.positions, idx = o.indices || null;
    const nor = o.normals || (idx ? vertexNormals(pos, idx) : faceNormals(pos));
    const nv = pos.length / 3;
    const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    const attr = (name, data, size) => {
      const l = this.loc[name]; if (l < 0) return null;
      const b = this._buf(gl.ARRAY_BUFFER, data); gl.enableVertexAttribArray(l); gl.vertexAttribPointer(l, size, gl.FLOAT, false, 0, 0); return b;
    };
    const obj = { vao, nv, idx: !!idx, count: idx ? idx.length : nv, lines: !!o.lines,
      color: o.color || [0.7, 0.72, 0.76], alpha: o.opacity ?? 1, visible: o.visible ?? true,
      mode: 0, min: 0, max: 1, rev: false, offset: o.offset || 0, lit: o.lines ? 0 : 1, order: o.order || 0,
      pos, indices: idx, pickable: !!o.pickable, disp: !!o.disp, depthTest: o.depthTest ?? true, clip: o.clip ?? !o.lines };
    obj.bPos = attr('aPos', pos, 3); obj.bNor = attr('aNor', nor, 3);
    obj.bScal = attr('aScal', o.scalars || new Float32Array(nv), 1);
    obj.bCol = attr('aCol', o.colors || new Float32Array(nv * 3), 3);
    obj.bDisp = attr('aDisp', o.disp || new Float32Array(nv * 3), 3);
    if (idx) { obj.bIdx = this._buf(gl.ELEMENT_ARRAY_BUFFER, idx); }
    gl.bindVertexArray(null);
    if (o.scalars) { obj.mode = 1; }
    if (o.colors) { obj.mode = 2; }
    this.objs.set(id, obj); this.redraw(); return obj;
  }
  setLines(id, positions, color, opts = {}) {
    return this.setMesh(id, { positions: new Float32Array(positions), lines: true, color, normals: new Float32Array(positions.length), ...opts });
  }
  _upd(obj, buf, data) { const gl = this.gl; gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); }
  setScalars(id, s, min, max, rev = false) {
    const o = this.objs.get(id); if (!o) return;
    this._upd(o, o.bScal, s); o.mode = 1; o.min = min; o.max = max; o.rev = rev; this.redraw();
  }
  setColors(id, c) { const o = this.objs.get(id); if (!o) return; this._upd(o, o.bCol, c); o.mode = 2; this.redraw(); }
  setDisp(id, d) { const o = this.objs.get(id); if (!o) return; this._upd(o, o.bDisp, d); o.disp = true; this.redraw(); }
  setFlat(id, color) { const o = this.objs.get(id); if (!o) return; o.mode = 0; if (color) o.color = color; this.redraw(); }
  set(id, props) { const o = this.objs.get(id); if (o) { Object.assign(o, props); this.redraw(); } }
  get(id) { return this.objs.get(id); }
  remove(id) {
    const o = this.objs.get(id); if (!o) return;
    const gl = this.gl;
    for (const b of [o.bPos, o.bNor, o.bScal, o.bCol, o.bDisp, o.bIdx]) if (b) gl.deleteBuffer(b);
    gl.deleteVertexArray(o.vao); this.objs.delete(id); this.redraw();
  }
  removePrefix(p) { for (const k of [...this.objs.keys()]) if (k.startsWith(p)) this.remove(k); }

  // ------------------------------------------------------------------ Kamera
  upVec() { return this.up === 'z' ? [0, 0, 1] : [0, 1, 0]; }
  eye() {
    const cp = Math.cos(this.pitch), sp = Math.sin(this.pitch), cy = Math.cos(this.yaw), sy = Math.sin(this.yaw);
    const d = this.up === 'z' ? [cp * cy, cp * sy, sp] : [cp * sy, sp, cp * cy];
    return add(this.target, mul(d, this.dist));
  }
  fit(lo, hi) {
    this.target = mul(add(lo, hi), 0.5);
    this.radius = Math.max(1e-6, 0.5 * Math.hypot(hi[0] - lo[0], hi[1] - lo[1], hi[2] - lo[2]));
    const fov = 0.6; this.dist = this.radius / Math.sin(fov / 2) * 1.05; this.redraw();
  }
  view(name) {
    const v = { iso: [-0.8, 0.55], front: [-Math.PI / 2, 0], back: [Math.PI / 2, 0], right: [0, 0], left: [Math.PI, 0],
      top: [-Math.PI / 2, Math.PI / 2 - 1e-4], bottom: [-Math.PI / 2, -Math.PI / 2 + 1e-4] }[name];
    if (v) { this.yaw = v[0]; this.pitch = v[1]; this.redraw(); }
  }
  matrices() {
    const c = this.canvas, w = c.width, h = c.height, asp = w / Math.max(h, 1);
    const e = this.eye(), V = lookAt(e, this.target, this.upVec());
    const n = Math.max(this.dist - this.radius * 4, this.dist * 1e-3), f = this.dist + this.radius * 4;
    let Pm;
    if (this.ortho) { const hh = this.dist * Math.tan(0.3); Pm = ortho(2 * hh * asp, 2 * hh, n, f); }
    else Pm = persp(0.6, asp, n, f);
    return { P: Pm, V, e, asp };
  }
  ray(cx, cy) {
    const r = this.canvas.getBoundingClientRect();
    const x = ((cx - r.left) / r.width) * 2 - 1, y = -(((cy - r.top) / r.height) * 2 - 1);
    const e = this.eye(), f = norm(sub(this.target, e)), rgt = norm(cross(f, this.upVec())), u = cross(rgt, f);
    const t = Math.tan(0.3), asp = r.width / Math.max(r.height, 1);
    if (this.ortho) {
      const hh = this.dist * t;
      const o = add(add(e, mul(rgt, x * hh * asp)), mul(u, y * hh));
      return { o, d: f };
    }
    return { o: e, d: norm(add(f, add(mul(rgt, x * t * asp), mul(u, y * t)))) };
  }
  pick(cx, cy, id) {
    const o = this.objs.get(id); if (!o) return null;
    const { o: ro, d } = this.ray(cx, cy), p = o.pos, ix = o.indices;
    const nt = ix ? ix.length / 3 : p.length / 9;
    let best = Infinity, bt = -1;
    for (let t = 0; t < nt; t++) {
      let a, b, c;
      if (ix) { a = ix[3 * t] * 3; b = ix[3 * t + 1] * 3; c = ix[3 * t + 2] * 3; } else { a = 9 * t; b = a + 3; c = a + 6; }
      const e1x = p[b] - p[a], e1y = p[b + 1] - p[a + 1], e1z = p[b + 2] - p[a + 2];
      const e2x = p[c] - p[a], e2y = p[c + 1] - p[a + 1], e2z = p[c + 2] - p[a + 2];
      const px = d[1] * e2z - d[2] * e2y, py = d[2] * e2x - d[0] * e2z, pz = d[0] * e2y - d[1] * e2x;
      const det = e1x * px + e1y * py + e1z * pz;
      if (Math.abs(det) < 1e-20) continue;
      const inv = 1 / det, tx = ro[0] - p[a], ty = ro[1] - p[a + 1], tz = ro[2] - p[a + 2];
      const u = (tx * px + ty * py + tz * pz) * inv; if (u < 0 || u > 1) continue;
      const qx = ty * e1z - tz * e1y, qy = tz * e1x - tx * e1z, qz = tx * e1y - ty * e1x;
      const v = (d[0] * qx + d[1] * qy + d[2] * qz) * inv; if (v < 0 || u + v > 1) continue;
      const dist = (e2x * qx + e2y * qy + e2z * qz) * inv;
      if (dist > 0 && dist < best) { best = dist; bt = t; }
    }
    return bt < 0 ? null : { tri: bt, point: add(ro, mul(d, best)) };
  }

  _bindInput() {
    const c = this.canvas; let drag = null;
    c.addEventListener('contextmenu', e => e.preventDefault());
    c.addEventListener('pointerdown', e => {
      c.setPointerCapture(e.pointerId);
      drag = { x: e.clientX, y: e.clientY, b: (e.button === 2 || e.button === 1 || e.shiftKey) ? 'pan' : 'rot', moved: 0 };
    });
    c.addEventListener('pointermove', e => {
      if (!drag) return;
      const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY;
      drag.moved += Math.abs(dx) + Math.abs(dy);
      if (drag.b === 'rot') {
        this.yaw -= dx * 0.008; this.pitch = Math.max(-1.55, Math.min(1.55, this.pitch + dy * 0.008));
      } else {
        const e0 = this.eye(), f = norm(sub(this.target, e0)), r = norm(cross(f, this.upVec())), u = cross(r, f);
        const s = this.dist * Math.tan(0.3) * 2 / c.clientHeight;
        this.target = add(this.target, add(mul(r, -dx * s), mul(u, dy * s)));
      }
      this.redraw();
    });
    c.addEventListener('pointerup', e => {
      const d = drag; drag = null;
      if (d && d.moved < 5 && e.button === 0 && this.onClick) this.onClick(e);
    });
    c.addEventListener('wheel', e => {
      e.preventDefault();
      this.dist *= Math.exp(Math.sign(e.deltaY) * 0.12); this.redraw();
    }, { passive: false });
    c.addEventListener('dblclick', e => {
      for (const id of ['res', 'part']) {
        const h = this.pick(e.clientX, e.clientY, id);
        if (h) { this.target = h.point; this.redraw(); break; }
      }
    });
  }

  _axes() {
    this.axisLabels = ['X', 'Y', 'Z'].map((t, i) => {
      const d = document.createElement('div'); d.className = 'axlbl'; d.textContent = t;
      d.style.color = ['#d33', '#2a2', '#36d'][i]; this.overlay.appendChild(d); return d;
    });
  }

  _drawObj(o, P, V) {
    const gl = this.gl, L = this.loc;
    gl.uniform3fv(L.uColor, o.color); gl.uniform1f(L.uAlpha, o.alpha); gl.uniform1i(L.uMode, o.mode);
    gl.uniform1i(L.uLit, o.lit); gl.uniform1f(L.uMin, o.min); gl.uniform1f(L.uMax, o.max); gl.uniform1i(L.uRev, o.rev ? 1 : 0);
    gl.uniform1f(L.uDisp, o.disp ? this.dispScale : 0);
    const cl = this.clip && o.clip && !this._noClip;
    gl.uniform1i(L.uClipOn, cl ? 1 : 0); if (cl) gl.uniform4fv(L.uClip, this.clip);
    if (o.offset) { gl.enable(gl.POLYGON_OFFSET_FILL); gl.polygonOffset(-o.offset, -o.offset * 2); }
    if (!o.depthTest) gl.disable(gl.DEPTH_TEST);
    gl.bindVertexArray(o.vao);
    const mode = o.lines ? gl.LINES : gl.TRIANGLES;
    if (o.idx) gl.drawElements(mode, o.count, gl.UNSIGNED_INT, 0); else gl.drawArrays(mode, 0, o.count);
    gl.bindVertexArray(null);
    if (o.offset) gl.disable(gl.POLYGON_OFFSET_FILL);
    if (!o.depthTest) gl.enable(gl.DEPTH_TEST);
  }

  _draw() {
    const gl = this.gl, c = this.canvas, dpr = window.devicePixelRatio || 1;
    const w = Math.max(1, Math.round(c.clientWidth * dpr)), h = Math.max(1, Math.round(c.clientHeight * dpr));
    if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    gl.viewport(0, 0, w, h);
    gl.clearColor(...this.bg, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST); gl.useProgram(this.prog);
    gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    const { P, V } = this.matrices();
    gl.uniformMatrix4fv(this.loc.uP, false, P); gl.uniformMatrix4fv(this.loc.uV, false, V);
    const list = [...this.objs.values()].filter(o => o.visible).sort((a, b) => a.order - b.order);
    gl.depthMask(true);
    for (const o of list) if (o.alpha >= 0.999) this._drawObj(o, P, V);
    gl.depthMask(false);
    for (const o of list) if (o.alpha < 0.999) this._drawObj(o, P, V);
    gl.depthMask(true);
    // Achsenkreuz unten links
    const s = Math.round(90 * dpr);
    gl.viewport(0, 0, s, s); gl.clear(gl.DEPTH_BUFFER_BIT);
    const e = norm(sub(this.eye(), this.target)), Va = lookAt(mul(e, 3), [0, 0, 0], this.upVec());
    const Pa = ortho(2.6, 2.6, 0.1, 10);
    gl.uniformMatrix4fv(this.loc.uP, false, Pa); gl.uniformMatrix4fv(this.loc.uV, false, Va);
    if (!this._axObj) {
      this.setLines('__axes_x', [0, 0, 0, 1, 0, 0], [0.85, 0.2, 0.2]);
      this.setLines('__axes_y', [0, 0, 0, 0, 1, 0], [0.15, 0.65, 0.15]);
      this.setLines('__axes_z', [0, 0, 0, 0, 0, 1], [0.2, 0.35, 0.9]);
      this._axObj = ['__axes_x', '__axes_y', '__axes_z'].map(k => { const o = this.objs.get(k); this.objs.delete(k); return o; });
    }
    this._noClip = true; for (const o of this._axObj) this._drawObj(o, Pa, Va); this._noClip = false;
    const proj = v => { // Beschriftung
      const x = Va[0] * v[0] + Va[4] * v[1] + Va[8] * v[2] + Va[12], y = Va[1] * v[0] + Va[5] * v[1] + Va[9] * v[2] + Va[13];
      return [(x / 1.3 * 0.5 + 0.5) * 90, (1 - (y / 1.3 * 0.5 + 0.5)) * 90];
    };
    const ch = c.clientHeight;
    [[1.15, 0, 0], [0, 1.15, 0], [0, 0, 1.15]].forEach((v, i) => {
      const [x, y] = proj(v); const d = this.axisLabels[i];
      d.style.left = (x - 4) + 'px'; d.style.top = (ch - 90 + y - 8) + 'px';
    });
  }
  screenshot() { this._draw(); return this.canvas.toDataURL('image/png'); }
}
