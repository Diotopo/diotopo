# -*- coding: utf-8 -*-
"""Prüft, ob die Grafikkarten genutzt werden können, und vergleicht gemeinsames Rechnen mit nur GPU / nur CPU."""
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from diotopo import engine as E, geom as G, solver as SO  # noqa: E402


def box_model(res):
    L, W, H = 100.0, 20.0, 20.0
    v = np.array([[x, y, z] for x in (0, L) for y in (0, W) for z in (0, H)])
    quads = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    tris = []
    for a, b, c, d in quads:
        tris += [[v[a], v[b], v[c]], [v[a], v[c], v[d]]]
    mesh = G.MeshData(np.array(tris), log=lambda m: None)
    t = mesh.tris
    x0 = [i for i in range(len(t)) if np.allclose(t[i][:, 0], 0)]
    x1 = [i for i in range(len(t)) if np.allclose(t[i][:, 0], L)]
    conds = [dict(type="fixed", tris=x0, dofs=[1, 1, 1]),
             dict(type="load", kind="force", tris=x1, value=1000, dir="z-", case=1)]
    return mesh, conds


def run(method, res, iters):
    mesh, conds = box_model(res)
    M = E.Model(mesh, dict(resolution=res, max_iter=iters, solver=method), conds, log=lambda m: None)
    O = E.Optimizer(M, log=lambda m: None)
    t0 = time.time()
    O.run()
    return time.time() - t0, O.hist[-1], M.solver_info, M.nfree


def main():
    print("Diotopo – GPU test")
    print("==================")
    from diotopo import gpu_ocl as GO
    cu = SO.gpu_status()
    print("CUDA (NVIDIA, CuPy):   " + (cu["device"] if cu["available"] else "not usable – " + cu["reason"]))
    oc = GO.status()
    if oc["available"]:
        kind = "integrated graphics" if oc["unified"] else "dedicated graphics card"
        print(f"OpenCL (all GPUs):    {oc['device']} ({kind}, {oc['memory_gb']:.1f} GB)")
        try:
            import pyopencl as cl
            alle = [d.name.strip() for p in cl.get_platforms() for d in p.get_devices(device_type=cl.device_type.GPU)]
            if len(alle) > 1:
                print("  further graphics cards: " + ", ".join(alle) + "  (selection: environment variable DIOTOPO_OPENCL_DEVICE)")
        except Exception:
            pass
        r = GO.benchmark()
        print(f"  Matrix-vector product: GPU {r:.2g}× as fast as one CPU core")
    else:
        print("OpenCL (all GPUs):     not usable – " + oc["reason"])
    if not cu["available"] and not oc["available"]:
        print("\nFix: update the graphics driver and  py -3 -m pip install pyopencl")
        print("(NVIDIA additionally, optionally faster:  py -3 -m pip install \"cupy-cuda12x[ctk]\")")
        return
    from diotopo import hybrid as HY, par as PR
    parts = HY.gpu_parts()
    print(f"\nCombined computing: CPU ({PR.n_threads()} Threads)"
          + "".join(" + " + p.name for p in parts))
    res = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    print(f"\nTest beam, resolution {res}, 6 iterations – please wait …\n")
    th, ch, ih, n = run("auto", res, 6)
    print(f"Combined:      {th:6.1f} s   ({ih})")
    tg, cg, ig, _ = run("gpu", res, 6)
    print(f"GPU only:{tg:6.1f} s   ({ig})")
    tc, cc, ic, _ = run("mg", res, 6)
    print(f"CPU only:        {tc:6.1f} s   ({ic})")
    print(f"\n{n} unknowns – combined {tc / th:.1f}× as fast as CPU only, {tg / th:.1f}× as fast as GPU only.")
    if th > min(tg, tc) * 1.15:
        print("Note: For small models the data exchange costs more than combined computing gains –"
              " test with a higher resolution (e.g.  py -3 gpu_test.py 160).")
    for name, c in (("GPU", cg), ("CPU", cc)):
        dev = abs(ch - c) / abs(c)
        print(f"Deviation combined/{name}: {dev:.1e} " + ("(ok)" if dev < 1e-4 else "(TOO LARGE – please report)"))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa
        import traceback
        traceback.print_exc()
    if os.name == "nt":
        input("\nPress Enter to close …")
