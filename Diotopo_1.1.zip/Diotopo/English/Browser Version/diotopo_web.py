# -*- coding: utf-8 -*-
"""
Diotopo – Browser Version: startet den Rechenkern als Webserver; die Oberfläche läuft in jedem Browser.

  python diotopo_web.py                 nur auf diesem PC (http://127.0.0.1:8765/), Browser öffnet sich
  python diotopo_web.py --netzwerk      auch von anderen Geräten im Heimnetz erreichbar
  python diotopo_web.py --port 9000     anderer Port
  python diotopo_web.py --kein-browser  Browser nicht automatisch öffnen

Beenden: dieses Fenster schließen oder Strg+C.
"""

import argparse
import os
import socket
import sys
import threading
import time
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.168.0.1", 9))           # es wird nichts gesendet, nur die Route ermittelt
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return socket.gethostbyname(socket.gethostname())


def programmdatei():
    """Für das Startskript: Pfad zu „Diotopo Web.exe“ ausgeben (legt sie bei Bedarf an), sonst nichts.
    Damit erscheint die Browser Version im Task-Manager als „Diotopo Web“ statt als „Python“."""
    try:
        from diotopo import runtime as RT
        exe = RT.ensure(os.path.join(HERE, "icon.ico"), log=lambda m: None, console=True)
        if exe:
            print(exe)
    except Exception:  # noqa
        pass


def main():
    if "--programmdatei" in sys.argv:
        programmdatei()
        return
    try:
        from diotopo import runtime as RT
        if RT.running_as_diotopo():
            RT.add_user_site()
    except Exception:  # noqa
        pass
    ap = argparse.ArgumentParser(description="Diotopo – Browser version")
    ap.add_argument("--netzwerk", "--network", dest="netzwerk", action="store_true", help="also reachable from other devices on the network")
    ap.add_argument("--port", type=int, default=0)
    ap.add_argument("--kein-browser", "--no-browser", dest="kein_browser", action="store_true")
    a = ap.parse_args()
    try:
        import numpy  # noqa: F401
        import scipy  # noqa: F401
    except ImportError:
        print("Python packages are missing. Please first run “Install packages.bat” (Windows) or\n"
              "  python3 -m pip install -r requirements.txt  .")
        input("Press Enter to close …")
        return
    from diotopo.server import make_server, find_port, VERSION
    host = "0.0.0.0" if a.netzwerk else "127.0.0.1"
    port = a.port or find_port()
    srv, port = make_server(port, host=host)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    local = f"http://127.0.0.1:{port}/"
    print(f"\n  Diotopo {VERSION} – Browser version is running.\n")
    print(f"  On this PC:        {local}")
    if a.netzwerk:
        print(f"  In the home network:  http://{lan_ip()}:{port}/")
        print("\n  WARNING: Anyone on the same network can now open Diotopo and start computations.")
        print("  Only use in trusted networks (not on public Wi-Fi).")
        print("  Windows may ask for a firewall permission – allow it for “Private network”.")
    print("\n  Quit: close this window or press Ctrl+C.\n")
    if not a.kein_browser:
        webbrowser.open(local)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    srv.shutdown()


if __name__ == "__main__":
    main()
