#!/bin/sh
# Diotopo (browser version) on Linux/macOS:  ./start.sh   (on the network: ./start.sh --network)
cd "$(dirname "$0")"
exec python3 diotopo_web.py "$@"
