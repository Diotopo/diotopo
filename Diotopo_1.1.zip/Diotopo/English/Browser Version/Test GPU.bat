@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Diotopo - GPU test
py -3 gpu_test.py %* 2>nul || python gpu_test.py %*
