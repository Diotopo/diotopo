@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Diotopo Web - Install packages

set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY goto nopython

echo [1/2] Installing required packages: numpy, scipy ...
%PY% -m pip install --upgrade pip >nul
%PY% -m pip install --only-binary=:all: -r requirements.txt
if errorlevel 1 goto failed
echo [2/2] Optional packages: cadquery-ocp-novtk for STEP (OpenCASCADE), pyopencl for graphics cards ...
for %%P in (cadquery-ocp-novtk pyopencl) do %PY% -m pip install --only-binary=:all: %%P >nul 2>nul || echo    Note: %%P not available - Diotopo still works, just without this additional feature.
echo.
echo Done. Start with "Start Diotopo in browser.bat".
pause
exit /b 0
:failed
echo.
echo Installation failed. Maybe there are no ready-made packages for this Python version yet -
echo in that case install Python 3.13 and start this file again.
pause
exit /b 1

:nopython
echo.
echo Python was not found.
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo and tick "Add python.exe to PATH". Then start this file again.
pause
exit /b 1
