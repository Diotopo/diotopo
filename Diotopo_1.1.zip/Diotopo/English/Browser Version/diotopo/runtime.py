# -*- coding: utf-8 -*-
"""
Eigene Programmdatei „Diotopo.exe“ (Windows), damit Diotopo im Task-Manager als „Diotopo“ mit
dem Dio-Symbol erscheint statt als „Python“.

Vorgehen (einmalig, in %LOCALAPPDATA%\\Diotopo\\programm):
* pythonw.exe des installierten Python wird als Diotopo.exe kopiert, dazu die Python-DLLs.
* pyvenv.cfg daneben verweist auf das installierte Python (Standardbibliothek und Pakete).
* In der Kopie werden Versionsinfo (Name „Diotopo“) und Symbol (icon.ico) ersetzt.
* Probestart: Nur wenn die Kopie numpy und scipy laden kann, wird sie verwendet.
Bei jedem Fehler bleibt alles wie bisher (Start über pythonw.exe).
"""

import ctypes
import os
import shutil
import struct
import subprocess
import sys

EXE_NAME = "Diotopo.exe"
VERSION = (1, 1, 0, 0)


def _dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "Diotopo", "programm")


WEB_EXE_NAME = "Diotopo Web.exe"        # Konsolenvariante für die Browser Version (zeigt die Adresse an)


def exe_path(console=False):
    return os.path.join(_dir(), WEB_EXE_NAME if console else EXE_NAME)


def running_as_diotopo():
    return os.path.basename(sys.executable).lower() in (EXE_NAME.lower(), WEB_EXE_NAME.lower())


# ================================================================ Ressourcen (Versionsinfo, Symbol)

def _pad4(b, start=0):
    return b + b"\0" * ((4 - (start + len(b)) % 4) % 4)


def _node(key, value=b"", vtype=1, children=(), vlen=None):
    """Ein Knoten von VS_VERSIONINFO: Kopf (Länge, Wertlänge, Typ), Schlüssel, Wert, Kinder –
    jeweils auf 4 Byte ausgerichtet. Die Länge zählt die Füllbytes am eigenen Ende nicht mit."""
    b = _pad4((key + "\0").encode("utf-16-le"), 6)
    b += value
    if children:
        b = _pad4(b, 6)
        for c in children:
            b += _pad4(c)
    return struct.pack("<HHH", 6 + len(b), len(value) if vlen is None else vlen, vtype) + b


def _string(name, val):
    return _node(name, (val + "\0").encode("utf-16-le"), 1, vlen=len(val) + 1)


def _holder():
    try:
        from . import rechteinhaber
        return rechteinhaber() or "Diotopo"
    except Exception:  # noqa
        return "Diotopo"


def version_resource(desc="Diotopo", version=VERSION, filename=EXE_NAME):
    ms = (version[0] << 16) | version[1]
    ls = (version[2] << 16) | version[3]
    ffi = struct.pack("<13I", 0xFEEF04BD, 0x00010000, ms, ls, ms, ls, 0x3F, 0, 0x00040004, 1, 0, 0, 0)
    vs = ".".join(str(x) for x in version)
    strings = [_string(k, v) for k, v in (
        ("CompanyName", "Diotopo"), ("FileDescription", desc), ("FileVersion", vs),
        ("InternalName", "Diotopo"), ("OriginalFilename", filename), ("ProductName", "Diotopo"),
        ("ProductVersion", vs), ("LegalCopyright", "© 2026 " + _holder()))]
    table = _node("040704B0", b"", 1, strings)
    sfi = _node("StringFileInfo", b"", 1, [table])
    var = _node("Translation", struct.pack("<HH", 0x0407, 0x04B0), 0)
    vfi = _node("VarFileInfo", b"", 1, [var])
    return _node("VS_VERSION_INFO", ffi, 0, [sfi, vfi])


def icon_resources(ico_path):
    """(Liste der Einzelbilder, Gruppenverzeichnis) aus einer .ico-Datei."""
    data = open(ico_path, "rb").read()
    _, typ, n = struct.unpack_from("<HHH", data, 0)
    if typ != 1 or n == 0:
        raise ValueError("no icon file")
    images, grp = [], struct.pack("<HHH", 0, 1, n)
    for i in range(n):
        w, h, cc, rs, planes, bits, size, off = struct.unpack_from("<BBBBHHII", data, 6 + 16 * i)
        images.append(data[off:off + size])
        grp += struct.pack("<BBBBHHIH", w, h, cc, rs, planes, bits, size, i + 1)
    return images, grp


def _patch_resources(exe, ico, desc="Diotopo"):
    """Versionsinfo und Symbol in exe ersetzen (Windows-API UpdateResource)."""
    from ctypes import wintypes
    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    RT_ICON, RT_GROUP_ICON, RT_VERSION = 3, 14, 16
    k32.LoadLibraryExW.restype = wintypes.HMODULE
    k32.LoadLibraryExW.argtypes = [wintypes.LPCWSTR, wintypes.HANDLE, wintypes.DWORD]
    k32.FreeLibrary.argtypes = [wintypes.HMODULE]
    k32.BeginUpdateResourceW.restype = wintypes.HANDLE
    k32.BeginUpdateResourceW.argtypes = [wintypes.LPCWSTR, wintypes.BOOL]
    k32.UpdateResourceW.restype = wintypes.BOOL
    k32.UpdateResourceW.argtypes = [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, wintypes.WORD,
                                    ctypes.c_void_p, wintypes.DWORD]
    k32.EndUpdateResourceW.restype = wintypes.BOOL
    k32.EndUpdateResourceW.argtypes = [wintypes.HANDLE, wintypes.BOOL]

    # vorhandene Einträge (Name, Sprache) ermitteln, damit sie ersetzt statt ergänzt werden
    NAMEPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HMODULE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p)
    LANGPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HMODULE, ctypes.c_void_p, ctypes.c_void_p,
                                  wintypes.WORD, ctypes.c_void_p)
    k32.EnumResourceNamesW.argtypes = [wintypes.HMODULE, ctypes.c_void_p, NAMEPROC, ctypes.c_void_p]
    k32.EnumResourceLanguagesW.argtypes = [wintypes.HMODULE, ctypes.c_void_p, ctypes.c_void_p, LANGPROC,
                                           ctypes.c_void_p]

    def ident(p):
        return p if p is not None and p < 0x10000 else ctypes.wstring_at(p)

    found = {RT_VERSION: [], RT_GROUP_ICON: []}
    h = k32.LoadLibraryExW(exe, None, 0x02 | 0x20)       # nur als Daten laden
    if h:
        try:
            for rt in found:
                names = []

                @NAMEPROC
                def on_name(hm, t, name, lp, names=names):
                    names.append(ident(name))
                    return True
                k32.EnumResourceNamesW(h, ctypes.c_void_p(rt), on_name, None)
                for nm in names:
                    langs = []

                    @LANGPROC
                    def on_lang(hm, t, n, lang, lp, langs=langs):
                        langs.append(lang)
                        return True
                    nm_p = ctypes.c_void_p(nm) if isinstance(nm, int) else ctypes.c_wchar_p(nm)
                    k32.EnumResourceLanguagesW(h, ctypes.c_void_p(rt), nm_p, on_lang, None)
                    found[rt] += [(nm, lg) for lg in langs]
        finally:
            k32.FreeLibrary(h)

    keep = []

    def rid(x):
        if isinstance(x, int):
            return ctypes.c_void_p(x)
        s = ctypes.c_wchar_p(x)
        keep.append(s)
        return ctypes.cast(s, ctypes.c_void_p)

    hu = k32.BeginUpdateResourceW(exe, False)
    if not hu:
        raise OSError(ctypes.get_last_error(), "BeginUpdateResource")
    ok = True
    try:
        for rt, entries in found.items():                      # alte Versionsinfo/Symbolgruppen entfernen
            for nm, lg in entries:
                k32.UpdateResourceW(hu, ctypes.c_void_p(rt), rid(nm), lg, None, 0)
        ver = version_resource(desc, filename=os.path.basename(exe).replace(".tmp", ""))
        buf = ctypes.create_string_buffer(ver, len(ver))
        ok &= bool(k32.UpdateResourceW(hu, ctypes.c_void_p(RT_VERSION), ctypes.c_void_p(1), 0x0407, buf, len(ver)))
        if ico and os.path.isfile(ico):
            images, grp = icon_resources(ico)
            for i, img in enumerate(images):
                b = ctypes.create_string_buffer(img, len(img))
                keep.append(b)
                ok &= bool(k32.UpdateResourceW(hu, ctypes.c_void_p(RT_ICON), ctypes.c_void_p(i + 1), 0x0407, b,
                                               len(img)))
            g = ctypes.create_string_buffer(grp, len(grp))
            ok &= bool(k32.UpdateResourceW(hu, ctypes.c_void_p(RT_GROUP_ICON), ctypes.c_void_p(1), 0x0407, g,
                                           len(grp)))
    finally:
        if not k32.EndUpdateResourceW(hu, not ok):
            ok = False
    return ok


# ================================================================ Programmdatei anlegen

def _stamp(ico):
    st = [sys.base_prefix, sys.version, str(VERSION)]
    try:
        st.append(str(int(os.path.getmtime(ico))))
    except OSError:
        pass
    return "\n".join(st)


def ensure(ico=None, log=print, console=False):
    """Pfad zu Diotopo.exe (bzw. „Diotopo Web.exe“ mit Konsole) oder None. Legt sie bei Bedarf an."""
    if os.name != "nt" or getattr(sys, "frozen", False):
        return None
    base = sys.base_prefix
    src = os.path.join(base, "python.exe" if console else "pythonw.exe")
    if not os.path.isfile(src) or "windowsapps" in base.lower():   # Store-Python: Kopie nicht möglich
        return None
    d, exe = _dir(), exe_path(console)
    stamp_file = os.path.join(d, ("stand_web.txt" if console else "stand.txt"))
    want = _stamp(ico or "")
    try:
        if os.path.isfile(exe) and open(stamp_file, encoding="utf-8").read() == want:
            return exe
    except OSError:
        pass
    try:
        os.makedirs(d, exist_ok=True)
        tmp = exe[:-4] + ".tmp.exe"
        shutil.copy2(src, tmp)
        for f in os.listdir(base):                     # Python-DLL und Laufzeit neben die Kopie
            fl = f.lower()
            if fl.endswith(".dll") and (fl.startswith("python") or fl.startswith("vcruntime")):
                try:
                    shutil.copy2(os.path.join(base, f), os.path.join(d, f))
                except OSError:
                    pass                               # wird evtl. gerade von der anderen Variante benutzt
        with open(os.path.join(d, "pyvenv.cfg"), "w", encoding="utf-8") as f:
            f.write(f"home = {base}\ninclude-system-site-packages = true\n"
                    f"version = {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}\n")
        try:
            _patch_resources(tmp, ico, "Diotopo Web" if console else "Diotopo")
        except Exception as e:  # noqa – Name/Symbol sind Kür, die Kopie funktioniert trotzdem
            log(f"Note: Program name/icon could not be set ({type(e).__name__}: {e})")
        os.replace(tmp, exe)
        # Probestart: findet die Kopie Python und die Pakete?
        test = ("import sys, site, os; v=sys.version_info; "
                "p=os.path.join(os.environ.get('APPDATA',''),'Python',f'Python{v.major}{v.minor}','site-packages'); "
                "os.path.isdir(p) and site.addsitedir(p); import numpy, scipy")
        r = subprocess.run([exe, "-c", test], capture_output=True, timeout=120,
                           creationflags=0x08000000)
        if r.returncode != 0:
            log(f"Note: own program file {os.path.basename(exe)} does not start – using Python directly")
            return None
        with open(stamp_file, "w", encoding="utf-8") as f:
            f.write(want)
        return exe
    except Exception as e:  # noqa
        log(f"Note: {os.path.basename(exe)} could not be created ({type(e).__name__}: {e})")
        return None


def add_user_site():
    """In der eigenen Programmdatei (venv-Modus) sind per „pip --user“ installierte Pakete sonst unsichtbar."""
    try:
        import site
        v = sys.version_info
        p = os.path.join(os.environ.get("APPDATA", ""), "Python", f"Python{v.major}{v.minor}", "site-packages")
        if os.path.isdir(p) and p not in sys.path:
            site.addsitedir(p)
    except Exception:  # noqa
        pass
