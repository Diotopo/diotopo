# -*- coding: utf-8 -*-
"""
3D-Druck: Anisotropie, Schichthaftung, Randschichten und Infill.

* Werkstoff transversal isotrop: in der Schichtebene E (= E_xy), in Aufbaurichtung E_z,
  Schubmodul zwischen den Schichten G_z = E_z / (2 (1 + ν)).
* Schichthaftung: Zug quer zu den Schichten und Schub in der Schichtfuge,
  Versagenskriterium  f = (⟨σ_n⟩ / S_z)² + (τ / S_s)²,  Ausnutzung u = √f, Sicherheit 1 / u.
* Randschichten (3D-Druck Erweitert): Anteil s je Element, der in der Wand, im Boden oder im Deckel
  liegt (massiv gedruckt). Der Rest ist Infill mit eigener (homogenisierter) Steifigkeit.
  s ist eine glatte Funktion der Nachbardichten → in der Optimierung differenzierbar.
* Infill-Steifigkeit je Muster: Richtwerte nach Gibson/Ashby bzw. Überlagerung der
  Wandscharen (Voigt), am Ende überblendet zum Vollmaterial bei 100 % Füllung.

Voigt-Reihenfolge wie im Element (engine._B): xx, yy, zz, xy, yz, zx (Ingenieur-Schiebungen).
"""

import math

import numpy as np

AM_KINDS = ("am", "am_adv")
# Index der Schubkomponenten, die die Achse a enthalten (xy=3, yz=4, zx=5)
SHEAR_WITH = {0: (3, 5), 1: (3, 4), 2: (4, 5)}
_PAIR = [(0, 0), (1, 1), (2, 2), (0, 1), (1, 2), (2, 0)]

PATTERNS = {
    # Schlüssel: (Anzeigename, Wandscharen κ für die Spannungsabschätzung)
    "grid": ("Grid", 2.0),
    "lines": ("Lines", 2.0),
    "triangles": ("Triangles", 3.0),
    "cubic": ("Cubic", 3.0),
    "gyroid": ("Gyroid", 2.0),
    "honeycomb": ("Honeycomb", 3.0),
}
LINE_W_MM = 0.45          # Linienbreite des Infills (nur für Anzeige und Musterabstand)


def is_am(S):
    return S.get("mfg") in AM_KINDS


# ================================================================ Tensoren

def voigt_to_c4(C):
    C4 = np.zeros((3, 3, 3, 3))
    for I, (i, j) in enumerate(_PAIR):
        for J, (k, l) in enumerate(_PAIR):
            v = C[I, J]
            for a, b in ((i, j), (j, i)):
                for c, d in ((k, l), (l, k)):
                    C4[a, b, c, d] = v
    return C4


def c4_to_voigt(C4):
    C = np.zeros((6, 6))
    for I, (i, j) in enumerate(_PAIR):
        for J, (k, l) in enumerate(_PAIR):
            C[I, J] = C4[i, j, k, l]
    return C


def rotate(C, Q):
    """Steifigkeit (Voigt) in ein gedrehtes System: x' = Q x."""
    C4 = voigt_to_c4(C)
    return c4_to_voigt(np.einsum("ia,jb,kc,ld,abcd->ijkl", Q, Q, Q, Q, C4, optimize=True))


def local_to_global(axis):
    """Lokales System (3 = Aufbaurichtung) → global (Aufbauachse = axis). Liefert Q mit x_g = Q x_l."""
    others = [a for a in range(3) if a != axis]
    Q = np.zeros((3, 3))
    Q[others[0], 0] = 1.0
    Q[others[1], 1] = 1.0
    Q[axis, 2] = 1.0
    return Q


def ortho_C(Ex, Ey, Ez, nxy, nxz, nyz, Gxy, Gyz, Gzx):
    """Orthotrope Steifigkeit aus Ingenieurkonstanten (ν_ij = −ε_j/ε_i bei Zug in i)."""
    S = np.zeros((6, 6))
    S[0, 0], S[1, 1], S[2, 2] = 1 / Ex, 1 / Ey, 1 / Ez
    S[0, 1] = S[1, 0] = -nxy / Ex
    S[0, 2] = S[2, 0] = -nxz / Ex
    S[1, 2] = S[2, 1] = -nyz / Ey
    S[3, 3], S[4, 4], S[5, 5] = 1 / Gxy, 1 / Gyz, 1 / Gzx
    return np.linalg.inv(S)


def solid_local(ez_ratio, nu, gz_ratio=None):
    """Vollmaterial lokal (normiert auf E_xy = 1), transversal isotrop um die Aufbauachse.
    gz_ratio: Schubmodul zwischen den Schichten relativ zu E_xy/(2(1+ν)) (Standard: wie E_z)."""
    E1, E3 = 1.0, float(ez_ratio)
    S = np.zeros((6, 6))
    S[0, 0] = S[1, 1] = 1 / E1
    S[2, 2] = 1 / E3
    S[0, 1] = S[1, 0] = -nu / E1
    S[0, 2] = S[2, 0] = S[1, 2] = S[2, 1] = -nu / math.sqrt(E1 * E3)
    S[3, 3] = 2 * (1 + nu) / E1
    S[4, 4] = S[5, 5] = 2 * (1 + nu) / (E3 if gz_ratio is None else float(gz_ratio))
    return np.linalg.inv(S)


def material_matrix(S):
    """Normierte Werkstoffmatrix D (global, E_xy = 1) für die Einstellungen S."""
    from .engine import material_D
    nu = float(S["nu"])
    if not is_am(S):
        return material_D(nu)
    r = ez_ratio(S)
    if abs(r - 1.0) < 1e-9:
        return material_D(nu)
    axis = "xyz".index(S.get("mfg_dir", "z+")[0])
    return rotate(solid_local(r, nu), local_to_global(axis))


def design_matrix(S):
    """Werkstoffmatrix für die Optimierung mit Schichthaftung: quer zu den Schichten zählt die Steifigkeit
    höchstens im Verhältnis (Haftfestigkeit / Festigkeit in der Schichtebene)². Dann entspricht minimale
    Nachgiebigkeit näherungsweise minimaler quadratischer Ausnutzung (σ²/E ~ (σ/S)²): Lastpfade quer zu
    schwach haftenden Schichten werden gemieden. Reine Steifigkeitsoptimierung – keine Spannungs-
    Nebenbedingung, die tragende Streben auflösen könnte. Liefert None, wenn nichts zu ändern ist."""
    if not is_am(S):
        return None
    nu = float(S["nu"])
    y = float(S.get("yield_") or 0)
    if y <= 0:
        return None
    st, ss = strengths(S)
    rz = ez_ratio(S)
    rn = min(rz, (st / y) ** 2)
    rs = min(rz, (ss / (y / math.sqrt(3))) ** 2)
    if rn >= rz - 1e-9 and rs >= rz - 1e-9:
        return None
    axis = "xyz".index(S.get("mfg_dir", "z+")[0])
    return rotate(solid_local(max(rn, 0.02), nu, max(rs, 0.02)), local_to_global(axis))


def ez_ratio(S):
    E = float(S["E"])
    ez = float(S.get("E_z") or 0) or E
    return min(max(ez / E, 0.02), 1.0 / 0.02)


def strengths(S):
    """(Zugfestigkeit quer zu den Schichten, Schubfestigkeit in der Schichtfuge) in MPa."""
    y = float(S.get("yield_") or 0) or 1.0
    st = float(S.get("S_z") or 0) or y
    ss = float(S.get("S_zs") or 0) or st
    return max(st, 1e-6), max(ss, 1e-6)


# ================================================================ Infill

def infill_local(pattern, phi, ez_ratio_, nu):
    """Homogenisierte Steifigkeit des Infills (lokal, 3 = Aufbaurichtung, normiert auf E_xy = 1)."""
    phi = float(min(max(phi, 0.0), 1.0))
    E1, E3 = 1.0, float(ez_ratio_)
    G13 = E3 / (2 * (1 + nu))
    Cs = solid_local(E3, nu)
    if phi >= 0.999:
        return Cs
    f = max(phi, 0.01)
    small = 0.03                     # schwache Querkopplung bei Wandscharen
    if pattern == "grid":            # zwei senkrechte Wandscharen, durchgehend in Z
        C = ortho_C(f / 2 * E1, f / 2 * E1, f * E3, small, small, small,
                    f ** 3 / 32 * E1, f / 2 * G13, f / 2 * G13)
    elif pattern == "lines":         # Linien, Richtung wechselt je Schicht: Z nur über Kreuzungspunkte
        C = ortho_C(f / 2 * E1, f / 2 * E1, f ** 2 * E3, small, small, small,
                    f ** 3 / 32 * E1, f ** 2 / 2 * G13, f ** 2 / 2 * G13)
    elif pattern == "triangles":     # drei Wandscharen 0/60/120°: in der Ebene isotrop, dehnungsdominiert
        Ein = f / 3 * E1
        C = ortho_C(Ein, Ein, f * E3, 1 / 3, small, small, Ein / (2 * (1 + 1 / 3)), f / 2 * G13, f / 2 * G13)
    elif pattern == "honeycomb":     # Waben: in der Ebene biegedominiert (Gibson/Ashby), in Z Wände
        Ein = 1.5 * f ** 3 * E1
        C = ortho_C(Ein, Ein, f * E3, 0.8, small, small, Ein / (2 * 1.8), f / 2 * G13, f / 2 * G13)
    elif pattern == "cubic":         # drei Plattenscharen eines auf der Spitze stehenden Würfels
        Eb = (2 * E1 + E3) / 3
        Gb = Eb / (2 * (1 + nu))
        fp = f / 3
        k = Eb / (1 - nu ** 2)
        Cc = np.zeros((6, 6))
        Cc[0, 0] = Cc[1, 1] = Cc[2, 2] = 2 * fp * k
        Cc[0, 1] = Cc[1, 0] = Cc[0, 2] = Cc[2, 0] = Cc[1, 2] = Cc[2, 1] = fp * k * nu
        Cc[3, 3] = Cc[4, 4] = Cc[5, 5] = fp * Gb
        Cc += np.eye(6) * 1e-4 * f * Eb
        r2, r3, r6 = math.sqrt(2), math.sqrt(3), math.sqrt(6)
        Q = np.array([[1 / r2, -1 / r2, 0], [1 / r6, 1 / r6, -2 / r6], [1 / r3, 1 / r3, 1 / r3]])
        C = rotate(Cc, Q)
    else:                            # gyroid: nahezu isotrop
        Eb = (2 * E1 + E3) / 3
        Eg = 0.4 * f ** 1.4 * Eb
        C = ortho_C(Eg, Eg, Eg, 0.3, 0.3, 0.3, Eg / 2.6, Eg / 2.6, Eg / 2.6)
    w = phi ** 3                     # bei 100 % Füllung → Vollmaterial
    return (1 - w) * C + w * Cs


def infill_matrix(S):
    axis = "xyz".index(S.get("mfg_dir", "z+")[0])
    C = infill_local(S.get("infill_pattern", "grid"), float(S.get("infill_pct", 20)) / 100.0,
                     ez_ratio(S), float(S["nu"]))
    return rotate(C, local_to_global(axis))


def infill_moduli(S):
    """E in Schichtebene und Aufbaurichtung des Infills [MPa] (für Hinweise)."""
    C = infill_local(S.get("infill_pattern", "grid"), float(S.get("infill_pct", 20)) / 100.0,
                     ez_ratio(S), float(S["nu"]))
    Sm = np.linalg.inv(C)
    return float(S["E"]) / Sm[0, 0], float(S["E"]) / Sm[2, 2]


def pattern_kappa(S):
    return PATTERNS.get(S.get("infill_pattern", "grid"), PATTERNS["grid"])[1]


# ================================================================ Randschichten

class ShellMap:
    """Anteil s ∈ [0, 1] jedes Elements, der in einer Randschicht liegt.

    Für jede Richtung d (oben, unten, 4 × seitlich) und jeden Abstand k = 1 … ⌈t_d⌉ (in Voxeln):
    liegt der Nachbar e + k·d im Leeren (Leere v = 1 − x), gehört der Elementanteil
    c_k = clip(t_d − (k − 1), 0, 1) zur Randschicht. Verknüpft wird wie eine Wahrscheinlichkeit:
        s = 1 − Π_j (1 − c_j · v_j)
    Nachbarn außerhalb des Bauraums sind leer. Ableitung exakt über die Produktregel."""
    KMAX = 6

    def __init__(self, ei, ej, ek, shape, emap, axis, sign, t_top, t_bot, t_wall):
        self.pairs = []                       # (Nachbarindex je Element, c)
        dirs = []
        up = np.zeros(3, dtype=int)
        up[axis] = 1 if sign > 0 else -1
        dirs.append((up, t_top))
        dirs.append((-up, t_bot))
        for a in range(3):
            if a != axis:
                for s in (1, -1):
                    d = np.zeros(3, dtype=int)
                    d[a] = s
                    dirs.append((d, t_wall))
        sh = np.array(shape)
        self.clipped = False
        for d, t in dirs:
            t = max(float(t), 0.0)
            if t > self.KMAX:
                t = float(self.KMAX)
                self.clipped = True
            for k in range(1, int(math.ceil(t - 1e-9)) + 1):
                c = min(max(t - (k - 1), 0.0), 1.0)
                if c <= 1e-6:
                    continue
                p = np.stack([ei, ej, ek], 1) + k * d
                ok = np.all((p >= 0) & (p < sh), axis=1)
                nb = np.full(len(ei), -1, dtype=np.int64)
                nb[ok] = emap[p[ok, 0], p[ok, 1], p[ok, 2]]
                self.pairs.append((nb.astype(np.int32), float(c)))
        self.ne = len(ei)

    def forward(self, xp):
        xp = np.asarray(xp, dtype=np.float64)
        Q = np.ones(self.ne)
        qs = []
        for nb, c in self.pairs:
            v = np.ones(self.ne)
            m = nb >= 0
            v[m] = 1.0 - np.clip(xp[nb[m]], 0.0, 1.0)
            q = 1.0 - c * v
            qs.append(q.astype(np.float32))
            Q *= q
        return 1.0 - Q, (Q, qs)

    def backward(self, gs, cache):
        """gs = ∂L/∂s je Element → ∂L/∂x."""
        Q, qs = cache
        gx = np.zeros(self.ne)
        for (nb, c), q in zip(self.pairs, qs):
            m = nb >= 0
            if not m.any():
                continue
            w = -c * Q[m] / np.maximum(q[m].astype(np.float64), 1e-9) * gs[m]
            gx += np.bincount(nb[m], weights=w, minlength=self.ne)
        return gx


# ================================================================ Schichthaftung

def layer_util(sig, axis, St, Ss, grad=False):
    """Ausnutzung u der Schichthaftung je Zeile von sig (n × 6, MPa). grad: ∂u/∂σ (n × 6)."""
    a1, a2 = SHEAR_WITH[axis]
    sn = sig[:, axis]
    eps = 1e-6 * St
    rt = np.sqrt(sn * sn + eps * eps)
    smac = 0.5 * (sn + rt)
    f = (smac / St) ** 2 + (sig[:, a1] ** 2 + sig[:, a2] ** 2) / Ss ** 2
    u = np.sqrt(f)
    if not grad:
        return u
    G = np.zeros_like(sig)
    inv = 1.0 / np.maximum(u, 1e-30)
    G[:, axis] = smac / St ** 2 * 0.5 * (1 + sn / rt) * inv
    G[:, a1] = sig[:, a1] / Ss ** 2 * inv
    G[:, a2] = sig[:, a2] / Ss ** 2 * inv
    return u, G


def von_mises(sig):
    sx, sy, sz, txy, tyz, tzx = sig.T
    return np.sqrt(0.5 * ((sx - sy) ** 2 + (sy - sz) ** 2 + (sz - sx) ** 2) + 3 * (txy ** 2 + tyz ** 2 + tzx ** 2))


# ================================================================ Anzeige: Wände & Infill

def _pattern_dist(pattern, P, phi, w):
    """Abstand [mm] zur Mittelfläche der nächsten Infill-Wand. P: Punkte (n × 3, mm, lokal; z = Aufbau)."""
    phi = max(phi, 0.02)
    x, y, z = P[:, 0], P[:, 1], P[:, 2]

    def fam(t, s):
        return np.abs(t - s * np.round(t / s))

    if pattern == "grid":
        s = 2 * w / phi
        return np.minimum(fam(x, s), fam(y, s))
    if pattern == "lines":
        s = w / phi
        lay = np.floor(z / (2.0 * w)).astype(int) % 2
        return np.where(lay == 0, fam(x, s), fam(y, s))
    if pattern == "triangles":
        s = 3 * w / phi
        d = None
        for a in (0.0, math.pi / 3, 2 * math.pi / 3):
            t = fam(x * math.cos(a) + y * math.sin(a), s)
            d = t if d is None else np.minimum(d, t)
        return d
    if pattern == "cubic":
        s = 3 * w / phi
        r2, r3, r6 = math.sqrt(2), math.sqrt(3), math.sqrt(6)
        Q = np.array([[1 / r2, -1 / r2, 0], [1 / r6, 1 / r6, -2 / r6], [1 / r3, 1 / r3, 1 / r3]])
        d = None
        for k in range(3):
            t = fam(P @ Q[:, k], s)                   # Würfelachse k im lokalen System
            d = t if d is None else np.minimum(d, t)
        return d
    if pattern == "honeycomb":
        a = 2 * w / (math.sqrt(3) * phi)              # Sechseckseite
        D = math.sqrt(3) * a                          # Abstand der Zellmitten
        b1 = np.array([D, 0.0])
        b2 = np.array([D / 2, D * math.sqrt(3) / 2])
        Binv = np.linalg.inv(np.stack([b1, b2], 1))
        q = np.stack([x, y], 1) @ Binv.T
        base = np.floor(q)
        best1 = np.full(len(x), np.inf)
        best2 = np.full(len(x), np.inf)
        c1 = np.zeros((len(x), 2))
        c2 = np.zeros((len(x), 2))
        for i in (-1, 0, 1, 2):
            for j in (-1, 0, 1, 2):
                c = (base + [i, j]) @ np.stack([b1, b2], 0)
                dd = (x - c[:, 0]) ** 2 + (y - c[:, 1]) ** 2
                m1 = dd < best1
                m2 = ~m1 & (dd < best2)
                best2 = np.where(m1, best1, np.where(m2, dd, best2))
                c2 = np.where(m1[:, None], c1, np.where(m2[:, None], c, c2))
                best1 = np.where(m1, dd, best1)
                c1 = np.where(m1[:, None], c, c1)
        L = np.maximum(np.linalg.norm(c2 - c1, axis=1), 1e-9)
        return (best2 - best1) / (2 * L)
    # Gyroid
    per = 3.1 * w / phi
    k = 2 * math.pi / per
    g = np.sin(k * x) * np.cos(k * y) + np.sin(k * y) * np.cos(k * z) + np.sin(k * z) * np.cos(k * x)
    return np.abs(g) / (1.25 * k)


def walls_infill(field, S, scale, max_tris=1_200_000, log=print):
    """Aus dem feinen Ergebnisfeld: Volumen der Randschichten und des Infill-Kerns [mm³] und ein
    (schematisches) Netz des Infill-Musters im Kern. field = (Feld > 0 innen, lo, h)."""
    from scipy.ndimage import distance_transform_edt, map_coordinates
    from .isosurface import marching_cubes
    final, lo, hf = field
    inside = final > 0
    axis = "xyz".index(S.get("mfg_dir", "z+")[0])
    sign = 1 if S.get("mfg_dir", "z+")[1] == "+" else -1
    hmm = hf * scale
    tw = float(S.get("shell_wall_mm") or 0)
    tt = float(S.get("shell_top_mm") or 0)
    tb = float(S.get("shell_bottom_mm") or 0)
    samp = [1.0, 1.0, 1.0]
    samp[axis] = 1e6                                 # nur seitlich (in der Schicht) messen
    core = inside & (distance_transform_edt(inside, sampling=samp) * hmm > tw)
    for t, d in ((tt, sign), (tb, -sign)):
        k = int(math.ceil(t / hmm - 1e-9))
        for j in range(1, k + 1):
            sh = np.zeros_like(inside)
            src = [slice(None)] * 3
            dst = [slice(None)] * 3
            if d > 0:
                src[axis], dst[axis] = slice(j, None), slice(None, -j)
            else:
                src[axis], dst[axis] = slice(None, -j), slice(j, None)
            sh[tuple(dst)] = inside[tuple(src)]
            core &= sh
    v_in = float(inside.sum()) * hmm ** 3
    v_core = float(core.sum()) * hmm ** 3
    out = dict(v_shell=v_in - v_core, v_core=v_core, verts=None, faces=None)
    if v_core <= 0:
        return out
    # Muster auf gröberem Raster (Anzeige)
    phi = max(float(S.get("infill_pct", 20)) / 100.0, 0.02)
    w = LINE_W_MM
    pat = S.get("infill_pattern", "grid")
    fam = {"grid": 2, "lines": 1, "triangles": 3, "cubic": 3, "honeycomb": 1.5, "gyroid": 1.6}.get(pat, 2)
    spacing = {"grid": 2 * w / phi, "lines": w / phi, "triangles": 3 * w / phi, "cubic": 3 * w / phi,
               "honeycomb": 2 * w / (math.sqrt(3) * phi), "gyroid": 3.1 * w / phi}.get(pat, 2 * w / phi)
    area = 2.0 * fam * v_core / max(spacing, 1e-6)
    hd = max(hmm, spacing / 6.0, math.sqrt(2.0 * area / max_tris), (v_core / 6e6) ** (1 / 3))
    f = hd / hmm
    shp = tuple(max(2, int(math.ceil(n / f))) for n in core.shape)
    idx = [np.minimum((np.arange(n) + 0.5) * f, core.shape[a] - 1) for a, n in enumerate(shp)]
    cg = core[np.ix_(*[np.round(i).astype(int) for i in idx])]
    if not cg.any():
        return out
    # Kernfläche (Innenseite der Randschichten) – für die Schnittansicht
    from scipy.ndimage import gaussian_filter
    Fc = np.pad(gaussian_filter(cg.astype(np.float32), 0.6) - 0.5, 1, constant_values=-0.5)
    if Fc.max() > 0:
        cv, cf, _, _ = marching_cubes(Fc, 0.0, spacing=(hd, hd, hd))
        cv = cv - hd + lo * scale + 0.5 * hmm
        out["core_v"] = (cv / scale).astype(np.float32)
        out["core_f"] = cf.astype(np.uint32)
    pts = np.stack(np.meshgrid(*[lo[a] * scale + (idx[a] + 0.5) * hmm for a in range(3)], indexing="ij"), -1)
    others = [a for a in range(3) if a != axis]
    loc = np.stack([pts[..., others[0]], pts[..., others[1]], pts[..., axis] * sign], -1).reshape(-1, 3)
    sel = cg.ravel()
    d = np.full(loc.shape[0], 1e9)
    d[sel] = _pattern_dist(pat, loc[sel], phi, w)
    td = max(w, 1.2 * hd)
    F = np.where(cg.ravel(), 0.5 * td - d, -hd).reshape(cg.shape).astype(np.float32)
    F = np.pad(F, 1, constant_values=-hd)
    if F.max() <= 0:
        return out
    v, fc, _, _ = marching_cubes(F, 0.0, spacing=(hd, hd, hd))
    v = v - hd + lo * scale + 0.5 * hmm              # mm
    out["verts"] = (v / scale).astype(np.float32)
    out["faces"] = fc.astype(np.uint32)
    out["display_mm"] = td
    return out
