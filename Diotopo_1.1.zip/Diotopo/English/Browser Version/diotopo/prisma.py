# -*- coding: utf-8 -*-
"""
Fräsen prismatisch (2,5D): Ergebnis aus Tiefenstufen mit ebenen Böden und senkrechten Wänden.

Ablauf
  1. Je Tiefenstufe (Band entlang der Werkzeugachse) ein 2D-Dichtefeld aus der Optimierung,
     geglättet und auf ein feines Raster übertragen → Materialmaske je Stufe.
  2. Fertigungsregeln auf dem Raster: Zugang des Werkzeugs (keine Hinterschnitte), kleinster Fräser
     (morphologisches Schließen mit dem Fräserradius), nur innerhalb des Bauteils (Bohrungen in
     Werkzeugrichtung bleiben erhalten), keine Berührung nur an Kanten/Ecken (sonst nicht-mannigfaltig).
  3. Ränder der Masken als gemeinsamer ebener Graph: jede Kante wird genau einmal geglättet und
     vereinfacht, deshalb passen Wände und Böden exakt aneinander (wasserdicht).
  4. Flächenmodell aus ebenen Flächen (Wände je Kantenabschnitt, Böden/Deckel mit Löchern) →
     Dreiecksnetz (STL/3MF/OBJ), STEP (AP214, Volumenkörper aus ebenen Flächen) und DXF (Konturen je Stufe).
"""

import math

import numpy as np
from scipy.ndimage import distance_transform_edt, gaussian_filter, label, map_coordinates

from . import geom as G

_S4 = np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)


# ================================================================ Masken

def _closing(m, r):
    """Morphologisches Schließen mit einer Kreisscheibe vom Radius r (Rasterzellen)."""
    if r < 0.5 or not m.any():
        return m
    p = int(math.ceil(r)) + 2
    mp = np.pad(m, p)
    dil = distance_transform_edt(~mp) <= r
    clo = distance_transform_edt(dil) > r
    return clo[p:-p, p:-p] | m


def _crit2d(m):
    """2×2-Felder mit diagonalem Kontakt (in der Ebene). Liefert eine zu füllende Zellmaske."""
    a, b, c, d = m[:-1, :-1], m[1:, :-1], m[:-1, 1:], m[1:, 1:]
    diag = a & d & ~b & ~c
    anti = b & c & ~a & ~d
    fill = np.zeros_like(m)
    fill[1:, :-1] |= diag          # b füllen
    fill[:-1, :-1] |= anti         # a füllen
    return fill


def _crit_vertical(ms):
    """Kanten-/Eckkontakte zwischen benachbarten Stufen (nur bei 2 Aufspannungen möglich)."""
    n = len(ms)
    fills = [np.zeros_like(ms[0]) for _ in range(n)]
    for k in range(n - 1):
        lo, hi = ms[k], ms[k + 1]
        for ax in (0, 1):
            sl0 = (slice(None, -1), slice(None)) if ax == 0 else (slice(None), slice(None, -1))
            sl1 = (slice(1, None), slice(None)) if ax == 0 else (slice(None), slice(1, None))
            # (i,k) und (i+1,k+1) belegt, (i+1,k) und (i,k+1) leer – bzw. gespiegelt
            c1 = lo[sl0] & hi[sl1] & ~lo[sl1] & ~hi[sl0]
            c2 = lo[sl1] & hi[sl0] & ~lo[sl0] & ~hi[sl1]
            f = fills[k]
            f[sl1] |= c1
            f[sl0] |= c2
        # Eckkontakt über die Raumdiagonale (2×2×2): nur zwei gegenüberliegende Zellen belegt bzw. leer
        win = [(slice(None, -1), slice(None, -1)), (slice(1, None), slice(None, -1)),
               (slice(None, -1), slice(1, None)), (slice(1, None), slice(1, None))]
        Aw = [lo[w] for w in win]
        Bw = [hi[w] for w in win]
        cnt = sum(x.astype(np.int8) for x in Aw + Bw)
        for i in range(4):
            j = 3 - i                               # gegenüberliegende Ecke im oberen Band
            only = Aw[i] & Bw[j] & (cnt == 2)
            hole = ~Aw[i] & ~Bw[j] & (cnt == 6)
            fills[k][win[j]] |= only                # Zelle unter der oberen Ecke füllen
            fills[k][win[i]] |= hole
    return fills


def _opening(m, r):
    if r < 0.5 or not m.any():
        return m
    p = int(math.ceil(r)) + 2
    mp = np.pad(m, p)
    ero = distance_transform_edt(mp) > r
    return (distance_transform_edt(~ero) <= r)[p:-p, p:-p] & m


def _thin_parts(region, r):
    """Zusammenhängende Teile, in die keine Kreisscheibe vom Radius r passt (durchgehend schmal)."""
    if not region.any():
        return region
    lab, n = label(region, structure=_S4)
    wide = np.zeros(n + 1, dtype=bool)
    wide[np.unique(lab[_opening(region, r)])] = True
    wide[0] = True
    return ~wide[lab]


def _merge_thin_steps(m, part, r, order, two_setups):
    """Absätze zwischen zwei Stufen, die durchgehend schmaler als ≈ 2r sind, zur Wand zusammenlegen."""
    if r < 0.5:
        return m
    for a, b in zip(order[:-1], order[1:]):          # (Grund-seitig, Werkzeug-seitig)
        m[b] = m[b] | (_thin_parts(m[a] & ~m[b], r) & part[b])
        if two_setups:
            m[a] = m[a] | (_thin_parts(m[b] & ~m[a], r) & part[a])
    return m


def _drop_specks(m, order, min_cells, two_setups):
    """Kleinstinseln (Material und Löcher) unter min_cells Rasterzellen entfernen bzw. füllen."""
    if min_cells < 2:
        return m
    seq = order[::-1] if not two_setups else order
    for k in seq:                                     # vom Werkzeug zum Grund (Teilmengen zuerst)
        lab, n = label(m[k], structure=_S4)
        if n:
            sz = np.bincount(lab.ravel())
            small = sz < min_cells
            small[0] = False
            m[k] = m[k] & ~small[lab]
        lab, n = label(~m[k], structure=_S4)
        if n:
            sz = np.bincount(lab.ravel())
            small = sz < min_cells
            small[0] = False
            border = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
            small[border] = False                     # Bereiche am Rand sind kein Loch
            m[k] = m[k] | small[lab]
    if not two_setups:
        for a, b in zip(order[:-1], order[1:]):
            m[b] = m[b] & m[a]
    return m


def make_masks(raw, part, tool_r, from_plus, two_setups, passive=None, step_r=0.0, min_cells=0):
    """Fertigungsgerechte Masken je Stufe (Liste von bool-Feldern, Index 0 = kleinste Koordinate)."""
    n = len(raw)
    order = list(range(n)) if from_plus else list(range(n - 1, -1, -1))   # vom Grund zum Werkzeug
    m = [r.copy() for r in raw]
    if passive is not None:
        for k in range(n):
            m[k] |= passive[k]

    def access(ms):
        if two_setups:
            st = np.stack(ms)
            below = np.maximum.accumulate(st, axis=0)
            above = np.maximum.accumulate(st[::-1], axis=0)[::-1]
            st = below & above                      # Säule ohne Lücke: von oben und von unten erreichbar
            return [st[k] for k in range(n)]
        for a, b in zip(order[::-1][1:], order[::-1][:-1]):   # Material oben → darunter auch Material
            ms[a] = ms[a] | ms[b]
        return ms

    m = access(m)
    m = [_closing(x, tool_r) for x in m]
    m = [x & p for x, p in zip(m, part)]
    if not two_setups:                              # Überhänge des Bauteils selbst: oben entfernen
        for a, b in zip(order[:-1], order[1:]):
            m[b] = m[b] & m[a]
    m = _merge_thin_steps(m, part, step_r, order, two_setups)
    m = _drop_specks(m, order, min_cells, two_setups)
    m = [x & p for x, p in zip(m, part)]
    if two_setups:
        m = access(m)
        m = [x & p for x, p in zip(m, part)]
    for _ in range(30):
        changed = False
        for k in range(n):
            f = _crit2d(m[k]) & part[k]
            if f.any():
                changed = True
                m[k] |= f
                if not two_setups:                  # gefüllte Zelle auch in allen Stufen darunter
                    i = order.index(k)
                    for kk in order[:i]:
                        m[kk] |= f & part[kk]
        if two_setups:
            fv = _crit_vertical(m)
            for k in range(n):
                f = fv[k] & part[k]
                if f.any():
                    changed = True
                    m[k] |= f
            m = access(m)
            m = [x & p for x, p in zip(m, part)]
        if not changed:
            break
    return m


# ================================================================ Ränder → Schleifen

def boundary_edges(m):
    """Gerichtete Randkanten (Material links) einer Maske: (start, ende, zelle_i, zelle_j) als Gitterpunkte."""
    nu, nv = m.shape
    p = np.pad(m, 1)
    c = p[1:-1, 1:-1]
    out = []
    # unten: Nachbar (i, j-1) leer → (i,j)→(i+1,j)
    I, J = np.nonzero(c & ~p[1:-1, :-2])
    out.append((I, J, I + 1, J, I, J))
    I, J = np.nonzero(c & ~p[2:, 1:-1])           # rechts → (i+1,j)→(i+1,j+1)
    out.append((I + 1, J, I + 1, J + 1, I, J))
    I, J = np.nonzero(c & ~p[1:-1, 2:])           # oben → (i+1,j+1)→(i,j+1)
    out.append((I + 1, J + 1, I, J + 1, I, J))
    I, J = np.nonzero(c & ~p[:-2, 1:-1])          # links → (i,j+1)→(i,j)
    out.append((I, J + 1, I, J, I, J))
    W = nv + 1
    a = np.concatenate([o[0] * W + o[1] for o in out]).astype(np.int64)
    b = np.concatenate([o[2] * W + o[3] for o in out]).astype(np.int64)
    ci = np.concatenate([o[4] for o in out])
    cj = np.concatenate([o[5] for o in out])
    return a, b, ci, cj


def chain_loops(a, b, W):
    """Gerichtete Kanten zu geschlossenen Schleifen; an Berührpunkten wird links abgebogen
    (trennt nur über Ecken verbundene Bereiche). Liefert Liste (Punktliste, erste Kante)."""
    n = len(a)
    if n == 0:
        return []
    used = np.zeros(n, dtype=bool)
    from collections import defaultdict
    outg = defaultdict(list)
    for e in range(n):
        outg[int(a[e])].append(e)

    def dvec(e):
        ua, va = divmod(int(a[e]), W)
        ub, vb = divmod(int(b[e]), W)
        return ub - ua, vb - va

    loops = []
    for e0 in range(n):
        if used[e0]:
            continue
        pts = []
        e = e0
        while True:
            used[e] = True
            pts.append(int(a[e]))
            v = int(b[e])
            cand = outg[v]
            if len(cand) > 1:
                dx, dy = dvec(e)
                left = (-dy, dx)
                cand = sorted(cand, key=lambda x: 0 if dvec(x) == left else (1 if dvec(x) == (dx, dy) else 2))
            if not cand or used[cand[0]]:
                break
            e = cand[0]
        loops.append((pts, e0))
    return loops


def signed_area(P):
    x, y = P[:, 0], P[:, 1]
    return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(np.roll(x, -1), y))


# ================================================================ Glätten & Vereinfachen

def _dp(P, tol):
    """Douglas-Peucker: Indizes der behaltenen Punkte (Endpunkte bleiben)."""
    n = len(P)
    if n <= 2:
        return list(range(n))
    keep = np.zeros(n, dtype=bool)
    keep[0] = keep[-1] = True
    stack = [(0, n - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        A, B = P[i], P[j]
        d = B - A
        L = math.hypot(d[0], d[1])
        Q = P[i + 1:j] - A
        if L < 1e-12:
            dist = np.hypot(Q[:, 0], Q[:, 1])
        else:
            dist = np.abs(Q[:, 0] * d[1] - Q[:, 1] * d[0]) / L
        k = int(np.argmax(dist))
        if dist[k] > tol:
            m = i + 1 + k
            keep[m] = True
            stack.append((i, m))
            stack.append((m, j))
    return list(np.flatnonzero(keep))


class Graph2D:
    """Gemeinsamer ebener Graph aller Randschleifen: Ketten zwischen Knotenpunkten werden einmal
    geglättet und vereinfacht, damit alle Schleifen, die eine Kette benutzen, identisch bleiben."""

    def __init__(self, W, u0, v0, c, tol=0.3, smooth=3, corner_run=3):
        self.W, self.u0, self.v0, self.c = W, u0, v0, c
        self.tol, self.smooth, self.corner_run = tol, smooth, corner_run
        self.loops = []

    def add(self, pts):
        self.loops.append(pts)
        return len(self.loops) - 1

    def _xy(self, vid):
        i, j = divmod(vid, self.W)
        return np.array([i, j], dtype=float)

    def solve(self):
        from collections import defaultdict
        nb = defaultdict(set)
        for L in self.loops:
            n = len(L)
            for k in range(n):
                p, q = L[k], L[(k + 1) % n]
                nb[p].add(q)
                nb[q].add(p)
        junction = {v for v, s in nb.items() if len(s) != 2}
        pos = {}
        keep = set(junction)
        seen_edge = set()

        def walk(v0, v1):
            seq = [v0, v1]
            prev, cur = v0, v1
            while cur not in junction:
                nxt = [x for x in nb[cur] if x != prev]
                if not nxt:
                    break
                prev, cur = cur, nxt[0]
                seq.append(cur)
                if cur == v0:
                    break
            return seq

        chains = []
        for v in list(junction):
            for w in nb[v]:
                if (v, w) in seen_edge:
                    continue
                seq = walk(v, w)
                for x, y in zip(seq[:-1], seq[1:]):
                    seen_edge.add((x, y))
                    seen_edge.add((y, x))
                chains.append(seq)
        # geschlossene Ketten ohne Knotenpunkt
        for v in nb:
            if v in junction:
                continue
            w = next(iter(nb[v]))
            if (v, w) in seen_edge:
                continue
            seq = walk(v, w)
            for x, y in zip(seq[:-1], seq[1:]):
                seen_edge.add((x, y))
                seen_edge.add((y, x))
            chains.append(seq)
        for seq in chains:
            self._chain(seq, pos, keep)
        for v in keep:
            if v not in pos:
                pos[v] = self._xy(v)
        self.pos, self.keep = pos, keep

    def _chain(self, seq, pos, keep):
        closed = seq[0] == seq[-1]
        P = np.array([self._xy(v) for v in seq])
        n = len(P)
        fixed = np.zeros(n, dtype=bool)
        fixed[0] = fixed[-1] = True
        # echte Ecken: Richtungswechsel zwischen zwei langen geraden Abschnitten bleiben scharf
        d = np.diff(P, axis=0)
        run = np.zeros(len(d), dtype=int)
        k = 0
        while k < len(d):
            j = k
            while j + 1 < len(d) and np.all(d[j + 1] == d[k]):
                j += 1
            run[k:j + 1] = j - k + 1
            k = j + 1
        for k in range(1, n - 1):
            if np.any(d[k - 1] != d[k]) and run[k - 1] >= self.corner_run and run[k] >= self.corner_run:
                fixed[k] = True
        if closed and fixed.sum() <= 2:
            far = int(np.argmax(np.hypot(*(P - P[0]).T)))
            if 0 < far < n - 1:
                fixed[far] = True
        Q = P.copy()
        for _ in range(self.smooth):
            Qn = Q.copy()
            Qn[1:-1] = 0.5 * Q[1:-1] + 0.25 * (Q[:-2] + Q[2:])
            Q = np.where(fixed[:, None], P, Qn)
        idx = np.flatnonzero(fixed)
        kept = set()
        for s, e in zip(idx[:-1], idx[1:]):
            for t in _dp(Q[s:e + 1], self.tol):
                kept.add(s + t)
        for t in kept:
            v = seq[t]
            keep.add(v)
            pos[v] = Q[t]

    def simplified(self, li):
        L = [v for v in self.loops[li] if v in self.keep]
        out = []
        for v in L:
            if not out or out[-1] != v:
                out.append(v)
        if len(out) > 1 and out[0] == out[-1]:
            out.pop()
        return out

    def world(self, vid):
        p = self.pos[vid]
        return self.u0 + p[0] * self.c, self.v0 + p[1] * self.c


# ================================================================ Dreiecke (ebene Flächen)

def _cross2(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _merge_holes(outer, holes, P):
    """Löcher über Brücken in den Außenrand einhängen (Eberly). Indizes in P (2D)."""
    poly = list(outer)
    holes = [h for h in holes if len(h) >= 3]
    holes.sort(key=lambda h: -max(P[i][0] for i in h))
    for h in holes:
        hm = max(range(len(h)), key=lambda k: (P[h[k]][0], -P[h[k]][1]))
        M = P[h[hm]]
        best, bi, bx = None, None, math.inf
        n = len(poly)
        for k in range(n):
            a, b = P[poly[k]], P[poly[(k + 1) % n]]
            if (a[1] > M[1]) == (b[1] > M[1]) and not (a[1] == M[1] or b[1] == M[1]):
                continue
            if a[1] == b[1]:
                cand = [(a[0], k), (b[0], (k + 1) % n)]
                for x, kk in cand:
                    if x >= M[0] and x - M[0] < bx and a[1] == M[1]:
                        bx, bi, best = x - M[0], kk, P[poly[kk]]
                continue
            t = (M[1] - a[1]) / (b[1] - a[1])
            if t < 0 or t > 1:
                continue
            x = a[0] + t * (b[0] - a[0])
            if x < M[0] - 1e-12 or x - M[0] >= bx:
                continue
            bx = x - M[0]
            kk = k if a[0] > b[0] else (k + 1) % n
            bi, best = kk, (x, M[1])
        if bi is None:
            bi = min(range(n), key=lambda k: (P[poly[k]][0] - M[0]) ** 2 + (P[poly[k]][1] - M[1]) ** 2)
        else:
            # sichtbarer Punkt: Endpunkt der getroffenen Kante, ggf. Reflexpunkt im Dreieck M-I-P näher am Strahl
            Pp = P[poly[bi]]
            I = best
            tri = (M, I, Pp)
            cand_k, cand_a = bi, None
            for k in range(n):
                q = P[poly[k]]
                if poly[k] == poly[bi]:
                    continue
                if q[0] < M[0]:
                    continue
                pr, nx = P[poly[k - 1]], P[poly[(k + 1) % n]]
                if _cross2(pr, q, nx) >= 0:          # nicht reflex (Außenrand gegen den Uhrzeigersinn)
                    continue
                if _in_tri(q, *tri):
                    ang = abs(math.atan2(q[1] - M[1], q[0] - M[0]))
                    if cand_a is None or ang < cand_a:
                        cand_a, cand_k = ang, k
            bi = cand_k
        hr = h[hm:] + h[:hm]
        poly = poly[:bi + 1] + hr + [hr[0], poly[bi]] + poly[bi + 1:]
    return poly


def _in_tri(p, a, b, c):
    d1 = _cross2(a, b, p)
    d2 = _cross2(b, c, p)
    d3 = _cross2(c, a, p)
    neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (neg and pos)


def earclip(poly, P):
    """Ohrenschneiden für ein einfaches Polygon (gegen den Uhrzeigersinn, Brücken erlaubt)."""
    idx = list(poly)
    tris = []
    Pa = np.asarray(P, dtype=float)
    guard = 0
    while len(idx) > 3 and guard < 10 * len(poly) + 100:
        guard += 1
        n = len(idx)
        cut = False
        V = Pa[idx]
        prv, nxt = np.roll(V, 1, axis=0), np.roll(V, -1, axis=0)
        cr = (V[:, 0] - prv[:, 0]) * (nxt[:, 1] - prv[:, 1]) - (V[:, 1] - prv[:, 1]) * (nxt[:, 0] - prv[:, 0])
        conv = cr > 1e-14
        reflex = np.flatnonzero(~conv)
        for k in np.flatnonzero(conv):
            a, b, c = idx[k - 1], idx[k], idx[(k + 1) % n]
            A, B, C = Pa[a], Pa[b], Pa[c]
            if len(reflex):
                R = reflex[(np.array(idx)[reflex] != a) & (np.array(idx)[reflex] != b) & (np.array(idx)[reflex] != c)]
                if len(R):
                    Q = V[R]
                    d1 = (B[0] - A[0]) * (Q[:, 1] - A[1]) - (B[1] - A[1]) * (Q[:, 0] - A[0])
                    d2 = (C[0] - B[0]) * (Q[:, 1] - B[1]) - (C[1] - B[1]) * (Q[:, 0] - B[0])
                    d3 = (A[0] - C[0]) * (Q[:, 1] - C[1]) - (A[1] - C[1]) * (Q[:, 0] - C[0])
                    inside = (d1 >= -1e-14) & (d2 >= -1e-14) & (d3 >= -1e-14)
                    # Punkte, die genau auf Ecken liegen (Brücken), stören nicht
                    same = (np.hypot(Q[:, 0] - A[0], Q[:, 1] - A[1]) < 1e-12) | \
                           (np.hypot(Q[:, 0] - B[0], Q[:, 1] - B[1]) < 1e-12) | \
                           (np.hypot(Q[:, 0] - C[0], Q[:, 1] - C[1]) < 1e-12)
                    if np.any(inside & ~same):
                        continue
            tris.append((a, b, c))
            del idx[k]
            cut = True
            break
        if not cut:
            # numerisch entartet: kleinsten Rest-Winkel abschneiden
            k = int(np.argmax(cr))
            tris.append((idx[k - 1], idx[k], idx[(k + 1) % n]))
            del idx[k]
    if len(idx) == 3:
        tris.append(tuple(idx))
    return tris


# ================================================================ Prisma bauen

class Prism:
    pass


def build(model, xp, level, sigma, bands, two_setups, tool_mm, cell_mm=0.0, log=print, progress=None,
          max_cells=2_500_000):
    """Prismatisches Ergebnis aus der (bandweise konstanten) Dichte xp."""
    step = progress or (lambda f, t: None)
    mesh, S = model.mesh, model.S
    axis = bands["axis"]
    sign = bands.get("sign") or (1 if S["mfg_dir"][1] == "+" else -1)
    ou, ov = [a for a in range(3) if a != axis]
    sc = model.scale
    h = model.h
    n = bands["n"]
    L = bands["L"]
    cut = bands["cut"]                                 # Bandgrenzen in w (0 = Grund)
    # Bandgrenzen in Weltkoordinaten (aufsteigend) und Schichtbereiche je Band (Index 0 = kleinste Koordinate)
    if sign > 0 or bands.get("world"):
        lb = list(cut)
    else:
        lb = [L - c for c in cut[::-1]]
    z = [model.lo[axis] + l * h for l in lb]
    z[0] = max(z[0], mesh.lo[axis])
    z[-1] = min(z[-1], mesh.hi[axis])
    from_plus = sign > 0
    # ---------------------------------------------------------------- grobe Banddichte
    g = np.zeros(model.shape)
    g[model.ei, model.ej, model.ek] = xp
    dom = np.zeros(model.shape, dtype=bool)
    dom[model.ei, model.ej, model.ek] = True
    pas = np.zeros(model.shape, dtype=bool)
    pas[model.ei[model.passive], model.ej[model.passive], model.ek[model.passive]] = True
    gm = np.moveaxis(g, axis, -1)
    dm = np.moveaxis(dom, axis, -1)
    pm = np.moveaxis(pas, axis, -1)
    D, Pc = [], []
    for k in range(n):
        sl = slice(lb[k], lb[k + 1])
        # Material irgendwo in der Stufe → ganze Stufe (die Dichte ist je Stufe konstant; ergänzte
        # Verbindungen zwischen getrennten Stücken liegen nur in einzelnen Schichten und müssen mitzählen)
        D.append(np.where(dm[:, :, sl].any(-1), gm[:, :, sl].max(-1), 0.0))
        Pc.append(pm[:, :, sl].any(-1))
    # ---------------------------------------------------------------- feines Raster
    ext = mesh.hi - mesh.lo
    cfine = (float(cell_mm) / sc) if cell_mm and cell_mm > 0 else h / 4.0
    cfine = max(cfine, math.sqrt(ext[ou] * ext[ov] / max_cells), h / 10.0)
    zc = cfine
    if ext[ou] * ext[ov] * max(ext[axis], cfine) / (cfine * cfine * zc) > 3.0e7:
        zc = ext[ou] * ext[ov] * ext[axis] / (cfine * cfine * 3.0e7)
    u0, v0 = float(mesh.lo[ou]), float(mesh.lo[ov])
    Nu = max(1, int(math.ceil(ext[ou] / cfine - 1e-9)))
    Nv = max(1, int(math.ceil(ext[ov] / cfine - 1e-9)))
    step(0.05, "Prism: part on fine raster")
    # Bauteil fein voxelisieren (in der Ebene cfine, entlang der Achse zc)
    part = _part_masks(mesh, S, axis, ou, ov, u0, v0, cfine, Nu, Nv, z, zc)
    step(0.35, "Prism: depth levels")
    uc = u0 + (np.arange(Nu) + 0.5) * cfine
    vc = v0 + (np.arange(Nv) + 0.5) * cfine
    iu = (uc - model.lo[ou]) / h - 0.5
    iv = (vc - model.lo[ov]) / h - 0.5
    IU, IV = np.meshgrid(iu, iv, indexing="ij")
    raw, pasf = [], []
    for k in range(n):
        f = gaussian_filter(D[k], sigma) if sigma > 0 else D[k]
        fv = map_coordinates(f, [IU.ravel(), IV.ravel()], order=1, mode="nearest").reshape(Nu, Nv)
        raw.append(fv > level)
        pn = map_coordinates(Pc[k].astype(float), [IU.ravel(), IV.ravel()], order=0, mode="nearest").reshape(Nu, Nv)
        pasf.append(pn > 0.5)
    tool_r = 0.5 * float(tool_mm or 0) / sc / cfine
    masks = make_masks(raw, part, tool_r, from_plus, two_setups, pasf, step_r=0.6 * h / cfine,
                       min_cells=int((h / cfine) ** 2))
    masks = _keep_supported(model, masks, axis, ou, ov, u0, v0, cfine, z, log)
    if not any(m.any() for m in masks):
        raise ValueError("No material in the prismatic result – check the threshold.")
    step(0.55, "Prism: smoothing contours")
    P = Prism()
    P.axis, P.ou, P.ov, P.z, P.masks = axis, ou, ov, z, masks
    P.u0, P.v0, P.c, P.Nu, P.Nv, P.from_plus = u0, v0, cfine, Nu, Nv, from_plus
    P.pieces = int(label(np.stack(masks))[1])
    _geometry(P)
    step(0.85, "Prism: faces and triangles")
    _mesh(P)
    P.xb = _coarse(model, P)
    log(f"Prismatic result: {n} depth level(s) at "
        + ", ".join(f"{(zz - z[0]) * sc:.1f}" for zz in z[1:-1]) + (" mm, " if n > 1 else "")
        + f"raster {cfine * sc:.2f} mm, {len(P.faces3)} planar faces, {len(P.tri)} triangles")
    return P


def _keep_supported(model, masks, axis, ou, ov, u0, v0, c, z, log):
    """Nur Material behalten, das (über Stufen hinweg flächig) mit einer Lagerfläche verbunden ist."""
    st = np.stack(masks)                              # (Stufe, u, v)
    if not st.any():
        return masks
    lab, n = label(st)                                # 6er-Nachbarschaft: in der Ebene und zur Nachbarstufe
    if n <= 1:
        return masks
    keep = set()
    zz = np.asarray(z)
    for cnd in model.conds:
        if cnd["type"] not in ("fixed", "frictionless", "pin") or cnd.get("tris") is None or not len(cnd["tris"]):
            continue
        pts, _ = G.sample_triangles(model.mesh.tris[np.asarray(cnd["tris"], dtype=np.int64)], c)
        if not len(pts):
            continue
        iu = np.floor((pts[:, ou] - u0) / c).astype(int)
        iv = np.floor((pts[:, ov] - v0) / c).astype(int)
        k = np.clip(np.searchsorted(zz, pts[:, axis]) - 1, 0, st.shape[0] - 1)
        for du in (-2, -1, 0, 1, 2):
            for dv in (-2, -1, 0, 1, 2):
                a = np.clip(iu + du, 0, st.shape[1] - 1)
                b = np.clip(iv + dv, 0, st.shape[2] - 1)
                v = lab[k, a, b]
                keep.update(np.unique(v[v > 0]).tolist())
    if not keep:
        return masks
    km = np.zeros(n + 1, dtype=bool)
    km[list(keep)] = True
    drop = st & ~km[lab]
    if drop.any():
        log(f"{n - len(keep)} loose part(s) without connection to a support removed from the prismatic result.")
        st = st & km[lab]
    return [st[k] for k in range(st.shape[0])]


def _part_masks(mesh, S, axis, ou, ov, u0, v0, c, Nu, Nv, z, zc):
    """Bauteilquerschnitt je Stufe: Zelle gehört dazu, wenn das Bauteil über die ganze Stufe massiv ist."""
    n = len(z) - 1
    # Voxelisierung erwartet Würfel: Achsen so drehen, dass die Werkzeugachse z ist, dann skalieren
    perm = [ou, ov, axis]
    tris = mesh.tris[:, :, perm].copy()
    lo = np.array([u0, v0, z[0]])
    tris[:, :, 2] = (tris[:, :, 2] - z[0]) * (c / zc) + z[0]
    Nz = max(1, int(math.ceil((z[-1] - z[0]) / zc - 1e-9)))
    solid, _ = G.voxelize(tris, lo, c, (Nu, Nv, Nz), robust=bool(S.get("robust")) or not mesh.watertight)
    zcen = z[0] + (np.arange(Nz) + 0.5) * zc
    out = []
    for k in range(n):
        sel = (zcen >= z[k]) & (zcen <= z[k + 1])
        if not sel.any():
            sel = np.zeros(Nz, dtype=bool)
            sel[min(Nz - 1, max(0, int((0.5 * (z[k] + z[k + 1]) - z[0]) / zc)))] = True
        out.append(solid[:, :, sel].all(-1))
    return out


def _geometry(P):
    """Schleifen aller Wände und Böden, gemeinsamer Graph, Flächen (3D-Punkte in uvw)."""
    masks, n = P.masks, len(P.masks)
    W = P.Nv + 1
    Gr = Graph2D(W, P.u0, P.v0, P.c)
    wall_loops = []                                   # (Band, Schleife)
    for k, m in enumerate(masks):
        a, b, _, _ = boundary_edges(m)
        for pts, _ in chain_loops(a, b, W):
            wall_loops.append((k, Gr.add(pts)))
    flat_faces = []                                   # (Grenze b, oben?, [Schleifen])
    empty = np.zeros_like(masks[0])
    for bnd in range(n + 1):
        below = masks[bnd - 1] if bnd >= 1 else empty
        above = masks[bnd] if bnd < n else empty
        for up, reg in ((True, below & ~above), (False, above & ~below)):
            if not reg.any():
                continue
            lab, nl = label(reg, structure=_S4)
            a, b, ci, cj = boundary_edges(reg)
            comp = lab[ci, cj]
            for c in range(1, nl + 1):
                sel = comp == c
                loops = [Gr.add(pts) for pts, _ in chain_loops(a[sel], b[sel], W)]
                flat_faces.append((bnd, up, loops))
    Gr.solve()
    P.graph = Gr
    # ---- Punkte (u, v, Ebene)
    pts, pid = [], {}

    def point(v, lvl):
        key = (v, lvl)
        if key not in pid:
            u, w = Gr.world(v)
            pid[key] = len(pts)
            pts.append((u, w, P.z[lvl]))
        return pid[key]

    faces = []                                        # (Normale uvw, [Schleifen als Punktindizes])
    # ---- Böden/Deckel
    for bnd, up, loops in flat_faces:
        Ls = [Gr.simplified(li) for li in loops]
        Ls = [L for L in Ls if len(L) >= 3]
        if not Ls:
            continue
        idx = [[point(v, bnd) for v in L] for L in Ls]
        area = [signed_area(np.array([Gr.pos[v] for v in L])) for L in Ls]
        o = int(np.argmax(area))
        outer = idx[o]
        holes = [idx[i] for i in range(len(idx)) if i != o]
        if not up:                                    # nach unten: von unten gesehen gegen den Uhrzeigersinn
            outer = outer[::-1]
            holes = [h[::-1] for h in holes]
        faces.append(dict(kind="flat", n=(0, 0, 1 if up else -1), outer=outer, holes=holes, lvl=bnd,
                          L2=[Ls[o]] + [Ls[i] for i in range(len(Ls)) if i != o], up=up))
    # ---- Wände: Abschnitte je Band, über Bänder zusammengefasst
    segs = {}
    for k, li in wall_loops:
        L = Gr.simplified(li)
        m = len(L)
        if m < 3:
            continue
        for i in range(m):
            segs.setdefault((L[i], L[(i + 1) % m]), set()).add(k)
    used = set(pid.keys())
    runs = []
    for (va, vb), ks in segs.items():
        ks = sorted(ks)
        s0 = ks[0]
        for i in range(1, len(ks) + 1):
            if i == len(ks) or ks[i] != ks[i - 1] + 1:
                runs.append((va, vb, s0, ks[i - 1] + 1))
                if i < len(ks):
                    s0 = ks[i]
        for k in ks:
            used.add((va, k))
            used.add((va, k + 1))
            used.add((vb, k))
            used.add((vb, k + 1))
    for va, vb, l0, l1 in runs:
        right = [point(vb, l) for l in range(l0, l1 + 1) if l in (l0, l1) or (vb, l) in used]
        left = [point(va, l) for l in range(l0, l1 + 1) if l in (l0, l1) or (va, l) in used]
        pa, pb = np.array(Gr.world(va)), np.array(Gr.world(vb))
        d = pb - pa
        nrm = np.array([d[1], -d[0], 0.0])
        ln = np.linalg.norm(nrm)
        if ln < 1e-15:
            continue
        loop = [left[0], right[0]] + right[1:] + left[1:][::-1]
        # Schleife: a unten → b unten → b oben … → a oben … (gegen den Uhrzeigersinn von außen)
        faces.append(dict(kind="wall", n=tuple(nrm / ln), outer=loop, holes=[], left=left, right=right))
    P.pts = np.array(pts, dtype=float)
    P.faces3 = faces


def _mesh(P):
    tris = []
    for f in P.faces3:
        if f["kind"] == "wall":
            L, R = f["left"], f["right"]
            i = j = 0
            while i < len(L) - 1 or j < len(R) - 1:
                # Reißverschluss zwischen linker (a) und rechter (b) senkrechter Kante
                if j < len(R) - 1 and (i == len(L) - 1 or P.pts[R[j + 1], 2] <= P.pts[L[i + 1], 2]):
                    tris.append((L[i], R[j], R[j + 1]))
                    j += 1
                else:
                    tris.append((L[i], R[j], L[i + 1]))
                    i += 1
        else:
            outer, holes = f["outer"], f["holes"]
            P2 = P.pts[:, :2]
            if f["up"]:
                poly = _merge_holes(outer, holes, P2)
                tris.extend(earclip(poly, P2))
            else:                                     # von oben gesehen umdrehen, dann zurück
                poly = _merge_holes(outer[::-1], [h[::-1] for h in holes], P2)
                tris.extend((a, c, b) for a, b, c in earclip(poly, P2))
    P.tri = np.array(tris, dtype=np.int64).reshape(-1, 3)
    # uvw → xyz
    X = np.zeros_like(P.pts)
    X[:, P.ou], X[:, P.ov], X[:, P.axis] = P.pts[:, 0], P.pts[:, 1], P.pts[:, 2]
    P.verts = X
    Q = np.zeros((3, 3))
    Q[P.ou, 0], Q[P.ov, 1], Q[P.axis, 2] = 1, 1, 1
    P.flip = np.linalg.det(Q) < 0                      # linkshändige Achsfolge → Umlaufsinn umkehren
    if P.flip:
        P.tri = P.tri[:, ::-1].copy()
    t = X[P.tri]
    P.volume = float(abs(np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2])).sum() / 6.0))


def _coarse(model, P):
    """0/1-Belegung der Rechenvoxel aus dem Prisma (für die Analyse): Voxel gilt als Material, wenn
    mindestens 30 % seiner Grundfläche belegt sind; Kanten-/Eckkontakte werden überbrückt."""
    from .support_check import bridge_hinges
    h = model.h
    nu_c, nv_c = model.shape[P.ou], model.shape[P.ov]
    uc = P.u0 + (np.arange(P.Nu) + 0.5) * P.c
    vc = P.v0 + (np.arange(P.Nv) + 0.5) * P.c
    cu = np.clip(((uc - model.lo[P.ou]) / h).astype(int), 0, nu_c - 1)
    cv = np.clip(((vc - model.lo[P.ov]) / h).astype(int), 0, nv_c - 1)
    CU, CV = np.meshgrid(cu, cv, indexing="ij")
    lin = (CU * nv_c + CV).ravel()
    cnt = np.bincount(lin, minlength=nu_c * nv_c).astype(float)
    frac = [np.bincount(lin, weights=m.ravel().astype(float), minlength=nu_c * nv_c) / np.maximum(cnt, 1)
            for m in P.masks]
    c = model.ecent
    k = np.clip(np.searchsorted(np.asarray(P.z), c[:, P.axis]) - 1, 0, len(P.masks) - 1)
    idx = [model.ei, model.ej, model.ek]
    li = idx[P.ou] * nv_c + idx[P.ov]
    xb = np.stack(frac)[k, li] >= 0.3
    g = np.zeros(model.shape, dtype=bool)
    g[model.ei, model.ej, model.ek] = xb
    g, _ = bridge_hinges(g, model.emap >= 0)
    return g[model.ei, model.ej, model.ek].astype(float)


def fine_field(P):
    """(Maske, lo, h) auf einem Würfelraster für die Wandstärkenprüfung."""
    if getattr(P, "multi", False):
        return P.F > 0, P.lo, P.c
    c = P.c
    z0, z1 = P.z[0], P.z[-1]
    Nz = max(1, int(math.ceil((z1 - z0) / c)))
    zc = z0 + (np.arange(Nz) + 0.5) * c
    k = np.clip(np.searchsorted(np.asarray(P.z), zc) - 1, 0, len(P.masks) - 1)
    st = np.stack(P.masks)[k]                         # (Nz, Nu, Nv)
    m = np.moveaxis(st, 0, -1)                        # (Nu, Nv, Nz) in u, v, w
    order = np.argsort([P.ou, P.ov, P.axis])
    m = np.transpose(m, order)
    lo = np.zeros(3)
    lo[P.ou], lo[P.ov], lo[P.axis] = P.u0, P.v0, z0
    return m, lo, c


# ================================================================ Export

def step_bytes(P, scale=1.0, name="Diotopo"):
    """STEP AP214: ein Volumenkörper (MANIFOLD_SOLID_BREP) aus ebenen Flächen, Einheit mm."""
    import unicodedata
    name = unicodedata.normalize("NFKD", str(name)).encode("ascii", "ignore").decode("ascii")
    name = "".join(ch for ch in name if ch.isalnum() or ch in " _-.") or "Diotopo"
    X = P.verts * scale
    lines = []
    nid = [0]

    def add(txt):
        nid[0] += 1
        lines.append(f"#{nid[0]}={txt};")
        return nid[0]

    def f(x):
        s = f"{x:.6f}".rstrip("0")
        return s + "0" if s.endswith(".") else s

    def pt(p):
        return add(f"CARTESIAN_POINT('',({f(p[0])},{f(p[1])},{f(p[2])}))")

    def dr(d):
        return add(f"DIRECTION('',({f(d[0])},{f(d[1])},{f(d[2])}))")

    flip = P.flip
    vtx = {}

    def vertex(i):
        if i not in vtx:
            vtx[i] = add(f"VERTEX_POINT('',#{pt(X[i])})")
        return vtx[i]

    edges = {}

    def edge(i, j):
        key = (min(i, j), max(i, j))
        if key not in edges:
            a, b = key
            d = X[b] - X[a]
            ln = float(np.linalg.norm(d))
            line = add(f"LINE('',#{pt(X[a])},#{add(f'VECTOR({chr(39)}{chr(39)},#{dr(d / ln)},{f(ln)})')})")
            edges[key] = add(f"EDGE_CURVE('',#{vertex(a)},#{vertex(b)},#{line},.T.)")
        return edges[key], i < j

    def to_xyz(n):
        v = np.zeros(3)
        v[P.ou], v[P.ov], v[P.axis] = n
        return v

    face_ids = []
    for fc in P.faces3:
        loops = [fc["outer"]] + fc["holes"]
        if flip:
            loops = [L[::-1] for L in loops]
        nrm = to_xyz(fc["n"])
        bounds = []
        for li, L in enumerate(loops):
            oes = []
            for k in range(len(L)):
                e, fwd = edge(L[k], L[(k + 1) % len(L)])
                oes.append(add(f"ORIENTED_EDGE('',*,*,#{e},{'.T.' if fwd else '.F.'})"))
            el = add("EDGE_LOOP('',(" + ",".join(f"#{o}" for o in oes) + "))")
            kind = "FACE_OUTER_BOUND" if li == 0 else "FACE_BOUND"
            bounds.append(add(f"{kind}('',#{el},.T.)"))
        p0 = X[loops[0][0]]
        ref = X[loops[0][1]] - p0
        ref = ref - nrm * float(ref @ nrm)
        rl = float(np.linalg.norm(ref))
        ref = ref / rl if rl > 1e-12 else np.array([1.0, 0, 0]) if abs(nrm[0]) < 0.9 else np.array([0, 1.0, 0])
        ax = add(f"AXIS2_PLACEMENT_3D('',#{pt(p0)},#{dr(nrm)},#{dr(ref)})")
        pl = add(f"PLANE('',#{ax})")
        face_ids.append(add("ADVANCED_FACE('',(" + ",".join(f"#{b}" for b in bounds) + f"),#{pl},.T.)"))
    shell = add("CLOSED_SHELL('',(" + ",".join(f"#{i}" for i in face_ids) + "))")
    solid = add(f"MANIFOLD_SOLID_BREP('{name}',#{shell})")
    # Kontext, Einheiten (mm), Produktstruktur
    lu = add("( LENGTH_UNIT() NAMED_UNIT(*) SI_UNIT(.MILLI.,.METRE.) )")
    au = add("( NAMED_UNIT(*) PLANE_ANGLE_UNIT() SI_UNIT($,.RADIAN.) )")
    su = add("( NAMED_UNIT(*) SI_UNIT($,.STERADIAN.) SOLID_ANGLE_UNIT() )")
    unc = add(f"UNCERTAINTY_MEASURE_WITH_UNIT(LENGTH_MEASURE(1.E-05),#{lu},'distance_accuracy_value','')")
    ctx = add(f"( GEOMETRIC_REPRESENTATION_CONTEXT(3) GLOBAL_UNCERTAINTY_ASSIGNED_CONTEXT((#{unc})) "
              f"GLOBAL_UNIT_ASSIGNED_CONTEXT((#{lu},#{au},#{su})) REPRESENTATION_CONTEXT('',''))")
    origin = add(f"AXIS2_PLACEMENT_3D('',#{pt((0, 0, 0))},#{dr((0, 0, 1))},#{dr((1, 0, 0))})")
    rep = add(f"ADVANCED_BREP_SHAPE_REPRESENTATION('',(#{origin},#{solid}),#{ctx})")
    appc = add("APPLICATION_CONTEXT('core data for automotive mechanical design processes')")
    add(f"APPLICATION_PROTOCOL_DEFINITION('international standard','automotive_design',2000,#{appc})")
    pc = add(f"PRODUCT_CONTEXT('',#{appc},'mechanical')")
    prod = add(f"PRODUCT('{name}','{name}','',(#{pc}))")
    add(f"PRODUCT_RELATED_PRODUCT_CATEGORY('part',$,(#{prod}))")
    pdf = add(f"PRODUCT_DEFINITION_FORMATION('','',#{prod})")
    pdc = add(f"PRODUCT_DEFINITION_CONTEXT('part definition',#{appc},'design')")
    pd = add(f"PRODUCT_DEFINITION('design','',#{pdf},#{pdc})")
    pds = add(f"PRODUCT_DEFINITION_SHAPE('','',#{pd})")
    add(f"SHAPE_DEFINITION_REPRESENTATION(#{pds},#{rep})")
    import time as _t
    stamp = _t.strftime("%Y-%m-%dT%H:%M:%S")
    head = ("ISO-10303-21;\nHEADER;\nFILE_DESCRIPTION(('Diotopo prismatic part'),'2;1');\n"
            f"FILE_NAME('{name}.step','{stamp}',(''),(''),'Diotopo','Diotopo','');\n"
            "FILE_SCHEMA(('AUTOMOTIVE_DESIGN { 1 0 10303 214 1 1 1 1 }'));\nENDSEC;\nDATA;\n")
    return (head + "\n".join(lines) + "\nENDSEC;\nEND-ISO-10303-21;\n").encode("ascii")


def dxf_bytes(P, scale=1.0):
    """DXF (R12): geschlossene Konturen je Tiefenstufe auf eigenem Layer, Z = Oberkante der Stufe."""
    if getattr(P, "multi", False):
        return dxf_multi(P, scale)
    Gr = P.graph
    n = len(P.masks)
    out = ["0", "SECTION", "2", "HEADER", "9", "$ACADVER", "1", "AC1009", "0", "ENDSEC",
           "0", "SECTION", "2", "ENTITIES"]
    names = []
    for k in range(n):
        top = P.z[k + 1] if P.from_plus else P.z[k]
        nm = f"STUFE_{k + 1 if P.from_plus else n - k}_Z{(top - P.z[0]) * scale:.2f}".replace(".", "_")
        names.append((nm, top))
    for k, m in enumerate(P.masks):
        nm, top = names[k]
        a, b, _, _ = boundary_edges(m)
        for pts, _ in chain_loops(a, b, P.Nv + 1):
            L = [v for v in pts if v in Gr.keep]
            if len(L) < 3:
                continue
            out += ["0", "POLYLINE", "8", nm, "66", "1", "10", "0.0", "20", "0.0", "30", f"{top * scale:.4f}",
                    "70", "9"]
            for v in L:
                u, w = Gr.world(v)
                q = np.zeros(3)
                q[P.ou], q[P.ov], q[P.axis] = u, w, top
                q = q * scale
                out += ["0", "VERTEX", "8", nm, "10", f"{q[0]:.4f}", "20", f"{q[1]:.4f}", "30", f"{q[2]:.4f}",
                        "70", "32"]
            out += ["0", "SEQEND", "8", nm]
    out += ["0", "ENDSEC", "0", "EOF"]
    return ("\n".join(out) + "\n").encode("ascii")


# ================================================================ Mehrere Achsen (3+2, bis 6 Seiten)

def build_any(model, xp, level, sigma, tool_mm, cell_mm=0.0, log=print, progress=None, coarse=False):
    """Prismatisches Ergebnis nach den gewählten Frässeiten: eine Achse → exakter Stufenkörper (build),
    mehrere Achsen → Schnitt der Stufenkörper je Achse (build_multi)."""
    from .engine import prism_sides, prism_bands
    sides = prism_sides(model.S)
    if len(sides) == 1 and _cross_features(model, next(iter(sides))) > 0.01:
        # Bauteil hat Formen quer zur Fräsachse (Querbohrungen, Schrägen): der exakte Stufenkörper würde daraus
        # Schlitze über ganze Stufen machen – stattdessen bleibt die Originalgeometrie dort erhalten
        P = build_multi(model, xp, level, sigma, sides, tool_mm, cell_mm, log=log, progress=progress,
                        max_voxels=1_500_000 if coarse else 8_000_000)
        P.cross = True
        return P
    if len(sides) == 1:
        axis, sg = next(iter(sides.items()))
        n, cut, _ = prism_bands(model, model.S, axis)
        bands = dict(axis=axis, n=n, cut=cut, L=model.shape[axis], world=True, sign=1 if 1 in sg else -1)
        P = build(model, xp, level, sigma, bands, len(sg) == 2, tool_mm, cell_mm, log=log, progress=progress)
        P.multi = False
        P.sides = sides
        return P
    return build_multi(model, xp, level, sigma, sides, tool_mm, cell_mm, log=log, progress=progress,
                       max_voxels=1_500_000 if coarse else 8_000_000)


def _cross_features(model, axis):
    """Anteil des Bauteilvolumens, der nicht prismatisch entlang der Achse ist (je Tiefenstufe nicht über die
    ganze Stufe massiv) – z. B. Querbohrungen. Grob gerastert, je Modell und Achse einmal."""
    from .engine import prism_bands
    cache = model.__dict__.setdefault("_cross_cache", {})
    n, cut, _ = prism_bands(model, model.S, axis)
    key = (axis, n)
    if key not in cache:
        mesh = model.mesh
        c = float(max(mesh.hi - mesh.lo)) / 160.0
        lo, shape = G.grid_for(mesh.lo, mesh.hi, c, pad=1)
        solid, _ = G.voxelize(mesh.tris, lo, c, tuple(int(x) for x in shape),
                              robust=bool(model.S.get("robust")) or not mesh.watertight)
        m = np.moveaxis(solid, axis, -1)
        w = lo[axis] + (np.arange(m.shape[-1]) + 0.5) * c
        inner = (w > mesh.lo[axis] + 0.5 * c) & (w < mesh.hi[axis] - 0.5 * c)
        z = np.array([model.lo[axis] + l * model.h for l in cut[1:-1]])
        band = np.searchsorted(z, w, side="right")
        keep = 0
        for k in range(n):
            sel = inner & (band == k)
            if sel.any():
                keep += int(m[:, :, sel].all(-1).sum()) * int(sel.sum())
        tot = int(m[:, :, inner].sum())
        cache[key] = 1.0 - keep / max(tot, 1)
    return cache[key]


def _scan_fill(loops, Nu, Nv):
    """Innen/außen für Zellmitten aus geschlossenen Polygonen (gerade/ungerade, Gitterkoordinaten)."""
    cnt = np.zeros((Nu, Nv + 1), dtype=np.int32)
    for Q in loops:
        a, b = Q, np.roll(Q, -1, axis=0)
        u0, u1 = np.minimum(a[:, 0], b[:, 0]), np.maximum(a[:, 0], b[:, 0])
        r0 = np.ceil(u0 - 0.5).astype(int)
        r1 = np.ceil(u1 - 0.5).astype(int)            # Zeilen r mit u0 <= r+0.5 < u1
        nr = np.maximum(r1 - r0, 0)
        if not nr.sum():
            continue
        sid = np.repeat(np.arange(len(a)), nr)
        rr = np.repeat(r0, nr) + (np.arange(nr.sum()) - np.repeat(np.cumsum(nr) - nr, nr))
        uu = rr + 0.5
        t = (uu - a[sid, 0]) / (b[sid, 0] - a[sid, 0])
        vv = a[sid, 1] + t * (b[sid, 1] - a[sid, 1])
        col = np.clip(np.floor(vv - 0.5).astype(int) + 1, 0, Nv)
        ok = (rr >= 0) & (rr < Nu)
        np.add.at(cnt, (rr[ok], col[ok]), 1)
    return (np.cumsum(cnt[:, :Nv], axis=1) % 2).astype(bool)


def _poly_sdf(loops, mask, band=3.0):
    """Vorzeichenbehafteter Abstand (positiv innen, in Zellen) der Zellmitten zu den Polygonen: exakt nahe
    am Rand, weiter weg aus der Abstandstransformation."""
    from scipy.spatial import cKDTree
    Nu, Nv = mask.shape
    inside = _scan_fill(loops, Nu, Nv) if loops else np.zeros_like(mask)
    din = distance_transform_edt(inside)
    dout = distance_transform_edt(~inside)
    d = np.where(inside, din - 0.5, -(dout - 0.5))
    if not loops:
        return np.full(mask.shape, -band - 1.0)
    A = np.concatenate([Q for Q in loops])
    B = np.concatenate([np.roll(Q, -1, axis=0) for Q in loops])
    near = np.abs(d) < band
    if near.any():
        ln = np.linalg.norm(B - A, axis=1)
        k = np.maximum(1, np.ceil(ln / 0.25).astype(int))
        sid = np.repeat(np.arange(len(A)), k)
        t = (np.arange(k.sum()) - np.repeat(np.cumsum(k) - k, k) + 0.5) / np.repeat(k, k)
        S = A[sid] + t[:, None] * (B[sid] - A[sid])
        tree = cKDTree(S)
        ci, cj = np.nonzero(near)
        Pq = np.stack([ci + 0.5, cj + 0.5], 1)
        _, nn = tree.query(Pq, k=min(4, len(S)))
        nn = np.atleast_2d(nn).reshape(len(Pq), -1)
        best = np.full(len(Pq), np.inf)
        off = np.concatenate([[0], np.cumsum([len(Q) for Q in loops])])
        lid = np.searchsorted(off, np.arange(len(A)), side="right") - 1
        for col in range(nn.shape[1]):
            s0 = sid[nn[:, col]]
            for dd in (-1, 0, 1):
                L0 = lid[s0]
                n_l = off[L0 + 1] - off[L0]
                s = off[L0] + (s0 - off[L0] + dd) % n_l
                a, b = A[s], B[s]
                ab = b - a
                tt = np.clip(np.einsum("ij,ij->i", Pq - a, ab) / np.maximum(np.einsum("ij,ij->i", ab, ab), 1e-18), 0, 1)
                q = a + tt[:, None] * ab
                best = np.minimum(best, np.linalg.norm(Pq - q, axis=1))
        d[ci, cj] = np.where(inside[ci, cj], best, -best)
    return d


def build_multi(model, xp, level, sigma, sides, tool_mm, cell_mm=0.0, log=print, progress=None,
                max_voxels=8_000_000):
    """Fräsen prismatisch von mehreren Seiten: je Achse ein Stufenkörper (Taschen mit ebenem Boden und
    Wänden parallel zur Achse), das Teil ist Rohteil ∩ alle Stufenkörper. Abstandsfelder je Achse (Wände
    exakt aus den vereinfachten Konturen, Böden exakt in der Stufenebene) → Oberfläche."""
    from .engine import prism_bands, drop_floating_fine
    from .isosurface import marching_cubes
    step = progress or (lambda f, t: None)
    mesh, S = model.mesh, model.S
    sc, h = model.scale, model.h
    ext = mesh.hi - mesh.lo
    vol = float(np.prod(ext + 1e-12))
    c = float(cell_mm) / sc if cell_mm and cell_mm > 0 else h / 3.0
    c = max(c, (vol / max_voxels) ** (1 / 3), h / 8.0)
    lo, shape = G.grid_for(mesh.lo, mesh.hi, c, pad=3)
    shape = tuple(int(x) for x in shape)
    step(0.03, "Prism: part on fine raster")
    inside, _ = G.voxelize(mesh.tris, lo, c, shape, robust=bool(S.get("robust")) or not mesh.watertight)
    din = distance_transform_edt(inside).astype(np.float32)
    dout = distance_transform_edt(~inside).astype(np.float32)
    F = gaussian_filter(np.where(inside, din - 0.5, -(dout - 0.5)) * np.float32(c), 0.7).astype(np.float32)
    del din, dout, inside
    g = np.zeros(model.shape)
    g[model.ei, model.ej, model.ek] = xp
    dom = np.zeros(model.shape, dtype=bool)
    dom[model.ei, model.ej, model.ek] = True
    pas = np.zeros(model.shape, dtype=bool)
    pas[model.ei[model.passive], model.ej[model.passive], model.ek[model.passive]] = True
    cen = [lo[a] + (np.arange(shape[a]) + 0.5) * c for a in range(3)]
    tool_r = 0.5 * float(tool_mm or 0) / sc / c
    P = Prism()
    P.multi, P.sides, P.axes = True, sides, []
    nax = len(sides)
    for ia, axis in enumerate(sorted(sides)):
        sg = sides[axis]
        two = len(sg) == 2
        from_plus = 1 in sg and not two
        ou, ov = [a for a in range(3) if a != axis]
        step(0.1 + 0.6 * ia / nax, f"Prism: levels from {'XYZ'[axis]}")
        n, cut, _ = prism_bands(model, S, axis)
        z = [model.lo[axis] + l * h for l in cut]
        z[0] = max(z[0], mesh.lo[axis])
        z[-1] = min(z[-1], mesh.hi[axis])
        gm, dm, pm = (np.moveaxis(x, axis, -1) for x in (g, dom, pas))
        # Bandmaximum der Dichte (wie im Optimierer: Material in der Stufe → ganze Stufe)
        iu = (cen[ou] - model.lo[ou]) / h - 0.5
        iv = (cen[ov] - model.lo[ov]) / h - 0.5
        IU, IV = np.meshgrid(iu, iv, indexing="ij")
        Nu, Nv = shape[ou], shape[ov]
        raw, pasf = [], []
        for k in range(n):
            sl = slice(cut[k], cut[k + 1])
            D = np.where(dm[:, :, sl].any(-1), gm[:, :, sl].max(-1), 0.0)
            f = gaussian_filter(D, sigma) if sigma > 0 else D
            raw.append(map_coordinates(f, [IU.ravel(), IV.ravel()], order=1, mode="nearest").reshape(Nu, Nv) > level)
            pn = map_coordinates(pm[:, :, sl].any(-1).astype(float), [IU.ravel(), IV.ravel()], order=0,
                                 mode="nearest").reshape(Nu, Nv)
            pasf.append(pn > 0.5)
        full = [np.ones((Nu, Nv), dtype=bool)] * n
        masks = make_masks(raw, full, tool_r, from_plus, two, pasf, step_r=0.6 * h / c,
                           min_cells=int((h / c) ** 2))
        # Konturen aller Stufen in einem gemeinsamen Graphen (gleiche Wände bleiben deckungsgleich)
        W = Nv + 1
        Gr = Graph2D(W, 0.0, 0.0, 1.0)
        lids = []
        for k, m in enumerate(masks):
            a, b, _, _ = boundary_edges(m)
            lids.append([Gr.add(pts) for pts, _ in chain_loops(a, b, W)])
        Gr.solve()
        polys = []
        fk = []
        for k in range(n):
            Ls = [Gr.simplified(li) for li in lids[k]]
            Ls = [np.array([Gr.pos[v] for v in L]) for L in Ls if len(L) >= 3]
            polys.append(Ls)
            fk.append((_poly_sdf(Ls, masks[k]) * c).astype(np.float32))
        P.axes.append(dict(axis=axis, ou=ou, ov=ov, z=z, polys=polys, lo=lo.copy(), c=c, sides=sg))
        # Stufenkörper: Vereinigung der Scheiben je Stufe (und je zwei Nachbarstufen, damit an der
        # Stufengrenze keine Delle entsteht), Abstand in der Stufe = min(Wand, Boden, Deckel)
        w = cen[axis]
        Fa = np.full((Nu, Nv, shape[axis]), -3.0 * c, dtype=np.float32)
        for k0, k1 in [(k, k) for k in range(n)] + [(k, k + 1) for k in range(n - 1)]:
            zlo, zhi = (z[k0] if k0 > 0 else z[0] - 3 * c), (z[k1 + 1] if k1 < n - 1 else z[-1] + 3 * c)
            if k0 == 0:
                zlo = z[0] - 3 * c                      # Rohteilgrenze übernimmt das Bauteilfeld
            sel = np.flatnonzero((w > zlo - 3 * c) & (w < zhi + 3 * c))
            if not len(sel):
                continue
            fxy = fk[k0] if k0 == k1 else np.minimum(fk[k0], fk[k1])
            dw = np.minimum(w[sel] - zlo, zhi - w[sel]).astype(np.float32)
            sub = np.minimum(fxy[:, :, None], dw[None, None, :])
            Fa[:, :, sel] = np.maximum(Fa[:, :, sel], sub)
        Fa = np.moveaxis(Fa, -1, axis)
        np.minimum(F, Fa, out=F)
        del Fa
    step(0.75, "Prism: removing loose parts")
    F, _ = drop_floating_fine(model, F, lo, c, log=log)
    if F.max() <= 0:
        raise ValueError("No material in the prismatic result – check the threshold.")
    step(0.85, "Prism: surface")
    verts, faces, _, _ = marching_cubes(F, 0.0, spacing=(c, c, c))
    # Liegt die Oberfläche genau auf Rasterpunkten, fallen Punkte zusammen: verschmelzen und Dreiecke ohne
    # Fläche entfernen (sonst hätte das STEP Kanten der Länge null)
    key = np.round(verts / (1e-4 * c)).astype(np.int64)
    _, first, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    if len(first) < len(verts):
        verts, faces = verts[first], inv.ravel()[faces]
        faces = faces[(faces[:, 0] != faces[:, 1]) & (faces[:, 1] != faces[:, 2]) & (faces[:, 0] != faces[:, 2])]
    verts = verts + lo + 0.5 * c
    t = verts[faces]
    v6 = np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2])).sum() / 6.0
    if v6 < 0:
        faces = faces[:, ::-1]
    P.verts, P.tri = verts, np.ascontiguousarray(faces.astype(np.int64))
    P.volume = float(abs(v6))
    P.F, P.lo, P.c = F, lo, c
    P.pieces = int(label(F > 0)[1])
    P.z = P.axes[0]["z"]
    P.xb = _coarse_multi(model, P)
    _planar_faces(P)
    lv = ", ".join(f"{'XYZ'[a['axis']]}: {len(a['z']) - 1}" for a in P.axes)
    log(f"Prismatic result (several sides): depth levels {lv}, grid {c * sc:.2f} mm, "
        f"{len(P.faces3)} planar faces, {len(P.tri)} triangles")
    return P


def _coarse_multi(model, P):
    from .support_check import bridge_hinges
    sol = P.F > 0
    h = model.h
    idx = []
    for a in range(3):
        cc = P.lo[a] + (np.arange(sol.shape[a]) + 0.5) * P.c
        idx.append(np.clip(np.floor((cc - model.lo[a]) / h).astype(int), 0, model.shape[a] - 1))
    I, J, K = np.meshgrid(*idx, indexing="ij")
    lin = ((I * model.shape[1] + J) * model.shape[2] + K).ravel()
    nn = int(np.prod(model.shape))
    cnt = np.bincount(lin, minlength=nn).astype(float)
    hit = np.bincount(lin, weights=sol.ravel().astype(float), minlength=nn)
    g = (hit / np.maximum(cnt, 1)).reshape(model.shape) >= 0.3
    g &= model.emap >= 0
    g, _ = bridge_hinges(g, model.emap >= 0)
    return g[model.ei, model.ej, model.ek].astype(float)


def _planar_faces(P):
    """Ebene Flächen fürs STEP: benachbarte Dreiecke derselben Ebene zusammenfassen, Randschleifen."""
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components
    V, T = P.verts, P.tri
    nt = len(T)
    nrm = np.cross(V[T[:, 1]] - V[T[:, 0]], V[T[:, 2]] - V[T[:, 0]])
    ln = np.linalg.norm(nrm, axis=1)
    ok = ln > 1e-14
    nrm = nrm / np.maximum(ln, 1e-300)[:, None]
    d = np.einsum("ij,ij->i", nrm, V[T[:, 0]])
    e = np.concatenate([T[:, [0, 1]], T[:, [1, 2]], T[:, [2, 0]]])
    tid = np.tile(np.arange(nt), 3)
    key = e[:, 0].astype(np.int64) * len(V) + e[:, 1]
    rkey = e[:, 1].astype(np.int64) * len(V) + e[:, 0]
    order = np.argsort(key)
    pos = np.searchsorted(key[order], rkey)
    pos = np.clip(pos, 0, len(key) - 1)
    has = key[order][pos] == rkey
    other = np.where(has, tid[order][pos], -1)
    tol_d = 1e-4 * P.c
    same = has & ok[tid] & (other >= 0)
    o = np.maximum(other, 0)
    same &= ok[o] & (np.einsum("ij,ij->i", nrm[tid], nrm[o]) > 1 - 1e-7) & (np.abs(d[tid] - d[o]) < tol_d)
    A = coo_matrix((np.ones(int(same.sum())), (tid[same], o[same])), shape=(nt, nt))
    _, lab = connected_components(A, directed=False)
    faces = []
    bnd = ~same                                       # Kante liegt am Rand ihrer Flächengruppe
    eb, gb = e[bnd], lab[tid[bnd]]
    srt = np.argsort(gb, kind="stable")
    eb, gb = eb[srt], gb[srt]
    starts = np.flatnonzero(np.r_[True, gb[1:] != gb[:-1]])
    ends = np.r_[starts[1:], len(gb)]
    # Flächennormale je Gruppe (flächengewichtet)
    gn = np.zeros((lab.max() + 1, 3))
    np.add.at(gn, lab, nrm * ln[:, None])
    for s0, s1 in zip(starts, ends):
        grp = gb[s0]
        nx = gn[grp] / max(np.linalg.norm(gn[grp]), 1e-300)
        nxt = {}
        for a, b in eb[s0:s1].tolist():
            nxt.setdefault(a, []).append(b)
        loops = []
        while nxt:
            a0 = next(iter(nxt))
            L = [a0]
            cur = a0
            while True:
                lst = nxt.get(cur)
                if not lst:
                    break
                b = lst.pop()
                if not lst:
                    del nxt[cur]
                if b == a0:
                    break
                L.append(b)
                cur = b
            if len(L) >= 3:
                loops.append(L)
        if not loops:
            continue
        # Außenschleife: größte Fläche mit positivem Umlauf um die Normale
        ar = []
        for L in loops:
            Q = V[L]
            ar.append(float(np.cross(Q, np.roll(Q, -1, axis=0)).sum(0) @ nx) * 0.5)
        oi = int(np.argmax(ar))
        faces.append(dict(kind="flat", n=tuple(nx), outer=loops[oi], holes=[L for i, L in enumerate(loops) if i != oi]))
    P.faces3 = faces
    P.ou, P.ov, P.axis, P.flip = 0, 1, 2, False


def dxf_multi(P, scale=1.0):
    """DXF (R12) für mehrere Frässeiten: Konturen je Achse und Stufe auf eigenem Layer."""
    out = ["0", "SECTION", "2", "HEADER", "9", "$ACADVER", "1", "AC1009", "0", "ENDSEC",
           "0", "SECTION", "2", "ENTITIES"]
    for A in P.axes:
        ax, ou, ov, z = A["axis"], A["ou"], A["ov"], A["z"]
        for k, Ls in enumerate(A["polys"]):
            top = z[k + 1]
            nm = (f"{'XYZ'[ax]}_STUFE_{k + 1}_{(z[k] - z[0]) * scale:.2f}_{(top - z[0]) * scale:.2f}"
                  .replace(".", "_").replace("-", "M"))
            for Q in Ls:
                out += ["0", "POLYLINE", "8", nm, "66", "1", "10", "0.0", "20", "0.0", "30", "0.0", "70", "9"]
                for p in Q:
                    q = np.zeros(3)
                    q[ou] = A["lo"][ou] + p[0] * A["c"]
                    q[ov] = A["lo"][ov] + p[1] * A["c"]
                    q[ax] = top
                    q = q * scale
                    out += ["0", "VERTEX", "8", nm, "10", f"{q[0]:.4f}", "20", f"{q[1]:.4f}", "30", f"{q[2]:.4f}",
                            "70", "32"]
                out += ["0", "SEQEND", "8", nm]
    out += ["0", "ENDSEC", "0", "EOF"]
    return ("\n".join(out) + "\n").encode("ascii")
