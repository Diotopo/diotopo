# -*- coding: utf-8 -*-
"""
FE-Modell auf Voxeln (Hexaeder, linear-elastisch), Strukturanalyse und
Topologieoptimierung (SIMP, minimale gewichtete Nachgiebigkeit über alle Lastfälle).

Randbedingungen:  fest (je Richtung), reibungsfrei, Bolzen (radial/axial/tangential)
Lasten:           Kraft, Druck, Moment, Lagerlast, Fernkraft, Schwerkraft
Zonen:            massiv erhalten / frei halten (Fläche mit Tiefe oder Box)
Fertigung:        Symmetrie, Mindestwandstärke, 3D-Druck ohne Stützen,
                  einseitige Entformung/Fräsen, Extrusion (2,5D)
"""

import math
import time
import warnings

import numpy as np
import scipy.sparse as sp
from scipy.ndimage import convolve, distance_transform_edt, gaussian_filter, label
from scipy.spatial import cKDTree

from . import aniso as A
from . import geom as G
from . import support_check as SC
from . import perf as PF
from . import par as PR

LEN_MM = {"mm": 1.0, "cm": 10.0, "m": 1000.0, "in": 25.4}
FORCE_N = {"N": 1.0, "kN": 1000.0, "lbf": 4.4482216152605}
MOMENT_NMM = {"N": 1000.0, "kN": 1e6, "lbf": 4.4482216152605 * 25.4}       # N·m, kN·m, lbf·in
PRESSURE_MPA = {"N": 1.0, "kN": 1.0, "lbf": 0.00689475729}                  # MPa, MPa, psi
UNIT_LABELS = {"N": ("N", "N·m", "MPa"), "kN": ("kN", "kN·m", "MPa"), "lbf": ("lbf", "lbf·in", "psi")}

MATERIALS = {
    # Name: E [MPa], nu, Dichte [g/cm³], Streckgrenze [MPa],
    #       3D-Druck in Aufbaurichtung (zwischen den Schichten): E_z [MPa], Haftfestigkeit Zug S_z [MPa],
    #       Haftfestigkeit Schub S_zs [MPa]. Richtwerte aus Datenblättern/Literatur (stark druckabhängig).
    "Aluminium 6061-T6": (68900, 0.33, 2.70, 276, 68900, 276, 159),
    "Aluminium 7075-T6": (71700, 0.33, 2.81, 503, 71700, 503, 290),
    "Aluminium AlSi10Mg (SLM)": (70000, 0.33, 2.67, 230, 68000, 200, 115),
    "Steel S235": (210000, 0.30, 7.85, 235, 210000, 235, 136),
    "Steel S355": (210000, 0.30, 7.85, 355, 210000, 355, 205),
    "Steel 42CrMo4 (quenched and tempered)": (210000, 0.30, 7.85, 750, 210000, 750, 433),
    "Stainless steel 1.4301 (304)": (193000, 0.29, 8.00, 215, 193000, 215, 124),
    "Stainless steel 316L (SLM)": (190000, 0.30, 7.99, 450, 180000, 400, 230),
    "Titanium Ti-6Al-4V": (114000, 0.34, 4.43, 880, 110000, 820, 470),
    "Grey cast iron EN-GJL-250": (110000, 0.27, 7.20, 165, 110000, 165, 95),
    "Brass CuZn39Pb3": (97000, 0.34, 8.47, 250, 97000, 250, 144),
    "PLA (FDM)": (3500, 0.36, 1.24, 50, 3000, 25, 22),
    "PETG (FDM)": (2100, 0.38, 1.27, 45, 1800, 25, 22),
    "ABS (FDM)": (2300, 0.35, 1.05, 40, 1900, 18, 16),
    "ASA (FDM)": (2200, 0.35, 1.07, 45, 1800, 20, 18),
    # ASA-CF: Mittel aus Datenblättern (X-Y): E 3600–4200 MPa, Zugfestigkeit 34–44 MPa, Dichte 1,09 g/cm³.
    # In Z-Richtung (zwischen den Schichten) deutlich schwächer: E ≈ 1900–2300 MPa, ≈ 25–30 MPa.
    "ASA-CF (FDM)": (3800, 0.35, 1.09, 35, 2100, 27, 24),
    "PA12 (SLS/MJF)": (1700, 0.40, 1.01, 45, 1650, 42, 37),
    "PA12-CF (FDM)": (6000, 0.35, 1.15, 70, 2300, 30, 26),
    "TPU 95A (FDM)": (26, 0.45, 1.21, 8, 24, 6, 5),
    "Resin standard (SLA)": (2500, 0.38, 1.18, 55, 2450, 52, 46),
}

DEFAULTS = dict(
    unit_len="mm", unit_force="N",
    E=68900.0, nu=0.33, rho=2.70, yield_=276.0,
    resolution=40, volfrac=0.30, minwall_mm=0.0, max_iter=80,
    sym=[False, False, False],
    mfg="none", mfg_dir="z+", overhang=45, extrude="none",
    cnc_setups=1, cnc_tool_mm=6.0, cnc_depth_mm=0.0,
    keep_bc=True, bc_layers=1, bc_wall_mm=2.0,
    keep_holes=[], hole_wall_mm=2.0, refine=True, detail_mm=0.0,
    robust=False, case_weights={}, allow_split=False, safety_target=0.0,
    sigma=0.7, level=0.0,
    # 3D-Druck: Werkstoff in Aufbaurichtung (None = wie in der Schichtebene) und Schichthaftung
    E_z=None, S_z=None, S_zs=None, layer_opt=True,
    # 3D-Druck Erweitert: Randschichten [mm] und Infill
    shell_top_mm=0.8, shell_bottom_mm=0.8, shell_wall_mm=1.2, infill_pct=20.0, infill_pattern="grid",
    mass_mode=False,
    # Fräsen prismatisch: Tiefenstufen (Anzahl) oder feste Stufenhöhe [mm] (> 0 hat Vorrang)
    prism_levels=4, prism_step_mm=0.0,
)

EMIN = 1e-9
PEN = 3.0


# ================================================================ Element

_OFFS = np.array([(0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0),
                  (0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)])
_SGN = _OFFS * 2.0 - 1.0


def _B(xi, eta, ze):
    dN = np.empty((8, 3))
    s = _SGN
    dN[:, 0] = s[:, 0] * (1 + s[:, 1] * eta) * (1 + s[:, 2] * ze) / 8
    dN[:, 1] = s[:, 1] * (1 + s[:, 0] * xi) * (1 + s[:, 2] * ze) / 8
    dN[:, 2] = s[:, 2] * (1 + s[:, 0] * xi) * (1 + s[:, 1] * eta) / 8
    dN *= 2.0
    B = np.zeros((6, 24))
    for a in range(8):
        bx, by, bz = dN[a]
        B[0, 3 * a] = bx
        B[1, 3 * a + 1] = by
        B[2, 3 * a + 2] = bz
        B[3, 3 * a], B[3, 3 * a + 1] = by, bx
        B[4, 3 * a + 1], B[4, 3 * a + 2] = bz, by
        B[5, 3 * a], B[5, 3 * a + 2] = bz, bx
    return B


def material_D(nu):
    f = 1.0 / ((1 + nu) * (1 - 2 * nu))
    D = np.zeros((6, 6))
    D[:3, :3] = f * nu
    D[range(3), range(3)] = f * (1 - nu)
    D[3, 3] = D[4, 4] = D[5, 5] = f * (1 - 2 * nu) / 2
    return D


def hex8_stiffness(nu):
    return hex8_stiffness_D(material_D(nu))


def hex8_stiffness_D(D):
    """Elementsteifigkeit (Würfel, Kantenlänge 1) für eine beliebige (normierte) Werkstoffmatrix D."""
    g = 1.0 / math.sqrt(3.0)
    Ke = np.zeros((24, 24))
    for xi in (-g, g):
        for eta in (-g, g):
            for ze in (-g, g):
                B = _B(xi, eta, ze)
                Ke += B.T @ D @ B / 8.0
    return Ke


def build_filter(centers, rmin):
    n = len(centers)
    tree = cKDTree(centers)
    pairs = tree.query_pairs(rmin, output_type="ndarray")
    if len(pairs):
        d = np.linalg.norm(centers[pairs[:, 0]] - centers[pairs[:, 1]], axis=1)
        w = np.maximum(rmin - d, 0.0)
        rows = np.concatenate([pairs[:, 0], pairs[:, 1], np.arange(n)])
        cols = np.concatenate([pairs[:, 1], pairs[:, 0], np.arange(n)])
        data = np.concatenate([w, w, np.full(n, rmin)])
    else:
        rows = cols = np.arange(n)
        data = np.full(n, rmin)
    H = sp.csr_matrix((data, (rows, cols)), shape=(n, n))
    return H, np.asarray(H.sum(axis=1)).ravel()


class LayerFilter:
    """Schichtfilter (Langelaar) für 3D-Druck ohne Stützen (kind 'am') bzw.
    einseitige Entformung/Fräsen (kind 'cast'). Basis liegt der Richtung gegenüber."""
    P = 40.0
    EPS = 1e-6

    def __init__(self, ei, ej, ek, shape, axis, sign, kind, overhang=45):
        coords = [ei, ej, ek]
        others = [a for a in range(3) if a != axis]
        w = coords[axis]
        if sign < 0:
            w = shape[axis] - 1 - w
        self.u, self.v, self.w = coords[others[0]], coords[others[1]], w
        self.gshape = (shape[others[0]], shape[others[1]], shape[axis])
        if kind == "cast":
            self.K = np.ones((1, 1))
        else:
            r = 2 if overhang >= 60 else 1
            self.K = np.ones((2 * r + 1, 2 * r + 1))

    def _conv(self, a):
        return a if self.K.shape == (1, 1) else convolve(a, self.K, mode="constant")

    def forward(self, xv):
        P, eps = self.P, self.EPS
        X = np.zeros(self.gshape)
        X[self.u, self.v, self.w] = xv
        L = self.gshape[2]
        Xi = np.zeros_like(X)
        Sv = np.zeros_like(X)
        Ss = np.zeros_like(X)
        Dd = np.ones_like(X)
        Xi[:, :, 0] = X[:, :, 0]
        for l in range(1, L):
            S = self._conv(np.maximum(Xi[:, :, l - 1], 0.0) ** P)
            s = np.power(S, 1.0 / P)
            x = X[:, :, l]
            d = np.sqrt((x - s) ** 2 + eps)
            Xi[:, :, l] = 0.5 * (x + s - d + math.sqrt(eps))
            Sv[:, :, l], Ss[:, :, l], Dd[:, :, l] = S, s, d
        return Xi[self.u, self.v, self.w], (X, Xi, Sv, Ss, Dd)

    def backward(self, gv, cache):
        P = self.P
        X, Xi, Sv, Ss, Dd = cache
        Gr = np.zeros(self.gshape)
        Gr[self.u, self.v, self.w] = gv
        dX = np.zeros(self.gshape)
        L = self.gshape[2]
        carry = np.zeros(self.gshape[:2])
        for l in range(L - 1, 0, -1):
            g = Gr[:, :, l] + carry
            x, s, d, S = X[:, :, l], Ss[:, :, l], Dd[:, :, l], Sv[:, :, l]
            dX[:, :, l] = g * 0.5 * (1.0 - (x - s) / d)
            dL_ds = g * 0.5 * (1.0 + (x - s) / d)
            ok = S > 1e-250
            dsdS = np.zeros_like(S)
            dsdS[ok] = (1.0 / P) * S[ok] ** (1.0 / P - 1.0)
            carry = P * np.maximum(Xi[:, :, l - 1], 0.0) ** (P - 1.0) * self._conv(dL_ds * dsdS)
        dX[:, :, 0] = Gr[:, :, 0] + carry
        return dX[self.u, self.v, self.w]


class MillFilter:
    """3-Achs-Fräsen: Das Werkzeug erreicht einen Voxel nur, wenn in Werkzeugrichtung kein Material
    darüber liegt (keine Hinterschnitte). Material, an das das Werkzeug nicht herankommt, bleibt stehen:
        1 Aufspannung:  y(l) = max(x(l), y(l+1))                      (Zugang von der Werkzeugseite)
        2 Aufspannungen (gewendet): y(l) = min(max_{k≤l} x(k), max_{k≥l} x(k))   (Zugang von beiden Seiten)
    max/min werden glatt angenähert (differenzierbar), Schicht für Schicht über alle Säulen gleichzeitig.
    Säulenrichtung wie beim Schichtfilter: w wächst zur Werkzeugseite hin."""
    EPS = 1e-6

    def __init__(self, ei, ej, ek, shape, axis, sign, setups=1):
        coords = [ei, ej, ek]
        others = [a for a in range(3) if a != axis]
        w = coords[axis]
        if sign < 0:
            w = shape[axis] - 1 - w
        self.u, self.v, self.w = coords[others[0]], coords[others[1]], w
        self.gshape = (shape[others[0]], shape[others[1]], shape[axis])
        self.two = int(setups) >= 2

    def _smax(self, a, b):
        d = np.sqrt((a - b) ** 2 + self.EPS)
        return 0.5 * (a + b + d - math.sqrt(self.EPS)), d

    def _scan(self, X, reverse):
        """Laufendes glattes Maximum entlang der Säule (reverse: von der Werkzeugseite her)."""
        L = X.shape[2]
        Y = np.empty_like(X)
        D = np.ones_like(X)
        order = range(L - 1, -1, -1) if reverse else range(L)
        prev = None
        for l in order:
            if prev is None:
                Y[:, :, l] = X[:, :, l]
            else:
                Y[:, :, l], D[:, :, l] = self._smax(X[:, :, l], Y[:, :, prev])
            prev = l
        return Y, D

    def _scan_back(self, X, Y, D, G, reverse):
        L = X.shape[2]
        G = G.copy()
        gX = np.zeros_like(X)
        order = list(range(L - 1, -1, -1) if reverse else range(L))
        for i in range(len(order) - 1, 0, -1):          # rückwärts durch die Rekursion
            l, prev = order[i], order[i - 1]
            r = (X[:, :, l] - Y[:, :, prev]) / D[:, :, l]
            gX[:, :, l] += G[:, :, l] * 0.5 * (1 + r)
            G[:, :, prev] += G[:, :, l] * 0.5 * (1 - r)
        gX[:, :, order[0]] += G[:, :, order[0]]
        return gX

    def forward(self, xv):
        X = np.zeros(self.gshape)
        X[self.u, self.v, self.w] = xv
        Q, DQ = self._scan(X, reverse=True)              # Material darüber (Werkzeugseite)
        if not self.two:
            return Q[self.u, self.v, self.w], (X, Q, DQ)
        P, DP = self._scan(X, reverse=False)             # Material darunter (Gegenseite)
        d = np.sqrt((P - Q) ** 2 + self.EPS)
        Y = 0.5 * (P + Q - d + math.sqrt(self.EPS))      # glattes Minimum
        return Y[self.u, self.v, self.w], (X, Q, DQ, P, DP, d)

    def backward(self, gv, cache):
        G = np.zeros(self.gshape)
        G[self.u, self.v, self.w] = gv
        if not self.two:
            X, Q, DQ = cache
            g = self._scan_back(X, Q, DQ, G, reverse=True)
        else:
            X, Q, DQ, P, DP, d = cache
            r = (P - Q) / d
            g = (self._scan_back(X, P, DP, G * 0.5 * (1 - r), reverse=False)
                 + self._scan_back(X, Q, DQ, G * 0.5 * (1 + r), reverse=True))
        return g[self.u, self.v, self.w]

    def depth(self):
        """Abstand jedes Elements (in Voxeln) zur nächsten zugänglichen Seite des Rohteils."""
        top = self.w.max() - self.w
        if not self.two:
            return top
        return np.minimum(top, self.w - self.w.min())


class ToolClosing:
    """Werkzeugdurchmesser: morphologisches Schließen quer zur Werkzeugachse (Dilatation, dann Erosion
    mit einer Kreisscheibe vom Werkzeugradius). Lücken, Schlitze und Innenecken, in die der Fräser
    nicht passt, werden mit Material gefüllt. Glatt über exponentielle Mittelung (Sigmund 2007)."""
    BETA = 25.0

    def __init__(self, ei, ej, ek, axis, radius):
        c = np.stack([ei, ej, ek], 1).astype(float)
        c[:, axis] *= 1000.0                               # nur Nachbarn in derselben Schicht
        tree = cKDTree(c)
        pairs = tree.query_pairs(radius + 1e-9, output_type="ndarray")
        n = len(c)
        rows = np.concatenate([pairs[:, 0], pairs[:, 1], np.arange(n)]) if len(pairs) else np.arange(n)
        cols = np.concatenate([pairs[:, 1], pairs[:, 0], np.arange(n)]) if len(pairs) else np.arange(n)
        H = sp.csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n))
        self.H = PR.ThreadedCSR(H)
        self.Hs = np.asarray(H.sum(axis=1)).ravel()

    def _dil(self, x):
        E = np.exp(self.BETA * x)
        S = self.H @ E
        return np.log(S / self.Hs) / self.BETA, E, S

    def forward(self, x):
        d, E1, S1 = self._dil(x)                           # Dilatation
        b = 1.0 - d
        e, E2, S2 = self._dil(b)                           # Erosion = 1 − Dilatation(1 − ·)
        return 1.0 - e, (E1, S1, E2, S2)

    def backward(self, g, cache):
        E1, S1, E2, S2 = cache
        gd = E2 * (self.H @ (g / S2))
        return E1 * (self.H @ (gd / S1))


def prism_sides(S):
    """Frässeiten fürs prismatische Fräsen: {Achse: Menge der Vorzeichen}. Ohne Angabe (Projekte vor dem
    6-Seiten-Fräsen) aus Werkzeugrichtung und Aufspannungen."""
    sides = S.get("prism_sides")
    if sides is None:
        d = S.get("mfg_dir", "z+")
        sides = [d] + ([d[0] + ("-" if d[1] == "+" else "+")] if int(S.get("cnc_setups", 1) or 1) >= 2 else [])
    out = {}
    for sd in sides:
        if len(sd) == 2 and sd[0] in "xyz" and sd[1] in "+-":
            out.setdefault("xyz".index(sd[0]), set()).add(1 if sd[1] == "+" else -1)
    return out


def prism_bands(M, S, axis):
    """Gleich hohe Tiefenstufen entlang einer Achse: Stufe je Voxelschicht (Weltreihenfolge) und Grenzen."""
    L = M.shape[axis]
    step = float(S.get("prism_step_mm") or 0)
    n = int(round(L * M.h_mm / step)) if step > 0 else int(S.get("prism_levels") or 4)
    n = max(1, min(n, L))
    cut = [int(math.ceil(i * L / n)) for i in range(n + 1)]
    layer_band = np.searchsorted(np.asarray(cut[1:]), np.arange(L), side="right")
    return n, cut, layer_band


class PrismHull:
    """Fräsen prismatisch von bis zu 6 Seiten (3+2): Je Achse mit Frässeiten das 2,5D-Prisma, das die Fräser
    nicht wegnehmen können – je Stufe und Säule eine gemeinsame Dichte (Mittelwert, P = 1: ebener Boden; die
    Penalisierung treibt jede Stufe auf voll oder leer, die Ableitung bleibt für alle Voxel der Stufe gleich –
    ein schärferes Maximum, P > 1, ließ die Optimierung pendeln), Zugang von der/den Seite(n) (MillFilter), Fräserradius quer zur Achse (ToolClosing). Das Teil ist
    der Schnitt dieser Prismen (glattes Minimum über die Achsen) = Rohteil minus alle Taschen."""
    P = 1.0
    EPS = 1e-6

    def __init__(self, M, S, log):
        self.M = M
        self.axes = []
        sides = prism_sides(S)
        if not sides:
            raise ValueError("Prismatic milling: please select at least one milling side.")
        tool = float(S.get("cnc_tool_mm", 0) or 0)
        rv = 0.5 * tool / M.h_mm if tool > 0 else 0.0
        self.note = []
        if 0 < rv < 0.75:
            log(f"Note: Cutter Ø {tool:g} mm is smaller than one voxel ({M.h_mm:.2f} mm) – the diameter only takes effect "
                "at a higher resolution.")
        if rv > 8:
            log(f"Note: Cutter Ø {tool:g} mm = {2 * rv:.0f} voxels – to limit the computing time it is taken into account as "
                f"{16 * M.h_mm:.1f} mm.")
            rv = 8.0
        idx = [M.ei, M.ej, M.ek]
        reach = np.zeros(M.ne, dtype=bool)
        dmax = float(S.get("cnc_depth_mm", 0) or 0)
        for axis in sorted(sides):
            sg = sides[axis]
            two = len(sg) == 2
            sign = 1 if 1 in sg else -1
            mill = MillFilter(M.ei, M.ej, M.ek, M.shape, axis, sign, 2 if two else 1)
            n, cut, layer_band = prism_bands(M, S, axis)
            others = [a for a in range(3) if a != axis]
            band = layer_band[idx[axis]]
            gid = (idx[others[0]].astype(np.int64) * M.shape[others[1]] + idx[others[1]]) * n + band
            _, inv = np.unique(gid, return_inverse=True)
            tc = ToolClosing(M.ei, M.ej, M.ek, axis, rv) if rv >= 0.75 else None
            self.axes.append(dict(axis=axis, sides=sg, mill=mill, inv=inv, cnt=np.bincount(inv), n=n, cut=cut,
                                  tool=tc))
            if dmax > 0:
                top = mill.w.max() - mill.w                 # Abstand zur Seite, aus der das Werkzeug kommt
                reach |= top * M.h_mm <= dmax
                if two:
                    reach |= (mill.w - mill.w.min()) * M.h_mm <= dmax
        self.dmax = dmax
        if dmax > 0:
            deep = ~reach
            if deep.mean() >= S["volfrac"] * 0.98:
                raise ValueError(f"With a max. milling depth of {dmax:g} mm the cutters only reach {(1 - deep.mean()) * 100:.0f} % "
                                 "of the part – the rest stays solid and is already above the target volume. Increase the milling "
                                 "depth, select more milling sides or increase the target volume.")
            if deep.any():
                M.passive = M.passive | deep
                self.note.append(f"max. milling depth {dmax:g} mm ({deep.mean() * 100:.0f} % remain solid)")
        self.tool_mm = tool if rv >= 0.75 else 0.0
        # massive Bereiche gelten als ganzer Stufenkörper (sonst wären Böden und Wände dort nicht eben) –
        # so rechnet die Optimierung mit genau dem Material, das im Ergebnis stehen bleibt
        if M.passive.any():
            full = self.hull(M.passive) > 0.5
            add = full & ~M.passive
            if add.any():
                M.passive = M.passive | full
                self.note.append(f"solid zones extended to whole levels (+{int(add.sum())} voxels)")

    def describe(self):
        sides = []
        for a in self.axes:
            sides += ["xyz"[a["axis"]] + ("+" if s > 0 else "-") for s in sorted(a["sides"], reverse=True)]
        lv = ", ".join(f"{'XYZ'[a['axis']]} {a['n']}" for a in self.axes)
        return (f"Prismatic milling from {len(sides)} side(s) ({' '.join(sides)}), flat floors and perpendicular walls per "
                f"side, depth levels {lv}"
                + (f", cutter Ø {self.tool_mm:g} mm (smallest pocket/inner corner)" if self.tool_mm else "")
                + ("; " + "; ".join(self.note) if self.note else ""))

    def hull(self, mask):
        """Stufenkörper eines festen Bereichs (0/1): was die Fräser davon stehen lassen müssen."""
        p, self.P = self.P, 200.0
        try:
            return (self.forward(np.asarray(mask, dtype=float))[0] > 0.5).astype(float)
        finally:
            self.P = p

    def _pmax(self, a, x):
        """Glattes Maximum je Stufe und Säule: p-Mittel (bei gleichen Werten exakt)."""
        p = self.P
        xs = np.maximum(x, 0.0)
        m = np.bincount(a["inv"], weights=xs ** p) / a["cnt"]
        y = m ** (1.0 / p)
        return y[a["inv"]], (xs, y)

    def _pmax_back(self, a, g, cache):
        p = self.P
        xs, y = cache
        gg = np.bincount(a["inv"], weights=g)            # Summe der Ableitungen je Gruppe
        yy = np.maximum(y, 1e-12)
        return (gg / a["cnt"])[a["inv"]] * xs ** (p - 1.0) * yy[a["inv"]] ** (1.0 - p)

    def forward(self, xf):
        ys, cs = [], []
        for a in self.axes:
            y, c0 = self._pmax(a, xf)
            y, c1 = a["mill"].forward(y)
            c = [c0, c1]
            if a["tool"] is not None:
                y, c2 = a["tool"].forward(y)
                y, c3 = a["mill"].forward(y)
                c += [c2, c3]
            ys.append(y)
            cs.append(c)
        # Schnitt der Prismen: glattes Minimum (paarweise)
        m = ys[0]
        mc = []
        for y in ys[1:]:
            d = np.sqrt((m - y) ** 2 + self.EPS)
            mc.append((m, y, d))
            m = 0.5 * (m + y - d + math.sqrt(self.EPS))
        return m, (cs, mc)

    def backward(self, g, cache):
        cs, mc = cache
        gs = [None] * len(self.axes)
        for i in range(len(mc) - 1, -1, -1):           # Minimum rückwärts
            m, y, d = mc[i]
            r = (m - y) / d
            gs[i + 1] = g * 0.5 * (1 + r)
            g = g * 0.5 * (1 - r)
        gs[0] = g
        out = np.zeros(self.M.ne)
        for a, c, gy in zip(self.axes, cs, gs):
            if a["tool"] is not None:
                gy = a["mill"].backward(gy, c[3])
                gy = a["tool"].backward(gy, c[2])
            gy = a["mill"].backward(gy, c[1])
            out += self._pmax_back(a, gy, c[0])
        return out


# ================================================================ Löser

from .solver import Solver, Stopped  # noqa: E402,F401


def axis_vec(d):
    v = np.zeros(3)
    v["xyz".index(d[0])] = 1.0 if d[1] == "+" else -1.0
    return v


# ================================================================ Modell

class Model:
    """Voxel-FE-Modell inkl. Randbedingungen aller Lastfälle."""

    def __init__(self, mesh, settings, conditions, log=print):
        self.mesh = mesh
        self.S = {**DEFAULTS, **(settings or {})}
        self.conds = list(conditions)
        self.log = log
        nt = len(mesh.tris)
        for c in self.conds:
            t = c.get("tris")
            if t is not None and len(t) and (int(np.max(t)) >= nt or int(np.min(t)) < 0):
                raise ValueError("Supports/loads do not match the loaded part (e.g. project from an older "
                                 "version or a STEP file meshed differently). Please assign the faces again.")
        keep = self.S.get("keep_holes")
        if keep:
            holes = G.find_holes(mesh)
            if keep is True or keep == "all":
                sel = list(range(len(holes)))
            else:
                sel = [int(i) for i in keep if 0 <= int(i) < len(holes)]
            if sel:
                wall = float(self.S.get("hole_wall_mm", 2.0) or 0)
                sc = LEN_MM[self.S["unit_len"]]
                for i in sel:
                    self.conds.append(dict(type="solid", tris=holes[i]["tris"], depth=wall, _hole=True))
                dm = ", ".join("%.1f" % (2 * holes[i]["radius"] * sc) for i in sel[:8])
                log(f"{len(sel)} hole(s) kept with {wall:g} mm ring (Ø {dm} mm)")
        self._prepare()

    # ------------------------------------------------------------ Aufbau
    def _prepare(self):
        S, log, mesh = self.S, self.log, self.mesh
        self.scale = LEN_MM[S["unit_len"]]
        uf = S["unit_force"]
        self.f_scale, self.m_scale, self.p_scale = FORCE_N[uf], MOMENT_NMM[uf], PRESSURE_MPA[uf]
        d = mesh.hi - mesh.lo
        log(f"Part: {d[0]:.2f} × {d[1]:.2f} × {d[2]:.2f} {S['unit_len']}, {len(mesh.tris)} triangles")

        h = float(d.max()) / int(S["resolution"])
        lo, shape = G.grid_for(mesh.lo, mesh.hi, h)
        solid, odd = G.voxelize(mesh.tris, lo, h, shape, robust=bool(S["robust"]))
        if not S["robust"] and (odd > 0.02 or not mesh.watertight):
            alt, _ = G.voxelize(mesh.tris, lo, h, shape, robust=True)
            if odd > 0.02 or alt.sum() >= 0.8 * solid.sum():
                log("Mesh not closed – using robust wrapping.")
                solid = alt
        self.lo, self.h = lo, h
        self.h_mm = h * self.scale

        ei, ej, ek = np.nonzero(solid)
        centers = lo + (np.stack([ei, ej, ek], 1) + 0.5) * h
        remove = np.zeros(len(ei), dtype=bool)
        for c in self.conds:
            if c["type"] == "void":
                r = max(float(c.get("depth", 0) or 0) / self.scale, 0.75 * h)
                pts, _ = self._samples(c, h)
                if len(pts):
                    dist, _ = cKDTree(pts).query(centers, distance_upper_bound=r)
                    remove |= np.isfinite(dist)
            elif c["type"] == "box_void":
                remove |= self._in_box(centers, c)
        allowed = np.ones(shape, dtype=bool)
        if remove.any():
            solid[ei[remove], ej[remove], ek[remove]] = False
            allowed[ei[remove], ej[remove], ek[remove]] = False
            log(f"Empty zones: {int(remove.sum())} voxels removed")
        solid = self._repair_voxels(solid, allowed, lo, h)
        ei, ej, ek = np.nonzero(solid)
        ne = len(ei)
        if ne == 0:
            raise ValueError("No voxels are left.")
        self._check_memory(ne, h * self.scale)
        self.ei, self.ej, self.ek, self.ne, self.shape = ei, ej, ek, ne, shape
        self.solid = solid
        log(f"Voxel grid {shape[0]}×{shape[1]}×{shape[2]}, voxel size {self.h_mm:.3f} mm, {ne} elements")

        ny, nz = shape[1], shape[2]
        nid = ((ei[:, None] + _OFFS[:, 0]) * (ny + 1) + (ej[:, None] + _OFFS[:, 1])) * (nz + 1) \
            + (ek[:, None] + _OFFS[:, 2])
        used, inv = np.unique(nid, return_inverse=True)
        self.enodes = np.asarray(inv).reshape(ne, 8)
        self.nn = len(used)
        nc = np.stack([used // ((ny + 1) * (nz + 1)), (used // (nz + 1)) % (ny + 1), used % (nz + 1)], 1)
        self.ncoord = nc
        self.npos = lo + nc * h
        self.ndof = 3 * self.nn
        self.edof = (self.enodes[:, :, None] * 3 + np.arange(3)).reshape(ne, 24)
        valence = np.bincount(self.enodes.ravel(), minlength=self.nn)
        self.bnodes = np.flatnonzero(valence < 8)
        self.btree = cKDTree(self.npos[self.bnodes])
        self.ecent = lo + (np.stack([ei, ej, ek], 1) + 0.5) * h
        emap = -np.ones(shape, dtype=np.int64)
        emap[ei, ej, ek] = np.arange(ne)
        self.emap = emap

        self._material()
        self.kpen = 1e5 * float(self.Ke[0, 0]) * 8.0
        self._boundary_conditions()
        self._check_supports()
        self._build_assembly()

    def _material(self):
        """Werkstoffmatrix (isotrop bzw. beim 3D-Druck transversal isotrop in Aufbaurichtung),
        Schichthaftung und – bei 3D-Druck Erweitert – Infill und Randschichten."""
        S, log = self.S, self.log
        self.D = A.material_matrix(S)
        self.Ke = self.Ke_true = hex8_stiffness_D(self.D)
        self.Ke_opt = None
        self.layer = None
        self.shell = None
        self.D2 = self.Ke2 = None
        if not A.is_am(S):
            return
        axis = "xyz".index(S["mfg_dir"][0])
        sign = 1 if S["mfg_dir"][1] == "+" else -1
        st, ss = A.strengths(S)
        self.layer = dict(axis=axis, St=st, Ss=ss)
        ez = A.ez_ratio(S) * float(S["E"])
        log(f"3D-printing material: E {float(S['E']):.0f} MPa in the layer plane, {ez:.0f} MPa in build direction "
            f"{S['mfg_dir']}; layer adhesion {st:g} MPa tension, {ss:g} MPa shear")
        if S.get("layer_opt", True):
            Dd = A.design_matrix(S)
            if Dd is not None:
                self.Ke_opt = hex8_stiffness_D(Dd)
        if S["mfg"] != "am_adv":
            return
        self.D2 = A.infill_matrix(S)
        self.Ke2 = hex8_stiffness_D(self.D2)
        sc = 1.0 / self.h_mm
        tt, tb, tw = (float(S.get(k) or 0) for k in ("shell_top_mm", "shell_bottom_mm", "shell_wall_mm"))
        self.shell = A.ShellMap(self.ei, self.ej, self.ek, self.shape, self.emap, axis, sign,
                                tt * sc, tb * sc, tw * sc)
        exy, ezi = A.infill_moduli(S)
        name = A.PATTERNS.get(S.get("infill_pattern"), A.PATTERNS["grid"])[0]
        log(f"Shells: top {tt:g} mm, bottom {tb:g} mm, walls {tw:g} mm · infill {name} "
            f"{float(S.get('infill_pct', 20)):g} %: E ≈ {exy:.0f} MPa in the layer plane, ≈ {ezi:.0f} MPa across "
            "the layers")
        thin = [v for v in (tt, tb, tw) if v > 0]
        if thin and min(thin) < 0.5 * self.h_mm:
            log(f"Note: The shells are thinner than one computation voxel ({self.h_mm:.2f} mm) – they are "
                "computed as a fraction of each voxel; increase the resolution for more accurate results.")
        if self.shell.clipped:
            log(f"Note: Shells thicker than {A.ShellMap.KMAX} voxels are computed with {A.ShellMap.KMAX} voxels.")

    def design(self, on):
        """Optimierung mit festigkeitsgewichtetem Werkstoff (Schichthaftung), Analyse mit dem echten."""
        if self.Ke_opt is None:
            return
        self.Ke = self.Ke_opt if on else self.Ke_true
        self.ktri = self.ktri_opt if on else self.ktri_true

    def split_E(self, Eb, xp):
        """Elementsteifigkeiten: (Wand-/Vollmaterial, Infill, Randanteil s). Ohne Infill: (Eb, None, None)."""
        if self.shell is None:
            return Eb, None, None
        s, _ = self.shell.forward(xp)
        return Eb * s, Eb * (1.0 - s), s

    def _check_memory(self, ne, h_mm):
        """Grenze nach freiem Arbeitsspeicher statt fester Elementzahl."""
        S = dict(self.S, _h_mm=h_mm)
        need = PF.fe_memory(ne, S, refine=bool(self.S.get("refine")))
        avail, total = PF.ram()
        self.log(f"Memory required ≈ {need / 2**30:.1f} GB" +
                 (f" (free: {avail / 2**30:.1f} GB of {total / 2**30:.1f} GB)" if avail else ""))
        if avail and need > avail * PF.RAM_USE:
            mx, _ = PF.max_elements(S, refine=bool(self.S.get("refine")))
            res = int(self.S["resolution"])
            rmax = max(16, int(res * (mx / ne) ** (1 / 3)))
            nes = f"{ne:,}".replace(",", ".")
            raise ValueError(f"{nes} elements need ≈ {need / 2**30:.1f} GB of memory, free are "
                             f"{avail / 2**30:.1f} GB. Please reduce the resolution to at most ≈ {rmax} "
                             "or close other programs.")

    def _repair_voxels(self, solid, allowed, lo, h):
        """Kanten-/Eckkontakte überbrücken und Bereiche ohne Lager entfernen."""
        from scipy.ndimage import label as _label
        log = self.log
        solid, added = SC.bridge_hinges(solid, allowed)
        if added:
            log(f"Computation grid repaired: {added} voxels added where regions only touched at edges/corners "
                "(otherwise hinges in the FE model).")
        lab, n = _label(solid)
        if n <= 1:
            return solid
        ei, ej, ek = np.nonzero(solid)
        el = lab[ei, ej, ek]
        cent = lo + (np.stack([ei, ej, ek], 1) + 0.5) * h
        tree = cKDTree(cent)

        def touched(types):
            hit = np.zeros(n + 1, dtype=bool)
            for c in self.conds:
                if c["type"] in types and c.get("tris") is not None:
                    pts, _ = self._samples(c, h)
                    if len(pts):
                        dist, j = tree.query(pts, distance_upper_bound=1.9 * h)
                        hit[el[j[np.isfinite(dist)]]] = True
            return hit

        sup = touched(("fixed", "frictionless", "pin"))
        lod = touched(("load",))
        sizes = np.bincount(el, minlength=n + 1)
        bad = [k for k in range(1, n + 1) if lod[k] and not sup[k]]
        if bad and sup[1:].any():
            k = max(bad, key=lambda q: sizes[q])
            pc = cent[el == k].mean(0) * self.scale
            raise ValueError(
                "A loaded region is not connected to a supported region in the computation grid "
                f"(at approx. {pc[0]:.1f} / {pc[1]:.1f} / {pc[2]:.1f} mm). Usually the connection is thinner than "
                f"one voxel size ({h * self.scale:.2f} mm) – please increase the resolution. If they really are "
                "separate parts, each needs its own support.")
        drop = np.array([not sup[k] for k in range(n + 1)])
        drop[0] = False
        if sup[1:].any() and drop.any():
            rm = drop[el]
            solid = solid.copy()
            solid[ei[rm], ej[rm], ek[rm]] = False
            log(f"Note: {int(drop.sum())} loose region(s) without support ({int(rm.sum())} voxels) "
                "are not included in the computation.")
        return solid

    def _check_supports(self):
        """Lastunabhängige Prüfung: halten die Lager jeden Bereich gegen alle Starrkörperbewegungen?"""
        from scipy.ndimage import label as _label
        m = np.zeros(self.shape, dtype=bool)
        m[self.ei, self.ej, self.ek] = True
        lab, n = _label(m)
        el = lab[self.ei, self.ej, self.ek]
        node_comp = np.zeros(self.nn, dtype=np.int64)
        node_comp[self.enodes.ravel()] = np.repeat(el, 8)
        fixed_set = np.zeros(self.nn, dtype=bool)
        fixed_set[self.fixed_nodes_all] = True
        F0 = self.loads(np.ones(self.ne))
        types = {c["type"] for c in self.conds}
        for key, ks in self.groups.items():
            elim = self.elim
            Kp = self.Kpen[key]
            for comp in range(1, min(n, 50) + 1):
                nodes = np.flatnonzero(node_comp == comp)
                if len(nodes) == 0:
                    continue
                sn = nodes[fixed_set[nodes]]
                center = self.npos[sn].mean(0) if len(sn) else None
                free_m, null = SC.rigid_modes(self.npos, nodes, elim, Kp, self.dmap, self.kpen, center)
                if not free_m:
                    continue
                # Regen die Lasten diese Bewegungen an? Sonst nur ein Hinweis (Rechnung bleibt eindeutig).
                p = self.npos[nodes]
                c = p.mean(0) if center is None else center
                Lc = max(float(np.linalg.norm(p.max(0) - p.min(0))), 1e-12)
                d = (p - c) / Lc
                dofs = (nodes[:, None] * 3 + np.arange(3)).ravel()
                Fc = F0[dofs][:, ks]
                work = 0.0
                for j in range(null.shape[1]):
                    t, r = null[:3, j], null[3:, j]
                    u = (t[None, :] + np.cross(r[None, :], d)).ravel()
                    work = max(work, float(np.abs(u @ Fc).max()) / max(float(np.abs(Fc).sum()), 1e-300))
                txt = SC.describe(free_m, self.scale)
                where = ""
                if n > 1:
                    pc = p.mean(0) * self.scale
                    where = f" (region at approx. {pc[0]:.1f} / {pc[1]:.1f} / {pc[2]:.1f} mm)"
                case = f" in load case {key}" if key else ""
                if work < 1e-6:
                    self.log(f"Note: The part{where} can still move freely{case}: {txt}. The loads "
                             "do not excite this motion – the computation is still unique.")
                    continue
                tips = []
                if "pin" in types and any(k == "rot" for k, _, _ in free_m):
                    tips.append("A pin support leaves the rotation about the pin free – lock “tangential” "
                                "or add a second support")
                if "frictionless" in types:
                    tips.append("frictionless supports only hold perpendicular to the face")
                if any(c["type"] == "fixed" and not all(c.get("dofs", [1, 1, 1])) for c in self.conds):
                    tips.append("with “Fixed” not all directions are locked")
                if not len(sn):
                    tips.append("no support acts on this region")
                raise ValueError(f"The part{where} is not sufficiently supported{case}: it can still move "
                                 f"freely: {txt}." + (" Note: " + "; ".join(tips) + "." if tips else
                                                   " Please add another support or lock directions."))

    def _samples(self, c, h):
        tris = self.mesh.tris[np.asarray(c["tris"], dtype=np.int64)]
        return G.sample_triangles(tris, 0.5 * h)

    def _in_box(self, pts, c):
        lo = np.asarray(c["min"], float)
        hi = np.asarray(c["max"], float)
        return np.all((pts >= lo) & (pts <= hi), axis=1)

    def _support_nodes(self, c):
        pts, _ = self._samples(c, self.h)
        if len(pts) == 0:
            raise ValueError("A boundary condition contains no face.")
        dist, _ = cKDTree(pts).query(self.npos[self.bnodes], distance_upper_bound=1.0 * self.h)
        nodes = self.bnodes[np.isfinite(dist)]
        if len(nodes) == 0:   # Fläche liegt im Inneren des Gitters (z. B. kleine Bohrung)
            dist, _ = cKDTree(pts).query(self.npos, distance_upper_bound=1.0 * self.h)
            nodes = np.flatnonzero(np.isfinite(dist))
        if len(nodes) == 0:
            raise ValueError("A selected face does not lie on the voxel grid – "
                             "increase the resolution or check the face.")
        return nodes

    def _load_points(self, c):
        """Stützpunkte einer Lastfläche mit Flächengewicht (mm²), Normale und Knotenzuordnung."""
        idx = np.asarray(c["tris"], dtype=np.int64)
        tris = self.mesh.tris[idx]
        pts, owner = G.sample_triangles(tris, 0.4 * self.h)
        cnt = np.bincount(owner, minlength=len(idx))
        w = self.mesh.area[idx][owner] / cnt[owner] * self.scale ** 2
        nrm = self.mesh.normals[idx][owner]
        dist, j = self.btree.query(pts, distance_upper_bound=1.5 * self.h)
        ok = np.isfinite(dist)
        nodes = self.bnodes
        if ok.mean() < 0.5:   # Fläche kleiner als das Rechengitter (z. B. kleine Bohrung)
            if not hasattr(self, "_ntree"):
                self._ntree = cKDTree(self.npos)
            dist, j = self._ntree.query(pts, distance_upper_bound=1.5 * self.h)
            ok = np.isfinite(dist)
            nodes = np.arange(self.nn)
        if not ok.any():
            raise ValueError("A load face does not lie on the voxel grid – increase the resolution.")
        return pts[ok] * self.scale, w[ok], nrm[ok], nodes[j[ok]]

    def _dir(self, c, avg_normal):
        d = c.get("dir", "z-")
        if d == "n_in":
            return -avg_normal
        if d == "n_out":
            return avg_normal
        if d == "custom":
            v = np.asarray(c.get("vec", [0, 0, -1]), float)
            n = np.linalg.norm(v)
            if n == 0:
                raise ValueError("The direction vector of a load is zero.")
            return v / n
        return axis_vec(d)

    def _boundary_conditions(self):
        S, log = self.S, self.log
        cases = sorted({int(c.get("case", 1)) for c in self.conds if c["type"] in ("load", "gravity")})
        if not cases:
            raise ValueError("Please define at least one load.")
        self.cases = cases
        ci = {k: i for i, k in enumerate(cases)}
        nc = len(cases)
        F = np.zeros((self.ndof, nc))
        self.grav = np.zeros((nc, 3))        # Beschleunigung je Lastfall [N/mm³ pro Dichte 1]
        elim = np.zeros(self.ndof, dtype=bool)
        pen = {}                              # Lastfall (0 = alle) -> Liste (Knoten, 3x3 Blöcke)
        bc_nodes, fixed_nodes, load_nodes = [], [], []
        passive = np.zeros(self.ne, dtype=bool)
        n_sup = 0

        for c in self.conds:
            t = c["type"]
            case = int(c.get("case", 0 if t in ("fixed", "frictionless", "pin") else 1))
            if t in ("fixed", "frictionless", "pin"):
                if case and case not in ci:
                    log(f"Note: Support for load case {case} without loads is ignored.")
                    continue
                nodes = self._support_nodes(c)
                n_sup += 1
                bc_nodes.append(nodes)
                fixed_nodes.append(nodes)
                if t == "fixed":
                    dofs = c.get("dofs", [1, 1, 1])
                    if case == 0:
                        for a in range(3):
                            if dofs[a]:
                                elim[nodes * 3 + a] = True
                    else:
                        D = np.diag([float(bool(x)) for x in dofs])
                        pen.setdefault(case, []).append((nodes, np.broadcast_to(D, (len(nodes), 3, 3))))
                    log(f"Fixed support ({''.join(a for a, f in zip('XYZ', dofs) if f)}): {len(nodes)} nodes"
                        + (f", load case {case}" if case else ""))
                elif t == "frictionless":
                    pts, _, nrm, nod = self._load_points(c)
                    acc = np.zeros((self.nn, 3))
                    np.add.at(acc, nod, nrm)
                    nn_ = acc[nodes]
                    ln = np.linalg.norm(nn_, axis=1)
                    has = ln > 1e-12
                    if not has.any():
                        nn_ = np.tile(np.asarray(self.mesh.face_summary(c["tris"])["normal"] or [0, 0, 1]),
                                      (len(nodes), 1))
                        has[:] = True
                        ln = np.ones(len(nodes))
                    nodes2 = nodes[has]
                    nv = nn_[has] / ln[has][:, None]
                    pen.setdefault(case, []).append((nodes2, nv[:, :, None] * nv[:, None, :]))
                    log(f"Frictionless support: {len(nodes2)} nodes")
                else:  # pin
                    info = self.mesh.face_summary(c["tris"])
                    cyl = info.get("cylinder")
                    if cyl is None:
                        raise ValueError("A pin support needs a cylindrical face (hole or shaft).")
                    ax = np.asarray(cyl["axis"])
                    p0 = np.asarray(cyl["point"])
                    r = self.npos[nodes] - p0
                    r -= (r @ ax)[:, None] * ax
                    rl = np.linalg.norm(r, axis=1)
                    ok = rl > 1e-12
                    nodes, r = nodes[ok], r[ok] / rl[ok][:, None]
                    tg = np.cross(ax, r)
                    blk = np.zeros((len(nodes), 3, 3))
                    if c.get("radial", 1):
                        blk += r[:, :, None] * r[:, None, :]
                    if c.get("axial", 1):
                        blk += ax[None, :, None] * ax[None, None, :]
                    if c.get("tangential", 0):
                        blk += tg[:, :, None] * tg[:, None, :]
                    pen.setdefault(case, []).append((nodes, blk))
                    log(f"Pin support (r = {cyl['radius'] * self.scale:.2f} mm): {len(nodes)} nodes")

            elif t == "load":
                k = ci[case]
                kind = c.get("kind", "force")
                val = float(c.get("value", c.get("force", 0.0)) or 0.0)
                pts, w, nrm, nod = self._load_points(c)
                load_nodes.append(np.unique(nod))
                bc_nodes.append(np.unique(nod))
                navg = (nrm * w[:, None]).sum(0)
                nl = np.linalg.norm(navg)
                navg = navg / nl if nl > 0 else np.array([0, 0, 1.0])
                f = np.zeros((len(pts), 3))
                if kind == "force":
                    dvec = self._dir(c, navg)
                    f = np.outer(w / w.sum(), dvec * val * self.f_scale)
                    desc = f"Force {val:g} {S['unit_force']}"
                elif kind == "pressure":
                    f = -nrm * (w * val * self.p_scale)[:, None]
                    desc = f"Pressure {val:g} {UNIT_LABELS[S['unit_force']][2]}"
                elif kind == "bearing":
                    dvec = self._dir(c, navg)
                    ww = w * np.maximum(0.0, -(nrm @ dvec))
                    if ww.sum() <= 0:
                        raise ValueError("Bearing load: no face points against the load direction.")
                    f = np.outer(ww / ww.sum(), dvec * val * self.f_scale)
                    desc = f"Bearing load {val:g} {S['unit_force']}"
                elif kind in ("moment", "remote"):
                    cen = (pts * w[:, None]).sum(0) / w.sum()
                    if kind == "moment":
                        info = self.mesh.face_summary(c["tris"])
                        if c.get("dir") == "face_axis":
                            cyl = info.get("cylinder")
                            av = np.asarray(cyl["axis"]) if cyl else navg
                        else:
                            av = self._dir(c, navg)
                        Mv = av * val * self.m_scale
                        Fv = np.zeros(3)
                        desc = f"Moment {val:g} {UNIT_LABELS[S['unit_force']][1]}"
                    else:
                        dvec = self._dir(c, navg)
                        Fv = dvec * val * self.f_scale
                        P = np.asarray(c.get("point", cen / self.scale), float) * self.scale
                        Mv = np.cross(P - cen, Fv)
                        desc = f"Remote force {val:g} {S['unit_force']}"
                    f = np.outer(w / w.sum(), Fv)
                    Mn = np.linalg.norm(Mv)
                    if Mn > 0:
                        a = Mv / Mn
                        r = pts - cen
                        rp = r - (r @ a)[:, None] * a
                        D = (w * (rp ** 2).sum(1)).sum()
                        if D <= 0:
                            raise ValueError("Moment: face has no lever arm about the axis.")
                        f += np.cross(Mv, r) * (w / D)[:, None]
                else:
                    raise ValueError(f"Unknown load type “{kind}”.")
                for a in range(3):
                    np.add.at(F[:, k], nod * 3 + a, f[:, a])
                tot = f.sum(0)
                log(f"Load case {case}: {desc} on {len(np.unique(nod))} nodes, "
                    f"Sum ({tot[0]:.4g}, {tot[1]:.4g}, {tot[2]:.4g}) N")
            elif t == "gravity":
                k = ci[case]
                acc = float(c.get("g", 1.0)) * 9.81e-6 * float(S["rho"])  # N/mm³
                self.grav[k] += axis_vec(c.get("dir", "z-")) * acc if c.get("dir") != "custom" else \
                    np.asarray(c.get("vec"), float) / np.linalg.norm(c.get("vec")) * acc
                log(f"Load case {case}: gravity {float(c.get('g', 1.0)):g} g")
            elif t == "solid":
                r = max(float(c.get("depth", 0) or 0) / self.scale, 1.0 * self.h)
                pts, _ = self._samples(c, self.h)
                if len(pts):
                    dist, _ = cKDTree(pts).query(self.ecent, distance_upper_bound=r)
                    passive |= np.isfinite(dist)
            elif t == "box_solid":
                passive |= self._in_box(self.ecent, c)

        if n_sup == 0:
            raise ValueError("Please define at least one support.")
        if not (np.any(F) or np.any(self.grav)):
            raise ValueError("All loads are zero.")
        self.F_ext = F
        self.elim = elim
        self.free = np.flatnonzero(~elim)
        self.pen = pen
        self.fixed_nodes_all = np.unique(np.concatenate(fixed_nodes))
        self.load_nodes_all = np.unique(np.concatenate(load_nodes)) if load_nodes else \
            np.zeros(0, dtype=np.int64)
        # Gruppen mit gleichen Strafsteifigkeiten (je Gruppe eine Zerlegung)
        groups = {}
        for k, cs in enumerate(cases):
            key = cs if cs in pen else 0
            groups.setdefault(key, []).append(k)
        self.groups = groups
        self.Kpen = {}
        dmap = -np.ones(self.ndof, dtype=np.int64)
        dmap[self.free] = np.arange(len(self.free))
        self.dmap = dmap
        for key in groups:
            items = list(pen.get(0, [])) + (list(pen.get(key, [])) if key else [])
            rows, cols, vals = [], [], []
            for nodes, blk in items:
                for a in range(3):
                    for b in range(3):
                        v = blk[:, a, b]
                        m = np.abs(v) > 1e-14
                        ra, cb = dmap[nodes[m] * 3 + a], dmap[nodes[m] * 3 + b]
                        ok = (ra >= 0) & (cb >= 0)
                        rows.append(ra[ok])
                        cols.append(cb[ok])
                        vals.append(v[m][ok] * self.kpen)
            nf = len(self.free)
            if rows:
                self.Kpen[key] = sp.csc_matrix((np.concatenate(vals), (np.concatenate(rows),
                                                np.concatenate(cols))), shape=(nf, nf))
            else:
                self.Kpen[key] = None
        if not elim.any() and all(v is None for v in self.Kpen.values()):
            raise ValueError("The part is not supported.")

        if S["keep_bc"] and bc_nodes:
            # wie implicit.build: nur die gewählten Lager-/Lastflächen bleiben massiv – erste Elementschicht
            # (nötig für die Krafteinleitung) plus die Wandstärke, gemessen als Abstand zur Fläche
            nodes = np.unique(np.concatenate(bc_nodes))
            passive |= np.isin(self.enodes, nodes).any(axis=1)
            wall = float(S.get("bc_wall_mm", 2.0) or 0) / self.scale
            if wall > 0.75 * self.h:
                for c in self.conds:
                    if c["type"] in ("fixed", "frictionless", "pin", "load") and c.get("tris") is not None:
                        pts, _ = self._samples(c, self.h)
                        if len(pts):
                            dist, _ = cKDTree(pts).query(self.ecent, distance_upper_bound=wall)
                            passive |= np.isfinite(dist)
            if 0 < wall < 0.95 * self.h:
                log(f"Note: The wall thickness at support/load faces ({wall * self.scale:.1f} mm) is smaller than "
                    f"one computation voxel ({self.h_mm:.1f} mm) – increase the resolution for thinner rings.")
        self.passive = passive

        # Element-Schwerkraftvektoren (pro Dichte 1): 24 Einträge
        V = self.h_mm ** 3
        self.ge = np.zeros((len(cases), 24))
        for k in range(len(cases)):
            self.ge[k] = np.tile(self.grav[k] * V / 8.0, 8)

    def _build_assembly(self):
        """Obere Dreieckshälfte der Steifigkeitsmatrix vorindizieren.
        Speichersparend: Schlüssel blockweise in int64, Element/lokaler Eintrag werden aus der
        Sortierreihenfolge abgeleitet (statt mehrerer großer Hilfs-Arrays)."""
        ne = self.ne
        iu, ju = np.triu_indices(24)
        nl = len(iu)                                   # 300 Einträge je Element
        nf = len(self.free)
        m = ne * nl
        BIG = np.iinfo(np.int64).max
        key = np.empty(m, dtype=np.int64)
        dmap = self.dmap.astype(np.int64)
        CH = max(1, 2_000_000 // nl)
        for e0 in range(0, ne, CH):
            e1 = min(ne, e0 + CH)
            ed = dmap[self.edof[e0:e1]]
            I, J = ed[:, iu], ed[:, ju]
            r, c = np.minimum(I, J), np.maximum(I, J)
            k = c * nf + r
            k[r < 0] = BIG                             # gesperrte Freiheitsgrade ans Ende sortieren
            key[e0 * nl:e1 * nl] = k.ravel()
            del ed, I, J, r, c, k
        order = np.argsort(key)
        key.sort()
        valid = int(np.searchsorted(key, BIG))
        key = key[:valid]
        new = np.empty(valid, dtype=bool)
        new[0] = True
        np.not_equal(key[1:], key[:-1], out=new[1:])
        self.starts = np.flatnonzero(new)
        del new
        ks = key[self.starts]
        del key
        self.rows = (ks % nf).astype(np.int32)
        cols = ks // nf
        del ks
        self.indptr = np.concatenate([[0], np.cumsum(np.bincount(cols, minlength=nf))]).astype(np.int64)
        del cols
        order = order[:valid]
        self.eoe = (order // nl).astype(np.int32)      # Element je Eintrag
        self.loc = (order % nl).astype(np.uint16)      # lokaler Eintrag (0…299) je Eintrag
        del order
        self.ktri = self.ktri_true = self.Ke[iu, ju].astype(np.float64)
        self.ktri_opt = None if self.Ke_opt is None else self.Ke_opt[iu, ju].astype(np.float64)
        self.ktri2 = None if self.Ke2 is None else self.Ke2[iu, ju].astype(np.float64)
        self.nfree = nf

    # ------------------------------------------------------------ FE
    def _build_full(self):
        """Einmalig je Geometrie: Struktur der vollen (symmetrischen) Matrix im CSR-Format und die
        Zuordnung Eintrag → Eintrag der oberen Hälfte. Danach entsteht K in jeder Iteration ohne
        Sortieren/Spiegeln/Addieren, nur durch paralleles Einsammeln der Werte."""
        nup = len(self.starts)
        code = sp.csc_matrix((np.arange(1, nup + 1, dtype=np.float64), self.rows, self.indptr),
                             shape=(self.nfree, self.nfree))
        full = (code + sp.triu(code, k=1, format="csc").T).tocsr()
        full.sort_indices()
        idt = np.int32 if nup < 2**31 - 2 else np.int64
        self.f_map = (full.data - 1).astype(idt)
        self.f_indices = full.indices.astype(np.int32 if self.nfree < 2**31 - 2 else np.int64)
        self.f_indptr = full.indptr.astype(np.int64)
        rows = np.repeat(np.arange(self.nfree, dtype=self.f_indices.dtype), np.diff(self.f_indptr))
        self.f_diag = np.flatnonzero(self.f_indices == rows)
        if len(self.f_diag) != self.nfree:
            self.f_diag = None                         # (nicht erwartet) dann klassisch addieren
        self._pen_pos = {}
        del full, code, rows

    def _upper(self, E, E2=None):
        """Werte der oberen Dreieckshälfte, blockweise auf allen Kernen summiert.
        E2: zweite Elementsteifigkeit (Infill) mit eigener Elementmatrix Ke2."""
        starts, n = self.starts, len(self.starts)
        data = np.empty(n, dtype=np.float64)
        total = len(self.eoe)
        CH = max(500_000, total // (2 * PR.n_threads()) + 1)
        cuts = [0]
        while cuts[-1] < n:
            a = starts[cuts[-1]]
            i1 = int(np.searchsorted(starts, a + CH, side="left"))
            cuts.append(min(n, max(i1, cuts[-1] + 1)))

        def blk(j):
            i0, i1 = cuts[j], cuts[j + 1]
            a = starts[i0]
            b = starts[i1] if i1 < n else total
            el, lc = self.eoe[a:b], self.loc[a:b]
            vals = E[el] * self.ktri[lc]
            if E2 is not None:
                vals += E2[el] * self.ktri2[lc]
            data[i0:i1] = np.add.reduceat(vals, starts[i0:i1] - a)
        PR.run_tasks(len(cuts) - 1, blk)
        return data

    def stiffness(self, E, eps=0.0, E2=None):
        """Steifigkeitsmatrix (CSR, symmetrisch, volle Struktur); eps wird auf die Diagonale addiert."""
        if getattr(self, "f_map", None) is None:
            self._build_full()
        up = self._upper(E, E2 if self.ktri2 is not None else None)
        data = PR.take(up, self.f_map)
        if eps:
            if self.f_diag is not None:
                data[self.f_diag] += eps
        K = sp.csr_matrix((data, self.f_indices, self.f_indptr), shape=(self.nfree, self.nfree), copy=False)
        K.has_sorted_indices = True
        if eps and self.f_diag is None:
            K = (K + sp.identity(self.nfree, format="csr") * eps).tocsr()
        return K

    def _add_pen(self, K, key):
        """K + Kpen[key] – Lagerfedern liegen in der Struktur von K: nur Werte addieren."""
        Kp = self.Kpen[key]
        if key not in self._pen_pos:
            c = Kp.tocoo()
            n = self.nfree
            rows = np.repeat(np.arange(n, dtype=np.int64), np.diff(K.indptr))
            fk = rows * n + K.indices
            del rows
            kk = c.row.astype(np.int64) * n + c.col
            pos = np.searchsorted(fk, kk)
            ok = bool(np.all(pos < len(fk))) and bool(np.all(fk[np.minimum(pos, len(fk) - 1)] == kk))
            self._pen_pos[key] = (pos, c.data.copy()) if ok else None
            del fk
        pv = self._pen_pos[key]
        if pv is None:
            return (K + Kp).tocsr()
        data = K.data.copy()
        np.add.at(data, pv[0], pv[1])
        M = sp.csr_matrix((data, K.indices, K.indptr), shape=K.shape, copy=False)
        M.has_sorted_indices = True
        return M

    def loads(self, xp):
        """Lastmatrix (ndof × Lastfälle), Schwerkraft abhängig von der Dichte."""
        F = self.F_ext.copy()
        if np.any(self.grav):
            for k in range(len(self.cases)):
                if np.any(self.ge[k]):
                    np.add.at(F[:, k], self.edof.ravel(), (xp[:, None] * self.ge[k][None, :]).ravel())
        return F

    def solve(self, E, xp, U0=None, strict=False, active_nodes=None, E2=None, keep=False):
        """strict: Plausibilitätsprüfung der Verformung (nur Hinweis). active_nodes: nur an diesen
        Knoten Lasten aufbringen und Verformungen prüfen (Material ohne Verbindung bleibt lastfrei).
        E2: Infill-Steifigkeit je Element. keep: Löser behalten für weitere rechte Seiten (resolve)."""
        ph = getattr(self, "phases", None) or PF.Phases()
        self.phases = ph
        self._sols = None                  # alte Löser (Mehrgitter, Grafikspeicher) zuerst freigeben
        sols = {}
        # schwache Federn an allen Knoten: verhindert Singularität bei Starrkörperbewegung
        with ph.measure("Matrix"):
            K = self.stiffness(E, eps=self.kpen * 1e-14, E2=E2)
        F = self.loads(xp)
        chk = slice(None)
        if active_nodes is not None:
            act = np.zeros(self.nn, dtype=bool)
            act[active_nodes] = True
            F[~np.repeat(act, 3)] = 0.0
            chk = np.repeat(act, 3)[self.free]
        U = np.zeros_like(F)
        self.solver_info = ""
        self.big_deform = None
        cancel = getattr(self, "cancel", None)
        for key, ks in self.groups.items():
            if cancel is not None and cancel():
                raise Stopped()
            with ph.measure("Matrix"):
                Kg = K if self.Kpen[key] is None else self._add_pen(K, key)
            try:
                if not hasattr(self, "_solver_cache"):
                    self._solver_cache = {}
                w0, c0 = time.perf_counter(), time.process_time()
                sol = Solver(Kg, self.free, self.ncoord, self.S.get("solver", "auto"), cancel=cancel,
                             cache=self._solver_cache, log=self.log, tol=getattr(self, "solve_tol", 1e-8))
                w1, c1 = time.perf_counter(), time.process_time()
                sub = getattr(getattr(sol, "hy", None), "times", None) or {}
                sw = sum(v[0] for v in sub.values())
                sc = sum(v[1] for v in sub.values())
                for n, (w, c) in sub.items():
                    ph.add(n, w, c)
                ph.add("Multigrid setup", max(w1 - w0 - sw, 0.0), max(c1 - c0 - sc, 0.0))
                with ph.measure("Solver"):
                    X = sol.solve(F[self.free][:, ks], None if U0 is None else U0[self.free][:, ks])
                self.solver_info = sol.kind + (f" ({sol.info})" if sol.info else "")
                if keep:
                    sols[key] = sol
            except RuntimeError as e:
                raise ValueError("The system of equations cannot be solved – the part is probably "
                                 "not sufficiently supported (rigid body motion).") from e
            Xc = X[chk]
            umax = np.abs(Xc).max() / (self.S["E"] * self.h_mm) if Xc.size else 0.0
            size = self.mesh.diag * self.scale
            # Die Lagerung selbst prüft _check_supports (lastunabhängig). Hier nur noch echte Singularität:
            if not np.all(np.isfinite(X)) or umax > 1e4 * size:
                raise ValueError("The system of equations is nearly singular: parts of the computation grid are "
                                 "movable (e.g. very thin spots). Please increase the resolution.")
            if strict and umax > 0.1 * size:
                self.big_deform = umax
                msg = (f"Note: Very large deformation ({umax:.3g} mm at {size:.3g} mm part size) – "
                       "the linear computation is no longer accurate here. Please check load, force unit and Young’s modulus.")
                if getattr(self, "_last_deform_msg", None) != msg[:40]:
                    self.log(msg)
                    self._last_deform_msg = msg[:40]
            U[np.ix_(self.free, ks)] = X
        if keep:
            self._sols = sols
        return U, F

    def resolve(self, R, X0=None):
        """Weitere rechte Seiten (ndof × Lastfälle) mit den Lösern der letzten Rechnung (solve(keep=True)),
        z. B. für die adjungierte Rechnung. Gesperrte Freiheitsgrade bleiben 0."""
        X = np.zeros_like(R)
        ph = getattr(self, "phases", None) or PF.Phases()
        for key, ks in self.groups.items():
            sol = self._sols[key]
            with ph.measure("Solver"):
                Y = sol.solve(R[self.free][:, ks], None if X0 is None else X0[self.free][:, ks])
            X[np.ix_(self.free, ks)] = Y
        return X

    def release(self):
        self._sols = None

    def stress_matrix(self, D=None):
        """σ_e (6) = U_e (24, normiert) @ Mσ: Spannung im Elementmittelpunkt [MPa]."""
        D = self.D if D is None else D
        return (_B(0, 0, 0).T @ D.T) / self.h_mm ** 2

    def stresses(self, U, s=None):
        """Verschiebungen [mm], von-Mises-Spannung [MPa] und – beim 3D-Druck – Ausnutzung der
        Schichthaftung (u = 1/Sicherheit) je Element und Lastfall. s: Randanteil (3D-Druck Erweitert):
        im Infill werden die Wandspannungen aus der Dehnung abgeschätzt (siehe aniso)."""
        S = self.S
        ur = U / (S["E"] * self.h_mm)
        Ms = self.stress_matrix()
        Mi = None
        if s is not None and self.D2 is not None:
            phi = max(float(S.get("infill_pct", 20)) / 100.0, 0.01)
            Mi = self.stress_matrix(self.D2) * (A.pattern_kappa(S) / phi)
        nc = U.shape[1]
        vm = np.zeros((self.ne, nc))
        lay = np.zeros((self.ne, nc)) if self.layer is not None else None
        for k in range(nc):
            Ue = U[:, k][self.edof]
            sig = Ue @ Ms
            vm[:, k] = A.von_mises(sig)
            if lay is not None:
                lay[:, k] = A.layer_util(sig, self.layer["axis"], self.layer["St"], self.layer["Ss"])
            if Mi is not None:
                core = s < 0.05                      # reines Infill: kleinerer der beiden Schätzwerte
                si = Ue[core] @ Mi
                vm[core, k] = np.minimum(vm[core, k], A.von_mises(si))
                if lay is not None:
                    lay[core, k] = np.minimum(lay[core, k], A.layer_util(si, self.layer["axis"],
                                                                         self.layer["St"], self.layer["Ss"]))
        self.last_layer = lay
        return ur, vm


# ================================================================ Optimierung

class Optimizer:
    def __init__(self, model, log=print, on_frame=lambda it, dens, info: None, stop=lambda: False,
                 on_phase=lambda name: None):
        self.M = model
        self.log, self.on_frame, self.stop, self.on_phase = log, on_frame, stop, on_phase
        S = model.S
        M = model
        ne = M.ne
        mw = float(S["minwall_mm"] or 0)
        R = max(1.5, mw / M.h_mm) if mw > 0 else 1.5
        if mw > 0 and mw / M.h_mm < 2.0:
            self.log(f"Note: The minimum wall thickness corresponds to only {mw / M.h_mm:.1f} voxels – "
                     "increase the resolution for reliable wall thicknesses.")
        R = min(R, 10.0)
        if 4 / 3 * math.pi * R ** 3 * ne > 4e7:
            raise ValueError("Minimum wall thickness × element count too large – reduce resolution or wall thickness.")
        H, self.Hs = build_filter(np.stack([M.ei, M.ej, M.ek], 1).astype(float), R)
        self.H = PR.ThreadedCSR(H)                 # Dichtefilter auf allen Kernen
        self.log(f"Filter radius {R:.2f} voxels (≈ {R * M.h_mm:.2f} mm)")

        self.partners = []
        for ax in range(3):
            if S["sym"][ax]:
                idx = [M.ei, M.ej, M.ek]
                idx[ax] = M.shape[ax] - 1 - idx[ax]
                p = M.emap[idx[0], idx[1], idx[2]]
                self.partners.append(np.where(p < 0, np.arange(ne), p))
        self.columns = None
        if S["extrude"] in ("x", "y", "z"):
            a = "xyz".index(S["extrude"])
            o = [i for i in range(3) if i != a]
            cc = [M.ei, M.ej, M.ek]
            colid = cc[o[0]] * M.shape[o[1]] + cc[o[1]]
            _, inv = np.unique(colid, return_inverse=True)
            self.columns = inv
            self.colcount = np.bincount(inv)
            self.log(f"Manufacturing: extrusion along {S['extrude'].upper()} (2,5D)")
        self.mfg = None
        self.tool = None
        self.prism = None
        if S["mfg"] == "cnc_prism":
            self.prism = PrismHull(M, S, self.log)
            self.log("Manufacturing: " + self.prism.describe())
        elif S["mfg"] == "cnc3":
            axis = "xyz".index(S["mfg_dir"][0])
            sign = 1 if S["mfg_dir"][1] == "+" else -1
            setups = 2 if int(S.get("cnc_setups", 1) or 1) >= 2 else 1
            self.mfg = MillFilter(M.ei, M.ej, M.ek, M.shape, axis, sign, setups)
            txt = (f"Milling organic (3-axis), tool from {S['mfg_dir']}"
                   + (f" and {S['mfg_dir'][0]}{'-' if sign > 0 else '+'} (2 setups)" if setups == 2 else ""))
            tool = float(S.get("cnc_tool_mm", 0) or 0)
            if tool > 0:
                rv = 0.5 * tool / M.h_mm
                if rv < 0.75:
                    self.log(f"Note: Cutter Ø {tool:g} mm is smaller than one voxel ({M.h_mm:.2f} mm) – "
                             "the diameter only takes effect at a higher resolution.")
                else:
                    if rv > 8:
                        self.log(f"Note: Cutter Ø {tool:g} mm = {2 * rv:.0f} voxels – to limit computing time "
                                 f"considered with {16 * M.h_mm:.1f} mm.")
                        rv = 8.0
                    self.tool = ToolClosing(M.ei, M.ej, M.ek, axis, rv)
                    txt += f", cutter Ø {tool:g} mm (smallest pocket/inner corner)"
            dmax = float(S.get("cnc_depth_mm", 0) or 0)
            if dmax > 0:
                deep = self.mfg.depth() * M.h_mm > dmax
                if deep.mean() >= S["volfrac"] * 0.98:
                    raise ValueError(f"With a max. milling depth of {dmax:g} mm the cutter reaches only "
                                     f"{(1 - deep.mean()) * 100:.0f} % of the part – the rest "
                                     f"({deep.mean() * 100:.0f} %) stays solid and already exceeds the target volume. "
                                     "Increase the milling depth, choose 2 setups or increase the target volume.")
                if deep.any():
                    M.passive = M.passive | deep
                    txt += f", max. milling depth {dmax:g} mm ({deep.mean() * 100:.0f} % of the part stay solid)"
            self.log("Manufacturing: " + txt)
        elif S["mfg"] in ("am", "am_adv", "cast"):
            axis = "xyz".index(S["mfg_dir"][0])
            sign = 1 if S["mfg_dir"][1] == "+" else -1
            kind = "cast" if S["mfg"] == "cast" else "am"
            self.mfg = LayerFilter(M.ei, M.ej, M.ek, M.shape, axis, sign, kind, int(S["overhang"]))
            name = {"am": "3D printing simple", "am_adv": "3D printing advanced"}.get(S["mfg"])
            self.log("Manufacturing: " + (f"{name} without supports ({int(S['overhang'])}°)" if name
                                      else "one-sided demolding (casting)") + f", direction {S['mfg_dir']}")
        # Schichthaftung als Nebenbedingung (3D-Druck): Ausnutzung · Mindestsicherheit ≤ 1
        if M.Ke_opt is not None:
            st, ss = A.strengths(S)
            self.log(f"Layer adhesion in the optimization: load paths across the layers are avoided according to the ratio "
                     f"bond strength/strength ({st:g}/{float(S['yield_']):g} MPa) – the analysis uses "
                     "the real material values.")
        elif M.layer is not None and S.get("layer_opt", True):
            self.log("Layer adhesion: the bond strength is not lower than the strength in the layer plane – "
                     "the shape is designed for stiffness only (anisotropic).")
        # Massenziel mit Infill: Masse = Wände + Infill-Füllgrad × Innenraum (mit Ableitung über die Randschichten)
        self.mass_mode = bool(S.get("mass_mode")) and M.shell is not None
        self.phi = float(S.get("infill_pct", 20)) / 100.0
        pm = self._measure(M.passive.astype(float))
        if pm >= S["volfrac"] * 0.98:
            raise ValueError(f"Solid regions already occupy {pm * 100:.0f} % of the part – "
                             "Increase the target volume or make the zones smaller."
                             + (" With prismatic milling a solid zone (including the wall at support and "
                                "load faces) applies to the whole depth level and column: choose more depth levels, select more milling sides "
                                "or switch off “Keep support/load faces solid”." if self.prism is not None else ""))
        if pm >= S["volfrac"] * 0.6:
            self.log(f"Note: solid regions already take up {pm * 100:.0f} % of the part"
                     + (" (as whole depth levels with prismatic milling)" if self.prism is not None else "")
                     + f" – only {(S['volfrac'] - pm) * 100:.0f} % remain for the load-bearing structure. For a stiffer "
                     "result increase the target volume or reduce the solid zones.")
        w = S.get("case_weights") or {}
        self.wk = np.array([float(w.get(str(c), w.get(c, 1.0))) for c in M.cases])

    def _measure(self, xp, grad=False):
        """Volumenanteil (bzw. beim Massenziel mit Infill: Massenanteil am vollen Bauteil)."""
        if not self.mass_mode:
            return (float(xp.mean()), None) if grad else float(xp.mean())
        s, sc = self.M.shell.forward(xp)
        f = s + self.phi * (1.0 - s)
        val = float((xp * f).mean())
        if not grad:
            return val
        g = f + self.M.shell.backward(xp * (1.0 - self.phi), sc)
        return val, g / len(xp)

    def _proj(self, v):
        for p in self.partners:
            v = 0.5 * (v + v[p])
        if self.columns is not None:
            v = (np.bincount(self.columns, weights=v) / self.colcount)[self.columns]
        return v

    def _physical(self, x):
        xf = (self.H @ x) / self.Hs
        if self.prism is not None:
            xf = xf.copy()
            xf[self.M.passive] = 1.0
            xp, cache = self.prism.forward(xf)
            xp = xp.copy()
            xp[self.M.passive] = 1.0
            return xp, cache
        if self.mfg is not None:
            xp, cache = self.mfg.forward(xf)
        else:
            xp, cache = xf, None
        if self.tool is not None:
            xp, tc = self.tool.forward(xp)
            xp, c2 = self.mfg.forward(xp)        # Zugänglichkeit nach dem Schließen erneut sicherstellen
            cache = (cache, tc, c2)
        xp = xp.copy()
        xp[self.M.passive] = 1.0
        return xp, cache

    def _back(self, g, cache):
        g = g.copy()
        g[self.M.passive] = 0.0
        if self.prism is not None:
            g = self.prism.backward(g, cache)
            g[self.M.passive] = 0.0
            return self.H @ (g / self.Hs)
        if self.tool is not None:
            cache, tc, c2 = cache
            g = self.mfg.backward(g, c2)
            g = self.tool.backward(g, tc)
        if self.mfg is not None:
            g = self.mfg.backward(g, cache)
        return self.H @ (g / self.Hs)

    def run(self):
        M, S, log = self.M, self.M.S, self.log
        t0 = time.time()
        ne, vf = M.ne, float(S["volfrac"])
        x = np.full(ne, vf)
        x[M.passive] = 1.0
        x = self._proj(x)
        xp, cache = self._physical(x)
        self.hist, self.snaps = [], []
        U = None
        M.cancel = self.stop                      # Löser prüft den Abbruch auch während der Rechnung
        M.design(True)
        try:
            log("Checking supports on the solid part …")
            self.on_phase("check")
            M.solve(np.ones(ne), np.ones(ne), strict=True)
            self.on_phase("loop")
            log(f"Starting optimization ({len(M.cases)} load case(s)) …")
            self._loop(x, xp, cache, U, ne, vf)
        except Stopped:
            log("Stopped – using the last complete state." if self.snaps
                else "Stopped before the first iteration.")
        finally:
            M.cancel = None
            M.design(False)
        log(f"Optimization finished in {time.time() - t0:.1f} s.")
        return self.snaps

    def _energy(self, a, b, Eb, dEb, s):
        """Ableitung von aᵀ K(x) b nach der physikalischen Dichte: (lokal, über den Randanteil s)."""
        M = self.M
        q1 = ((a @ M.Ke) * b).sum(axis=1)
        if s is None:
            return dEb * q1, None
        q2 = ((a @ M.Ke2) * b).sum(axis=1)
        return dEb * (s * q1 + (1.0 - s) * q2), Eb * (q1 - q2)

    def _loop(self, x, xp, cache, U, ne, vf):
        M, S, log = self.M, self.M.S, self.log
        for it in range(1, int(S["max_iter"]) + 1):
            if self.stop():
                raise Stopped()
            M.phases = PF.Phases()
            iw, ic = time.perf_counter(), time.process_time()
            Eb = EMIN + xp ** PEN * (1 - EMIN)
            dEb = PEN * xp ** (PEN - 1) * (1 - EMIN)
            scache = None
            if M.shell is not None:
                s, scache = M.shell.forward(xp)
                E1, E2 = Eb * s, Eb * (1.0 - s)
            else:
                s, E1, E2 = None, Eb, None
            U, F = M.solve(E1, xp, U, E2=E2)
            dc = np.zeros(ne)
            dcs = np.zeros(ne) if s is not None else None
            c = 0.0
            for k in range(len(M.cases)):
                Ue = U[:, k][M.edof]
                c += self.wk[k] * float(F[:, k] @ U[:, k])
                gl, gsk = self._energy(Ue, Ue, Eb, dEb, s)
                g = -gl
                if gsk is not None:
                    dcs -= self.wk[k] * gsk
                if np.any(M.ge[k]):
                    g += 2.0 * (Ue @ M.ge[k])
                dc += self.wk[k] * g
            if s is not None:
                dc += M.shell.backward(dcs, scache)
            move = 0.2
            dc = self._proj(self._back(dc, cache))
            _, gm = self._measure(xp, grad=True)
            dv = self._proj(self._back(gm if gm is not None else np.full(ne, 1.0 / ne), cache)) * ne
            dv = np.maximum(dv, 1e-9)
            l1, l2 = 0.0, 1e9
            if self.stop():
                raise Stopped()
            while (l2 - l1) / (l1 + l2 + 1e-30) > 1e-4:
                lm = 0.5 * (l1 + l2)
                xn = np.clip(x * np.sqrt(np.maximum(-dc, 0) / (dv * lm)),
                             np.maximum(0.0, x - move), np.minimum(1.0, x + move))
                xn[M.passive] = 1.0
                xn = self._proj(xn)
                xpn, cn = self._physical(xn)
                if self._measure(xpn) > vf:
                    l1 = lm
                else:
                    l2 = lm
            change = float(np.abs(xn - x).max())
            x, xp, cache = xn, xpn, cn
            c_real = c / (S["E"] * M.h_mm)
            self.hist.append(c_real)
            self.snaps.append(xp.astype(np.float16))
            info = dict(it=it, c=c_real, vol=float(xp.mean()), change=change)
            if self.mass_mode:
                info["mass"] = self._measure(xp)
            self.on_frame(it, xp, info)
            log(f"Iter {it:3d}  compliance {c_real:.4e} N·mm  volume {xp.mean():.3f}  change {change:.3f}")
            tw, tc = time.perf_counter() - iw, time.process_time() - ic
            avail, total = PF.ram()
            ram = f" · RAM free {avail / 2**30:.1f} of {total / 2**30:.1f} GB" if avail and total else ""
            log(f"   time {tw:.1f} s, ⌀ {tc / max(tw, 1e-9):.1f} of {PR.n_threads()} threads: "
                + M.phases.text(tw, tc) + ram)
            if change < 0.01 and it > 15:
                log("Converged.")
                break
        M.release()
        if self.mass_mode:
            # Ergebnisnetz: Schwelle so, dass das fertige (0/1-)Teil mit Wänden und Infill die Zielmasse hat
            S["volfrac"] = mass_to_volfrac(M, xp, vf, self.phi)
            log(f"Target mass with walls and infill: outer volume of the result ≈ {S['volfrac'] * 100:.0f} % of the part")


# ================================================================ Auswertung

def element_field_to_grid(model, vals, mask=None):
    """Elementwerte auf das Voxelgitter, leere Voxel mit nächstem gültigen Wert füllen."""
    grid = np.zeros(model.shape, dtype=np.float32)
    grid[model.ei, model.ej, model.ek] = vals
    m = np.zeros(model.shape, dtype=bool)
    if mask is None:
        m[model.ei, model.ej, model.ek] = True
    else:
        m[model.ei, model.ej, model.ek] = mask
    if m.any() and not m.all():
        _, (ix, iy, iz) = distance_transform_edt(~m, return_indices=True)
        grid = grid[ix, iy, iz]
    return grid


def sample_grid(model, grid, pts):
    idx = np.floor((pts - model.lo) / model.h).astype(np.int64)
    idx = np.clip(idx, 0, np.array(model.shape) - 1)
    return grid[idx[:, 0], idx[:, 1], idx[:, 2]]


def connected_to_supports(model, xb):
    """Nur Material, das flächig mit einem Lager verbunden ist. Kanten-/Eckkontakte (Gelenke) werden
    vorher überbrückt. Liefert (Maske, Teile, Warnung)."""
    act = (xb > 0.5) | model.passive
    mask = np.zeros(model.shape, dtype=bool)
    mask[model.ei, model.ej, model.ek] = act
    mask, _ = SC.bridge_hinges(mask, model.emap >= 0)
    act = mask[model.ei, model.ej, model.ek]
    lab, nparts = label(mask)
    elab = lab[model.ei, model.ej, model.ek]
    fixed_el = np.unique(elab[np.isin(model.enodes, model.fixed_nodes_all).any(1) & act])
    load_el = np.unique(elab[np.isin(model.enodes, model.load_nodes_all).any(1) & act])
    fixed_el, load_el = fixed_el[fixed_el > 0], load_el[load_el > 0]
    warn = None
    if len(fixed_el) == 0:
        return act, int(nparts), "No material at the supports – increase the volume."
    if len(model.load_nodes_all) and (len(load_el) == 0 or not np.all(np.isin(load_el, fixed_el))):
        warn = ("The load path is interrupted – unconnected load faces were removed from the result. "
                "Set the threshold to 0 (automatic) or lower it, increase the volume or compute more iterations.")
    conn = act & np.isin(elab, fixed_el)
    return conn, int(nparts), warn


def analyze(model, xb, verts, conn_check=True):
    """Lineare Analyse einer 0/1-Dichteverteilung; Werte an den Netzpunkten `verts`."""
    S = model.S
    warn, nparts = None, 1
    conn = xb > 0.5
    if conn_check:
        conn, nparts, warn = connected_to_supports(model, xb)
        if nparts > 1:
            model.log(f"Note: {nparts - 1} loose parts without connection to the support are ignored.")
    xs = conn.astype(float)
    E = EMIN + xs * (1 - EMIN)
    E1, E2, s = model.split_E(E, xs)
    an = np.unique(model.enodes[conn]) if conn.any() else None
    U, F = model.solve(E1, xs, strict=True, active_nodes=an, E2=E2)
    ur, vm = model.stresses(U, s)
    vm = vm * conn[:, None]
    lay = model.last_layer
    nc = len(model.cases)
    env = vm.max(axis=1)
    msk = conn if conn.any() else None
    grids = [element_field_to_grid(model, vm[:, k], msk) for k in range(nc)]
    genv = element_field_to_grid(model, env, msk)
    vstress = np.stack([sample_grid(model, g, verts) for g in grids], 1)
    venv = sample_grid(model, genv, verts)
    anodes = np.unique(model.enodes[conn if conn.any() else slice(None)])
    tree = cKDTree(model.npos[anodes])
    _, j = tree.query(verts)
    vnode = anodes[j]
    urn = ur.reshape(model.nn, 3, nc)
    vdisp = urn[vnode].transpose(2, 0, 1)                      # (Lastfälle, Punkte, 3)
    umag = np.linalg.norm(urn[anodes], axis=1)                 # (Knoten, Lastfälle)
    cases = []
    for k, cs in enumerate(model.cases):
        v = vm[conn, k] if conn.any() else vm[:, k]
        smax = float(v.max()) if len(v) else 0.0
        cases.append(dict(case=cs, umax=float(umag[:, k].max()) if umag.size else 0.0,
                          vm_max=smax, vm_p95=float(np.percentile(v, 95)) if len(v) else 0.0,
                          compliance=float(F[:, k] @ U[:, k]) / (S["E"] * model.h_mm),
                          safety=(S["yield_"] / smax) if smax > 0 else None))
    smax = max(c["vm_max"] for c in cases)
    out = dict(vstress=vstress.astype(np.float32), venv=venv.astype(np.float32),
               vdisp=vdisp.astype(np.float32), cases=cases, vm_max=smax,
               umax=max(c["umax"] for c in cases),
               safety=(S["yield_"] / smax) if smax > 0 else None, yield_=S["yield_"],
               parts=nparts, warning=warn, grid_env=genv, solver=model.solver_info,
               layer_safety=None, vlayer=None, vlayer_env=None)
    if lay is not None:
        lay = lay * conn[:, None]
        lgr = [element_field_to_grid(model, lay[:, k], msk) for k in range(nc)]
        out["vlayer"] = np.stack([sample_grid(model, g, verts) for g in lgr], 1).astype(np.float32)
        out["vlayer_env"] = sample_grid(model, element_field_to_grid(model, lay.max(axis=1), msk),
                                        verts).astype(np.float32)
        for k, c in enumerate(cases):
            v = lay[conn, k] if conn.any() else lay[:, k]
            um = float(v.max()) if len(v) else 0.0
            c["layer_safety"] = (1.0 / um) if um > 0 else None
        um = float(lay[conn].max()) if conn.any() else float(lay.max())
        out["layer_safety"] = (1.0 / um) if um > 0 else None
    if s is not None:
        out["shell_frac"] = float((s * xs).sum() / max(xs.sum(), 1.0))
    g = np.zeros(model.shape, dtype=bool)
    g[model.ei, model.ej, model.ek] = conn
    out["pieces"] = int(label(g)[1]) if conn.any() else 0
    return out


def print_mass_frac(model, xb, phi=None):
    """Massenanteil (bezogen auf das volle Bauteil) eines 0/1-Teils mit Randschichten und Infill."""
    if model.shell is None:
        return float(np.mean(xb))
    phi = float(model.S.get("infill_pct", 20)) / 100.0 if phi is None else phi
    s, _ = model.shell.forward(xb)
    return float((xb * (s + phi * (1.0 - s))).mean())


def mass_to_volfrac(model, xp, mass, phi=None):
    """Außenvolumen-Anteil, bei dem das Ergebnisnetz (Schwelle) die gewünschte Druckmasse hat."""
    field = _smoothed_field(model, xp, float(model.S.get("sigma", 0.7)))
    inner = field[model.ei + 1, model.ej + 1, model.ek + 1]
    lo, hi = 0.02, 0.95
    for _ in range(22):
        t = 0.5 * (lo + hi)
        lev = _auto_level(model, field, t)
        if print_mass_frac(model, (inner > lev).astype(float), phi) > mass:
            hi = t
        else:
            lo = t
    return float(0.5 * (lo + hi))


def density_grid(model, xp):
    g = np.zeros(model.shape, dtype=np.float32)
    g[model.ei, model.ej, model.ek] = xp
    return g


def _sup_load_elems(model):
    if getattr(model, "_sl_el", None) is None:
        sup = np.isin(model.enodes, model.fixed_nodes_all).any(1)
        lod = (np.isin(model.enodes, model.load_nodes_all).any(1) if len(model.load_nodes_all)
               else np.zeros(model.ne, dtype=bool))
        model._sl_el = (sup, lod)
    return model._sl_el


def _smoothed_field(model, xp, sigma, excl=None):
    """Geglättetes Dichtefeld (mit 1 Voxel Rand). Erhaltene Zonen werden auf 1 gesetzt,
    ausgeschlossene Elemente (schwebende Bereiche) auf 0."""
    field = np.pad(density_grid(model, xp), 1)
    if sigma > 0:
        field = gaussian_filter(field, sigma)
    # erhaltene Zonen (Lager-/Lastflächen, massive Bereiche) dürfen durch Glätten nicht wegfallen;
    # am Rand des Bauraums würde die Glättung sie sonst "anfressen"
    pas = model.passive if excl is None else (model.passive & ~excl)
    field[model.ei[pas] + 1, model.ej[pas] + 1, model.ek[pas] + 1] = \
        np.maximum(field[model.ei[pas] + 1, model.ej[pas] + 1, model.ek[pas] + 1], 1.0)
    if excl is not None and excl.any():
        field[model.ei[excl] + 1, model.ej[excl] + 1, model.ek[excl] + 1] = 0.0
    return field


def _auto_level(model, field, target=None):
    tgt = (target if target is not None else model.S["volfrac"]) * model.ne
    lo_l, hi_l = 0.02, 0.95      # weiter Bereich: der Volumen-Regler kann das Bauteil auch deutlich wachsen lassen
    for _ in range(25):
        mid = 0.5 * (lo_l + hi_l)
        if (field > mid).sum() > tgt:
            lo_l = mid
        else:
            hi_l = mid
    return 0.5 * (lo_l + hi_l)


def _dead_elements(model, act):
    """Elemente ohne Kraftfluss (unbelastete Anhängsel): grobe FE-Rechnung, Formänderungsenergie."""
    Em = EMIN + act * (1 - EMIN)
    an = np.unique(model.enodes[act])
    old = getattr(model, "solve_tol", 1e-8)
    model.solve_tol = 1e-4
    try:
        U, F = model.solve(Em, act.astype(float), active_nodes=an)
    finally:
        model.solve_tol = old
    ce = np.zeros(model.ne)
    for k in range(U.shape[1]):
        Ue = U[:, k][model.edof]
        ce = np.maximum(ce, ((Ue @ model.Ke) * Ue).sum(axis=1))
    ce *= act
    cand = act & ~model.passive
    cm = getattr(model, "_conn_mask", None)
    if cm is not None and len(cm) == model.ne:
        cand &= ~cm                                     # Verbindungsstege nicht als "unbelastet" entfernen
    if not cand.any():
        return np.zeros(model.ne, dtype=bool)
    ref = float(np.median(ce[cand]))
    return cand & (ce < 1e-4 * ref) if ref > 0 else np.zeros(model.ne, dtype=bool)


def _elem_graph(model):
    """Nachbarschaft der Rechenvoxel (flächig) als Kantenliste, einmal je Modell."""
    if getattr(model, "_egraph", None) is None:
        a_l, b_l = [], []
        for ax in range(3):
            idx = [model.ei, model.ej, model.ek]
            nb = list(idx)
            nb[ax] = idx[ax] + 1
            ok = nb[ax] < model.shape[ax]
            j = -np.ones(model.ne, dtype=np.int64)
            j[ok] = model.emap[nb[0][ok], nb[1][ok], nb[2][ok]]
            m = j >= 0
            a_l.append(np.flatnonzero(m))
            b_l.append(j[m])
        a, b = np.concatenate(a_l), np.concatenate(b_l)
        model._egraph = (np.concatenate([a, b]), np.concatenate([b, a]))
    return model._egraph


def connect_parts(model, solid, xp, required, log=None):
    """Verbindet alle Stücke, die Pflichtbereiche (Lager, Lasten, massive Zonen) enthalten, mit dem Hauptteil.
    Weg mit den geringsten Kosten durch den Bauraum (Dijkstra): Elemente, die die Optimierung schon (teilweise)
    mit Material belegt hat, sind billig. Der Weg wird auf etwa Mindestwandstärke verdickt (beim prismatischen
    Fräsen macht der Stufenkörper daraus ganze Stufen). Liefert die ergänzten Elemente (bool) oder None."""
    from scipy.sparse import csr_matrix
    from scipy.sparse.csgraph import dijkstra
    g = np.zeros(model.shape, dtype=bool)
    g[model.ei, model.ej, model.ek] = solid
    gb, _ = SC.bridge_hinges(g, model.emap >= 0)
    lab, n = label(gb)
    el = lab[model.ei, model.ej, model.ek]
    req_c = np.unique(el[required & (el > 0)])
    # Pflichtelemente außerhalb jedes Stücks (z. B. dünne massive Zone unter der Schwelle) bilden eigene Ziele
    loose = required & (el == 0)
    if len(req_c) + int(loose.any()) <= 1:
        return None
    sup, _ = _sup_load_elems(model)
    counts = np.bincount(el[sup & (el > 0)], minlength=n + 1) if (sup & (el > 0)).any() else np.zeros(n + 1)
    main = int(np.argmax(counts)) if counts.max() > 0 else int(req_c[np.argmax(np.bincount(el[el > 0])[req_c])])
    a, b = _elem_graph(model)
    ne = model.ne
    x = np.clip(np.asarray(xp, float), 0.0, 1.0)
    cost = np.where(el > 0, 0.05, 1.0 + 8.0 * (1.0 - x))
    src = np.flatnonzero(el == main)
    rows = np.concatenate([a, np.full(len(src), ne)])
    cols = np.concatenate([b, src])
    w = np.concatenate([cost[b], np.full(len(src), 1e-9)])
    G = csr_matrix((w, (rows, cols)), shape=(ne + 1, ne + 1))
    dist, pred = dijkstra(G, directed=True, indices=ne, return_predecessors=True)
    dist = dist[:ne]
    path = np.zeros(ne, dtype=bool)
    targets = [np.flatnonzero(el == c) for c in req_c if c != main]
    targets += [np.flatnonzero(loose)] if loose.any() else []
    ok = 0
    for t in targets:
        t = t[np.isfinite(dist[t])]
        if not len(t):
            continue
        k = int(t[np.argmin(dist[t])])
        while 0 <= k < ne and el[k] != main:
            path[k] = True
            k = int(pred[k])
        ok += 1
    if not path.any():
        return None
    # verdicken (Mindestwandstärke, wenigstens 1 Voxel rundum)
    r = max(1.0, 0.5 * float(model.S.get("minwall_mm") or 0) / model.h_mm)
    gp = np.zeros(model.shape, dtype=bool)
    gp[model.ei[path], model.ej[path], model.ek[path]] = True
    thick = distance_transform_edt(~gp) <= r
    add = thick[model.ei, model.ej, model.ek] & ~solid
    if log:
        log(f"{ok} separate piece(s) connected to the main part ({int(add.sum())} voxels added) – "
            "the result stays one part (can be switched off: “Allow separate parts”).")
    return add


def clean_density(model, xp, level=0.0, sigma=0.7, target=None, prune=True):
    """Sorgt dafür, dass das Ergebnis eine zusammenhängende, an den Lagern hängende Struktur ist:
    * automatische Schwelle wird gesenkt, bis alle Lastflächen mit einem Lager verbunden sind,
    * Kanten-/Eckkontakte werden flächig überbrückt,
    * schwebende Bereiche ohne Verbindung zu einem Lager werden entfernt.
    Liefert (bereinigte Dichte, Schwelle, ausgeschlossene Elemente, Info)."""
    auto = level is None or level <= 0
    xp = np.asarray(xp, dtype=np.float64).copy()
    excl = np.zeros(model.ne, dtype=bool)
    field = _smoothed_field(model, xp, sigma)
    lev = _auto_level(model, field, target) if auto else float(level)
    info = dict(level0=lev, lowered=False, islands=0, removed=0, bridges=0, load_ok=True, connected=0)
    sup, lod = _sup_load_elems(model)
    allowed = model.emap >= 0
    ii, jj, kk = model.ei + 1, model.ej + 1, model.ek + 1
    one_part = not model.S.get("allow_split")
    conn_mask = getattr(model, "_conn_mask", None)
    if prune or conn_mask is None or len(conn_mask) != model.ne:
        conn_mask = model._conn_mask = np.zeros(model.ne, dtype=bool)
    for rnd in range(6):
        if rnd:
            field = _smoothed_field(model, xp, sigma, excl)
        for _ in range(14):
            solid = field[ii, jj, kk] > lev
            g = np.zeros(model.shape, dtype=bool)
            g[model.ei, model.ej, model.ek] = solid
            gb, _ = SC.bridge_hinges(g, allowed)
            lab, n = label(gb)
            el = lab[model.ei, model.ej, model.ek]
            sup_c = np.unique(el[sup & (el > 0)])
            load_c = np.unique(el[lod & (el > 0)])
            load_ok = len(sup_c) > 0 and (not lod.any() or (len(load_c) > 0 and np.all(np.isin(load_c, sup_c))))
            if load_ok or not auto or rnd or lev < 0.06:
                break
            lev *= 0.85                     # mehr Material zulassen, bis der Lastpfad geschlossen ist
            info["lowered"] = True
        if one_part and rnd < 4:
            # immer ein Teil: Stücke mit Lagern, Lasten oder massiven Zonen an das Hauptteil anschließen
            add = connect_parts(model, solid, xp, sup | lod | model.passive, log=getattr(model, "clean_log", None))
            if add is not None and add.any():
                xp[add] = 1.0
                excl[add] = False
                conn_mask |= add
                info["connected"] += int(add.sum())
                field = _smoothed_field(model, xp, sigma, excl)
                continue
        # behalten: Stücke mit Lager (bzw. im Ein-Teil-Modus alle Stücke mit Pflichtbereichen)
        keep_c = np.unique(el[(sup | lod | model.passive) & (el > 0)]) if one_part else sup_c
        keep = (el > 0) & np.isin(el, keep_c)
        drop = solid & ~keep
        bridge = keep & ~solid
        if rnd == 0:
            info["islands"] = int(n - len(sup_c))
            info["load_ok"] = bool(load_ok)
        if not drop.any() and not bridge.any():
            break
        excl |= drop
        info["removed"] += int(drop.sum())
        xp[drop] = 0.0
        xp[bridge] = 1.0
        excl[bridge] = False
        info["bridges"] += int(bridge.sum())
    info["level"] = lev
    info["pruned"] = 0
    if prune and info["load_ok"]:
        act = (_smoothed_field(model, xp, sigma, excl)[ii, jj, kk] > lev) & ~excl
        try:
            dead = _dead_elements(model, act)
        except Exception:
            dead = np.zeros(model.ne, dtype=bool)
        if dead.any():
            excl |= dead
            xp[dead] = 0.0
            info["pruned"] = int(dead.sum())
            # danach erneut bereinigen (feste Schwelle): keine Inseln, Kanten überbrückt
            xp, _, ex2, i2 = clean_density(model, xp, lev, sigma, None, prune=False)
            excl |= ex2
            info["removed"] += i2["removed"]
            info["bridges"] += i2["bridges"]
    return xp, lev, excl, info


def result_mesh(model, xp, level=0.0, sigma=0.7, target=None, clean=True, prune=True):
    """Isofläche der Dichte. level<=0: Schwelle so wählen, dass das Zielvolumen getroffen wird.
    clean: schwebende Teile entfernen und Lastpfad schließen (siehe clean_density)."""
    from .isosurface import marching_cubes
    excl = None
    if clean:
        xp, level, excl, info = clean_density(model, xp, level, sigma, target, prune=prune)
        info["xp"], info["excl"] = xp, excl
        model.last_clean = info
    field = _smoothed_field(model, xp, sigma, excl)
    if level is None or level <= 0:
        level = _auto_level(model, field, target)
    inner = field[model.ei + 1, model.ej + 1, model.ek + 1]
    xb = (inner > level).astype(float)
    if clean:
        model.last_clean["xb"] = xb
    if field.max() <= level:
        raise ValueError("The threshold is too high – no material left.")
    verts, faces, _, _ = marching_cubes(field, level=float(level))
    vphys = model.lo + (verts - 0.5) * model.h
    t = vphys[faces]
    vol = np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2])).sum() / 6.0
    if vol < 0:
        faces = faces[:, ::-1]
        vol = -vol
    return vphys, np.ascontiguousarray(faces), xb, float(level), float(vol)


def drop_floating_fine(model, final, lo, hf, log=print):
    """Feines Ergebnisfeld: alle Bereiche ohne Verbindung zu einer Lagerfläche entfernen."""
    solid = final > 0
    lab, n = label(solid)
    if n <= 1:
        return final, 0
    keep = set()
    shape = np.array(final.shape)
    r = np.arange(-2, 3)
    off = np.stack(np.meshgrid(r, r, r, indexing="ij"), -1).reshape(-1, 3)
    for c in model.conds:
        if c["type"] in ("fixed", "frictionless", "pin") and c.get("tris") is not None and len(c["tris"]):
            pts, _ = G.sample_triangles(model.mesh.tris[np.asarray(c["tris"], dtype=np.int64)], hf)
            if not len(pts):
                continue
            idx = np.floor((pts - lo) / hf).astype(np.int64)
            for o in off:
                q = np.clip(idx + o, 0, shape - 1)
                v = lab[q[:, 0], q[:, 1], q[:, 2]]
                keep.update(np.unique(v[v > 0]).tolist())
    if not keep:
        sizes = np.bincount(lab.ravel())
        sizes[0] = 0
        keep = {int(sizes.argmax())}
        log("WARNING: No support face touches the result – only the largest region is kept.")
    km = np.zeros(n + 1, dtype=bool)
    km[list(keep)] = True
    drop = solid & ~km[lab]
    nd = n - len(keep)
    if nd:
        final = final.copy()
        final[drop] = -hf
        log(f"{nd} floating part(s) without connection to the support removed from the fine mesh "
            f"({drop.sum() * hf ** 3 * model.scale ** 3:.1f} mm³).")
    return final, nd


def refined_mesh(model, xp, level, sigma=0.7, detail_mm=0.0, max_voxels=16_000_000, log=print, excl=None,
                 skeleton=None, progress=None):
    """Ergebnis auf feinem Gitter, verschnitten mit der Originalgeometrie: Bohrungen, Außenflächen
    und erhaltene Zonen bleiben maßhaltig. Liefert (Punkte, Dreiecke, Volumen, (Feld, lo, h))."""
    from scipy.ndimage import map_coordinates
    from .isosurface import marching_cubes
    mesh, S = model.mesh, model.S
    step = progress or (lambda f, t: None)
    ext = mesh.hi - mesh.lo
    hf = float(detail_mm) / model.scale if detail_mm and detail_mm > 0 else 0.0
    auto = (float(np.prod(ext + 1e-12)) / 8e6) ** (1 / 3)
    hf = max(hf, auto if hf == 0 else 0, (float(np.prod(ext + 1e-12)) / max_voxels) ** (1 / 3), model.h / 8)
    lo, shape = G.grid_for(mesh.lo, mesh.hi, hf, pad=3)
    step(0.02, "Fine grid: reading the part")
    inside, odd = G.voxelize(mesh.tris, lo, hf, shape, robust=bool(S.get("robust")) or not mesh.watertight)
    step(0.12, "Fine grid: distance field")
    din = distance_transform_edt(inside).astype(np.float32)
    dout = distance_transform_edt(~inside).astype(np.float32)
    sdf = np.where(inside, din - 0.5, -(dout - 0.5)) * np.float32(hf)
    del din, dout
    sdf = gaussian_filter(sdf, 0.7).astype(np.float32)

    step(0.25, "Fine grid: density field")
    # Dichte nach außen fortsetzen, damit Ränder nicht ausdünnen
    if excl is not None and excl.any():
        xp = np.asarray(xp, dtype=np.float64).copy()
        xp[excl] = 0.0
    g = density_grid(model, xp)
    m = np.zeros(model.shape, dtype=bool)
    m[model.ei, model.ej, model.ek] = True
    if not m.all():
        _, (ix, iy, iz) = distance_transform_edt(~m, return_indices=True)
        g = g[ix, iy, iz]
    if sigma > 0:
        g = gaussian_filter(g, sigma)
    g = g.astype(np.float32)

    keep, cut = [], []
    for c in model.conds:
        t = c["type"]
        if t in ("solid", "void") and c.get("tris") is not None and len(c["tris"]):
            pts, _ = G.sample_triangles(mesh.tris[np.asarray(c["tris"], dtype=np.int64)], 0.5 * hf)
            d = max(float(c.get("depth", 0) or 0) / model.scale, model.h if t == "solid" else 0.75 * model.h)
            (keep if t == "solid" else cut).append((cKDTree(pts), d))
        elif t in ("fixed", "frictionless", "pin", "load") and S.get("keep_bc") and c.get("tris") is not None:
            pts, _ = G.sample_triangles(mesh.tris[np.asarray(c["tris"], dtype=np.int64)], 0.5 * hf)
            keep.append((cKDTree(pts), max(float(S.get("bc_wall_mm", 2.0) or 0) / model.scale, 0.5 * hf)))
    boxes = [(np.asarray(c["min"], float), np.asarray(c["max"], float), c["type"])
             for c in model.conds if c["type"] in ("box_solid", "box_void")]

    guard = None
    if skeleton is not None:
        # Mindestgerüst: 0,3 an jedem massiven Voxel des groben Ergebnisses, trilinear interpoliert.
        # Entlang jeder Verbindung zweier flächig benachbarter massiver Voxel ist es konstant 0,3 > 0,22:
        # die Verbindung bleibt garantiert erhalten – ohne Noppen und ohne das Bauteil aufzublähen
        # (an Außenflächen liegt die Gerüstgrenze innerhalb des Randvoxels).
        guard = np.zeros(model.shape, dtype=np.float32)
        guard[model.ei, model.ej, model.ek] = np.float32(0.3) * (np.asarray(skeleton) > 0.5)
    axes = [(lo[a] + (np.arange(shape[a]) + 0.5) * hf).astype(np.float32) for a in range(3)]
    final = np.empty(shape, dtype=np.float32)
    scale_d = np.float32(2.0 * model.h)
    for a0 in range(0, shape[0], 8):
        step(0.3 + 0.5 * a0 / max(shape[0], 1), "Fine grid: intersecting with original faces")
        sl = slice(a0, min(shape[0], a0 + 8))
        X = np.empty((sl.stop - sl.start, shape[1], shape[2], 3), dtype=np.float32)
        X[..., 0] = axes[0][sl][:, None, None]
        X[..., 1] = axes[1][None, :, None]
        X[..., 2] = axes[2][None, None, :]
        s = sdf[sl]
        near = s > -2 * hf
        f = np.minimum(s, -hf).astype(np.float32)
        if near.any():
            P = X[near]
            idx = ((P - model.lo) / model.h - 0.5).T
            rho = map_coordinates(g, idx, order=1, mode="nearest").astype(np.float32)
            fd = (rho - np.float32(level)) * scale_d
            if guard is not None:
                # Verbindungen des groben Ergebnisses dürfen im Feinnetz nicht abreißen
                gv = map_coordinates(guard, idx, order=1, mode="constant", cval=0.0).astype(np.float32)
                fd = np.maximum(fd, (gv - np.float32(0.22)) * scale_d)
            fn = np.minimum(fd, s[near])
            sn = s[near]
            for tree, d in keep:
                dist, _ = tree.query(P, distance_upper_bound=d + 2 * hf)
                fn = np.maximum(fn, np.minimum(sn, (d - dist).astype(np.float32)))
            for tree, d in cut:
                dist, _ = tree.query(P, distance_upper_bound=d + 2 * hf)
                fn = np.minimum(fn, (dist - d).astype(np.float32))
            for bmin, bmax, bt in boxes:
                inb = np.all((P >= bmin) & (P <= bmax), axis=1)
                if bt == "box_solid":
                    fn = np.where(inb, np.maximum(fn, sn), fn)
                else:
                    fn = np.where(inb, -hf, fn)
            f[near] = fn
        final[sl] = f
    if final.max() <= 0:
        raise ValueError("No material in the refined result – check the threshold.")
    step(0.82, "Fine mesh: removing loose parts")
    final, _ = drop_floating_fine(model, final, lo, hf, log=log)
    step(0.9, "Fine mesh: creating surface")
    verts, faces, _, _ = marching_cubes(final, 0.0, spacing=(hf, hf, hf))
    verts = verts + lo + 0.5 * hf
    t = verts[faces]
    vol = np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2])).sum() / 6.0
    if vol < 0:
        faces = faces[:, ::-1]
        vol = -vol
    log(f"Refined result: detail size {hf * model.scale:.2f} mm, {len(faces)} triangles "
        "(original faces adopted)")
    return verts, np.ascontiguousarray(faces), float(vol), (final, lo, hf)
