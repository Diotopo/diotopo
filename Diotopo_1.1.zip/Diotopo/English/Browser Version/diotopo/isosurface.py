# -*- coding: utf-8 -*-
"""
Isoflächen aus Voxelfeldern (Surface Nets), vollständig in numpy.
Ersetzt skimage.measure.marching_cubes – gleiche Koordinatenkonvention:
Punkt (i, j, k) entspricht dem Feldwert field[i, j, k]; Material ist field > level.
Die Dreiecke sind nach außen orientiert.
"""

import numpy as np


def surface_nets(field, level=0.0, spacing=(1.0, 1.0, 1.0), step_size=1):
    f = np.asarray(field, dtype=np.float32)
    if step_size > 1:
        f = f[::step_size, ::step_size, ::step_size]
    lv = np.float32(level)
    low = min(float(f.min()), float(lv)) - 1.0
    f = np.pad(f, 1, constant_values=low)          # Rand sicher außen
    inside = f > lv
    shp = np.array(f.shape)
    cshape = shp - 1                                  # Zellen
    csz = int(np.prod(cshape))

    sums = np.zeros((csz, 3), dtype=np.float64)
    cnt = np.zeros(csz, dtype=np.int32)
    edges = []
    for a in range(3):
        sl0 = [slice(None)] * 3
        sl1 = [slice(None)] * 3
        sl0[a] = slice(0, -1)
        sl1[a] = slice(1, None)
        cross = inside[tuple(sl0)] != inside[tuple(sl1)]
        idx = np.nonzero(cross)
        if len(idx[0]) == 0:
            edges.append(None)
            continue
        i = np.stack(idx, 1)
        f0 = f[tuple(sl0)][idx]
        f1 = f[tuple(sl1)][idx]
        t = (lv - f0) / np.where(f1 != f0, f1 - f0, 1.0)
        p = i.astype(np.float64)
        p[:, a] += t
        u, v = (a + 1) % 3, (a + 2) % 3
        for du in (0, 1):
            for dv in (0, 1):
                c = i.copy()
                c[:, u] -= du
                c[:, v] -= dv
                ok = (c[:, u] >= 0) & (c[:, v] >= 0) & (c[:, u] < cshape[u]) & (c[:, v] < cshape[v])
                lid = np.ravel_multi_index(c[ok].T, cshape)
                np.add.at(cnt, lid, 1)
                for k in range(3):
                    sums[:, k] += np.bincount(lid, weights=p[ok, k], minlength=csz)
        edges.append((i, f0 > lv))
    act = np.flatnonzero(cnt)
    if len(act) == 0:
        raise ValueError("No surface found.")
    verts = sums[act] / cnt[act, None]
    vmap = -np.ones(csz, dtype=np.int64)
    vmap[act] = np.arange(len(act))

    faces = []
    for a, e in enumerate(edges):
        if e is None:
            continue
        i, out_pos = e
        u, v = (a + 1) % 3, (a + 2) % 3
        ok = (i[:, u] >= 1) & (i[:, v] >= 1) & (i[:, u] < cshape[u]) & (i[:, v] < cshape[v])
        i, out_pos = i[ok], out_pos[ok]
        q = []
        for du, dv in ((1, 1), (0, 1), (0, 0), (1, 0)):   # (u-1,v-1),(u,v-1),(u,v),(u-1,v)
            c = i.copy()
            c[:, u] -= du
            c[:, v] -= dv
            q.append(vmap[np.ravel_multi_index(c.T, cshape)])
        q = np.stack(q, 1)
        # Normale +a, wenn Material am unteren Ende liegt, sonst umdrehen
        q[~out_pos] = q[~out_pos][:, ::-1]
        faces.append(np.concatenate([q[:, [0, 1, 2]], q[:, [0, 2, 3]]]))
    faces = np.concatenate(faces).astype(np.int64)
    faces = faces[(faces[:, 0] != faces[:, 1]) & (faces[:, 1] != faces[:, 2]) & (faces[:, 0] != faces[:, 2])]
    # Randversatz (-1) zurückrechnen, Schrittweite und Abstand anwenden
    verts = (verts - 1.0) * step_size * np.asarray(spacing, dtype=np.float64)
    return verts.astype(np.float64), faces


def marching_cubes(field, level=0.0, spacing=(1.0, 1.0, 1.0), step_size=1, **_):
    """Kompatible Schnittstelle zu skimage.measure.marching_cubes."""
    v, f = surface_nets(field, level, spacing, step_size)
    return v, f, None, None
