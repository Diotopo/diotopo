# -*- coding: utf-8 -*-
"""
Gleichungslöser auf der Grafikkarte über OpenCL – herstellerübergreifend:
NVIDIA, AMD und Intel (auch die in den Prozessor eingebaute Grafik).

* Alle Rechnungen auf der Grafikkarte in float32 (viele GPUs, z. B. Intel-Grafik, können kein
  float64; Spielegrafikkarten sind darin sehr langsam).
* Die volle Genauigkeit liefert eine Nachkorrektur auf der CPU in float64:
      r = b − K·x  (CPU, float64)   →   K·d ≈ r  (GPU, float32, vorkonditioniertes CG)   →   x += d
* Vorkonditionierer: geometrisches Mehrgitter (V-Zyklus, Chebyshev-Glätter) – Galerkin-Matrizen
  entstehen auf der CPU, Glättung/Transfers auf der GPU, gröbstes Gitter direkt auf der CPU.
* Matrizen im ELL-Format (spaltenweise gespeichert): gut für alle GPU-Architekturen.
"""

import os

import numpy as np

from . import solver as SO

KERNELS = r"""
// y = A x   (ELL, spaltenweise: Eintrag j der Zeile i liegt bei j*n + i; Spalte < 0 = leer)
__kernel void ell_spmv(const int n, const int w, __global const int *col, __global const float *val,
                       __global const float *x, __global float *y)
{
    int i = get_global_id(0);
    if (i >= n) return;
    float s = 0.0f;
    for (int j = 0; j < w; j++) {
        int c = col[j * n + i];
        if (c >= 0) s += val[j * n + i] * x[c];
    }
    y[i] = s;
}

// out = a*x + b*y
__kernel void axpby(const int n, const float a, __global const float *x, const float b,
                    __global const float *y, __global float *out)
{
    int i = get_global_id(0);
    if (i < n) out[i] = a * x[i] + b * y[i];
}

// out = d .* x * a
__kernel void dscale(const int n, const float a, __global const float *d, __global const float *x,
                     __global float *out)
{
    int i = get_global_id(0);
    if (i < n) out[i] = a * d[i] * x[i];
}

// Chebyshev-Schritt: d = c1*d + c2*Dinv.*(r - Ax);  x += d
__kernel void cheb(const int n, const float c1, const float c2, __global float *d,
                   __global const float *dinv, __global const float *r, __global const float *ax,
                   __global float *x)
{
    int i = get_global_id(0);
    if (i < n) {
        float v = c1 * d[i] + c2 * dinv[i] * (r[i] - ax[i]);
        d[i] = v;
        x[i] += v;
    }
}

// CG: x += a*p;  r -= a*ap
__kernel void cg_update(const int n, const float a, __global const float *p, __global const float *ap,
                        __global float *x, __global float *r)
{
    int i = get_global_id(0);
    if (i < n) {
        x[i] += a * p[i];
        r[i] -= a * ap[i];
    }
}

// Teilsummen eines Skalarprodukts: Arbeitselement g summiert i = g, g+G, g+2G, …
__kernel void dot_part(const int n, const int g_total, __global const float *x, __global const float *y,
                       __global float *part)
{
    int g = get_global_id(0);
    if (g >= g_total) return;
    float s = 0.0f;
    for (int i = g; i < n; i += g_total) s += x[i] * y[i];
    part[g] = s;
}
"""

WG = 64            # globale Größe wird auf Vielfache davon aufgerundet
DOT_PARTS = 2048   # Teilsummen je Skalarprodukt (auf der CPU in float64 addiert)


def _round(n):
    return ((int(n) + WG - 1) // WG) * WG


# ================================================================ Gerät

_STATE = {}


def _list_devices(cl):
    """Alle OpenCL-Grafikkarten (doppelt gemeldete – gleiche Karte über zwei Treiber – nur einmal)."""
    devs, seen = [], {}
    for pi, p in enumerate(cl.get_platforms()):
        try:
            found = p.get_devices(device_type=cl.device_type.GPU)
        except Exception:
            found = []
        for d in found:
            pci = None
            for attr in ("pci_bus_id_nv", "topology_amd"):
                try:
                    v = getattr(d, attr)
                    pci = (attr, str(v))
                    break
                except Exception:
                    pass
            key = (" ".join(str(d.name).split()), int(d.global_mem_size), pci)
            if key in seen and (pci is not None or seen[key] != pi):
                continue                                  # dieselbe Karte über einen zweiten Treiber
            seen[key] = pi
            devs.append(d)
    want = os.environ.get("DIOTOPO_OPENCL_DEVICE", "").strip().lower()
    if want:
        keep = []
        for w in (x.strip() for x in want.split(",") if x.strip()):
            for i, d in enumerate(devs):
                if (w == str(i) or w in d.name.lower()) and d not in keep:
                    keep.append(d)
        devs = keep
    return devs


def _score(d):   # eigene Grafikkarte (eigener Speicher) vor eingebauter, dann Rechenleistung
    discrete = 0 if getattr(d, "host_unified_memory", False) else 1
    return (discrete, int(d.max_compute_units) * int(getattr(d, "max_clock_frequency", 1000)),
            int(d.global_mem_size))


def _pick_device(cl):
    devs = _list_devices(cl)
    if not devs:
        raise RuntimeError("no OpenCL graphics card found")
    return max(devs, key=_score)


class CLDevice:
    def __init__(self, dev=None):
        import pyopencl as cl
        self.cl = cl
        self.dev = dev if dev is not None else _pick_device(cl)
        self.name = " ".join(str(self.dev.name).split())
        self.ctx = cl.Context([self.dev])
        self.q = cl.CommandQueue(self.ctx)
        self.prg = cl.Program(self.ctx, KERNELS).build()
        self.k = {n: getattr(self.prg, n) for n in ("ell_spmv", "axpby", "dscale", "cheb", "cg_update",
                                                    "dot_part")}
        self.mem = int(self.dev.global_mem_size)
        self.max_alloc = int(self.dev.max_mem_alloc_size)
        self.unified = bool(getattr(self.dev, "host_unified_memory", False))
        self._part = self.empty(DOT_PARTS)
        self._part_h = np.empty(DOT_PARTS, dtype=np.float32)
        self._probe()

    # ---------------- Speicher
    def empty(self, n, dtype=np.float32):
        return self.cl.Buffer(self.ctx, self.cl.mem_flags.READ_WRITE, size=max(int(n), 1) * np.dtype(dtype).itemsize)

    def upload(self, a, dtype=np.float32):
        a = np.ascontiguousarray(a, dtype=dtype)
        b = self.cl.Buffer(self.ctx, self.cl.mem_flags.READ_WRITE | self.cl.mem_flags.COPY_HOST_PTR, hostbuf=a)
        return b

    def write(self, buf, a):
        self.cl.enqueue_copy(self.q, buf, np.ascontiguousarray(a, dtype=np.float32))

    def read(self, buf, n):
        out = np.empty(int(n), dtype=np.float32)
        self.cl.enqueue_copy(self.q, out, buf)
        return out

    # ---------------- Matrizen (ELL)
    def ell(self, A):
        A = A.tocsr()
        n = A.shape[0]
        lens = np.diff(A.indptr)
        w = int(lens.max()) if n else 0
        col = np.full((w, n), -1, dtype=np.int32)
        val = np.zeros((w, n), dtype=np.float32)
        rows = np.repeat(np.arange(n), lens)
        pos = np.arange(A.nnz) - np.repeat(A.indptr[:-1], lens)
        col[pos, rows] = A.indices
        val[pos, rows] = A.data
        if w * n * 4 > self.max_alloc:
            raise MemoryError("Matrix larger than the largest permitted GPU allocation")
        return dict(n=n, w=w, col=self.upload(col.ravel(), np.int32), val=self.upload(val.ravel()))

    # ---------------- Operationen (alle float32)
    def spmv(self, M, x, y):
        self.k["ell_spmv"](self.q, (_round(M["n"]),), None, np.int32(M["n"]), np.int32(M["w"]),
                           M["col"], M["val"], x, y)

    def axpby(self, n, a, x, b, y, out):
        self.k["axpby"](self.q, (_round(n),), None, np.int32(n), np.float32(a), x, np.float32(b), y, out)

    def dscale(self, n, a, d, x, out):
        self.k["dscale"](self.q, (_round(n),), None, np.int32(n), np.float32(a), d, x, out)

    def cheb(self, n, c1, c2, d, dinv, r, ax, x):
        self.k["cheb"](self.q, (_round(n),), None, np.int32(n), np.float32(c1), np.float32(c2),
                       d, dinv, r, ax, x)

    def cg_update(self, n, a, p, ap, x, r):
        self.k["cg_update"](self.q, (_round(n),), None, np.int32(n), np.float32(a), p, ap, x, r)

    def dot(self, n, x, y):
        self.k["dot_part"](self.q, (_round(DOT_PARTS),), None, np.int32(n), np.int32(DOT_PARTS), x, y, self._part)
        self.cl.enqueue_copy(self.q, self._part_h, self._part)
        return float(self._part_h.astype(np.float64).sum())

    def _probe(self):
        """Kleine Rechnung gegen numpy prüfen (fängt defekte Treiber ab)."""
        import scipy.sparse as sp
        A = (sp.random(300, 300, density=0.03, format="csr", random_state=0) + sp.identity(300)).tocsr()
        x = np.random.default_rng(0).random(300).astype(np.float32)
        M = self.ell(A)
        xb, yb = self.upload(x), self.empty(300)
        self.spmv(M, xb, yb)
        y = self.read(yb, 300)
        ok = np.allclose(y, A @ x, rtol=1e-4, atol=1e-5)
        d = self.dot(300, xb, xb)
        ok = ok and abs(d - float(x.astype(np.float64) @ x)) < 1e-3 * max(d, 1)
        if not ok:
            raise RuntimeError("OpenCL probe returned wrong values")


def device():
    """OpenCL-Gerät oder None (einmalig ermittelt)."""
    if "dev" not in _STATE:
        d, why = None, ""
        if os.environ.get("DIOTOPO_NO_GPU"):
            why = "disabled via DIOTOPO_NO_GPU"
        else:
            try:
                d = CLDevice()
            except Exception as e:  # noqa
                why = f"{type(e).__name__}: {e}"
        _STATE["dev"], _STATE["why"] = d, why
    return _STATE["dev"]


def devices():
    """Alle nutzbaren OpenCL-Grafikkarten (je eine CLDevice, schnellste zuerst; einmalig ermittelt).
    Für das gemeinsame Rechnen werden alle gleichzeitig verwendet."""
    if "all" not in _STATE:
        out, why = [], []
        if not (os.environ.get("DIOTOPO_NO_GPU")):
            try:
                import pyopencl as cl
                found = sorted(_list_devices(cl), key=_score, reverse=True)
            except Exception as e:  # noqa
                found, why = [], [f"{type(e).__name__}: {e}"]
            for d in found:
                try:
                    out.append(CLDevice(d))
                except Exception as e:  # noqa
                    why.append(f"{' '.join(str(d.name).split())}: {type(e).__name__}: {e}")
        _STATE["all"], _STATE["all_why"] = out, "; ".join(why)
    return _STATE["all"]


def benchmark():
    """Tempo-Verhältnis CPU/GPU für ein Matrix-Vektor-Produkt typischer Größe (einmal je Sitzung).
    Der GPU-Löser braucht etwa 3× so viele Produkte wie der CPU-Löser – erst ab Verhältnis > 3 lohnt er."""
    if "ratio" in _STATE:
        return _STATE["ratio"]
    d = device()
    if d is None:
        return 0.0
    import time
    import scipy.sparse as sp
    try:
        n = 150_000
        A = sp.random(n, n, density=81.0 / n, format="csr", random_state=1, dtype=np.float64)
        x2 = np.ones((n, 2))
        t = time.perf_counter()
        for _ in range(3):
            A @ x2
        tc = (time.perf_counter() - t) / 3
        M = d.ell(A)
        xb, yb = d.upload(np.ones(n)), d.empty(n)
        d.spmv(M, xb, yb)
        d.q.finish()
        t = time.perf_counter()
        for _ in range(6):
            d.spmv(M, xb, yb)
        d.q.finish()
        tg = (time.perf_counter() - t) / 3          # zwei Produkte je Spalte ≙ 2 rechte Seiten
        _STATE["ratio"] = tc / max(tg, 1e-9)
    except Exception:
        _STATE["ratio"] = 0.0
    return _STATE["ratio"]


def worth_it():
    """Lohnt die GPU im Automatik-Modus? Eigene Grafikkarte: ja; eingebaute: nach Messung."""
    d = device()
    if d is None:
        return False
    if not d.unified:
        return True
    return benchmark() > 3.0


def status():
    d = device()
    return dict(available=d is not None, device=getattr(d, "name", None), reason=_STATE.get("why", ""),
                memory_gb=(d.mem / 2**30) if d else None, unified=getattr(d, "unified", None))


def memory_need(n):
    """Geschätzter GPU-Speicher (Byte) für n Unbekannte: ELL fein + grob, Vektoren."""
    return int(n * (81 * 8 * 1.35 + 40 * 4))


# ================================================================ Löser

class CLSolver:
    """Mehrgitter-PCG auf dem OpenCL-Gerät mit float64-Nachkorrektur auf der CPU."""

    def __init__(self, dev, K, free, node_coords, cache=None, cancel=None, degree=3):
        self.d, self.K, self.cancel, self.degree = dev, K.tocsr(), cancel, degree
        As, Ps = SO.galerkin_levels(self.K, free, node_coords, cache, cancel)
        self.coarse = SO._lu(As[-1])
        self.nlev = len(As)
        self.lv = []
        for lvl, A_ in enumerate(As[:-1]):
            Dinv, gersh = SO.smoother_bounds(A_)
            n = A_.shape[0]
            L = dict(n=n, A=dev.ell(A_), P=dev.ell(Ps[lvl][0]), PT=dev.ell(Ps[lvl][1]),
                     dinv=dev.upload(Dinv), nc=Ps[lvl][0].shape[1])
            for t in ("x", "d", "ax", "t", "x2", "pz"):
                L[t] = dev.empty(n)
            L["rc"] = dev.empty(L["nc"])
            # Potenzmethode auf dem Gerät (Warmstart mit dem letzten Eigenvektor)
            v0, nit = SO.power_start(cache, lvl, n)
            v, w = dev.upload(v0 / max(np.linalg.norm(v0), 1e-30)), dev.empty(n)
            lam = 1.0
            for _ in range(nit):
                dev.spmv(L["A"], v, L["t"])
                dev.dscale(n, 1.0, L["dinv"], L["t"], w)
                nw = np.sqrt(max(dev.dot(n, w, w), 1e-60))
                nv = np.sqrt(max(dev.dot(n, v, v), 1e-60))
                lam = nw / nv
                dev.axpby(n, 1.0 / nw, w, 0.0, w, v)
            if cache is not None:
                cache[("v", lvl, n)] = dev.read(v, n).astype(np.float64)
            L["lmax"] = min(1.3 * lam, gersh)
            self.lv.append(L)
        if self.nlev < 2:
            raise RuntimeError("System too small for the GPU solver")
        n0 = self.K.shape[0]
        self.n = n0
        self.Kd = self.lv[0]["A"]
        self.cg = {t: dev.empty(n0) for t in ("r", "z", "zo", "p", "ap", "x")}

    # ---------------- V-Zyklus (z = M⁻¹ r), alles auf dem Gerät außer der gröbsten Ebene
    def _smooth(self, L, r, x):
        dev, n = self.d, L["n"]
        lmax = L["lmax"]
        lmin = lmax / 30.0
        theta, delta = 0.5 * (lmax + lmin), 0.5 * (lmax - lmin)
        sigma = theta / delta
        rho = 1.0 / sigma
        dev.dscale(n, 1.0 / theta, L["dinv"], r, L["d"])
        dev.axpby(n, 1.0, L["d"], 0.0, L["d"], x)
        for _ in range(1, self.degree):
            rho_n = 1.0 / (2.0 * sigma - rho)
            dev.spmv(L["A"], x, L["ax"])
            dev.cheb(n, rho_n * rho, 2.0 * rho_n / delta, L["d"], L["dinv"], r, L["ax"], x)
            rho = rho_n

    def _vc(self, lvl, r, z):
        dev = self.d
        if lvl == self.nlev - 1:
            nc = self.lv[lvl - 1]["nc"]
            rh = dev.read(r, nc).astype(np.float64)
            dev.write(z, self.coarse.solve(rh).astype(np.float32))
            return
        L = self.lv[lvl]
        n = L["n"]
        self._smooth(L, r, z)                                   # z = S r
        dev.spmv(L["A"], z, L["ax"])
        dev.axpby(n, 1.0, r, -1.0, L["ax"], L["t"])             # t = r − A z
        dev.spmv(L["PT"], L["t"], L["rc"])                      # rc = Pᵀ t
        zc = L.setdefault("zc", dev.empty(L["nc"]))
        self._vc(lvl + 1, L["rc"], zc)                          # grobe Korrektur (rekursiv)
        dev.spmv(L["P"], zc, L["pz"])
        dev.axpby(n, 1.0, z, 1.0, L["pz"], z)                   # z += P zc
        dev.spmv(L["A"], z, L["ax"])
        dev.axpby(n, 1.0, r, -1.0, L["ax"], L["t"])             # t = r − A z
        self._smooth(L, L["t"], L["x2"])
        dev.axpby(n, 1.0, z, 1.0, L["x2"], z)                   # z += S t

    # ---------------- inneres PCG in float32: K d ≈ r0
    def _inner(self, r0, tol, maxit):
        dev, n, c = self.d, self.n, self.cg
        A = self.Kd
        dev.write(c["r"], r0)
        dev.axpby(n, 0.0, c["r"], 0.0, c["r"], c["x"])          # x = 0
        bn = np.sqrt(max(dev.dot(n, c["r"], c["r"]), 1e-60))
        self._vc(0, c["r"], c["z"])
        dev.axpby(n, 1.0, c["z"], 0.0, c["z"], c["p"])
        rz = dev.dot(n, c["r"], c["z"])
        it = 0
        for it in range(1, maxit + 1):
            dev.spmv(A, c["p"], c["ap"])
            pap = dev.dot(n, c["p"], c["ap"])
            if not (pap > 0):
                break
            a = rz / pap
            dev.cg_update(n, a, c["p"], c["ap"], c["x"], c["r"])
            res = np.sqrt(max(dev.dot(n, c["r"], c["r"]), 0.0)) / bn
            if res < tol:
                break
            if self.cancel is not None and self.cancel():
                raise SO.Stopped()
            dev.axpby(n, 1.0, c["z"], 0.0, c["z"], c["zo"])
            self._vc(0, c["r"], c["z"])
            rz_new = dev.dot(n, c["r"], c["z"])
            rz_pr = rz_new - dev.dot(n, c["r"], c["zo"])       # Polak-Ribière (robust in float32)
            beta = max(rz_pr, 0.0) / rz if rz > 0 else 0.0
            dev.axpby(n, 1.0, c["z"], beta, c["p"], c["p"])
            rz = rz_new
        return dev.read(c["x"], n).astype(np.float64), it

    def solve(self, B, X0=None, tol=1e-8, maxit=600):
        """float64-Lösung über Nachkorrektur; liefert (X, CG-Schritte gesamt, rel. Residuum)."""
        B = np.asarray(B, dtype=np.float64)
        B2 = B[:, None] if B.ndim == 1 else B
        X = np.zeros_like(B2) if X0 is None else np.array(X0, dtype=np.float64).reshape(B2.shape)
        total, worst = 0, 0.0
        for k in range(B2.shape[1]):
            b = B2[:, k]
            bn = max(np.linalg.norm(b), 1e-300)
            x = X[:, k]
            res = np.linalg.norm(b - self.K @ x) / bn
            for _ in range(12):
                r = b - self.K @ x                              # float64 auf der CPU
                res = np.linalg.norm(r) / bn
                if res < tol:
                    break
                s = max(float(np.abs(r).max()), 1e-300)
                # innere Genauigkeit über ~1e-3 hinaus bringt in float32 nichts (Kontrast der Steifigkeiten)
                d, it = self._inner((r / s).astype(np.float32), tol=max(3e-4, tol), maxit=maxit)
                total += it
                x = x + s * d
            X[:, k] = x
            worst = max(worst, res)
        return X.reshape(B.shape), total, worst
