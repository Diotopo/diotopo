# -*- coding: utf-8 -*-
"""
Geometrie: Import (STEP, STL, 3MF, OBJ, PLY, ZIP), Netzaufbereitung
(Orientierung, Flächenerkennung, Zylinder-Erkennung), Voxelisierung
(Strahlverfahren oder robustes Umhüllen) und Export (STL, 3MF, OBJ).
"""

import io
import math
import os
import re
import struct
import tempfile
import zipfile
import xml.etree.ElementTree as ET

import numpy as np
import scipy.sparse as sp
from scipy.ndimage import binary_dilation, binary_erosion, binary_fill_holes
from scipy.sparse.csgraph import breadth_first_order, connected_components

SUPPORTED = (".stl", ".step", ".stp", ".3mf", ".obj", ".ply", ".zip")
UNIT_MM = {"micron": 0.001, "millimeter": 1.0, "centimeter": 10.0, "meter": 1000.0,
           "inch": 25.4, "foot": 304.8}


# =============================================================== Import

def read_any(name, data, log=print):
    """Gibt (tris[n,3,3], face_ids[n] oder None, einheit, info) zurück.
    STEP und 3MF werden in mm geliefert, STL/OBJ/PLY in der Einheit der Datei."""
    ext = os.path.splitext(name.lower())[1]
    if ext == ".zip":
        return _read_zip(data, log)
    if ext == ".stl":
        return read_stl(data), None, None, "STL"
    if ext in (".step", ".stp"):
        tris, fid = read_step(data, log)
        return tris, fid, "mm", "STEP"
    if ext == ".3mf":
        return read_3mf(data), None, "mm", "3MF"
    if ext == ".obj":
        return read_obj(data), None, None, "OBJ"
    if ext == ".ply":
        return read_ply(data), None, None, "PLY"
    raise ValueError("File type is not supported. Allowed: " + ", ".join(SUPPORTED))


def _read_zip(data, log):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names = [n for n in z.namelist() if os.path.splitext(n.lower())[1] in SUPPORTED[:-1]]
        if not names:
            raise ValueError("The ZIP archive contains no STEP, STL, 3MF, OBJ or PLY file.")
        prio = {".step": 0, ".stp": 0, ".3mf": 1, ".stl": 2, ".obj": 3, ".ply": 4}
        names.sort(key=lambda n: (prio[os.path.splitext(n.lower())[1]], -z.getinfo(n).file_size))
        pick = names[0]
        if len(names) > 1:
            log(f"ZIP contains {len(names)} models – using “{pick}”.")
        return read_any(pick, z.read(pick), log)


def read_stl(data):
    if len(data) >= 84:
        n = struct.unpack("<I", data[80:84])[0]
        is_ascii = data[:5].lower() == b"solid" and b"facet" in data[:2000]
        if n > 0 and len(data) >= 84 + 50 * n and (len(data) == 84 + 50 * n or not is_ascii):
            dt = np.dtype([("n", "<f4", (3,)), ("v", "<f4", (3, 3)), ("a", "<u2")])
            arr = np.frombuffer(data, dtype=dt, count=n, offset=84)
            return arr["v"].astype(np.float64)
    text = data.decode("utf-8", errors="ignore")
    found = re.findall(r"vertex\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)\s+([-+0-9.eE]+)", text)
    if not found or len(found) % 3:
        raise ValueError("The file is not a valid STL file.")
    return np.array(found, dtype=np.float64).reshape(-1, 3, 3)


def read_obj(data):
    text = data.decode("utf-8", errors="ignore")
    verts, faces = [], []
    for line in text.splitlines():
        if line.startswith("v "):
            p = line.split()
            verts.append((float(p[1]), float(p[2]), float(p[3])))
        elif line.startswith("f "):
            idx = []
            for tok in line.split()[1:]:
                i = int(tok.split("/")[0])
                idx.append(i - 1 if i > 0 else len(verts) + i)
            for k in range(1, len(idx) - 1):
                faces.append((idx[0], idx[k], idx[k + 1]))
    if not faces:
        raise ValueError("The OBJ file contains no faces.")
    return np.asarray(verts, dtype=np.float64)[np.asarray(faces)]


_PLY_T = {"char": "i1", "int8": "i1", "uchar": "u1", "uint8": "u1", "short": "i2", "int16": "i2",
          "ushort": "u2", "uint16": "u2", "int": "i4", "int32": "i4", "uint": "u4", "uint32": "u4",
          "float": "f4", "float32": "f4", "double": "f8", "float64": "f8"}


def read_ply(data):
    end = data.find(b"end_header")
    if not data.startswith(b"ply") or end < 0:
        raise ValueError("The file is not a valid PLY file.")
    header = data[:end].decode("ascii", errors="ignore").splitlines()
    body = data[data.index(b"\n", end) + 1:]
    fmt = "ascii"
    elems = []
    for ln in header:
        p = ln.split()
        if not p:
            continue
        if p[0] == "format":
            fmt = p[1]
        elif p[0] == "element":
            elems.append([p[1], int(p[2]), []])
        elif p[0] == "property" and elems:
            elems[-1][2].append(p[1:])
    verts = faces = None
    if fmt == "ascii":
        tokens = body.split()
        pos = 0
        for name, count, props in elems:
            if name == "vertex":
                n = len(props)
                arr = np.array(tokens[pos:pos + n * count], dtype=np.float64).reshape(count, n)
                pos += n * count
                names = [pr[-1] for pr in props]
                verts = arr[:, [names.index("x"), names.index("y"), names.index("z")]]
            elif name == "face":
                faces = []
                for _ in range(count):
                    k = int(tokens[pos])
                    idx = [int(t) for t in tokens[pos + 1:pos + 1 + k]]
                    pos += 1 + k
                    for j in range(1, k - 1):
                        faces.append((idx[0], idx[j], idx[j + 1]))
                faces = np.asarray(faces)
            else:
                pos += len(props) * count
    else:
        bo = "<" if "little" in fmt else ">"
        off = 0
        for name, count, props in elems:
            if all(pr[0] != "list" for pr in props):
                dt = np.dtype([(pr[1], bo + _PLY_T[pr[0]]) for pr in props])
                arr = np.frombuffer(body, dtype=dt, count=count, offset=off)
                off += dt.itemsize * count
                if name == "vertex":
                    verts = np.stack([arr["x"], arr["y"], arr["z"]], 1).astype(np.float64)
            elif name == "face" and len(props) == 1:
                _, ct, it, _ = props[0]
                ctn, itn = bo + _PLY_T[ct], bo + _PLY_T[it]
                # schneller Weg: nur Dreiecke
                dt = np.dtype([("k", ctn), ("i", itn, (3,))])
                trial = np.frombuffer(body, dtype=dt, count=count, offset=off) \
                    if off + dt.itemsize * count <= len(body) else None
                if trial is not None and np.all(trial["k"] == 3):
                    faces = trial["i"].astype(np.int64)
                    off += dt.itemsize * count
                else:
                    faces = []
                    cs, isz = np.dtype(ctn).itemsize, np.dtype(itn).itemsize
                    for _ in range(count):
                        k = int(np.frombuffer(body, ctn, 1, off)[0])
                        off += cs
                        idx = np.frombuffer(body, itn, k, off)
                        off += isz * k
                        for j in range(1, k - 1):
                            faces.append((idx[0], idx[j], idx[j + 1]))
                    faces = np.asarray(faces, dtype=np.int64)
            else:
                raise ValueError("This PLY format is not supported.")
    if verts is None or faces is None or len(faces) == 0:
        raise ValueError("The PLY file contains no triangles.")
    return verts[faces]


def read_3mf(data):
    z = zipfile.ZipFile(io.BytesIO(data))
    models = [n for n in z.namelist() if n.lower().endswith(".model")]
    if not models:
        raise ValueError("The 3MF file contains no model.")
    objects = {}   # (pfad, id) -> ("mesh", tris) | ("comp", [(pfad, id, M)])
    root_path, unit = None, 1.0
    for mp in models:
        root = ET.fromstring(z.read(mp))
        key_path = "/" + mp.lstrip("/")
        if mp.lower().endswith("3d/3dmodel.model"):
            root_path = key_path
            unit = UNIT_MM.get(root.get("unit", "millimeter"), 1.0)
        for obj in root.iter():
            if not obj.tag.endswith("}object"):
                continue
            oid = obj.get("id")
            mesh = next((c for c in obj if c.tag.endswith("}mesh")), None)
            if mesh is not None:
                vs = next(c for c in mesh if c.tag.endswith("}vertices"))
                ts = next(c for c in mesh if c.tag.endswith("}triangles"))
                V = np.array([(float(v.get("x")), float(v.get("y")), float(v.get("z"))) for v in vs])
                T = np.array([(int(t.get("v1")), int(t.get("v2")), int(t.get("v3"))) for t in ts])
                objects[(key_path, oid)] = ("mesh", V[T] if len(T) else np.zeros((0, 3, 3)))
            comps = next((c for c in obj if c.tag.endswith("}components")), None)
            if comps is not None:
                lst = []
                for c in comps:
                    path = next((v for k, v in c.attrib.items() if k.endswith("path")), None) or key_path
                    lst.append((path, c.get("objectid"), _m3mf(c.get("transform"))))
                objects[(key_path, oid)] = ("comp", lst)
    if root_path is None:
        root_path = "/" + models[0].lstrip("/")
    root = ET.fromstring(z.read(root_path.lstrip("/")))
    out = []

    def emit(path, oid, M, depth=0):
        o = objects.get((path, oid))
        if o is None or depth > 20:
            return
        if o[0] == "mesh":
            t = o[1].reshape(-1, 3)
            out.append((t @ M[:3, :3] + M[3, :3]).reshape(-1, 3, 3))
        else:
            for p, i, Mc in o[1]:
                emit(p, i, Mc @ M, depth + 1)

    for it in root.iter():
        if it.tag.endswith("}item"):
            path = next((v for k, v in it.attrib.items() if k.endswith("path")), None) or root_path
            emit(path, it.get("objectid"), _m3mf(it.get("transform")))
    if not out:
        raise ValueError("The 3MF file contains no triangles.")
    return np.concatenate(out) * unit


def _m3mf(s):
    M = np.zeros((4, 3))
    M[:3] = np.eye(3)
    if s:
        v = [float(x) for x in s.split()]
        if len(v) == 12:
            M = np.array(v).reshape(4, 3)
    return M


def step_available():
    """STEP-Import möglich? (OpenCASCADE über das Paket „cadquery-ocp-novtk“ bzw. „cadquery-ocp“)"""
    try:
        import OCP.STEPControl  # noqa: F401
        return True
    except Exception:
        return False


def _occ(obj, name, *args):
    """Statische OCCT-Funktion aufrufen – je nach OCP-Version heißt sie „Name_s“ oder „Name“
    (in OCCT 7.9 ist z. B. TopoDS ein Namensraum geworden: TopoDS.Face statt TopoDS.Face_s)."""
    for n in (name + "_s", name):
        f = getattr(obj, n, None)
        if f is not None:
            return f(*args)
    raise AttributeError(f"{getattr(obj, '__name__', obj)}.{name}")


def _step_via_stl(shape):
    """Triangulierte Form von OCCT als STL schreiben lassen und einlesen (unabhängig von Bindungsdetails)."""
    from OCP.StlAPI import StlAPI_Writer
    fd, path = tempfile.mkstemp(suffix=".stl")
    os.close(fd)
    try:
        w = StlAPI_Writer()
        ok = w.Write(shape, path)
        if ok is False or not os.path.getsize(path):
            return None
        with open(path, "rb") as f:
            return read_stl(f.read())
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def read_step(data, log=print, fineness=1.0):
    """STEP über OpenCASCADE (OCCT, LGPL-2.1) einlesen und triangulieren; jedes Dreieck erhält die
    Nummer seiner CAD-Fläche. Einheiten werden von OCCT nach mm umgerechnet."""
    try:
        from OCP.STEPControl import STEPControl_Reader
        from OCP.IFSelect import IFSelect_RetDone
        from OCP.BRepMesh import BRepMesh_IncrementalMesh
        from OCP.TopExp import TopExp_Explorer
        from OCP.TopAbs import TopAbs_FACE, TopAbs_REVERSED
        from OCP.TopoDS import TopoDS
        from OCP.BRep import BRep_Tool
        from OCP.TopLoc import TopLoc_Location
        from OCP.Bnd import Bnd_Box
        from OCP.BRepBndLib import BRepBndLib
        from OCP.StlAPI import StlAPI_Writer  # noqa: F401
    except Exception:
        raise ValueError("STEP files require the package “cadquery-ocp-novtk” (OpenCASCADE). "
                         "Please run “Install packages.bat” again or "
                         "run “python -m pip install cadquery-ocp-novtk”. "
                         "Alternatively save the part as STL, 3MF, OBJ or PLY.")
    try:
        from OCP.Interface import Interface_Static
        _occ(Interface_Static, "SetCVal", "xstep.cascade.unit", "MM")
    except Exception:
        pass
    fd, path = tempfile.mkstemp(suffix=".step")
    with os.fdopen(fd, "wb") as f:
        f.write(data)
    try:
        reader = STEPControl_Reader()
        if reader.ReadFile(path) != IFSelect_RetDone:
            raise ValueError("The STEP file could not be read (damaged or not STEP AP203/AP214/AP242?).")
        reader.TransferRoots()
        shape = reader.OneShape()
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if shape is None or shape.IsNull():
        raise ValueError("The STEP file contains no geometry.")
    box = Bnd_Box()
    _occ(BRepBndLib, "Add", shape, box)
    if box.IsVoid():
        raise ValueError("The STEP file contains no geometry.")
    # Ecken über CornerMin/CornerMax (gp_Pnt) – Bnd_Box.Get() liefert in neueren OCP-Versionen
    # eine Struktur, die sich nicht nach Python umwandeln lässt
    try:
        p0, p1 = box.CornerMin(), box.CornerMax()
        lo, hi = (p0.X(), p0.Y(), p0.Z()), (p1.X(), p1.Y(), p1.Z())
    except Exception:
        v = box.Get()
        lo, hi = tuple(v[:3]), tuple(v[3:6])
    diag = math.dist(lo, hi)
    if not np.isfinite(diag) or diag <= 0:
        raise ValueError("The STEP file contains no geometry.")
    # Sehnenfehler ~0,15 % der Diagonale, Winkelfehler ~20° (feiner mit fineness > 1)
    BRepMesh_IncrementalMesh(shape, diag * 0.0015 / fineness, False, 0.35 / fineness, True)
    # Dreiecke je CAD-Fläche direkt auslesen; passen die Knotennummern nicht (Bindungen ändern sich
    # zwischen OCP-Versionen), schreibt OCCT selbst eine STL-Datei, die dann eingelesen wird.
    tris, fids, counts = [], [], []
    direkt = True
    exp = TopExp_Explorer(shape, TopAbs_FACE)
    k = 0
    while exp.More():
        face = _occ(TopoDS, "Face", exp.Current())
        loc = TopLoc_Location()
        tri = _occ(BRep_Tool, "Triangulation", face, loc)
        n_t = tri.NbTriangles() if tri is not None else 0
        counts.append(n_t)
        if direkt and n_t > 0:
            try:
                trsf = loc.Transformation()
                n_n = tri.NbNodes()
                nodes = np.empty((n_n, 3))
                for i in range(1, n_n + 1):
                    q = tri.Node(i).Transformed(trsf)
                    nodes[i - 1] = (q.X(), q.Y(), q.Z())
                idx = np.empty((n_t, 3), dtype=np.int64)
                for t in range(1, n_t + 1):
                    q = tri.Triangle(t)
                    idx[t - 1] = (q.Value(1), q.Value(2), q.Value(3))
                idx -= 1
                if idx.min() < 0 or idx.max() >= n_n:
                    raise IndexError(f"node number outside 1…{n_n}")
                if len(np.unique(idx)) != n_n:            # jeder Knoten gehört zu einem Dreieck
                    raise IndexError("implausible node numbers")
                if face.Orientation() == TopAbs_REVERSED:
                    idx = idx[:, ::-1]
                tris.append(nodes[idx])
                fids.append(np.full(n_t, k, dtype=np.int32))
            except Exception as e:  # noqa
                log(f"Note: STEP triangles read via OCCT STL output ({type(e).__name__}: {e})")
                direkt = False
        k += 1
        exp.Next()
    if not direkt or not tris:
        t_all = _step_via_stl(shape)
        if t_all is None or not len(t_all):
            raise ValueError("The STEP file could not be triangulated (no faces/no solid?).")
        # StlAPI_Writer schreibt die Flächen in derselben Reihenfolge wie TopExp_Explorer
        if len(t_all) == sum(counts):
            fid = np.repeat(np.arange(len(counts), dtype=np.int32), counts)
        else:
            fid = None
        log(f"STEP triangulated: {k} CAD faces, {len(t_all)} triangles.")
        return t_all, fid
    log(f"STEP triangulated: {k} CAD faces, {sum(len(t) for t in tris)} triangles.")
    return np.concatenate(tris), np.concatenate(fids)


# =============================================================== Netz

class MeshData:
    def __init__(self, tris, face_ids=None, log=print):
        t = np.asarray(tris, dtype=np.float64)
        cr = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
        keep = np.linalg.norm(cr, axis=1) > 0
        if not keep.all():
            t = t[keep]
            if face_ids is not None:
                face_ids = np.asarray(face_ids)[keep]
        if len(t) == 0:
            raise ValueError("The model contains no valid triangles.")
        self.tris = t
        self.lo = t.reshape(-1, 3).min(0)
        self.hi = t.reshape(-1, 3).max(0)
        self.diag = float(np.linalg.norm(self.hi - self.lo))
        self._build_topology()
        self.flipped = self._orient()
        self._update_geometry()
        self.has_cad_faces = face_ids is not None
        if face_ids is None:
            self.face_ids = self.segment(25.0)
        else:
            self.face_ids = np.asarray(face_ids, dtype=np.int32)
        self.n_faces = int(self.face_ids.max()) + 1
        self._face_index = None
        msg = []
        if self.flipped:
            msg.append(f"{self.flipped} triangles reoriented")
        if self.open_edges:
            msg.append(f"{self.open_edges} open edges (not watertight)")
        if msg:
            log("Mesh check: " + ", ".join(msg))

    # ----------------------------------------------------------- Topologie
    def _build_topology(self):
        t = self.tris
        n = len(t)
        q = max(self.diag * 1e-7, 1e-12)
        keys = np.round((t.reshape(-1, 3) - self.lo) / q).astype(np.int64)
        _, vid = np.unique(keys, axis=0, return_inverse=True)
        vid = np.asarray(vid).reshape(-1, 3)
        self.vid = vid
        nv = int(vid.max()) + 1
        a = np.concatenate([vid[:, 0], vid[:, 1], vid[:, 2]])
        b = np.concatenate([vid[:, 1], vid[:, 2], vid[:, 0]])
        tid = np.tile(np.arange(n), 3)
        key = np.minimum(a, b) * nv + np.maximum(a, b)
        fwd = a < b
        order = np.argsort(key, kind="stable")
        ks, ts, fs = key[order], tid[order], fwd[order]
        uniq, start, cnt = np.unique(ks, return_index=True, return_counts=True)
        self.open_edges = int((cnt == 1).sum())
        two = cnt == 2
        s = start[two]
        p, q2 = ts[s], ts[s + 1]
        same = fs[s] == fs[s + 1]  # gleiche Richtung -> inkonsistent orientiert
        ok = p != q2
        p, q2, same = p[ok], q2[ok], same[ok]
        self.adj_pairs = np.stack([p, q2], 1)
        self.adj_incons = same
        A = sp.coo_matrix((np.ones(len(p)), (p, q2)), shape=(n, n))
        self.adj = (A + A.T).tocsr()
        W = sp.coo_matrix((same.astype(np.int8) + 1, (p, q2)), shape=(n, n))
        self.adj_w = (W + W.T).tocsr()

    def _orient(self):
        """Konsistente Orientierung je zusammenhängendem Teil, Normalen nach außen."""
        n = len(self.tris)
        if self.adj_incons.any():
            flip = np.zeros(n, dtype=bool)
            seen = np.zeros(n, dtype=bool)
            W = self.adj_w
            for root in range(n):
                if seen[root]:
                    continue
                order, pred = breadth_first_order(self.adj, root, directed=False,
                                                  return_predecessors=True)
                seen[order] = True
                for node in order[1:]:
                    pr = pred[node]
                    row = slice(W.indptr[pr], W.indptr[pr + 1])
                    cols = W.indices[row]
                    w = W.data[row][np.searchsorted(cols, node)] if W.has_sorted_indices else \
                        W.data[row][np.flatnonzero(cols == node)[0]]
                    flip[node] = flip[pr] ^ (w == 2)
        else:
            flip = np.zeros(n, dtype=bool)
        t = self.tris
        if flip.any():
            t[flip] = t[flip][:, [0, 2, 1]]
            self.vid[flip] = self.vid[flip][:, [0, 2, 1]]
        ncomp, lab = connected_components(self.adj, directed=False)
        vol = np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2]))
        cv = np.bincount(lab, weights=vol, minlength=ncomp)
        bad = cv[lab] < 0
        if bad.any():
            t[bad] = t[bad][:, [0, 2, 1]]
            self.vid[bad] = self.vid[bad][:, [0, 2, 1]]
        self.components = ncomp
        self.comp_label = lab
        return int((flip ^ bad).sum())

    def _update_geometry(self):
        t = self.tris
        cr = np.cross(t[:, 1] - t[:, 0], t[:, 2] - t[:, 0])
        ln = np.linalg.norm(cr, axis=1)
        self.area = 0.5 * ln
        self.normals = cr / np.maximum(ln, 1e-300)[:, None]
        self.centroids = t.mean(1)
        self.volume = float(np.einsum("ij,ij->i", t[:, 0], np.cross(t[:, 1], t[:, 2])).sum() / 6.0)

    @property
    def watertight(self):
        return self.open_edges == 0

    # ----------------------------------------------------------- Flächen
    def segment(self, angle_deg):
        """Automatische Flächenerkennung: Nachbarn mit kleinem Knickwinkel gehören zusammen."""
        n = len(self.tris)
        p, q = self.adj_pairs[:, 0], self.adj_pairs[:, 1]
        dots = np.einsum("ij,ij->i", self.normals[p], self.normals[q])
        m = dots >= math.cos(math.radians(angle_deg))
        A = sp.coo_matrix((np.ones(m.sum()), (p[m], q[m])), shape=(n, n))
        _, lab = connected_components(A, directed=False)
        return lab.astype(np.int32)

    def face_triangles(self, fid):
        if self._face_index is None:
            order = np.argsort(self.face_ids, kind="stable")
            bounds = np.searchsorted(self.face_ids[order], np.arange(self.n_faces + 1))
            self._face_index = (order, bounds)
        order, bounds = self._face_index
        return order[bounds[fid]:bounds[fid + 1]]

    def grow(self, seed, tol_deg=20.0, smooth=False):
        A = self.adj
        ind, ptr = A.indices, A.indptr
        N = self.normals
        cos_t = math.cos(math.radians(tol_deg))
        seen = np.zeros(len(N), dtype=bool)
        seen[seed] = True
        out, stack = [int(seed)], [int(seed)]
        seed_n = N[seed]
        while stack:
            t = stack.pop()
            ref = N[t] if smooth else seed_n
            for nb in ind[ptr[t]:ptr[t + 1]]:
                if not seen[nb] and float(N[nb] @ ref) >= cos_t:
                    seen[nb] = True
                    out.append(int(nb))
                    stack.append(int(nb))
        return np.asarray(out, dtype=np.int64)

    def face_summary(self, tris_idx):
        """Fläche, Mittelpunkt, Normale und Zylinderdaten einer Auswahl."""
        idx = np.asarray(tris_idx, dtype=np.int64)
        A = self.area[idx]
        N = self.normals[idx]
        C = self.centroids[idx]
        tot = float(A.sum())
        cen = (C * A[:, None]).sum(0) / max(tot, 1e-300)
        nm = (N * A[:, None]).sum(0)
        nl = float(np.linalg.norm(nm))
        res = dict(area=tot, center=cen.tolist(),
                   normal=(nm / nl).tolist() if nl > 1e-9 * tot else None,
                   flatness=nl / max(tot, 1e-300))
        cyl = fit_cylinder(N, C, A)
        if cyl is not None:
            res["cylinder"] = cyl
        return res


def find_holes(mesh, max_rel=0.45):
    """Zylindrische Bohrungen (Normalen zeigen zur Achse). Liefert Liste mit tris, radius, axis, point."""
    holes = []
    for fid in range(mesh.n_faces):
        idx = mesh.face_triangles(fid)
        if len(idx) < 6:
            continue
        N, C, A = mesh.normals[idx], mesh.centroids[idx], mesh.area[idx]
        cyl = fit_cylinder(N, C, A)
        if cyl is None or cyl["radius"] > max_rel * mesh.diag:
            continue
        ax, p0 = np.asarray(cyl["axis"]), np.asarray(cyl["point"])
        r = C - p0
        r -= (r @ ax)[:, None] * ax
        if float(((N * r).sum(1) * A).sum()) >= 0:   # Normalen zeigen nach außen -> Welle, keine Bohrung
            continue
        holes.append(dict(tris=idx, **cyl))
    return holes


def fit_cylinder(N, C, A):
    """Achse, Punkt und Radius, wenn die Normalen zu einem Zylinder passen."""
    if len(N) < 6:
        return None
    M = (N * A[:, None]).T @ N
    w, V = np.linalg.eigh(M)
    if w[2] <= 0 or w[0] / w[2] > 0.08 or w[1] / w[2] < 0.15:
        return None
    ax = V[:, 0]
    P = np.eye(3) - np.outer(ax, ax)
    Q = np.zeros((3, 3))
    b = np.zeros(3)
    for n, c, a in zip(N, C, A):
        n2 = P @ n
        ln = np.linalg.norm(n2)
        if ln < 1e-9:
            continue
        n2 /= ln
        Pn = P - np.outer(n2, n2)
        Q += a * Pn
        b += a * (Pn @ c)
    Q += np.outer(ax, ax) * (np.trace(Q) * 1e-6 + 1e-12)
    try:
        p0 = np.linalg.solve(Q, b)
    except np.linalg.LinAlgError:
        return None
    r = np.linalg.norm((C - p0) @ P, axis=1)
    rad = float((r * A).sum() / A.sum())
    if rad <= 0 or np.std(r) > 0.15 * rad:
        return None
    return dict(axis=ax.tolist(), point=p0.tolist(), radius=rad)


def sample_triangles(tris, spacing, max_div=300):
    """Stützpunkte auf Dreiecken; liefert (Punkte, Index des Dreiecks)."""
    if len(tris) == 0:
        return np.zeros((0, 3)), np.zeros(0, dtype=np.int64)
    e = np.stack([np.linalg.norm(tris[:, 1] - tris[:, 0], axis=1),
                  np.linalg.norm(tris[:, 2] - tris[:, 1], axis=1),
                  np.linalg.norm(tris[:, 0] - tris[:, 2], axis=1)], axis=1).max(1)
    nd = np.clip(np.ceil(e / spacing).astype(int), 1, max_div)
    pts, owner = [], []
    for n in np.unique(nd):
        sel = np.flatnonzero(nd == n)
        T = tris[sel]
        ii, jj = np.meshgrid(np.arange(n + 1), np.arange(n + 1), indexing="ij")
        m = (ii + jj) <= n
        # Punkte etwas nach innen ziehen, damit Kantenpunkte nicht doppelt zählen
        a = ((ii[m] + 1 / 3) / (n + 1))[None, :, None]
        b = ((jj[m] + 1 / 3) / (n + 1))[None, :, None]
        p = T[:, 0][:, None, :] + a * (T[:, 1] - T[:, 0])[:, None, :] \
            + b * (T[:, 2] - T[:, 0])[:, None, :]
        pts.append(p.reshape(-1, 3))
        owner.append(np.repeat(sel, m.sum()))
    return np.concatenate(pts), np.concatenate(owner)


# =============================================================== Voxelisierung

def grid_for(lo, hi, h, pad=0):
    ext = hi - lo
    shape = np.maximum(np.ceil(ext / h - 1e-9).astype(int), 1) + 2 * pad
    lo2 = lo - pad * h
    return lo2, tuple(int(s) for s in shape)


def voxelize(tris, lo, h, shape, robust=False):
    """Voxel innerhalb des Netzes. Mittelpunkt von Voxel (i,j,k): lo + (i+0.5)h."""
    if robust:
        return voxelize_wrap(tris, lo, h, shape)
    nx, ny, nz = shape
    xs = lo[0] + (np.arange(nx) + 0.5) * h + 0.00137 * h
    ys = lo[1] + (np.arange(ny) + 0.5) * h + 0.00291 * h
    zc = lo[2] + (np.arange(nz) + 0.5) * h
    cols_l, z_l = [], []
    eps = 1e-14 * h * h
    tmin = tris.min(1)
    tmax = tris.max(1)
    i0a = np.maximum(0, np.ceil((tmin[:, 0] - xs[0]) / h)).astype(int)
    i1a = np.minimum(nx - 1, np.floor((tmax[:, 0] - xs[0]) / h)).astype(int)
    j0a = np.maximum(0, np.ceil((tmin[:, 1] - ys[0]) / h)).astype(int)
    j1a = np.minimum(ny - 1, np.floor((tmax[:, 1] - ys[0]) / h)).astype(int)
    valid = np.flatnonzero((i0a <= i1a) & (j0a <= j1a))
    # Dreiecke, die genau eine Strahlposition treffen können, gemeinsam behandeln
    single = valid[(i0a[valid] == i1a[valid]) & (j0a[valid] == j1a[valid])]
    multi = np.setdiff1d(valid, single)
    for idxs, I, J in ((single, i0a[single], j0a[single]),):
        if len(idxs):
            T = tris[idxs]
            a, b, c = T[:, 0], T[:, 1], T[:, 2]
            px, py = xs[I], ys[J]
            d = (b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) - (b[:, 1] - a[:, 1]) * (c[:, 0] - a[:, 0])
            ok = np.abs(d) > eps
            d = np.where(ok, d, 1.0)
            l1 = ((px - a[:, 0]) * (c[:, 1] - a[:, 1]) - (py - a[:, 1]) * (c[:, 0] - a[:, 0])) / d
            l2 = ((b[:, 0] - a[:, 0]) * (py - a[:, 1]) - (b[:, 1] - a[:, 1]) * (px - a[:, 0])) / d
            l0 = 1 - l1 - l2
            m = ok & (l0 >= 0) & (l1 >= 0) & (l2 >= 0)
            cols_l.append((I * ny + J)[m])
            z_l.append((l0 * a[:, 2] + l1 * b[:, 2] + l2 * c[:, 2])[m])
    for t in multi.tolist():
        a, b, c = tris[t]
        d = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        if abs(d) < eps:
            continue
        I, J = np.meshgrid(np.arange(i0a[t], i1a[t] + 1), np.arange(j0a[t], j1a[t] + 1), indexing="ij")
        px, py = xs[I], ys[J]
        l1 = ((px - a[0]) * (c[1] - a[1]) - (py - a[1]) * (c[0] - a[0])) / d
        l2 = ((b[0] - a[0]) * (py - a[1]) - (b[1] - a[1]) * (px - a[0])) / d
        l0 = 1.0 - l1 - l2
        m = (l0 >= 0) & (l1 >= 0) & (l2 >= 0)
        if m.any():
            cols_l.append((I * ny + J)[m])
            z_l.append((l0 * a[2] + l1 * b[2] + l2 * c[2])[m])
    solid = np.zeros(shape, dtype=bool)
    if not cols_l:
        return solid, 1.0
    cols = np.concatenate(cols_l)
    zs = np.concatenate(z_l)
    if len(cols) == 0:
        return solid, 1.0
    order = np.lexsort((zs, cols))
    cols, zs = cols[order], zs[order]
    ucols, starts, counts = np.unique(cols, return_index=True, return_counts=True)
    odd = int((counts % 2).sum())
    flat = solid.reshape(nx * ny, nz)
    for col, s, cnt in zip(ucols.tolist(), starts.tolist(), counts.tolist()):
        flat[col] = (np.searchsorted(zs[s:s + cnt], zc) % 2) == 1
    return solid, odd / max(len(ucols), 1)


def voxelize_wrap(tris, lo, h, shape):
    """Robust für offene Netze/Scans: Oberfläche rastern, Lücken schließen, Inneres füllen."""
    pts, _ = sample_triangles(tris, 0.45 * h, max_div=2000)
    sh = np.array(shape)
    idx = np.floor((pts - lo) / h).astype(np.int64)
    ok = np.all((idx >= -1) & (idx <= sh), axis=1)   # Punkte genau auf dem Rand behalten
    idx = np.clip(idx[ok], 0, sh - 1)
    surf = np.zeros(shape, dtype=bool)
    surf[idx[:, 0], idx[:, 1], idx[:, 2]] = True
    pad = 2
    s2 = np.pad(surf, pad)
    s2 = binary_dilation(s2, iterations=1)
    filled = binary_fill_holes(s2)
    filled = binary_erosion(filled, iterations=1, border_value=0)
    return filled[pad:-pad, pad:-pad, pad:-pad], 0.0


# =============================================================== Export

def stl_bytes(verts, faces):
    tri = verts[faces].astype(np.float32)
    nrm = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    ln = np.linalg.norm(nrm, axis=1, keepdims=True)
    nrm = np.divide(nrm, ln, out=np.zeros_like(nrm), where=ln > 0)
    dt = np.dtype([("n", "<f4", (3,)), ("v", "<f4", (3, 3)), ("a", "<u2")])
    arr = np.zeros(len(faces), dtype=dt)
    arr["n"], arr["v"] = nrm, tri
    return b"Diotopo".ljust(80, b"\0") + struct.pack("<I", len(faces)) + arr.tobytes()


def _fmt_rows(arr, fmt):
    return "\n".join(fmt % tuple(r) for r in arr.tolist())


def obj_bytes(verts, faces):
    s = "# Diotopo\n" + _fmt_rows(verts, "v %.5f %.5f %.5f") + "\n" + \
        _fmt_rows(faces + 1, "f %d %d %d") + "\n"
    return s.encode("ascii")


def threemf_bytes(verts, faces, name="Part"):
    vx = _fmt_rows(verts, '<vertex x="%.5f" y="%.5f" z="%.5f"/>')
    tr = _fmt_rows(faces, '<triangle v1="%d" v2="%d" v3="%d"/>')
    model = ('<?xml version="1.0" encoding="UTF-8"?>\n'
             '<model unit="millimeter" xml:lang="en-US" '
             'xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">\n'
             f'<metadata name="Title">{name}</metadata>\n'
             '<metadata name="Application">Diotopo</metadata>\n'
             '<resources><object id="1" type="model"><mesh><vertices>\n'
             f'{vx}\n</vertices><triangles>\n{tr}\n</triangles></mesh></object></resources>\n'
             '<build><item objectid="1"/></build>\n</model>\n')
    ct = ('<?xml version="1.0" encoding="UTF-8"?>\n'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/>'
          '</Types>')
    rels = ('<?xml version="1.0" encoding="UTF-8"?>\n'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Target="/3D/3dmodel.model" Id="rel0" '
            'Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>')
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("3D/3dmodel.model", model)
    return bio.getvalue()
