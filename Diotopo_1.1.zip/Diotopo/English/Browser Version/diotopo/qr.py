# -*- coding: utf-8 -*-
"""
Kleiner QR-Code-Erzeuger (ISO/IEC 18004), eigene Umsetzung ohne Fremdbibliothek.
Byte-Modus, Fehlerkorrektur M, Versionen 1–6 (bis 106 Byte) – genug für Links.

  python -m diotopo.qr "https://paypal.me/diotopo" > web/paypal_qr.svg
"""

import sys

# Version: (Gesamt-Codewörter, Korrektur-Codewörter je Block, Anzahl Blöcke) für Stufe M
_M = {1: (26, 10, 1), 2: (44, 16, 1), 3: (70, 26, 1), 4: (100, 18, 2), 5: (134, 24, 2), 6: (172, 16, 4)}
_ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34]}

# ---------------------------------------------------------------- Reed-Solomon über GF(256), Polynom 0x11D
_EXP, _LOG = [0] * 512, [0] * 256
_v = 1
for _i in range(255):
    _EXP[_i] = _v
    _LOG[_v] = _i
    _v <<= 1
    if _v & 0x100:
        _v ^= 0x11D
for _i in range(255, 512):
    _EXP[_i] = _EXP[_i - 255]


def _mul(a, b):
    return 0 if a == 0 or b == 0 else _EXP[_LOG[a] + _LOG[b]]


def _rs_ecc(data, n):
    gen = [1]                                   # Generator ∏ (x − α^i), i = 0 … n−1
    for i in range(n):
        gen = [a ^ _mul(b, _EXP[i]) for a, b in zip(gen + [0], [0] + gen)]
    rem = [0] * n
    for d in data:
        f = d ^ rem[0]
        rem = rem[1:] + [0]
        for j in range(n):
            rem[j] ^= _mul(gen[j + 1], f)
    return rem


# ---------------------------------------------------------------- Kodierung
def _codewords(payload):
    for ver in sorted(_M):
        total, ecn, nb = _M[ver]
        cap = total - ecn * nb
        if 4 + 8 + 8 * len(payload) <= cap * 8:
            break
    else:
        raise ValueError("Text too long for QR version 1–6")
    bits = [0, 1, 0, 0] + [(len(payload) >> (7 - i)) & 1 for i in range(8)]
    for byte in payload:
        bits += [(byte >> (7 - i)) & 1 for i in range(8)]
    bits += [0] * min(4, cap * 8 - len(bits))
    bits += [0] * (-len(bits) % 8)
    data = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    k = 0
    while len(data) < cap:                       # Füllbytes abwechselnd 0xEC, 0x11
        data.append((0xEC, 0x11)[k % 2])
        k += 1
    per = cap // nb
    blocks = [data[i * per:(i + 1) * per] for i in range(nb)]
    eccs = [_rs_ecc(b, ecn) for b in blocks]
    out = [b[i] for i in range(per) for b in blocks] + [e[i] for i in range(ecn) for e in eccs]
    return ver, out


def _format_bits(mask):
    d = (0 << 3) | mask                          # Stufe M = 00
    rem = d
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    return ((d << 10) | rem) ^ 0x5412


def _matrix(ver, words, mask):
    n = 17 + 4 * ver
    m = [[False] * n for _ in range(n)]
    fn = [[False] * n for _ in range(n)]

    def put(x, y, dark):
        m[y][x] = dark
        fn[y][x] = True

    for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):              # Suchmuster + Trennstreifen
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < n and 0 <= y < n:
                    d = max(abs(dx), abs(dy))
                    put(x, y, d not in (2, 4))
    for i in range(n):                                           # Taktlinien
        if not fn[6][i]:
            put(i, 6, i % 2 == 0)
        if not fn[i][6]:
            put(6, i, i % 2 == 0)
    al = _ALIGN[ver]
    for ay in al:                                                # Ausrichtungsmuster
        for ax in al:
            if (ax, ay) in ((6, 6), (6, al[-1]), (al[-1], 6)):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    put(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)
    fb = _format_bits(mask)                                      # Formatinformation (zweifach)
    bit = [(fb >> i) & 1 == 1 for i in range(15)]
    for i in range(6):
        put(8, i, bit[i])
    put(8, 7, bit[6])
    put(8, 8, bit[7])
    put(7, 8, bit[8])
    for i in range(9, 15):
        put(14 - i, 8, bit[i])
    for i in range(8):
        put(n - 1 - i, 8, bit[i])
    for i in range(8, 15):
        put(8, n - 15 + i, bit[i])
    put(8, n - 8, True)                                          # dunkles Modul
    i, total = 0, len(words) * 8                                 # Daten im Zickzack
    right = n - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(n):
            for j in range(2):
                x = right - j
                up = ((right + 1) & 2) == 0
                y = n - 1 - vert if up else vert
                if not fn[y][x]:
                    dark = i < total and (words[i >> 3] >> (7 - (i & 7))) & 1 == 1
                    i += 1
                    if _MASKS[mask](x, y):
                        dark = not dark
                    m[y][x] = dark
        right -= 2
    return m


_MASKS = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0,
          lambda x, y: (x + y) % 3 == 0, lambda x, y: (x // 3 + y // 2) % 2 == 0,
          lambda x, y: x * y % 2 + x * y % 3 == 0, lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
          lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0]


def _penalty(m):
    n = len(m)
    p = 0
    rows = m + [list(c) for c in zip(*m)]
    for r in rows:                                               # Läufe ≥ 5 gleicher Farbe
        run = 1
        for a, b in zip(r, r[1:]):
            if a == b:
                run += 1
            else:
                p += run - 2 if run >= 5 else 0
                run = 1
        p += run - 2 if run >= 5 else 0
        s = "".join("1" if v else "0" for v in r)                 # suchmusterähnliche Folgen
        p += 40 * (s.count("10111010000") + s.count("00001011101"))
    for y in range(n - 1):                                       # 2×2-Blöcke
        for x in range(n - 1):
            if m[y][x] == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                p += 3
    dark = sum(map(sum, m))
    p += 10 * (abs(dark * 20 - n * n * 10) // (n * n))
    return p


def encode(text):
    """QR-Matrix (Liste von Zeilen, True = dunkel)."""
    ver, words = _codewords(text.encode("utf-8"))
    return min((_matrix(ver, words, k) for k in range(8)), key=_penalty)


def svg(text, quiet=4, fg="#000", bg="#fff"):
    m = encode(text)
    n = len(m) + 2 * quiet
    path = "".join(f"M{x + quiet} {y + quiet}h1v1h-1z" for y, row in enumerate(m) for x, v in enumerate(row) if v)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {n} {n}" shape-rendering="crispEdges">'
            f'<rect width="{n}" height="{n}" fill="{bg}"/><path d="{path}" fill="{fg}"/></svg>')


if __name__ == "__main__":
    print(svg(sys.argv[1] if len(sys.argv) > 1 else "https://paypal.me/diotopo"))
