# -*- coding: utf-8 -*-
"""
Gemeinsames Rechnen: alle CPU-Kerne, alle Grafikkarten und der Arbeitsspeicher zugleich.

Statt einen Löser für das ganze Modell auszuwählen, wird jede Ebene des Mehrgitterverfahrens
zeilenweise auf alle Rechenwerke aufgeteilt:

    Unbekannte 0 … n:   [ GPU 1 | GPU 2 | … | CPU (alle Kerne, Daten im Arbeitsspeicher) ]

* Jedes Rechenwerk hält „seine“ Zeilen der Matrizen und „seine“ Abschnitte aller Vektoren und
  rechnet daran gleichzeitig mit den anderen (Grafikkarten asynchron, CPU mit allen Kernen).
* Vor jedem Matrix-Vektor-Produkt werden nur die Randwerte ausgetauscht, die ein Rechenwerk von
  seinem Nachbarn braucht (Halo). Durch die Knotennummerierung (Schichten in x-Richtung) sind das
  wenige Prozent eines Vektors.
* Die Aufteilung richtet sich nach der gemessenen Geschwindigkeit jedes Rechenwerks und wird nach
  jeder Lösung nachgeregelt, so dass alle möglichst gleichzeitig fertig werden.
* Passt der Anteil einer Grafikkarte nicht in ihren Speicher, bekommt sie so viel, wie passt –
  der Rest bleibt im Arbeitsspeicher und wird von der CPU gerechnet (kein Rückfall auf „nur CPU“).
* Kleine (grobe) Ebenen und das gröbste Gitter rechnet die CPU, dort wäre der Austausch teurer
  als die Rechnung.
* Genauigkeit: äußeres CG in float64 auf allen CPU-Kernen (gleich viele Schritte wie der reine
  CPU-Löser), der Mehrgitter-Vorkonditionierer in float32 verteilt auf alle Rechenwerke.
* Ohne Grafikkarte läuft derselbe Löser nur mit dem Rechenwerk „CPU“ (alle Kerne).
"""

import math
import os
import time

import numpy as np
import scipy.sparse as sp

from . import par as PR
from . import solver as SO

f32 = np.float32
LEVEL_GPU_MIN = SO.GPU_MIN   # Ebenen mit weniger Unbekannten rechnet nur die CPU
PART_MIN = 8_000         # kleinster sinnvoller Anteil einer Grafikkarte (Zeilen der feinsten Ebene)
DOT_PARTS = 2048
WG = 64

KERNELS = r"""
__kernel void ell_spmv_o(const int n, const int w, __global const int *col, __global const float *val,
                         __global const float *x, __global float *y, const int off)
{
    int i = get_global_id(0);
    if (i >= n) return;
    float s = 0.0f;
    for (int j = 0; j < w; j++) {
        int c = col[j * n + i];
        if (c >= 0) s += val[j * n + i] * x[c];
    }
    y[off + i] = s;
}

__kernel void axpby_o(const int n, const int off, const float a, __global const float *x, const float b,
                      __global const float *y, __global float *out)
{
    int i = get_global_id(0);
    if (i < n) { int k = off + i; out[k] = a * x[k] + b * y[k]; }
}

__kernel void dscale_o(const int n, const int off, const float a, __global const float *d,
                       __global const float *x, __global float *out)
{
    int i = get_global_id(0);
    if (i < n) { int k = off + i; out[k] = a * d[k] * x[k]; }
}

__kernel void cheb_o(const int n, const int off, const float c1, const float c2, __global float *d,
                     __global const float *dinv, __global const float *r, __global const float *ax,
                     __global float *x)
{
    int i = get_global_id(0);
    if (i < n) {
        int k = off + i;
        float v = c1 * d[k] + c2 * dinv[k] * (r[k] - ax[k]);
        d[k] = v;
        x[k] += v;
    }
}

__kernel void cg_update_o(const int n, const int off, const float a, __global const float *p,
                          __global const float *ap, __global float *x, __global float *r)
{
    int i = get_global_id(0);
    if (i < n) { int k = off + i; x[k] += a * p[k]; r[k] -= a * ap[k]; }
}

__kernel void addto_o(const int n, const int off, __global const float *src, __global float *dst)
{
    int i = get_global_id(0);
    if (i < n) dst[off + i] += src[i];
}

__kernel void dot_part_o(const int n, const int off, const int g_total, __global const float *x,
                         __global const float *y, __global float *part)
{
    int g = get_global_id(0);
    if (g >= g_total) return;
    float s = 0.0f;
    for (int i = g; i < n; i += g_total) s += x[off + i] * y[off + i];
    part[g] = s;
}
"""


def _round(n):
    return ((int(n) + WG - 1) // WG) * WG


# ================================================================ Rechenwerke

class CPUPart:
    """Alle Prozessorkerne; Daten im Arbeitsspeicher."""
    kind = "cpu"

    def __init__(self, threads=None):
        self.T = threads or PR.n_threads()
        self.name = f"CPU ({self.T} Threads)"
        self.key = "cpu"

    def alloc(self, n):
        return np.zeros(max(int(n), 1), dtype=f32)

    def mat(self, A):
        return PR.ThreadedCSR(PR.astype_csr(A, f32), self.T)

    def max_rows(self, w):
        return None                                       # Arbeitsspeicher wird vorher geprüft

    def spmv(self, M, x, y, off, n):
        M.matvec(x, out=y[off:off + n])

    def axpby(self, off, n, a, x, b, y, out):
        a, b = f32(a), f32(b)

        def f(s, e):
            s, e = s + off, e + off
            if b == 0:
                np.multiply(x[s:e], a, out=out[s:e])
            elif a == 0:
                np.multiply(y[s:e], b, out=out[s:e])
            else:
                t = y[s:e] * b
                np.multiply(x[s:e], a, out=out[s:e])
                out[s:e] += t
        PR.run_chunks(n, f, self.T)

    def dscale(self, off, n, a, d, x, out):
        a = f32(a)

        def f(s, e):
            s, e = s + off, e + off
            np.multiply(d[s:e], x[s:e], out=out[s:e])
            out[s:e] *= a
        PR.run_chunks(n, f, self.T)

    def cheb(self, off, n, c1, c2, d, dinv, r, ax, x):
        c1, c2 = f32(c1), f32(c2)

        def f(s, e):
            s, e = s + off, e + off
            t = r[s:e] - ax[s:e]
            t *= dinv[s:e]
            t *= c2
            d[s:e] *= c1
            d[s:e] += t
            x[s:e] += d[s:e]
        PR.run_chunks(n, f, self.T)

    def cg_update(self, off, n, a, p, ap, x, r):
        a = f32(a)

        def f(s, e):
            s, e = s + off, e + off
            x[s:e] += a * p[s:e]
            r[s:e] -= a * ap[s:e]
        PR.run_chunks(n, f, self.T)

    def dot_start(self, off, n, x, y):
        acc = []

        def f(s, e):
            s, e = s + off, e + off
            t = 0.0
            for i in range(s, e, 65536):
                j = min(e, i + 65536)
                t += float(np.dot(x[i:j], y[i:j]))
            acc.append(t)
        PR.run_chunks(n, f, self.T)
        return math.fsum(acc)

    def dot_end(self, h):
        return h

    def read(self, buf, off, n):
        return buf[off:off + n], None

    def write(self, buf, off, host):
        def f(a, b):
            buf[off + a:off + b] = host[a:b]
        PR.run_chunks(len(host), f, self.T)

    def add(self, buf, off, host):
        buf[off:off + len(host)] += host

    def finish(self):
        pass

    def flush(self):
        pass

    def kernel_seconds(self, ev):
        return None

    def done(self, ev):
        return True


class SimGPUPart(CPUPart):
    """Simulierte Grafikkarte (nur zum Testen der Aufteilung: DIOTOPO_HYBRID_SIM=<Anzahl>)."""
    kind = "gpu"

    def __init__(self, i, mem=2**40):
        super().__init__(threads=1)
        self.name = f"Sim GPU {i}"
        self.key = ("sim", i)
        self.mem = mem

    def max_rows(self, w):
        return int(0.8 * self.mem / (w * 8 * 1.35 + 200))

    def read(self, buf, off, n):
        return buf[off:off + n].copy(), None


class CLPart:
    """Eine Grafikkarte über OpenCL (NVIDIA, AMD, Intel – auch eingebaute Grafik)."""
    kind = "gpu"

    def __init__(self, cldev, idx):
        cl = cldev.cl
        self.cl, self.d = cl, cldev
        self.name = cldev.name
        self.key = ("cl", cldev.name, idx)
        self.ctx = cldev.ctx
        self.q = cl.CommandQueue(self.ctx, properties=cl.command_queue_properties.PROFILING_ENABLE)
        self.prg = cl.Program(self.ctx, KERNELS).build()
        self.k = {n: getattr(self.prg, n) for n in ("ell_spmv_o", "axpby_o", "dscale_o", "cheb_o",
                                                    "cg_update_o", "dot_part_o", "addto_o")}
        self.mem = int(cldev.mem)
        self.max_alloc = int(cldev.max_alloc)
        self.unified = bool(cldev.unified)
        self._part = self.alloc(DOT_PARTS)
        self._scr, self._scr_n = None, 0

    def alloc(self, n):
        cl = self.cl
        return cl.Buffer(self.ctx, cl.mem_flags.READ_WRITE, size=max(int(n), 1) * 4)

    def _upload(self, a, dtype):
        cl = self.cl
        a = np.ascontiguousarray(a, dtype=dtype)
        if a.size == 0:
            a = np.zeros(1, dtype=dtype)
        return cl.Buffer(self.ctx, cl.mem_flags.READ_ONLY | cl.mem_flags.COPY_HOST_PTR, hostbuf=a)

    def mat(self, A):
        A = A.tocsr()
        n = A.shape[0]
        lens = np.diff(A.indptr)
        w = max(int(lens.max()) if n else 0, 1)
        if w * n * 4 > self.max_alloc:
            raise MemoryError("Matrix part larger than the largest permitted GPU allocation")
        col = np.full((w, n), -1, dtype=np.int32)
        val = np.zeros((w, n), dtype=f32)
        ip = A.indptr

        def fill(r0, r1):                                 # ELL-Umwandlung zeilenblockweise, alle Kerne
            s0, s1 = int(ip[r0]), int(ip[r1])
            ln = lens[r0:r1]
            rows = np.repeat(np.arange(r0, r1), ln)
            pos = np.arange(s0, s1) - np.repeat(ip[r0:r1], ln)
            col[pos, rows] = A.indices[s0:s1]
            val[pos, rows] = A.data[s0:s1]
        PR.run_chunks(n, fill, minsize=20000)
        return dict(n=n, w=w, col=self._upload(col.ravel(), np.int32), val=self._upload(val.ravel(), f32))

    def max_rows(self, w):
        per_row = w * 8 * 1.35 + 200                      # ELL fein + grobe Ebenen + Vektoren
        return int(min(0.8 * self.mem / per_row, self.max_alloc / (w * 4)))

    def spmv(self, M, x, y, off, n):
        return self.k["ell_spmv_o"](self.q, (_round(n),), None, np.int32(n), np.int32(M["w"]),
                                    M["col"], M["val"], x, y, np.int32(off))

    def axpby(self, off, n, a, x, b, y, out):
        self.k["axpby_o"](self.q, (_round(n),), None, np.int32(n), np.int32(off), f32(a), x, f32(b), y, out)

    def dscale(self, off, n, a, d, x, out):
        self.k["dscale_o"](self.q, (_round(n),), None, np.int32(n), np.int32(off), f32(a), d, x, out)

    def cheb(self, off, n, c1, c2, d, dinv, r, ax, x):
        self.k["cheb_o"](self.q, (_round(n),), None, np.int32(n), np.int32(off), f32(c1), f32(c2),
                         d, dinv, r, ax, x)

    def cg_update(self, off, n, a, p, ap, x, r):
        self.k["cg_update_o"](self.q, (_round(n),), None, np.int32(n), np.int32(off), f32(a), p, ap, x, r)

    def dot_start(self, off, n, x, y):
        self.k["dot_part_o"](self.q, (_round(DOT_PARTS),), None, np.int32(n), np.int32(off),
                             np.int32(DOT_PARTS), x, y, self._part)
        h = np.empty(DOT_PARTS, dtype=f32)
        ev = self.cl.enqueue_copy(self.q, h, self._part, is_blocking=False)
        return h, ev

    def dot_end(self, hd):
        h, ev = hd
        ev.wait()
        return float(h.astype(np.float64).sum())

    def read(self, buf, off, n):
        h = np.empty(int(n), dtype=f32)
        ev = self.cl.enqueue_copy(self.q, h, buf, device_offset=int(off) * 4, is_blocking=False)
        return h, ev

    def write(self, buf, off, host):
        self.cl.enqueue_copy(self.q, buf, np.ascontiguousarray(host, dtype=f32), device_offset=int(off) * 4,
                             is_blocking=True)

    def add(self, buf, off, host):
        """buf[off : off+len] += host"""
        n = len(host)
        if n > self._scr_n:
            self._scr, self._scr_n = self.alloc(n), n
        self.write(self._scr, 0, host)
        self.k["addto_o"](self.q, (_round(n),), None, np.int32(n), np.int32(off), self._scr, buf)

    def finish(self):
        self.q.finish()

    def flush(self):
        """Eingereihte Aufträge sofort an die Grafikkarte übergeben (sonst darf der Treiber sie
        zurückhalten, bis gewartet wird – dann rechnen GPU und CPU nacheinander statt gleichzeitig)."""
        self.q.flush()

    def kernel_seconds(self, ev):
        try:
            return (ev.profile.end - ev.profile.start) * 1e-9
        except Exception:
            return None

    def done(self, ev):
        try:
            return ev.command_execution_status == self.cl.command_execution_status.COMPLETE
        except Exception:
            return False


_PARTS = {}


def gpu_parts():
    """Alle nutzbaren Grafikkarten als Rechenwerke (einmal je Sitzung ermittelt)."""
    if "l" not in _PARTS:
        parts = []
        sim = os.environ.get("DIOTOPO_HYBRID_SIM", "").strip()
        if sim.isdigit():
            parts = [SimGPUPart(i) for i in range(int(sim))]
        elif not (os.environ.get("DIOTOPO_NO_GPU")):
            from . import gpu_ocl as GO
            for i, d in enumerate(GO.devices()):
                try:
                    parts.append(CLPart(d, i))
                except Exception:  # noqa
                    pass
        _PARTS["l"] = parts
    return [p for p in _PARTS["l"] if p.key not in _BROKEN]


_BROKEN = set()


def mark_broken(part):
    _BROKEN.add(part.key)


# ================================================================ Aufteilung und Geschwindigkeit

_RATES = {}      # Rechenwerk -> Zeilen je Sekunde (Matrix-Vektor-Produkt der feinsten Ebene, float32)


def _benchmark(part, A0, m):
    m = min(m, A0.shape[0])
    blk = A0[:m].tocsr()
    nc = int(blk.indices.max()) + 1 if blk.nnz else 1
    blk = sp.csr_matrix((blk.data, blk.indices, blk.indptr), shape=(m, nc))
    M = part.mat(blk)
    x, y = part.alloc(nc), part.alloc(m)
    part.write(x, 0, np.ones(nc, dtype=f32))
    part.spmv(M, x, y, 0, m)
    part.finish()
    t = time.perf_counter()
    for _ in range(3):
        part.spmv(M, x, y, 0, m)
    part.finish()
    dt = (time.perf_counter() - t) / 3
    return m / max(dt, 1e-7)


def rate(part, A0):
    if part.key not in _RATES:
        try:
            _RATES[part.key] = _benchmark(part, A0, 150_000)
        except Exception:  # noqa
            _RATES[part.key] = 0.0
    return _RATES[part.key]


def learn_rate(part, value):
    if value > 0 and math.isfinite(value):
        old = _RATES.get(part.key)
        _RATES[part.key] = value if not old else 0.5 * old + 0.5 * value


def split_rows(parts, A0):
    """Zeilenanzahl je Rechenwerk für die feinste Ebene: proportional zur Geschwindigkeit,
    Grafikkarten höchstens so viel, wie in ihren Speicher passt; der Rest geht an die CPU."""
    n = A0.shape[0]
    if len(parts) == 1:
        return np.array([n], dtype=np.int64)
    w = int(np.diff(A0.indptr).max()) if n else 1
    r = np.array([max(rate(p, A0), 0.0) for p in parts], dtype=float)
    if r[-1] <= 0:
        r[-1] = 1.0
    cap = np.array([np.inf if p.max_rows(w) is None else float(p.max_rows(w)) for p in parts])
    rows = np.zeros(len(parts))
    free = np.ones(len(parts), dtype=bool)
    left = float(n)
    for _ in range(len(parts) + 1):                     # Überlauf an die übrigen verteilen
        share = r * free
        if share.sum() <= 0:
            break
        add = left * share / share.sum()
        rows += add
        over = np.maximum(rows - cap, 0.0)
        rows = np.minimum(rows, cap)
        left = float(over.sum())
        free &= rows < cap
        if left < 1:
            break
    rows[-1] += left                                    # CPU nimmt immer den Rest
    rows = np.floor(rows).astype(np.int64)
    for i in range(len(parts) - 1):
        if rows[i] < PART_MIN:
            rows[-1] += rows[i]
            rows[i] = 0
    rows[-1] += n - rows.sum()
    return rows


# ================================================================ verteilte Vektoren und Matrizen

class Layout:
    """Aufteilung eines Vektorraums: Rechenwerk p besitzt [a_p, b_p) und hält zusätzlich
    Randwerte (Halo), sein Speicher deckt [lo_p, hi_p) ab."""

    def __init__(self, n, bounds):
        P = len(bounds) - 1
        self.n = int(n)
        self.a = [int(bounds[p]) for p in range(P)]
        self.b = [int(bounds[p + 1]) for p in range(P)]
        self._nl = [None] * P
        self._nh = [None] * P

    def need(self, p, lo, hi):
        if hi <= lo:
            return
        self._nl[p] = lo if self._nl[p] is None else min(self._nl[p], lo)
        self._nh[p] = hi if self._nh[p] is None else max(self._nh[p], hi)

    def finalize(self):
        P = len(self.a)
        self.lo, self.hi = [0] * P, [0] * P
        for p in range(P):
            a, b, nl, nh = self.a[p], self.b[p], self._nl[p], self._nh[p]
            if b > a:
                self.lo[p] = a if nl is None else min(a, nl)
                self.hi[p] = b if nh is None else max(b, nh)
            elif nl is not None:
                self.lo[p], self.hi[p] = nl, nh
                self.a[p] = self.b[p] = nl
            else:
                self.lo[p] = self.hi[p] = a
        self.plan = []
        for p in range(P):
            for s, e in ((self.lo[p], self.a[p]), (self.b[p], self.hi[p])):
                if e <= s:
                    continue
                for q in range(P):
                    if q == p or self.b[q] <= self.a[q]:
                        continue
                    s2, e2 = max(s, self.a[q]), min(e, self.b[q])
                    if e2 > s2:
                        self.plan.append((p, q, s2, e2))
        return self

    def off(self, p):
        return self.a[p] - self.lo[p]

    def cnt(self, p):
        return self.b[p] - self.a[p]

    def size(self, p):
        return self.hi[p] - self.lo[p]

    def halo(self):
        return sum(e - s for _, _, s, e in self.plan)


def _register(M, R, C):
    """Spaltenbedarf der Zeilen jedes Rechenwerks im Spaltenraum C vermerken."""
    for p in range(len(R.a)):
        a, b = R.a[p], R.b[p]
        if b <= a:
            continue
        idx = M.indices[M.indptr[a]:M.indptr[b]]
        if idx.size:
            C.need(p, int(idx.min()), int(idx.max()) + 1)


class DVec:
    def __init__(self, H, L):
        self.L = L
        self.b = [part.alloc(L.size(p)) if L.size(p) > 0 else None for p, part in enumerate(H.parts)]


class Op:
    def __init__(self, H, M, R, C, track=False):
        self.R, self.C, self.track = R, C, track
        self.m = [None] * len(H.parts)
        M = M.tocsr()
        for p, part in enumerate(H.parts):
            a, b = R.a[p], R.b[p]
            if b <= a:
                continue
            blk = M if (a == 0 and b == M.shape[0]) else M[a:b]
            ind = blk.indices if C.lo[p] == 0 else blk.indices - C.lo[p]
            blk = sp.csr_matrix((blk.data, ind, blk.indptr), shape=(b - a, max(C.size(p), 1)), copy=False)
            self.m[p] = part.mat(blk)


class OpT:
    """Restriktion rc = Pᵀ t, verteilt nach den Zeilen von P (= feine Unbekannte): jedes Rechenwerk
    rechnet die Teilsumme aus seinen eigenen feinen Werten in seinen groben Bereich (eigene + Halo);
    die Halo-Anteile werden danach beim Besitzer aufaddiert. So muss kein feiner Vektor wandern."""

    def __init__(self, H, P, Lf, Lc):
        self.Lf, self.Lc = Lf, Lc
        self.m = [None] * len(H.parts)
        P = P.tocsr()
        for p, part in enumerate(H.parts):
            nc = Lc.size(p)
            if nc <= 0:
                continue
            a, b = Lf.a[p], Lf.b[p]
            nf = max(Lf.size(p), 1)
            if b > a:
                c = P[a:b].tocoo()
                M = sp.csr_matrix((c.data, (c.col - Lc.lo[p], c.row + Lf.off(p))), shape=(nc, nf))
            else:
                M = sp.csr_matrix((nc, nf))
            self.m[p] = part.mat(M)


# ================================================================ Löser

class HybridSolver:
    """Mehrgitter-PCG gleichzeitig auf allen Rechenwerken, float64-Nachkorrektur auf allen CPU-Kernen."""

    def __init__(self, parts, K, free, node_coords, cache=None, cancel=None, degree=3):
        self.parts = list(parts)                         # Grafikkarten zuerst, CPU zuletzt
        self.K = K.tocsr()
        self.Kt = PR.ThreadedCSR(self.K)
        self.cancel, self.degree = cancel, degree
        self._tgpu, self._tcpu = {}, []
        self.times = {}                                   # Teilschritte des Aufbaus (Wand, CPU) fürs Protokoll
        w0, c0 = time.perf_counter(), time.process_time()
        As, Ps = SO.galerkin_levels(self.K, free, node_coords, cache, cancel)
        self.times["Coarse grid"] = (time.perf_counter() - w0, time.process_time() - c0)
        if len(As) < 2:
            raise RuntimeError("System too small for the multigrid solver")
        self.coarse = SO._lu(As[-1])
        self.nlev = len(As)
        n0 = As[0].shape[0]
        self.rows0 = split_rows(self.parts, As[0])
        frac = self.rows0 / max(n0, 1)
        P = len(self.parts)
        lays = []
        for A_ in As:
            nl = A_.shape[0]
            if nl < LEVEL_GPU_MIN:
                cut = np.zeros(P + 1, dtype=np.int64)
                cut[-1] = nl
            else:
                cut = np.concatenate([[0], np.round(np.cumsum(frac) * nl)]).astype(np.int64)
                cut[-1] = nl
                cut = np.maximum.accumulate(np.clip(cut, 0, nl))
            lays.append(Layout(nl, cut))
        for lvl in range(self.nlev - 1):
            _register(As[lvl], lays[lvl], lays[lvl])
            _register(Ps[lvl][0], lays[lvl], lays[lvl + 1])
        for L in lays:
            L.finalize()
        self.lays = lays
        self.lv = []
        w0, c0 = time.perf_counter(), time.process_time()
        for lvl, A_ in enumerate(As[:-1]):
            if cancel is not None and cancel():
                raise SO.Stopped()
            Lr, Lc = lays[lvl], lays[lvl + 1]
            Dinv, gersh = SO.smoother_bounds(A_)
            L = dict(n=A_.shape[0], lay=Lr,
                     A=Op(self, A_, Lr, Lr, track=(lvl == 0)),
                     P=Op(self, Ps[lvl][0], Lr, Lc), PT=OpT(self, Ps[lvl][0], Lr, Lc))
            L["dinv"] = DVec(self, Lr)
            self.scatter(L["dinv"], Dinv)
            for t in ("d", "ax", "t", "x2", "pz"):
                L[t] = DVec(self, Lr)
            L["rc"], L["zc"] = DVec(self, Lc), DVec(self, Lc)
            v0, nit = SO.power_start(cache, lvl, L["n"])
            v, w = DVec(self, Lr), DVec(self, Lr)
            self.scatter(v, v0 / max(np.linalg.norm(v0), 1e-30))
            lam = 1.0
            for _ in range(nit):                         # Potenzmethode für lambda_max(D^-1 A)
                self.spmv(L["A"], v, L["t"])
                self.dscale(1.0, L["dinv"], L["t"], w)
                nw = math.sqrt(max(self.dot(w, w), 1e-60))
                nv = math.sqrt(max(self.dot(v, v), 1e-60))
                lam = nw / nv
                self.axpby(1.0 / nw, w, 0.0, w, v)
            if cache is not None:
                cache[("v", lvl, L["n"])] = self.gather(v).astype(np.float64)
            L["lmax"] = min(1.3 * lam, gersh)
            self.lv.append(L)
        if any(p.kind == "gpu" for p in self.parts):
            self.times["Distribute matrices/GPU transfer"] = (time.perf_counter() - w0, time.process_time() - c0)
        else:
            self.times["Prepare matrices"] = (time.perf_counter() - w0, time.process_time() - c0)
        L0 = lays[0]
        self.n = n0
        self.cg = {t: DVec(self, L0) for t in ("r", "z")}

    # ---------------- Grundoperationen über alle Rechenwerke (Grafikkarten starten zuerst)
    def exchange(self, x):
        L = x.L
        if not L.plan:
            return
        got = []
        for p, q, s, e in L.plan:
            h, ev = self.parts[q].read(x.b[q], s - L.lo[q], e - s)
            got.append((p, s, h, ev))
        for g in got:
            if g[3] is not None:
                g[3].wait()
        for p, s, h, _ in got:
            self.parts[p].write(x.b[p], s - L.lo[p], h)

    def spmv(self, op, x, y):
        self.exchange(x)
        R = op.R
        track = op.track and len(self._tcpu) < 200
        t0 = time.perf_counter()
        evs = []
        for p, part in enumerate(self.parts):
            n = R.cnt(p)
            if n == 0 or op.m[p] is None:
                continue
            if part.kind == "cpu":
                self._go(part)
                t = time.perf_counter()
                part.spmv(op.m[p], x.b[p], y.b[p], R.off(p), n)
                if track:
                    self._tcpu.append(time.perf_counter() - t)
            else:
                ev = part.spmv(op.m[p], x.b[p], y.b[p], R.off(p), n)
                if track and ev is not None:
                    evs.append((p, ev))
        if track and evs:
            # Wandzeit jeder Grafikkarte (inkl. Warteschlange): wer nach der CPU fertig wird, bremst –
            # die Aufteilung richtet sich danach, nicht nach der reinen Rechenzeit des Kernels.
            t_cpu = time.perf_counter() - t0
            for p, ev in evs:
                part = self.parts[p]
                if part.done(ev):
                    ks = part.kernel_seconds(ev)
                    wall = min(t_cpu, ks) if ks else t_cpu
                else:
                    ev.wait()
                    wall = time.perf_counter() - t0
                self._tgpu.setdefault(p, []).append(wall)

    def _go(self, part):
        """Vor der CPU-Arbeit: alle Grafikkarten loslaufen lassen."""
        if part.kind == "cpu":
            for g in self.parts:
                if g.kind != "cpu":
                    g.flush()

    def restrict(self, op, t, rc):
        Lc = op.Lc
        for p, part in enumerate(self.parts):
            if op.m[p] is None:
                continue
            tb = t.b[p] if t.b[p] is not None else self._dummy(p)
            self._go(part)
            part.spmv(op.m[p], tb, rc.b[p], 0, Lc.size(p))
        self.accumulate(rc)

    def accumulate(self, v):
        """Halo-Teilsummen zum Besitzer schicken und dort addieren (Umkehrung von exchange)."""
        L = v.L
        if not L.plan:
            return
        got = []
        for p, q, s, e in L.plan:
            h, ev = self.parts[p].read(v.b[p], s - L.lo[p], e - s)
            got.append((q, s, h, ev))
        for g in got:
            if g[3] is not None:
                g[3].wait()
        for q, s, h, _ in got:
            self.parts[q].add(v.b[q], s - L.lo[q], h)

    def _dummy(self, p):
        if not hasattr(self, "_dm"):
            self._dm = {}
        if p not in self._dm:
            self._dm[p] = self.parts[p].alloc(1)
        return self._dm[p]

    def axpby(self, a, x, b, y, out):
        L = out.L
        for p, part in enumerate(self.parts):
            n = L.cnt(p)
            if n:
                self._go(part)
                part.axpby(L.off(p), n, a, x.b[p], b, y.b[p], out.b[p])

    def dscale(self, a, d, x, out):
        L = out.L
        for p, part in enumerate(self.parts):
            n = L.cnt(p)
            if n:
                self._go(part)
                part.dscale(L.off(p), n, a, d.b[p], x.b[p], out.b[p])

    def cheb(self, c1, c2, d, dinv, r, ax, x):
        L = x.L
        for p, part in enumerate(self.parts):
            n = L.cnt(p)
            if n:
                self._go(part)
                part.cheb(L.off(p), n, c1, c2, d.b[p], dinv.b[p], r.b[p], ax.b[p], x.b[p])

    def cg_update(self, a, p_, ap, x, r):
        L = x.L
        for p, part in enumerate(self.parts):
            n = L.cnt(p)
            if n:
                self._go(part)
                part.cg_update(L.off(p), n, a, p_.b[p], ap.b[p], x.b[p], r.b[p])

    def dot(self, x, y):
        L = x.L
        hs = []
        for p, part in enumerate(self.parts):
            n = L.cnt(p)
            if n:
                self._go(part)
                hs.append((part, part.dot_start(L.off(p), n, x.b[p], y.b[p])))
        return math.fsum(part.dot_end(h) for part, h in hs)

    def scatter(self, v, host):
        L = v.L
        host = np.ascontiguousarray(host, dtype=f32)
        for p, part in enumerate(self.parts):
            if L.cnt(p):
                part.write(v.b[p], L.off(p), host[L.a[p]:L.b[p]])

    def gather(self, v):
        L = v.L
        out = np.empty(L.n, dtype=f32)
        got = []
        for p, part in enumerate(self.parts):
            if L.cnt(p):
                h, ev = part.read(v.b[p], L.off(p), L.cnt(p))
                got.append((p, h, ev))
        for p, h, ev in got:
            if ev is not None:
                ev.wait()
            out[L.a[p]:L.b[p]] = h
        return out

    # ---------------- V-Zyklus z = M⁻¹ r
    def _smooth(self, L, r, x):
        lmax = L["lmax"]
        lmin = lmax / 30.0
        theta, delta = 0.5 * (lmax + lmin), 0.5 * (lmax - lmin)
        sigma = theta / delta
        rho = 1.0 / sigma
        self.dscale(1.0 / theta, L["dinv"], r, L["d"])
        self.axpby(1.0, L["d"], 0.0, L["d"], x)
        for _ in range(1, self.degree):
            rho_n = 1.0 / (2.0 * sigma - rho)
            self.spmv(L["A"], x, L["ax"])
            self.cheb(rho_n * rho, 2.0 * rho_n / delta, L["d"], L["dinv"], r, L["ax"], x)
            rho = rho_n

    def _vc(self, lvl, r, z):
        if lvl == self.nlev - 1:
            rh = self.gather(r).astype(np.float64)
            self.scatter(z, self.coarse.solve(rh))
            return
        L = self.lv[lvl]
        self._smooth(L, r, z)                                   # z = S r
        self.spmv(L["A"], z, L["ax"])
        self.axpby(1.0, r, -1.0, L["ax"], L["t"])               # t = r − A z
        self.restrict(L["PT"], L["t"], L["rc"])                 # rc = Pᵀ t
        self._vc(lvl + 1, L["rc"], L["zc"])                     # grobe Korrektur
        self.spmv(L["P"], L["zc"], L["pz"])
        self.axpby(1.0, z, 1.0, L["pz"], z)                     # z += P zc
        self.spmv(L["A"], z, L["ax"])
        self.axpby(1.0, r, -1.0, L["ax"], L["t"])
        self._smooth(L, L["t"], L["x2"])
        self.axpby(1.0, z, 1.0, L["x2"], z)                     # z += S t

    # ---------------- Vorkonditionierer für das äußere CG (float64 rein/raus, intern float32 verteilt)
    def precond(self, R):
        n, k = R.shape
        Z = np.empty_like(R)
        if not hasattr(self, "_r32"):
            self._r32 = np.empty(n, dtype=f32)
        r32, c = self._r32, self.cg
        for j in range(k):
            col = R[:, j]
            s = max(float(np.abs(col).max()), 1e-300)      # schützt float32 vor Über-/Unterlauf
            inv = 1.0 / s

            def conv(a, b):
                np.multiply(col[a:b], inv, out=r32[a:b], casting="unsafe")
            PR.run_chunks(n, conv)
            self.scatter(c["r"], r32)
            self._vc(0, c["r"], c["z"])
            z = self.gather(c["z"])

            def back(a, b):
                np.multiply(z[a:b], s, out=Z[a:b, j], casting="unsafe")
            PR.run_chunks(n, back)
        return Z

    def solve(self, B, X0=None, tol=1e-8, maxit=600):
        """Flexibles PCG in float64 auf allen CPU-Kernen; der Mehrgitter-Vorkonditionierer rechnet
        gleichzeitig auf allen Rechenwerken. Liefert (X, CG-Schritte, rel. Residuum)."""
        B = np.asarray(B, dtype=np.float64)
        w0, c0 = time.perf_counter(), time.process_time()
        X, it, res = PR.pcg(self.Kt, B, self.precond, X0, tol=tol, maxit=maxit, cancel=self.cancel,
                            stopped=SO.Stopped)
        wall = time.perf_counter() - w0
        self.cpu_busy = (time.process_time() - c0) / max(wall, 1e-9)   # ⌀ gleichzeitig rechnende Threads
        self._learn()
        return X.reshape(B.shape), it, res

    def _learn(self):
        """Gemessene Geschwindigkeit (während alle gleichzeitig rechnen) für die nächste Aufteilung."""
        for part in self.parts:
            part.finish()
        L0 = self.lays[0]
        for p, part in enumerate(self.parts):
            n = L0.cnt(p)
            if not n:
                continue
            ts = self._tcpu if part.kind == "cpu" else self._tgpu.get(p, [])
            if ts:
                learn_rate(part, n / max(sorted(ts)[len(ts) // 2], 1e-7))
        self._tgpu, self._tcpu = {}, []

    def describe(self):
        tot = max(sum(int(r) for r in self.rows0), 1)
        if len(self.parts) == 1:
            return f"on {self.parts[0].name}"
        return " + ".join(f"{p.name} {100.0 * r / tot:.0f} %" for p, r in zip(self.parts, self.rows0) if r > 0)
