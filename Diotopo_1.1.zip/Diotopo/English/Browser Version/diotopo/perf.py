# -*- coding: utf-8 -*-
"""
Arbeitsspeicher, Aufwandsschätzung und Fortschritt.

* ram(): freier und gesamter Arbeitsspeicher (Windows, Linux, macOS)
* fe_memory(): Speicherbedarf eines FE-Modells (gemessen: ~14 KB je Element + Grundbedarf)
* Speed: lernt die Geschwindigkeit dieses Rechners (Sekunden je Element) und speichert sie
* Progress: Phasenplan mit Fortschritt und Restzeit, korrigiert sich während der Rechnung
"""

import json
import math
import os
import sys
import threading
import time

BYTES_PER_ELEM = 15_000          # Spitzenbedarf je Voxel-Element (gemessen 13,9–17 KB)
BASE_BYTES = 350 * 2**20         # Python, Bibliotheken, Netz, Oberfläche
REFINE_BYTES = 700 * 2**20       # Feinvernetzung des Ergebnisses (unabhängig von der Elementzahl)
RAM_USE = 0.85                   # höchstens dieser Anteil des freien Speichers


def ram():
    """(frei, gesamt) in Byte; None, wenn unbekannt."""
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return int(m.ullAvailPhys), int(m.ullTotalPhys)
        if os.path.exists("/proc/meminfo"):
            info = {}
            with open("/proc/meminfo") as f:
                for line in f:
                    k, v = line.split(":", 1)
                    info[k] = int(v.split()[0]) * 1024
            avail, total = info.get("MemAvailable", info.get("MemFree")), info["MemTotal"]
            # Container-Grenze (cgroup) berücksichtigen
            for p in ("/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory/memory.limit_in_bytes"):
                try:
                    lim = open(p).read().strip()
                    if lim.isdigit() and int(lim) < total:
                        used = 0
                        for q in ("/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory/memory.usage_in_bytes"):
                            if os.path.exists(q):
                                used = int(open(q).read().strip())
                                break
                        total = int(lim)
                        avail = min(avail, total - used)
                        break
                except Exception:
                    pass
            return int(avail), int(total)
        if sys.platform == "darwin":
            import subprocess
            total = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"]).strip())
            return int(total * 0.5), total
    except Exception:
        pass
    try:
        import psutil
        vm = psutil.virtual_memory()
        return int(vm.available), int(vm.total)
    except Exception:
        return None, None


def filter_pairs(ne, minwall_mm, h_mm):
    R = max(1.5, minwall_mm / h_mm) if minwall_mm and minwall_mm > 0 else 1.5
    R = min(R, 10.0)
    return 4 / 3 * math.pi * R ** 3 * ne


def fe_memory(ne, S=None, refine=False):
    """Geschätzter Spitzenbedarf (Byte) eines FE-Modells mit ne Elementen."""
    S = S or {}
    b = BASE_BYTES + BYTES_PER_ELEM * ne
    h_mm = S.get("_h_mm")
    if h_mm:
        pairs = filter_pairs(ne, float(S.get("minwall_mm") or 0), h_mm)
        b += max(0.0, pairs - 20 * ne) * 40          # großer Filterradius (Mindestwandstärke)
    if refine:
        b += REFINE_BYTES
    if S.get("mfg") == "am_adv":
        b += 600 * ne                                # Randschichten (Nachbarn, Zwischenwerte)
    return int(b)


def max_elements(S=None, refine=False):
    avail, _ = ram()
    if not avail:
        return 250_000, None
    usable = avail * RAM_USE - BASE_BYTES - (REFINE_BYTES if refine else 0)
    return max(20_000, int(usable / BYTES_PER_ELEM)), avail


# ================================================================ Geschwindigkeit lernen

def _speed_file():
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "Diotopo", "speed.json")


class Speed:
    """Sekunden je Element; Startwerte gemessen auf einem langsamen 2-Kern-Rechner."""
    DEFAULTS = dict(build=2.2e-5, iter_mg=6.5e-5, iter_gpu=1.6e-5, iter_ocl=3.0e-5, iter_hybrid=2.5e-5, iter_pardiso=8e-5, iter_lu=8e-5,
                    analyze=9e-5, finish=1.2e-4, refine=6.0)
    _lock = threading.Lock()

    def __init__(self):
        self.v = dict(self.DEFAULTS)
        try:
            with open(_speed_file(), encoding="utf-8") as f:
                self.v.update({k: float(x) for k, x in json.load(f).items() if k in self.DEFAULTS})
        except Exception:
            pass

    def get(self, k):
        return self.v.get(k, self.DEFAULTS.get(k, 1e-4))

    def learn(self, k, value, weight=0.5):
        if not (value > 0 and math.isfinite(value)):
            return
        with self._lock:
            old = self.v.get(k, value)
            self.v[k] = old * (1 - weight) + value * weight
            try:
                os.makedirs(os.path.dirname(_speed_file()), exist_ok=True)
                with open(_speed_file(), "w", encoding="utf-8") as f:
                    json.dump(self.v, f)
            except Exception:
                pass


SPEED = Speed()


# ================================================================ Fortschritt

class Progress:
    """Phasenplan [(Name, erwartete Sekunden)]. Fortschritt und Restzeit werden aus dem Plan,
    der verstrichenen Zeit und – falls bekannt – dem Anteil innerhalb der Phase berechnet.
    Abweichungen der bisherigen Phasen korrigieren die Schätzung der restlichen."""

    def __init__(self, plan=None):
        self.t0 = time.time()
        self.set_plan(plan or [("Computing", 10.0)])

    def set_plan(self, plan):
        self.plan = [[n, max(float(e), 0.05)] for n, e in plan]
        self.i = 0
        self.t_phase = time.time()
        self.frac = None
        self.detail = ""
        self.act_done = 0.0
        self.exp_done = 0.0

    def phase(self, name):
        """Zur benannten Phase springen (vorherige gelten als erledigt)."""
        now = time.time()
        for j in range(self.i, len(self.plan)):
            if self.plan[j][0] == name:
                while self.i < j:                      # übersprungene Phasen zählen mit 0 s
                    self.act_done += now - self.t_phase
                    self.exp_done += self.plan[self.i][1]
                    self.t_phase = now
                    self.i += 1
                break
        self.frac = None
        self.detail = ""

    def expect(self, name, seconds):
        for p in self.plan:
            if p[0] == name:
                p[1] = max(float(seconds), 0.05)

    def set_detail(self, detail):
        """Nur den Text ändern; der Fortschritt läuft weiter nach der erwarteten Dauer."""
        self.detail = detail

    def set_frac(self, f, detail=None):
        self.frac = max(0.0, min(1.0, float(f)))
        if detail is not None:
            self.detail = detail

    def status(self):
        now = time.time()
        if self.i >= len(self.plan):
            return dict(progress=1.0, eta=0.0, phase="Done", detail="", elapsed=now - self.t0)
        name, exp = self.plan[self.i]
        el = now - self.t_phase
        f = self.frac if self.frac is not None else min(0.95, el / exp)
        total = sum(p[1] for p in self.plan)
        done = self.exp_done + f * exp
        prog = min(0.999, done / total) if total > 0 else 0.0
        # Geschwindigkeitskorrektur aus dem bisherigen Verlauf
        act = self.act_done + el
        r = act / done if done > 0.5 and act > 1.0 else 1.0
        r = max(0.25, min(4.0, r))
        if self.frac is not None and f > 0.02:
            rem_cur = el / f * (1 - f)                 # aktuelle Phase: aus eigenem Tempo
        else:
            rem_cur = max(exp * r - el, 0.15 * exp * r)
        rest = sum(p[1] for p in self.plan[self.i + 1:]) * r
        return dict(progress=prog, eta=rem_cur + rest, phase=name, detail=self.detail, elapsed=now - self.t0)


# ================================================================ Zeitmessung je Rechenschritt

class Phases:
    """Wandzeit und CPU-Zeit (alle Threads) je benanntem Schritt; ⌀ Threads = CPU-Zeit / Wandzeit."""

    def __init__(self):
        self.d = {}
        self.order = []

    def add(self, name, wall, cpu):
        if name not in self.d:
            self.d[name] = [0.0, 0.0]
            self.order.append(name)
        self.d[name][0] += wall
        self.d[name][1] += cpu

    def measure(self, name):
        ph = self

        class _M:
            def __enter__(self):
                self.w, self.c = time.perf_counter(), time.process_time()

            def __exit__(self, *a):
                ph.add(name, time.perf_counter() - self.w, time.process_time() - self.c)
        return _M()

    def text(self, total_wall=None, total_cpu=None):
        parts = []
        for n in self.order:
            w, c = self.d[n]
            if w >= 0.05:
                parts.append(f"{n} {w:.1f} s (⌀ {c / max(w, 1e-9):.1f} thr.)")
        if total_wall is not None:
            sw = sum(v[0] for v in self.d.values())
            sc = sum(v[1] for v in self.d.values())
            rw, rc = total_wall - sw, (total_cpu or 0) - sc
            if rw >= 0.05:
                parts.append(f"Rest {rw:.1f} s (⌀ {max(rc, 0) / rw:.1f} thr.)")
        return " · ".join(parts)

    def reset(self):
        self.d, self.order = {}, []
