# -*- coding: utf-8 -*-
"""
Gleichungslöser für Voxel-FE-Modelle.

Standard („Gemeinsam“, method="auto"/"hybrid"): Mehrgitter-CG, das gleichzeitig auf allen
CPU-Kernen und allen Grafikkarten rechnet; was nicht in den Grafikspeicher passt, bleibt im
Arbeitsspeicher und rechnet die CPU (siehe hybrid.py). Ohne Grafikkarte: Mehrgitter-CG auf allen
CPU-Kernen. Es wird nicht mehr ein einzelnes Rechenwerk ausgewählt.

Von Hand wählbar: "gpu" (nur Grafikkarte, CUDA oder OpenCL), "mg" (nur CPU, alle Kerne),
"pardiso" (Intel MKL, falls installiert), "lu" (direkt). Sehr kleine Systeme (bis SMALL Unbekannte)
werden immer direkt gelöst – dafür ist das Mehrgitterverfahren nicht geeignet.

Der Mehrgitter-Vorkonditionierer rechnet in einfacher Genauigkeit (float32), das CG selbst
in doppelter Genauigkeit. Die geometrieabhängigen Teile der Hierarchie (Interpolations-
matrizen) werden zwischengespeichert und in jeder Optimierungsiteration wiederverwendet.
"""

import os
import warnings

import numpy as np
import scipy.sparse as sp
from scipy.sparse.linalg import splu

from . import par as PR

SMALL = 12000       # bis zu so vielen Unbekannten direkt lösen
COARSE = 6000       # gröbstes Gitter direkt lösen
GPU_MIN = 30000     # ab so vielen Unbekannten lohnt sich die Grafikkarte


class Stopped(Exception):
    """Vom Benutzer abgebrochen."""


def _have_pardiso():
    try:
        import pypardiso  # noqa: F401
        return True
    except Exception:
        return False


HAVE_PARDISO = _have_pardiso()


# ================================================================ Rechen-Backends

class _CPU:
    name = "cpu"
    xp = np

    @staticmethod
    def mat(A, dtype):
        return A.astype(dtype)

    @staticmethod
    def dev(a, dtype=None):
        a = np.asarray(a)
        return a if dtype is None else a.astype(dtype, copy=False)

    @staticmethod
    def host(a):
        return np.asarray(a)

    @staticmethod
    def free_bytes():
        return None


class _CPUThreaded(_CPU):
    """CPU mit allen Kernen: Matrix-Vektor-Produkte werden auf alle Threads verteilt."""

    @staticmethod
    def mat(A, dtype):
        return PR.ThreadedCSR(A.astype(dtype))


class _GPU:
    name = "gpu"

    def __init__(self):
        import cupy as cp
        import cupyx.scipy.sparse as csp
        self.cp, self.csp, self.xp = cp, csp, cp
        props = cp.cuda.runtime.getDeviceProperties(0)
        nm = props["name"]
        self.device = nm.decode() if isinstance(nm, bytes) else str(nm)
        # Probe: eine kleine dünne Matrix-Vektor-Multiplikation muss funktionieren
        A = sp.random(50, 50, density=0.1, format="csr", random_state=0) + sp.identity(50, format="csr")
        x = np.ones((50, 2))
        y = cp.asnumpy(self.mat(A, np.float32) @ cp.asarray(x, dtype=cp.float32))
        if not np.allclose(y, A @ x, rtol=1e-4):
            raise RuntimeError("GPU probe returned wrong values")

    def mat(self, A, dtype):
        A = A.tocsr().astype(dtype)
        A.indices = A.indices.astype(np.int32, copy=False)
        A.indptr = A.indptr.astype(np.int32, copy=False)
        return self.csp.csr_matrix(A)

    def dev(self, a, dtype=None):
        return self.cp.asarray(a, dtype=dtype)

    def host(self, a):
        return self.cp.asnumpy(a)

    def free_bytes(self):
        free, _ = self.cp.cuda.runtime.memGetInfo()
        return free + self.cp.get_default_memory_pool().free_bytes()

    def release(self):
        try:
            self.cp.get_default_memory_pool().free_all_blocks()
        except Exception:
            pass


_GPU_STATE = {}


def gpu_backend():
    """GPU-Backend oder None (einmalig ermittelt). DIOTOPO_NO_GPU=1 schaltet die GPU ab."""
    if "b" not in _GPU_STATE:
        b, why = None, ""
        if os.environ.get("DIOTOPO_NO_GPU"):
            why = "disabled via DIOTOPO_NO_GPU"
        else:
            try:
                b = _GPU()
            except Exception as e:  # noqa
                why = f"{type(e).__name__}: {e}"
        _GPU_STATE["b"], _GPU_STATE["why"] = b, why
    return _GPU_STATE["b"]


def gpu_status():
    b = gpu_backend()
    return dict(available=b is not None, device=getattr(b, "device", None), reason=_GPU_STATE.get("why", ""))


def _is_oom(e):
    n = type(e).__name__
    return "OutOfMemory" in n or "out of memory" in str(e).lower() or "ALLOC_FAILED" in str(e)


# ================================================================ Mehrgitter

def _lu(K):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return splu(K.tocsc(), permc_spec="MMD_AT_PLUS_A", diag_pivot_thresh=0.0,
                    options=dict(SymmetricMode=True))


def prolongation(coords):
    """Trilineare Interpolation von einem 2:1 vergröberten Knotengitter.
    coords: ganzzahlige Knotenkoordinaten (n×3). Gibt (P, grobe Koordinaten) zurück."""
    lo = coords // 2
    hi = (coords + 1) // 2
    odd = (coords % 2) == 1
    nf = len(coords)
    rows, keys, vals = [], [], []
    dims = coords.max(0) // 2 + 2
    for bx in (0, 1):
        for by in (0, 1):
            for bz in (0, 1):
                b = np.array([bx, by, bz])
                c = np.where(b == 1, hi, lo)
                # Gewicht 0.5 je ungerader Achse, 1 bzw. 0 je gerader Achse
                w = np.where(odd, 0.5, np.where(b == 0, 1.0, 0.0)).prod(1)
                m = w > 0
                rows.append(np.flatnonzero(m))
                keys.append((c[m, 0] * dims[1] + c[m, 1]) * dims[2] + c[m, 2])
                vals.append(w[m])
    rows = np.concatenate(rows)
    keys = np.concatenate(keys)
    vals = np.concatenate(vals)
    uk, cols = np.unique(keys, return_inverse=True)
    cc = np.stack([uk // (dims[1] * dims[2]), (uk // dims[2]) % dims[1], uk % dims[2]], 1)
    P = sp.csr_matrix((vals, (rows, cols)), shape=(nf, len(uk)))
    return P, cc


def build_transfers(n, free, node_coords):
    """Interpolationsmatrizen der Hierarchie – hängen nur von der Geometrie ab (cachebar)."""
    Ps = []
    rows_free, coords, size = free, node_coords, n
    while size > COARSE and len(Ps) < 8:
        Pn, cc = prolongation(coords)
        P3 = sp.kron(Pn, sp.identity(3, format="csr"), format="csr")[rows_free]
        keep = np.flatnonzero(np.asarray(P3.getnnz(axis=0)) > 0)
        P3 = P3[:, keep].tocsr()
        if P3.shape[1] >= 0.7 * P3.shape[0]:
            break
        Ps.append((P3, P3.T.tocsr()))
        rows_free, coords, size = keep, cc, P3.shape[1]
    return Ps


def galerkin_levels(A, free, node_coords, cache=None, cancel=None):
    """Matrizen aller Ebenen (CPU, float64) und Transfers; Transfers werden zwischengespeichert."""
    A = A.tocsr()
    key = ("P", A.shape[0])
    if cache is not None and key in cache:
        Ps = cache[key]
    else:
        Ps = build_transfers(A.shape[0], free, node_coords)
        if cache is not None:
            cache[key] = Ps
    As = [A]
    for P3, P3T in Ps:
        if cancel is not None and cancel():
            raise Stopped()
        As.append(PR.spmm(PR.spmm(P3T, As[-1]), P3))          # Galerkin-Produkt auf allen Kernen
    return As, Ps


def smoother_bounds(A_):
    """Jacobi-Skalierung und Gershgorin-Schranke für lambda_max(D^-1 A)."""
    d = A_.diagonal()
    Dinv = np.where(d > 0, 1.0 / np.maximum(d, 1e-300), 0.0)
    gersh = float((Dinv * PR.row_abs_sum(A_)).max())
    return Dinv, gersh


def power_start(cache, lvl, n):
    """Startvektor der Potenzmethode: letzter Eigenvektor (Warmstart, wenige Schritte) oder Zufall."""
    v = cache.get(("v", lvl, n)) if cache is not None else None
    if v is not None:
        return v, 4
    return np.random.default_rng(1).random(n) - 0.5, 12


class MGHierarchy:
    """Galerkin-Hierarchie A_{l+1} = P^T A_l P mit Chebyshev-Glätter (Jacobi-skaliert).
    Die Galerkin-Produkte entstehen auf der CPU, Glättung und Transfers laufen im Backend
    (CPU oder GPU) in float32."""

    def __init__(self, A, free, node_coords, degree=3, backend=None, cache=None, cancel=None):
        self.degree = degree
        self.bk = backend or _CPU
        As, Ps = galerkin_levels(A, free, node_coords, cache, cancel)
        self.coarse = _lu(As[-1])
        bk, f32 = self.bk, np.float32
        self.A, self.P, self.PT, self.Dinv, self.lmax = [], [], [], [], []
        for lvl, A_ in enumerate(As[:-1]):
            Dinv, gersh = smoother_bounds(A_)
            Ad = bk.mat(A_, f32)
            Dd = bk.dev(Dinv, f32)
            xp = bk.xp
            v0, nit = power_start(cache, lvl, A_.shape[0])
            v = bk.dev(v0, f32)
            lam = 1.0
            for _ in range(nit):                     # Potenzmethode für lambda_max(D^-1 A)
                w = Dd * (Ad @ v)
                nw = float(xp.linalg.norm(w))
                lam = nw / max(float(xp.linalg.norm(v)), 1e-30)
                v = w / max(nw, 1e-30)
            if cache is not None:
                cache[("v", lvl, A_.shape[0])] = bk.host(v)
            self.A.append(Ad)
            self.Dinv.append(Dd)
            self.lmax.append(min(1.3 * lam, gersh))
            self.P.append(bk.mat(Ps[lvl][0], f32))
            self.PT.append(bk.mat(Ps[lvl][1], f32))
        self.nlev = len(As)

    def _smooth(self, lvl, r):
        """Chebyshev-Polynom angewendet auf das Residuum r (Startwert 0)."""
        A, Dinv, lmax = self.A[lvl], self.Dinv[lvl], self.lmax[lvl]
        if r.ndim == 2:
            Dinv = Dinv[:, None]
        lmin = lmax / 30.0
        theta, delta = 0.5 * (lmax + lmin), 0.5 * (lmax - lmin)
        sigma = theta / delta
        rho = 1.0 / sigma
        d = Dinv * r / theta
        x = d.copy()
        for _ in range(1, self.degree):
            rho_n = 1.0 / (2.0 * sigma - rho)
            d = rho_n * rho * d + (2.0 * rho_n / delta) * (Dinv * (r - A @ x))
            x += d
            rho = rho_n
        return x

    def _vc(self, r, lvl):
        if lvl == self.nlev - 1:
            bk = self.bk
            return bk.dev(self.coarse.solve(bk.host(r).astype(np.float64)), np.float32)
        A = self.A[lvl]
        x = self._smooth(lvl, r)
        rc = self.PT[lvl] @ (r - A @ x)
        x += self.P[lvl] @ self._vc(rc, lvl + 1)
        x += self._smooth(lvl, r - A @ x)
        return x

    def vcycle(self, r):
        """Vorkonditionierer: float64 rein, float64 raus, intern float32."""
        xp = self.bk.xp
        scale = xp.maximum(xp.abs(r).max(axis=0), 1e-300)     # schützt float32 vor Über-/Unterlauf
        z = self._vc((r / scale).astype(xp.float32), 0)
        return z.astype(xp.float64) * scale


def pcg(A, B, prec, X0=None, tol=1e-8, maxit=500, cancel=None, xp=np):
    """Vorkonditioniertes CG (flexible Variante, robust gegenüber float32-Vorkonditionierer)
    für mehrere rechte Seiten gleichzeitig."""
    B = B[:, None] if B.ndim == 1 else B
    X = xp.zeros_like(B) if X0 is None else X0.copy()
    R = B - A @ X
    bn = xp.maximum(xp.linalg.norm(B, axis=0), 1e-300)
    Z = prec(R)
    Pd = Z.copy()
    rz = (R * Z).sum(0)
    it, resmax = 0, float("inf")
    for it in range(1, maxit + 1):
        AP = A @ Pd
        pap = (Pd * AP).sum(0)
        alpha = xp.where(pap > 0, rz / xp.where(pap > 0, pap, 1.0), 0.0)
        X += Pd * alpha
        R -= AP * alpha
        res = xp.linalg.norm(R, axis=0) / bn
        resmax = float(res.max())                     # synchronisiert die GPU einmal je Schritt
        if resmax < tol:
            break
        if cancel is not None and cancel():
            raise Stopped()
        Zn = prec(R)
        rz_new = (R * Zn).sum(0)
        rz_pr = (R * (Zn - Z)).sum(0)                 # Polak-Ribière
        beta = xp.where(rz > 0, xp.maximum(rz_pr, 0.0) / xp.where(rz > 0, rz, 1.0), 0.0)
        Pd = Zn + Pd * beta
        Z, rz = Zn, rz_new
    return X, it, resmax


class Solver:
    """method: auto (= hybrid: alle Rechenwerke gemeinsam) | gpu | mg | pardiso | lu"""

    def __init__(self, K, free=None, node_coords=None, method="auto", cancel=None, cache=None, log=None,
                 tol=1e-8):
        self.cancel = cancel
        self.tol = tol
        self.cache = cache
        self.log = log or (lambda m: None)
        self.K = K.tocsr()
        n = K.shape[0]
        self.info = ""
        self.kind = None
        mg_ok = n > SMALL and node_coords is not None
        if method in ("auto", "hybrid", "mg") and mg_ok:
            self._try_hybrid(free, node_coords, use_gpu=method != "mg")
        if method == "gpu" and mg_ok:
            bk = gpu_backend()
            if bk is not None and self._gpu_fits(bk, n):
                try:
                    self.mg = MGHierarchy(self.K, free, node_coords, backend=bk, cache=cache, cancel=cancel)
                    self.Kd = bk.mat(self.K, np.float64)
                    self.kind, self.bk = "gpu", bk
                except Stopped:
                    raise
                except Exception as e:  # noqa
                    self._gpu_failed(bk, e)
            if self.kind is None:
                self._try_opencl(method, free, node_coords)
        if self.kind is None:
            if method == "pardiso" and HAVE_PARDISO:
                self.kind = "pardiso"
            elif method in ("gpu", "pardiso") and mg_ok:
                self.kind, self.bk = "mg", _CPUThreaded
                self.mg = MGHierarchy(self.K, free, node_coords, backend=_CPUThreaded, cache=cache, cancel=cancel)
            else:
                self.kind = "lu"
                self.lu = _lu(self.K)
        if cancel is not None and cancel():
            raise Stopped()

    def _try_hybrid(self, free, node_coords, use_gpu=True):
        """Alle Rechenwerke gleichzeitig: CPU (alle Kerne) + alle Grafikkarten + Arbeitsspeicher.
        Ohne Grafikkarte derselbe Löser nur auf der CPU."""
        from . import hybrid as HY
        gpus = HY.gpu_parts() if use_gpu and self.K.shape[0] >= GPU_MIN else []
        for attempt in (gpus, []) if gpus else ([],):
            try:
                self.hy = HY.HybridSolver(attempt + [HY.CPUPart()], self.K, free, node_coords,
                                          cache=self.cache, cancel=self.cancel)
                self.kind = "hybrid" if attempt else "mg"
                if attempt and (self.cache is None or not self.cache.get("hy_msg")):
                    self.log("Combined computing: " + self.hy.describe()
                             + " (split is readjusted based on measured run time)")
                    if self.cache is not None:
                        self.cache["hy_msg"] = True
                return
            except Stopped:
                raise
            except Exception as e:  # noqa
                self.hy = None
                if not attempt:
                    raise
                self._hybrid_failed(attempt, e)

    def _hybrid_failed(self, gpus, e):
        from . import hybrid as HY
        if not _is_oom(e) and not isinstance(e, MemoryError):
            for g in gpus:                        # Treiberfehler: diese Sitzung ohne Grafikkarte
                HY.mark_broken(g)
        self._note(f"Combined computing with graphics card failed ({type(e).__name__}: {e}) – "
                   "computing on all CPU cores")

    def _try_opencl(self, method, free, node_coords):
        """Herstellerübergreifend (NVIDIA, AMD, Intel) über OpenCL."""
        from . import gpu_ocl as GO
        dev = GO.device()
        if dev is None:
            if method == "gpu":
                self._note("No graphics card usable (CUDA: " + (gpu_status()["reason"] or "–") + "; OpenCL: " +
                           (GO.status()["reason"] or "–") + ") – computing on the CPU")
            return
        if method == "auto" and not GO.worth_it():
            self._note(f"{dev.name}: integrated graphics is not faster than the CPU here – computing on the CPU "
                       "(force it: equation solver “Graphics card”)")
            return
        n = self.K.shape[0]
        need = GO.memory_need(n)
        if need > 0.8 * dev.mem:
            self._note(f"Model too large for the graphics memory of {dev.name} (≈{need / 2**30:.1f} GB needed) – "
                       "computing on the CPU")
            return
        try:
            self.cl = GO.CLSolver(dev, self.K, free, node_coords, cache=self.cache, cancel=self.cancel)
            self.kind, self.dev_name = "ocl", dev.name
        except Stopped:
            raise
        except Exception as e:  # noqa
            self._note(f"OpenCL solver on {dev.name} failed ({type(e).__name__}: {e}) – computing on the CPU")
            self.cl = None

    def _Kt(self):
        if getattr(self, "_kt", None) is None:
            self._kt = PR.ThreadedCSR(self.K)
        return self._kt

    def _note(self, m):
        if self.cache is None or not self.cache.get(("note", m)):
            self.log("Note: " + m)
            if self.cache is not None:
                self.cache[("note", m)] = True

    def _gpu_fits(self, bk, n):
        """Grobe Speicherabschätzung: ~81 Einträge/Zeile, fein float64 + float32, grobe Ebenen ~+20 %."""
        free = bk.free_bytes()
        need = n * 81 * (12 + 8) * 1.25 + n * 8 * 40
        if free is not None and need > 0.9 * free:
            self._note(f"Model too large for the graphics memory (≈{need / 2**30:.1f} GB needed, "
                       f"{free / 2**30:.1f} GB free) – continuing without CUDA")
            return False
        return True

    def _gpu_failed(self, bk, e):
        bk.release()
        if _is_oom(e):
            self._note("Graphics memory not sufficient for CUDA – continuing without CUDA")
        else:
            self._note(f"CUDA solver failed ({type(e).__name__}: {e}) – continuing without CUDA")
        self.mg = None

    def solve(self, B, X0=None):
        B = np.asarray(B, dtype=np.float64)
        if self.kind in ("hybrid", "mg") and getattr(self, "hy", None) is not None:
            try:
                X, it, res = self.hy.solve(B, X0, tol=self.tol)
                self.info = (f"MGCG {self.hy.describe()} – {it} iter., res. {res:.1e}, {self.hy.nlev} levels, "
                             f"CPU utilization ⌀ {self.hy.cpu_busy:.1f} of {PR.n_threads()} Threads")
                if res <= max(1e-4, 10 * self.tol):
                    return X
                self.info += " – not converged, solving directly"
                return _lu(self.K).solve(B)
            except Stopped:
                raise
            except Exception as e:  # noqa
                gp = [p for p in self.hy.parts if p.kind == "gpu"]
                if not gp:
                    raise
                self._hybrid_failed(gp, e)
            from . import hybrid as HY
            self.hy = HY.HybridSolver([HY.CPUPart()], self.K, None, None, cache=self.cache, cancel=self.cancel)
            self.kind = "mg"
            return self.solve(B, X0)
        if self.kind == "ocl":
            try:
                X, it, res = self.cl.solve(B, X0, tol=self.tol)
                self.info = f"MGCG on {self.dev_name} (OpenCL) {it} iter., res. {res:.1e}, {self.cl.nlev} levels"
                if res <= max(1e-4, 10 * self.tol):
                    return X
                self._note(f"OpenCL solver not converged (res. {res:.1e}) – computing on the CPU")
            except Stopped:
                raise
            except Exception as e:  # noqa
                self._note(f"OpenCL solver failed ({type(e).__name__}: {e}) – computing on the CPU")
            self.cl = None
            self.kind, self.bk = "mg", _CPUThreaded
            self.mg = MGHierarchy(self.K, None, None, backend=_CPUThreaded, cache=self.cache, cancel=self.cancel)
            return self.solve(B, X0)
        if self.kind == "pardiso":
            import pypardiso
            X = pypardiso.spsolve(self.K, B)
            return X.reshape(B.shape)
        if self.kind in ("gpu", "mg"):
            bk = self.bk
            try:
                X, it, res = pcg(self.Kd if self.kind == "gpu" else self._Kt(), bk.dev(B),
                                 self.mg.vcycle, None if X0 is None else bk.dev(np.asarray(X0, np.float64)),
                                 tol=self.tol, maxit=600, cancel=self.cancel, xp=bk.xp)
                X = bk.host(X).reshape(B.shape)
            except Stopped:
                raise
            except Exception as e:  # noqa
                if self.kind != "gpu":
                    raise
                self._gpu_failed(bk, e)
                self.kind, self.bk = "mg", _CPUThreaded
                self.mg = MGHierarchy(self.K, None, None, backend=_CPUThreaded, cache=self.cache,
                                      cancel=self.cancel) \
                    if self.cache and ("P", self.K.shape[0]) in self.cache else None
                if self.mg is None:
                    self.kind = "lu"
                    return _lu(self.K).solve(B)
                return self.solve(B, X0)
            dev = f" on {bk.device}" if self.kind == "gpu" else f" on CPU ({PR.n_threads()} Threads)"
            self.info = f"MGCG{dev} {it} iter., res. {res:.1e}, {self.mg.nlev} levels"
            if res > max(1e-4, 10 * self.tol):
                self.info += " – not converged, solving directly"
                return _lu(self.K).solve(B)
            return X
        return self.lu.solve(B)


def planned_kind(n, method="auto"):
    """Welcher Löser würde für n Unbekannte gewählt? (für Zeitschätzungen, ohne Aufbau)"""
    mg_ok = n > SMALL
    if not mg_ok or method == "lu":
        return "lu"
    if method in ("auto", "hybrid"):
        from . import hybrid as HY
        return "hybrid" if n >= GPU_MIN and HY.gpu_parts() else "mg"
    if method == "gpu":
        bk = gpu_backend()
        if bk is not None:
            free = bk.free_bytes()
            need = n * 81 * (12 + 8) * 1.25 + n * 8 * 40
            if free is None or need <= 0.9 * free:
                return "gpu"
        from . import gpu_ocl as GO
        dev = GO.device()
        if dev is not None and GO.memory_need(n) <= 0.8 * dev.mem:
            return "ocl"
    if method == "pardiso" and HAVE_PARDISO:
        return "pardiso"
    return "mg"
