import { Viewer, isoSurface, sub, add, mul, dot, cross, norm } from './viewer.js';

const $ = id => document.getElementById(id);
const COL = { fixed: [0.18, 0.44, 0.93], frictionless: [0.35, 0.6, 0.98], pin: [0.1, 0.33, 0.8], load: [0.9, 0.28, 0.3],
  gravity: [0.9, 0.28, 0.3], solid: [0.19, 0.64, 0.42], void: [0.96, 0.65, 0.14],
  box_solid: [0.19, 0.64, 0.42], box_void: [0.96, 0.65, 0.14], sel: [1.0, 0.83, 0.23] };
const CSSC = c => `rgb(${c.map(v => Math.round(v * 255)).join(',')})`;
const LIME = [0.827, 0.953, 0.000];          // Ergebnisoberfläche (#D3F300)
const INF_COL = [0.98, 0.55, 0.12], CORE_COL = [0.96, 0.90, 0.74];   // Infill-Muster, Infill-Bereich (Schnitt)
// Eine eigene Farbe je Option unter „Auswahl zuweisen als …“ (gilt für Button, Fläche, Pfeil und Karte).
// Kein Gelbgrün #D3F300 (Ergebnis) und kein Gelb (Auswahl).
const OPT_COL = {
  fixed: [0.12, 0.44, 0.90],        // Fest – Blau
  frictionless: [0.13, 0.72, 0.81], // Reibungsfrei – Cyan
  pin: [0.16, 0.21, 0.58],          // Bolzen – Dunkelblau
  force: [0.90, 0.22, 0.23],        // Kraft – Rot
  pressure: [0.94, 0.55, 0.0],      // Druck – Orange
  moment: [0.84, 0.20, 0.52],       // Moment – Magenta
  bearing: [0.55, 0.33, 0.14],      // Lagerlast – Braun
  remote: [1.0, 0.54, 0.40],        // Fernkraft – Lachs
  solid: [0.04, 0.48, 0.46],        // Massiv erhalten – Petrol
  void: [0.29, 0.31, 0.34],         // Frei halten – Schiefergrau
  gravity: [0.55, 0.06, 0.12],      // Schwerkraft – Weinrot
  box_solid: [0.45, 0.75, 0.99],    // Box massiv – Hellblau
  box_void: [0.97, 0.51, 0.67],     // Box frei – Rosa
};
function itemColor(it) {
  return OPT_COL[it.type === 'load' ? it.kind : it.type] || OPT_COL.force;
}
document.querySelectorAll('[data-add]').forEach(b => {
  const c = OPT_COL[b.dataset.add]; if (c) b.style.setProperty('border-left-color', CSSC(c), 'important');
});
const NAMES = { fixed: 'Fixed', frictionless: 'Frictionless', pin: 'Pin support', force: 'Force', pressure: 'Pressure',
  moment: 'Moment', bearing: 'Bearing load', remote: 'Remote force', gravity: 'Gravity', solid: 'Keep solid',
  void: 'Keep empty', box_solid: 'Solid box', box_void: 'Empty box' };
const DIRS = [['x+', '+X'], ['x-', '−X'], ['y+', '+Y'], ['y-', '−Y'], ['z+', '+Z'], ['z-', '−Z'],
  ['n_in', 'Normal inward'], ['n_out', 'Normal outward'], ['custom', 'Vector …']];
const LOADKINDS = ['force', 'pressure', 'moment', 'bearing', 'remote'];

const S = {
  info: null, mesh: null, fileBytes: null, fileName: null,
  sel: [], selInfo: null, conds: [], nextId: 1, cases: [{ id: 1, name: 'Load case 1', weight: 1 }],
  holes: [], holeSel: new Set(),
  res: {}, checks: {}, view: 'original', tab: 'prep', poll: null, logN: 0, frameId: 0, frameBusy: false,
  anim: null, jobKind: null,
};

// ====================================================================== Hilfen
function toast(msg, kind = '') {
  const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = msg;
  $('toasts').appendChild(t); setTimeout(() => t.remove(), kind === 'err' ? 9000 : 4500);
}
function logLine(m) {
  const l = $('log'), d = document.createElement('div');
  d.textContent = m; if (/FEHLER/.test(m)) d.className = 'e'; else if (/WARNUNG|Hinweis/.test(m)) d.className = 'w';
  l.appendChild(d); l.scrollTop = l.scrollHeight;
}
async function api(path, opts = {}) {
  const r = await fetch(path, opts);
  if (r.status === 204) return null;
  const ct = r.headers.get('Content-Type') || '';
  if (!r.ok) { let m = 'Error ' + r.status; try { m = (await r.json()).error || m; } catch (e) {} throw new Error(m); }
  if (ct.includes('octet-stream')) return unpack(await r.arrayBuffer());
  if (ct.includes('json')) return r.json();
  return r;
}
const post = (p, o) => api(p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(o) });
function unpack(buf) {
  const dv = new DataView(buf), n = dv.getUint32(0, true);
  const head = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, 4, n)));
  const base = 4 + n, out = { meta: head.meta };
  const T = { float32: Float32Array, int32: Int32Array, uint32: Uint32Array, uint8: Uint8Array, int16: Int16Array };
  for (const a of head.arrays) out[a.name] = new T[a.dtype](buf.slice(base + a.offset, base + a.offset + a.bytes));
  return out;
}
function b64(buf) {
  const u = new Uint8Array(buf); let s = ''; const C = 0x8000;
  for (let i = 0; i < u.length; i += C) s += String.fromCharCode.apply(null, u.subarray(i, i + C)); return btoa(s);
}
function unb64(s) { const b = atob(s), u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u.buffer; }
const fmt = (x, d = 3) => (x === null || x === undefined || !isFinite(x)) ? '–' : Number(x).toPrecision(d);
const fmtN = x => x >= 1e6 ? (x / 1e6).toFixed(2) + ' M' : x >= 1e3 ? (x / 1e3).toFixed(0) + ' k' : String(x);
function fmtDur(s) {
  if (s == null || !isFinite(s)) return '–';
  s = Math.max(0, Math.round(s));
  if (s < 60) return `${s} s`;
  if (s < 3600) return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')} min`;
  return `${Math.floor(s / 3600)}:${String(Math.floor(s % 3600 / 60)).padStart(2, '0')} h`;
}
const JOB_TITLES = { analyze: 'Analysis of the solid part', optimize: 'Topology optimization', remesh: 'Generating result' };
function showLoad(ld) {
  for (const el of document.querySelectorAll('#jbLoad .ld')) {
    const k = el.dataset.k, v = ld ? ld[k] : null, ok = v != null && isFinite(v);
    el.classList.toggle('na', !ok);
    el.querySelector('.lf').style.width = ok ? Math.max(0, Math.min(100, v)).toFixed(0) + '%' : '0';
    el.querySelector('.lv').textContent = ok ? Math.round(v) + ' %' : '–';
    el.title = ok ? '' : (k === 'gpu' ? 'GPU utilization cannot be measured on this system' : 'not measurable');
    if (k === 'ram') { el.classList.toggle('hi', ok && v >= 80 && v < 92); el.classList.toggle('crit', ok && v >= 92); }
  }
}
function jobBar(kind, st) {
  const jb = $('jobBar'); jb.hidden = false; $('loadBox').hidden = false;
  $('jbTitle').textContent = JOB_TITLES[kind] || 'Computation';
  if (!st) { showLoad(null); jb.classList.add('indet'); $('jbPct').textContent = ''; $('jbPhase').textContent = 'Starting …'; $('jbTime').textContent = ''; return; }
  const p = Math.max(0, Math.min(1, st.progress || 0));
  jb.classList.toggle('indet', p <= 0.002);
  $('jbFill').style.width = (p * 100).toFixed(1) + '%';
  $('jbPct').textContent = Math.round(p * 100) + ' %';
  $('jbPhase').textContent = (S.stopping ? 'Stopping – ' : '') + (st.phase || '') + (st.detail ? ' · ' + st.detail : '');
  showLoad(st.load);
  $('jbTime').textContent = `${fmtDur(st.elapsed)} elapsed` + (st.state === 'running' && st.eta != null ? ` · approx. ${fmtDur(st.eta)}` : '');
}
const updateFeEstimate = debounce(async () => {
  if (!S.mesh) return;
  const show1 = async (kind, box, btn) => {
    try {
      const e = await post('/api/fe_estimate', { kind, settings: engineSettings(kind) });
      const ram = e.avail_mb ? ` of ${(e.avail_mb / 1024).toFixed(1)} GB free` : '';
      const solver = { hybrid: 'CPU + graphics card(s) combined', gpu: 'Graphics card (CUDA)', ocl: 'Graphics card (OpenCL)', mg: 'CPU (all cores)', pardiso: 'CPU (Pardiso)', lu: 'CPU (direct)' }[e.solver] || e.solver;
      let h = `≈ <b>${fmtN(e.elements)}</b> elements (voxel ${fmt(e.voxel_mm)} mm) · memory ≈ <b>${(e.memory_mb / 1024).toFixed(1)} GB</b>${ram}<br>`;
      h += kind === 'optimize'
        ? `Time: ≈ ${fmtDur(e.seconds_iter)} per iteration, total up to ≈ <b>${fmtDur(e.seconds)}</b> (${e.iterations} iterations) · ${solver}`
        : `Time ≈ <b>${fmtDur(e.seconds)}</b> · ${solver}`;
      if (e.too_big) h += `<br><b>Too large for the free memory – resolution at most ≈ ${e.max_resolution}.</b>`;
      else h += `<br><span class="small">Highest resolution with the free memory: ≈ ${e.max_resolution}</span>`;
      box.className = 'estimate ' + (e.too_big ? 'bad' : e.memory_mb > 0.7 * e.avail_mb ? 'warn' : 'muted');
      box.innerHTML = h;
      btn.dataset.toobig = e.too_big ? '1' : '';
      if (e.limits) { S.limits[kind] = e.limits; applyLimits(); }
    } catch (err) { box.textContent = err.message; }
  };
  await show1('analyze', $('estAn'), $('btnAnalyze'));
  await show1('optimize', $('estOpt'), $('btnOpt'));
}, 350);
function debounce(f, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => f(...a), ms); }; }
function el(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'on') for (const [ev, f] of Object.entries(v)) e.addEventListener(ev, f);
    else if (k === 'style') e.style.cssText = v; else if (k in e && k !== 'list') e[k] = v; else e.setAttribute(k, v);
  }
  for (const c of kids) if (c !== null && c !== undefined) e.append(c);
  return e;
}
function getK() {
  const o = {};
  document.querySelectorAll('[data-k]').forEach(e => {
    const k = e.dataset.k;
    if (e.type === 'checkbox') o[k] = e.checked;
    else if (e.type === 'number' || e.type === 'range') o[k] = e.value === '' ? null : parseFloat(e.value);
    else o[k] = e.value;
  });
  return o;
}
function setK(o) {
  for (const [k, v] of Object.entries(o || {})) {
    const e = document.querySelector(`[data-k="${k}"]`);
    if (!e || v === undefined || v === null) continue;
    if (e.type === 'checkbox') e.checked = !!v; else e.value = v;
  }
  refreshVis();
  if (Object.keys(SLIDERS).length) updateSliderBounds();
}

// ====================================================================== Schieberegler
// Jedes Zahlenfeld der Topologieoptimierung bekommt einen Regler vom kleinsten bis zum größten
// einstellbaren Wert. Feste Grenzen stehen im HTML (min/max); Felder ohne festes Maximum richten
// sich nach dem geladenen Bauteil (dynMax).
const SLIDERS = {};
S.limits = {};
// Grenzen aus Arbeitsspeicher und Rechenkern (vom Server je nach Bauteil und Einstellungen berechnet)
function capMax(k) {
  const L = S.limits.optimize, A = S.limits.analyze;
  if (k === 'resolution') return L?.resolution_max;
  if (k === 'an_resolution') return A?.resolution_max;
  if (k === 'minwall_mm') return L?.minwall_max_mm;
  if (k === 'cnc_tool_mm') return L?.cnc_tool_max_mm;
  return null;
}
const CAP_WHY = { resolution: 'memory', an_resolution: 'memory', minwall_mm: 'memory/resolution',
  cnc_tool_mm: 'Resolution' };
function applyLimits() {
  updateSliderBounds();
  // aktuelle Werte, die nicht mehr berechenbar sind, auf die Grenze setzen
  const fix = [];
  for (const k of ['resolution', 'an_resolution', 'minwall_mm', 'cnc_tool_mm']) {
    const inp = document.querySelector(`[data-k="${k}"]`), cm = capMax(k);
    if (!inp || cm == null) continue;
    const step = k.endsWith('_mm') ? 0.1 : 1, mx = Math.floor(cm / step) * step;
    inp.max = +mx.toFixed(3);
    if (parseFloat(inp.value) > mx) { inp.value = +mx.toFixed(3); fix.push(k); }
  }
  const dm = S.limits.optimize?.detail_min_mm, d = document.querySelector('[data-k="detail_mm"]');
  if (dm && d && parseFloat(d.value) > 0 && parseFloat(d.value) < dm) { d.value = +(Math.ceil(dm * 100) / 100).toFixed(2); fix.push('detail_mm'); }
  if (fix.length) {
    syncSliders();
    const names = { resolution: 'Resolution', an_resolution: 'Resolution (analysis)', minwall_mm: 'Minimum wall thickness',
      cnc_tool_mm: 'Cutter diameter', detail_mm: 'Detail size' };
    toast(`${fix.map(k => names[k]).join(', ')} set to the largest value that can be computed (available memory and computing capacity).`, 'warn');
    for (const k of fix) document.querySelector(`[data-k="${k}"]`).dispatchEvent(new Event('change', { bubbles: true }));
  }
}
function niceStep(x) {
  if (!(x > 0)) return 1;
  const p = 10 ** Math.floor(Math.log10(x)), f = x / p;
  return (f < 1.5 ? 1 : f < 3.5 ? 2 : f < 7.5 ? 5 : 10) * p;
}
function niceMax(x) { const s = niceStep(x / 20); return Math.max(s, Math.ceil(x / s) * s); }
function partDims() {           // Abmessungen in mm (ohne Bauteil: 100 mm)
  if (!S.mesh) return [100, 100, 100];
  const u = unitScale(); return sub(S.mesh.hi, S.mesh.lo).map(d => Math.abs(d) * u);
}
function dynMax(k) {
  const d = partDims(), dmin = Math.min(...d), dmax = Math.max(...d), K = getK();
  switch (k) {
    case 'mass_g': return niceMax(Math.max(origMass(), 1));
    case 'minwall_mm': case 'bc_wall_mm': return niceMax(dmin / 2);
    case 'cnc_tool_mm': return niceMax(dmax / 2);
    case 'prism_step_mm': return niceMax(dmax);
    case 'cnc_depth_mm': return niceMax(K.mfg === 'cnc_prism' ? dmax : (d['xyz'.indexOf((K.mfg_dir || 'z+')[0])] || dmax));
    case 'detail_mm': return niceMax(dmin / 4);
  }
  return null;
}
function initSliders() {
  for (const num of document.querySelectorAll('#optCard input[type=number][data-k], #optRes input[type=number][data-k]')) {
    const k = num.dataset.k, row = num.closest('.row');
    num.dataset.max0 = num.max;
    const r = el('input', { type: 'range', className: 'kslider' });
    r.setAttribute('aria-label', (row.querySelector('label')?.textContent || k) + ' (slider)');
    row.classList.add('srow');
    num.before(r);
    SLIDERS[k] = { r, num };
    r.addEventListener('input', () => {
      const dm = S.limits.optimize?.detail_min_mm;
      if (k === 'detail_mm' && dm && +r.value > 0 && +r.value < dm) r.value = dm;
      num.value = r.value; num.dispatchEvent(new Event('input', { bubbles: true }));
    });
    r.addEventListener('change', () => { num.value = r.value; num.dispatchEvent(new Event('change', { bubbles: true })); });
    num.addEventListener('input', () => { r.value = num.value; });
    num.addEventListener('change', () => { r.value = num.value; });
  }
  updateSliderBounds();
}
function updateSliderBounds() {
  for (const [k, { r, num }] of Object.entries(SLIDERS)) {
    const dm = dynMax(k);
    const min = num.min !== '' ? parseFloat(num.min) : 0;
    let max = dm != null ? dm : (num.dataset.max0 || num.max) !== '' ? parseFloat(num.dataset.max0 || num.max) : 100;
    const cm = capMax(k);
    if (cm != null && cm < max) max = Math.max(min, k.endsWith('_mm') ? Math.floor(cm * 10) / 10 : Math.floor(cm));
    let step = num.step && num.step !== 'any' ? parseFloat(num.step) : 1;
    if (dm != null) step = Math.min(step, niceStep((max - min) / 200));   // fein genug für den Bereich
    r.min = min; r.max = max; r.step = step;
    r.title = `${min} … ${+max.toPrecision(6)}` + (cm != null && max <= cm ? ` (largest computable value, limited by ${CAP_WHY[k]})` : '');
    if (k === 'detail_mm' && S.limits.optimize) r.title += ` · smallest possible detail size ≈ ${fmt(S.limits.optimize.detail_min_mm)} mm`;
    r.value = num.value;
  }
}
function syncSliders() { for (const { r, num } of Object.values(SLIDERS)) r.value = num.value; }
const unitScale = () => ({ mm: 1, cm: 10, m: 1000, in: 25.4 })[getK().unit_len] || 1;
const units = () => (S.info?.units?.[getK().unit_force]) || ['N', 'N·m', 'MPa'];
function origMass() { return S.mesh ? S.mesh.volume * unitScale() ** 3 * getK().rho * 1e-3 : 0; }

// ====================================================================== Viewer
const V = new Viewer($('gl'), $('overlay'));
window.__viewer = V;
$('viewSel').onchange = () => { if ($('viewSel').value) V.view($('viewSel').value); $('viewSel').value = ''; };
$('btnFit').onclick = () => S.mesh && V.fit(S.mesh.lo, S.mesh.hi);
$('upAxis').onchange = () => { V.up = $('upAxis').value; V.redraw(); };

// ====================================================================== Tabs & Sichtbarkeit
document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => setTab(b.dataset.tab));
function setTab(t) {
  S.tab = t;
  document.querySelectorAll('#tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === t));
  document.querySelectorAll('#side > section').forEach(s => s.hidden = s.dataset.tab !== t);
  if (t === 'prep' && S.view !== 'original') show('original');
  if (t === 'exp') { const w = $('expWhat'); if (!S.res[w.value]) w.value = S.res.optimize ? 'optimize' : 'original'; updateExportFormats(); }
  if (t === 'sim') updateFeEstimate();
}
const PRISM_SIDES = [['ps_zp', 'z+'], ['ps_zm', 'z-'], ['ps_yp', 'y+'], ['ps_ym', 'y-'], ['ps_xp', 'x+'], ['ps_xm', 'x-']];
function vis(sel, on) { document.querySelectorAll(sel).forEach(e => e.style.display = on ? '' : 'none'); }
function refreshVis() {
  const K = getK();
  vis('.grow-only', K.pick_mode === 'grow');
  vis('.tm-vol', K.target_mode === 'vol'); vis('.tm-mass', K.target_mode === 'mass');
  const am = K.mfg === 'am' || K.mfg === 'am_adv', cnc = K.mfg === 'cnc3' || K.mfg === 'cnc_prism';
  vis('.mfg-am', am); vis('.mfg-adv', K.mfg === 'am_adv');
  vis('.mfg-dir', K.mfg !== 'none' && K.mfg !== 'cnc_prism'); vis('.mfg-cnc', cnc); vis('.mfg-prism', K.mfg === 'cnc_prism');
  vis('.mfg-organic', K.mfg === 'cnc3');
  $('mfgDirLbl').textContent = { am: 'Build direction', am_adv: 'Build direction', cast: 'Demolding direction', cnc3: 'Tool comes from', cnc_prism: 'Tool comes from' }[K.mfg] || 'Direction';
}
document.querySelectorAll('[data-k]').forEach(e => e.addEventListener('change', () => {
  refreshVis();
  if (e.closest('section')?.dataset.tab === 'sim' || e.dataset.k === 'unit_len') updateFeEstimate();
  if (e.dataset.k === 'level') S.volTarget = null;      // feste Schwelle statt Volumen
  if (e.dataset.k === 'allow_split' && S.res.optimize && !S.poll) { S.dirty = true; preview(true); }
  if (['unit_force'].includes(e.dataset.k)) renderConds();
  if (['unit_len', 'rho', 'mfg', 'mfg_dir'].includes(e.dataset.k)) updateSliderBounds();
}));

// ====================================================================== Material
function fillMaterials() {
  const sel = $('material'); sel.innerHTML = '';
  for (const k of Object.keys(S.info.materials)) sel.append(el('option', { textContent: k }));
  sel.append(el('option', { textContent: 'Custom' }));
  sel.onchange = () => {
    const m = S.info.materials[sel.value]; if (!m) return;
    setK({ E: m.E, nu: m.nu, rho: m.rho, yield_: m.yield_, E_z: m.E_z, S_z: m.S_z, S_zs: m.S_zs });
  };
  ['E', 'nu', 'rho', 'yield_', 'E_z', 'S_z', 'S_zs'].forEach(k => document.querySelector(`[data-k="${k}"]`).addEventListener('input', () => sel.value = 'Custom'));
  sel.value = 'Aluminium 6061-T6'; sel.onchange();
}

// ====================================================================== Laden
$('btnOpen').onclick = () => $('fileIn').click();
$('fileIn').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) await openFile(f); };
const vw = $('viewwrap');
vw.addEventListener('dragover', e => { e.preventDefault(); $('drop').classList.add('over'); });
vw.addEventListener('dragleave', () => $('drop').classList.remove('over'));
vw.addEventListener('drop', async e => {
  e.preventDefault(); $('drop').classList.remove('over');
  const f = e.dataTransfer.files[0]; if (!f) return;
  if (/\.(topo|json)$/i.test(f.name)) await loadProject(f); else await openFile(f);
});
async function openFile(f) { await loadBytes(await f.arrayBuffer(), f.name); }

async function loadBytes(buf, name, keep = false) {
  toast(`Loading ${name} …`);
  let r;
  try { r = await api('/api/load?name=' + encodeURIComponent(name), { method: 'POST', body: buf }); }
  catch (err) { toast(err.message, 'err'); logLine('ERROR: ' + err.message); throw err; }
  const m = r.meta;
  S.mesh = { ...m, pos: r.pos, fid: r.fid, diag: Math.hypot(...sub(m.hi, m.lo)) };
  S.fileBytes = buf; S.fileName = name;
  S.res = {}; S.checks = {}; liveReset();
  if (!keep) { S.conds = []; S.cases = [{ id: 1, name: 'Load case 1', weight: 1 }]; }
  clearSel();
  V.removePrefix('');
  V.setMesh('part', { positions: S.mesh.pos, color: [0.72, 0.75, 0.8], pickable: true, order: 0 });
  V.fit(m.lo, m.hi); V.view('iso');
  if (m.unit) { setK({ unit_len: m.unit }); }
  document.querySelector('[data-k="unit_len"]').disabled = !!m.unit;
  $('drop').style.display = 'none';
  for (const l of m.logs || []) logLine(l);
  const d = sub(m.hi, m.lo), u = getK().unit_len;
  $('partInfo').innerHTML = `<b>${name}</b> (${m.kind})<br>${d.map(x => x.toFixed(2)).join(' × ')} ${u} · ${fmtN(m.n)} triangles<br>` +
    `${m.n_faces} ${m.cad_faces ? 'CAD faces' : 'detected faces'} · ` +
    (m.watertight ? '<span class="good">closed</span>' : `<span class="warnc">open (${m.open_edges} edges)</span>`) +
    (m.components > 1 ? ` · ${m.components} bodies` : '') +
'';
  if (!m.watertight) { setK({ robust: true }); toast('The mesh is not closed – “Repair mesh” has been enabled.', 'warn'); }
  ['analyze', 'live', 'optimize'].forEach(k => $('dispWhat').querySelector(`[value=${k}]`).disabled = true);
  $('optRes').hidden = true;
  setMassDefault(); updateSliderBounds();
  renderCases(); renderConds(); redrawOverlays(); show('original'); updateFeEstimate();
  $('stats').innerHTML = `<div class="muted small">Mass of solid part: ${fmt(origMass())} g</div>`;
  toast(`${name} loaded.`, 'ok');
}
function setMassDefault() { const mg = origMass(); if (mg > 0) setK({ mass_g: +(mg * 0.3).toPrecision(3) }); }

// ====================================================================== Auswahl
V.onClick = async e => {
  if (!S.mesh || S.tab !== 'prep') return;
  const h = V.pick(e.clientX, e.clientY, 'part');
  if (!h) { if (!e.ctrlKey) clearSel(); return; }
  try {
    const K = getK();
    const r = await post('/api/pick', { tri: h.tri, mode: K.pick_mode, angle: K.pick_angle, smooth: K.pick_smooth });
    let tris = r.tris;
    if (e.ctrlKey || e.metaKey) { const s = new Set(S.sel); for (const t of tris) s.add(t); tris = [...s]; }
    setSel(tris);
  } catch (err) { toast(err.message, 'err'); }
};
document.addEventListener('keydown', e => { if (e.key === 'Escape') clearSel(); });
function triPos(tris) {
  const p = new Float32Array(tris.length * 9);
  tris.forEach((t, i) => p.set(S.mesh.pos.subarray(t * 9, t * 9 + 9), i * 9)); return p;
}
function geomOf(tris) {
  const p = S.mesh.pos; let A = 0; const c = [0, 0, 0], n = [0, 0, 0];
  for (const t of tris) {
    const o = t * 9, a = [p[o], p[o + 1], p[o + 2]], b = [p[o + 3], p[o + 4], p[o + 5]], cc = [p[o + 6], p[o + 7], p[o + 8]];
    const cr = cross(sub(b, a), sub(cc, a)), ar = 0.5 * Math.hypot(...cr);
    A += ar; for (let k = 0; k < 3; k++) { c[k] += ar * (a[k] + b[k] + cc[k]) / 3; n[k] += cr[k]; }
  }
  return { area: A, center: mul(c, 1 / Math.max(A, 1e-30)), normal: norm(n) };
}
async function setSel(tris) {
  S.sel = tris;
  if (!tris.length) return clearSel();
  V.setMesh('sel', { positions: triPos(tris), color: COL.sel, offset: 2, order: 5 });
  $('selInfo').classList.add('on');
  $('selInfo').textContent = `${tris.length} triangles selected …`;
  try {
    const fi = await post('/api/faceinfo', { tris });
    S.selInfo = fi;
    const u = getK().unit_len;
    let t = `${tris.length} triangles · area ${fmt(fi.area, 4)} ${u}²`;
    if (fi.cylinder) t += ` · cylinder r = ${fmt(fi.cylinder.radius, 4)} ${u}`;
    else if (fi.flatness > 0.999) t += ' · planar';
    $('selInfo').textContent = t;
  } catch (e) { $('selInfo').textContent = `${tris.length} triangles`; }
}
function clearSel() {
  S.sel = []; S.selInfo = null; V.remove('sel');
  $('selInfo').classList.remove('on'); $('selInfo').textContent = 'No selection.';
}

// ====================================================================== Lastfälle
function renderCases() {
  const L = $('caseList'); L.innerHTML = '';
  for (const c of S.cases) {
    L.append(el('div', { className: 'caserow' },
      el('input', { type: 'text', value: c.name, on: { input: e => { c.name = e.target.value; renderConds(); } } }),
      el('span', { className: 'muted small', textContent: 'Weight' }),
      el('input', { type: 'number', value: c.weight, step: 0.1, min: 0, on: { input: e => c.weight = parseFloat(e.target.value) || 0 } }),
      S.cases.length > 1 ? el('button', { className: 'small', textContent: '✕', title: 'Remove load case', on: { click: () => removeCase(c.id) } }) : null));
  }
}
$('addCase').onclick = () => {
  const id = Math.max(...S.cases.map(c => c.id)) + 1;
  S.cases.push({ id, name: 'Load case ' + id, weight: 1 }); renderCases(); renderConds();
};
function removeCase(id) {
  S.cases = S.cases.filter(c => c.id !== id);
  for (const c of S.conds) {
    if (c.case === id) c.case = isLoad(c) ? S.cases[0].id : 0;
  }
  renderCases(); renderConds();
}
const isLoad = c => c.type === 'load' || c.type === 'gravity';
const isSup = c => ['fixed', 'frictionless', 'pin'].includes(c.type);

// ====================================================================== Bedingungen
document.querySelectorAll('[data-add]').forEach(b => b.onclick = () => addCond(b.dataset.add));
function dirPerp(axis) {
  const a = axis.map(Math.abs); const k = a.indexOf(Math.min(...a));
  const up = getK().unit_len && V.up === 'z' ? 2 : 1;
  const cand = [up, k].find(i => a[i] < 0.5) ?? k; return 'xyz'[cand] + '-';
}
function addCond(kind) {
  if (!S.mesh) return toast('Please load a part first.', 'warn');
  const needSel = !['gravity', 'box_solid', 'box_void'].includes(kind);
  if (needSel && !S.sel.length) return toast('Please first click one or more faces in the 3D view.', 'warn');
  const info = S.selInfo, lc = S.cases[0].id;
  let c = { id: S.nextId++ };
  if (['fixed', 'frictionless', 'pin'].includes(kind)) {
    c = { ...c, type: kind, tris: S.sel, case: 0 };
    if (kind === 'fixed') c.dofs = [1, 1, 1];
    if (kind === 'pin') {
      if (!info?.cylinder) return toast('A pin support needs a cylindrical face (hole or shaft).', 'warn');
      Object.assign(c, { radial: 1, axial: 1, tangential: 0 });
    }
  } else if (LOADKINDS.includes(kind)) {
    c = { ...c, type: 'load', kind, tris: S.sel, case: lc, value: 100, dir: 'n_in' };
    if (kind === 'pressure') c.value = 1;
    if (kind === 'moment') { c.value = 10; c.dir = info?.cylinder ? 'face_axis' : 'n_out'; }
    if (kind === 'bearing') {
      if (!info?.cylinder) return toast('A bearing load needs a cylindrical face.', 'warn');
      c.dir = dirPerp(info.cylinder.axis);
    }
    if (kind === 'remote') {
      const g = geomOf(S.sel); c.point = add(g.center, mul(g.normal, S.mesh.diag * 0.25)).map(v => +v.toFixed(3));
      c.dir = V.up === 'z' ? 'z-' : 'y-';
    }
  } else if (kind === 'gravity') {
    c = { ...c, type: 'gravity', g: 1, dir: V.up === 'z' ? 'z-' : 'y-', case: lc };
  } else if (kind === 'box_solid' || kind === 'box_void') {
    const ce = mul(add(S.mesh.lo, S.mesh.hi), 0.5), sz = mul(sub(S.mesh.hi, S.mesh.lo), 0.15);
    c = { ...c, type: kind, min: sub(ce, sz).map(v => +v.toFixed(3)), max: add(ce, sz).map(v => +v.toFixed(3)) };
  } else {
    c = { ...c, type: kind, tris: S.sel, depth: 0 };
  }
  c.info = info;
  S.conds.push(c); clearSel(); renderConds(); redrawOverlays();
}
function condTitle(c) { return c.type === 'load' ? NAMES[c.kind] : NAMES[c.type]; }
function caseSelect(c, allowAll) {
  const s = el('select', { on: { change: e => { c.case = parseInt(e.target.value); } } });
  if (allowAll) s.append(el('option', { value: 0, textContent: 'all load cases' }));
  for (const k of S.cases) s.append(el('option', { value: k.id, textContent: k.name }));
  s.value = c.case; return s;
}
function numIn(v, f, step = 'any', w) { return el('input', { type: 'number', value: v, step, style: w ? `width:${w}px` : '', on: { input: e => { f(parseFloat(e.target.value)); } } }); }
function row(label, ...kids) { return el('div', { className: 'row' }, el('label', { textContent: label }), ...kids); }
function vecIn(arr, f) {
  return el('span', { className: 'vec' }, ...[0, 1, 2].map(i => numIn(arr[i], v => { arr[i] = isFinite(v) ? v : 0; f(); }, 'any', 56)));
}
function dirSelect(c, extra = []) {
  const s = el('select', { style: 'width:150px', on: { change: e => { c.dir = e.target.value; if (c.dir === 'custom' && !c.vec) c.vec = [0, 0, -1]; renderConds(); redrawOverlays(); } } });
  for (const [v, t] of [...DIRS, ...extra]) s.append(el('option', { value: v, textContent: t }));
  s.value = c.dir; return s;
}
function renderConds() {
  const L = $('condList'); L.innerHTML = ''; $('condCount').textContent = S.conds.length;
  const [uF, uM, uP] = units();
  for (const c of S.conds) {
    const col = itemColor(c);
    const card = el('div', { className: 'cond', style: `--c:${CSSC(col)}` });
    const n = c.tris ? ` · ${c.tris.length} rot.` : '';
    card.append(el('div', { className: 'h' }, el('span', {}, `${condTitle(c)} ${c.id}`, el('span', { className: 'muted small', textContent: n })),
      el('button', { className: 'small x', textContent: '✕', title: 'Remove', on: { click: () => { S.conds = S.conds.filter(x => x !== c); renderConds(); redrawOverlays(); } } })));
    const redraw = () => redrawOverlays();
    if (c.type === 'fixed') {
      card.append(row('Locked', el('span', { className: 'chk' }, ...['X', 'Y', 'Z'].map((a, k) => el('label', {},
        el('input', { type: 'checkbox', checked: !!c.dofs[k], on: { change: e => c.dofs[k] = e.target.checked ? 1 : 0 } }), ' ' + a)))));
    }
    if (c.type === 'pin') {
      card.append(row('Locked', el('span', { className: 'chk' }, ...[['radial', 'radial'], ['axial', 'axial'], ['tangential', 'Rotation']].map(([k, t]) =>
        el('label', {}, el('input', { type: 'checkbox', checked: !!c[k], on: { change: e => c[k] = e.target.checked ? 1 : 0 } }), ' ' + t)))));
      if (c.info?.cylinder) card.append(el('div', { className: 'muted small', textContent: `Cylinder r = ${fmt(c.info.cylinder.radius, 4)} ${getK().unit_len}` }));
    }
    if (isSup(c)) card.append(row('Applies to', caseSelect(c, true)));
    if (c.type === 'load') {
      const unit = c.kind === 'pressure' ? uP : c.kind === 'moment' ? uM : uF;
      card.append(row(`${c.kind === 'pressure' ? 'Pressure' : c.kind === 'moment' ? 'Moment' : 'Force'} [${unit}]`, numIn(c.value, v => c.value = v)));
      if (c.kind !== 'pressure') {
        const extra = c.kind === 'moment' ? [['face_axis', 'Axis of the face']] : [];
        card.append(row(c.kind === 'moment' ? 'Rotation axis' : 'Direction', dirSelect(c, extra)));
        if (c.dir === 'custom') card.append(row('Vector', vecIn(c.vec, redraw)));
      } else card.append(el('div', { className: 'muted small', textContent: 'acts perpendicular to the face (positive = inward)' }));
      if (c.kind === 'remote') card.append(row(`Point of application [${getK().unit_len}]`, vecIn(c.point, redraw)));
      card.append(row('Load case', caseSelect(c, false)));
    }
    if (c.type === 'gravity') {
      card.append(row('Acceleration [g]', numIn(c.g, v => c.g = v)));
      card.append(row('Direction', dirSelect(c)));
      if (c.dir === 'custom') card.append(row('Vector', vecIn(c.vec, redraw)));
      card.append(row('Load case', caseSelect(c, false)));
    }
    if (c.type === 'solid' || c.type === 'void') card.append(row('Depth [mm] (0 = thin)', numIn(c.depth, v => c.depth = v || 0, 0.5)));
    if (c.min) {
      card.append(row('Min X/Y/Z', vecIn(c.min, redraw)));
      card.append(row('Max X/Y/Z', vecIn(c.max, redraw)));
    }
    card.addEventListener('mouseenter', () => V.set('c' + c.id, { color: COL.sel }));
    card.addEventListener('mouseleave', () => V.set('c' + c.id, { color: itemColor(c) }));
    L.append(card);
  }
}

function loadDir(c, g) {
  if (c.dir === 'n_in') return mul(g.normal, -1);
  if (c.dir === 'n_out') return g.normal;
  if (c.dir === 'custom') return norm(c.vec || [0, 0, -1]);
  if (c.dir === 'face_axis') return c.info?.cylinder ? c.info.cylinder.axis : g.normal;
  const v = [0, 0, 0]; v['xyz'.indexOf(c.dir[0])] = c.dir[1] === '+' ? 1 : -1; return v;
}
function arrowMesh(tip, d, L, out) {
  // Schaft (Zylinder) + Spitze (Kegel) als Dreiecke
  d = norm(d); const n = 14, rs = L * 0.035, rh = L * 0.1, hl = L * 0.3;
  const p = Math.abs(d[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0], u = norm(cross(d, p)), w = cross(d, u);
  const base = sub(tip, mul(d, L)), neck = sub(tip, mul(d, hl));
  const ring = (c, r, a) => add(c, add(mul(u, r * Math.cos(a)), mul(w, r * Math.sin(a))));
  for (let i = 0; i < n; i++) {
    const a0 = i / n * 2 * Math.PI, a1 = (i + 1) / n * 2 * Math.PI;
    const b0 = ring(base, rs, a0), b1 = ring(base, rs, a1), t0 = ring(neck, rs, a0), t1 = ring(neck, rs, a1);
    out.push(...b0, ...b1, ...t1, ...b0, ...t1, ...t0);
    const h0 = ring(neck, rh, a0), h1 = ring(neck, rh, a1);
    out.push(...h0, ...h1, ...tip, ...neck, ...h1, ...h0, ...base, ...b1, ...b0);
  }
  return out;
}
function arrowLines(tip, d, L) {
  const base = sub(tip, mul(d, L)), h = L * 0.22;
  const p = Math.abs(d[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0], u = norm(cross(d, p)), w = cross(d, u);
  const pts = [...base, ...tip];
  for (const s of [u, w, mul(u, -1), mul(w, -1)]) pts.push(...tip, ...add(sub(tip, mul(d, h)), mul(s, h * 0.45)));
  return pts;
}
function redrawOverlays() {
  V.removePrefix('c'); V.removePrefix('a');
  if (!S.mesh) return;
  const on = $('showBC').checked, L = S.mesh.diag * 0.16;
  const faces = on && S.view === 'original';
  for (const c of S.conds) {
    const col = itemColor(c);
    if (c.tris) V.setMesh('c' + c.id, { positions: triPos(c.tris), color: col, offset: 1, order: 3, visible: faces, opacity: 0.92 });
    if (c.type === 'load') {
      const g = geomOf(c.tris); const d = loadDir(c, g);
      let pts;
      if (c.kind === 'moment') {
        const ax = norm(d), p = Math.abs(ax[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0], u = norm(cross(ax, p)), w = cross(ax, u), r = L * 0.45;
        pts = [];
        for (let i = 0; i < 28; i++) {
          const a0 = i / 32 * 2 * Math.PI, a1 = (i + 1) / 32 * 2 * Math.PI;
          pts.push(...add(g.center, add(mul(u, r * Math.cos(a0)), mul(w, r * Math.sin(a0)))), ...add(g.center, add(mul(u, r * Math.cos(a1)), mul(w, r * Math.sin(a1)))));
        }
        const a = 28 / 32 * 2 * Math.PI, tip = add(g.center, add(mul(u, r * Math.cos(a)), mul(w, r * Math.sin(a))));
        const tdir = norm(add(mul(u, -Math.sin(a)), mul(w, Math.cos(a))));
        pts.push(...arrowLines(tip, tdir, L * 0.25).slice(6));
        pts.push(...sub(g.center, mul(ax, L * 0.5)), ...add(g.center, mul(ax, L * 0.5)));
      } else if (c.kind === 'remote') {
        pts = [...c.point, ...g.center, ...arrowLines(c.point, d, L)];
      } else if (c.kind === 'pressure') {
        pts = arrowLines(g.center, mul(g.normal, -1), L);
      } else pts = arrowLines(g.center, d, L);
      const am = [];
      if (c.kind === 'moment') {
        V.setLines('a' + c.id, pts, col, { order: 6, visible: on, depthTest: false });
        arrowMesh(add(g.center, mul(norm(d), L * 0.75)), d, L * 0.5, am);
      } else if (c.kind === 'remote') {
        V.setLines('a' + c.id, [...c.point, ...g.center], col, { order: 6, visible: on, depthTest: false });
        arrowMesh(c.point, d, L, am);
      } else if (c.kind === 'pressure') {
        for (const f of [0, 1, 2, 3, 4]) {
          const k = f === 0 ? [0, 0] : [[1, 0], [-1, 0], [0, 1], [0, -1]][f - 1];
          const nn = g.normal, pp = Math.abs(nn[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0], uu = norm(cross(nn, pp)), ww = cross(nn, uu);
          const r = Math.sqrt(g.area) * 0.3;
          arrowMesh(add(g.center, add(mul(uu, k[0] * r), mul(ww, k[1] * r))), mul(nn, -1), L * 0.6, am);
        }
      } else arrowMesh(g.center, d, L, am);
      V.setMesh('am' + c.id, { positions: new Float32Array(am), color: col, order: 7, visible: on, depthTest: false });
    }
    if (c.type === 'gravity') {
      const ce = mul(add(S.mesh.lo, S.mesh.hi), 0.5);
      const d = c.dir === 'custom' ? norm(c.vec || [0, 0, -1]) : loadDir(c, { normal: [0, 0, 1] });
      V.setMesh('am' + c.id, { positions: new Float32Array(arrowMesh(add(ce, mul(d, L * 0.6)), d, L * 1.3, [])),
        color: col, order: 7, visible: on, depthTest: false });
    }
    if (c.type === 'pin' && c.info?.cylinder) {
      const cy = c.info.cylinder, g = geomOf(c.tris);
      const t = dot(sub(g.center, cy.point), cy.axis), p0 = add(cy.point, mul(cy.axis, t));
      V.setLines('a' + c.id, [...sub(p0, mul(cy.axis, L)), ...add(p0, mul(cy.axis, L))], col, { order: 6, visible: on, depthTest: false });
    }
    if (c.min) {
      const a = c.min, b = c.max, P = [];
      const v = [[a[0], a[1], a[2]], [b[0], a[1], a[2]], [b[0], b[1], a[2]], [a[0], b[1], a[2]], [a[0], a[1], b[2]], [b[0], a[1], b[2]], [b[0], b[1], b[2]], [a[0], b[1], b[2]]];
      for (const [i, j] of [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]]) P.push(...v[i], ...v[j]);
      V.setLines('c' + c.id, P, col, { order: 6, visible: faces });
    }
  }
}
$('showBC').onchange = () => redrawOverlays();

// ====================================================================== Schnittansicht
function updateClip() {
  const on = $('clipOn').checked && !!S.mesh;
  document.querySelectorAll('.clip-only').forEach(e => e.style.display = on ? '' : 'none');
  if (!on) { V.clip = null; V.redraw(); if ($('dispMode').value === 'infill') applyColors(); return; }
  const a = +$('clipAxis').value, t = +$('clipPos').value / 1000, flip = $('clipFlip').checked;
  const pos = S.mesh.lo[a] + (S.mesh.hi[a] - S.mesh.lo[a]) * t, n = [0, 0, 0]; n[a] = flip ? -1 : 1;
  V.clip = new Float32Array([...n, flip ? -pos : pos]); V.redraw();
  if ($('dispMode').value === 'infill') applyColors();
}
['clipOn', 'clipAxis', 'clipFlip'].forEach(id => $(id).onchange = updateClip);
$('clipPos').oninput = updateClip;
updateClip();

function condsForServer() {
  return S.conds.map(c => {
    const o = {};
    for (const k of ['type', 'tris', 'dofs', 'case', 'radial', 'axial', 'tangential', 'kind', 'value', 'dir', 'vec', 'point', 'g', 'depth', 'min', 'max'])
      if (c[k] !== undefined) o[k] = c[k];
    return o;
  });
}

// ====================================================================== Einstellungen
function engineSettings(kind) {
  const K = getK();
  let vf = K.volfrac_pct / 100;
  if (K.target_mode === 'mass') { const m0 = origMass(); vf = m0 > 0 ? K.mass_g / m0 : 0.3; }
  vf = Math.min(0.95, Math.max(0.03, vf));
  const w = {}; for (const c of S.cases) w[c.id] = c.weight;
  return { unit_len: K.unit_len, unit_force: K.unit_force, E: K.E, nu: K.nu, rho: K.rho, yield_: K.yield_,
    resolution: kind === 'analyze' ? K.an_resolution : K.resolution, volfrac: vf, minwall_mm: K.minwall_mm || 0,
    max_iter: K.max_iter, sym: [K.sym_x, K.sym_y, K.sym_z], mfg: K.mfg, mfg_dir: K.mfg_dir, overhang: parseInt(K.overhang),
    cnc_setups: parseInt(K.cnc_setups) || 1, cnc_tool_mm: K.cnc_tool_mm || 0, cnc_depth_mm: K.cnc_depth_mm || 0,
    extrude: K.extrude, keep_bc: K.keep_bc, bc_layers: 1, robust: K.robust, case_weights: w,
    sigma: K.sigma ?? 0.7, level: K.level || 0, solver: K.solver,
    keep_holes: [], bc_wall_mm: K.bc_wall_mm ?? 2, refine: K.refine, detail_mm: K.detail_mm || 0, allow_split: !!K.allow_split,
    E_z: K.E_z || K.E, S_z: K.S_z || K.yield_, S_zs: K.S_zs || K.S_z || K.yield_, layer_opt: !!K.layer_opt,
    shell_top_mm: K.shell_top_mm ?? 0.8, shell_bottom_mm: K.shell_bottom_mm ?? 0.8, shell_wall_mm: K.shell_wall_mm ?? 1.2,
    infill_pct: K.infill_pct ?? 20, infill_pattern: K.infill_pattern || 'grid',
    mass_mode: K.target_mode === 'mass' && K.mfg === 'am_adv',
    prism_levels: K.prism_levels || 4, prism_step_mm: K.prism_step_mm || 0,
    prism_sides: PRISM_SIDES.filter(([k]) => K[k]).map(([, s]) => s), safety_target: Math.max(0, K.safety_target || 0) };
}
// ====================================================================== Aufträge
$('btnAnalyze').onclick = () => startJob('analyze');
$('btnOpt').onclick = () => startJob('optimize');
// Stopp: Optimierung → erster Klick beendet die Iterationen (Ergebnis aus dem letzten Stand),
// zweiter Klick bricht auch das Erzeugen des Ergebnisnetzes ab. Andere Aufträge: sofort abbrechen.
async function stopJob() {
  const second = S.stopping;
  S.stopping = true;
  $('btnStop').disabled = S.jobKind !== 'optimize' || second;
  $('jbStop').disabled = S.jobKind !== 'optimize' ? true : second;
  if (S.jobKind === 'optimize' && !second) $('jbStop').textContent = 'Cancel completely';
  $('progTxt').textContent = second || S.jobKind !== 'optimize' ? 'Cancelling …' : 'Stopping …';
  try { await post('/api/stop', {}); } catch (err) { toast(err.message, 'err'); }
}
$('btnStop').onclick = stopJob;
$('jbStop').onclick = stopJob;
async function startJob(kind) {
  if (!S.mesh) return toast('Please load a part first.', 'warn');
  if (!S.conds.some(isSup)) return toast('Please define at least one support (tab “Prepare”).', 'warn');
  if (!S.conds.some(isLoad)) return toast('Please define at least one load (tab “Prepare”).', 'warn');
  const settings = engineSettings(kind);
  try { await post('/api/job', { kind, settings, conditions: condsForServer() }); }
  catch (err) { return toast(err.message, 'err'); }
  S.jobKind = kind; S.stopping = false; S.logN = 0; S.frameId = 0; $('log').innerHTML = '';
  jobBar(kind, null);
  setBusy(true);
  if (kind === 'optimize') { $('dispWhat').querySelector('[value=live]').disabled = false; show('live'); }
  S.poll = setInterval(poll, 450);
}
function setBusy(b) {
  for (const id of ['btnAnalyze', 'btnOpt', 'btnRemesh', 'btnOpen', 'btnProjOpen', 'volSlider', 'itSlider']) $(id).disabled = b;
  $('btnStop').disabled = !b || S.jobKind !== 'optimize' || S.stopping;
  $('jbStop').disabled = !b; $('jbStop').textContent = S.jobKind === 'optimize' ? 'Stop' : 'Cancel';
}
async function poll() {
  if (S.polling) return;                 // vorige Abfrage läuft noch (z. B. Ergebnis wird geladen)
  S.polling = true;
  try { await pollOnce(); } finally { S.polling = false; }
}
async function pollOnce() {
  let st; try { st = await api('/api/status?log_from=' + S.logN); } catch (e) { return; }
  if (!st || st.state === 'idle') return;
  for (const l of st.logs) logLine(l);
  S.logN = st.log_n;
  const bar = $('progBar');
  bar.style.width = Math.round((st.progress || 0) * 100) + '%';
  jobBar(st.kind, st);
  if (st.kind === 'optimize' || st.kind === 'remesh' || st.kind === 'analyze') {
    const rest = st.state === 'running' && st.eta != null ? ` · approx. ${fmtDur(st.eta)}` : '';
    $('progTxt').textContent = `${st.phase || ''}${st.detail ? ' – ' + st.detail : ''} · ${Math.round((st.progress || 0) * 100)} %${rest}`;
  }
  if (st.kind === 'optimize') {
    drawPlot(st.hist);
    if (S.stopping) $('progTxt').textContent = `Stopped – evaluating result … · ${fmtDur(st.elapsed)}`;
    else if (st.info?.it) $('progTxt').textContent = `Iteration ${st.info.it} · volume ${(st.info.vol * 100).toFixed(0)} % · change ${fmt(st.info.change, 2)} · approx. ${fmtDur(st.eta)}`;
    if (st.frame_id > S.frameId && !S.frameBusy && S.view === 'live') {
      S.frameBusy = true;
      try {
        const f = await api('/api/frame');
        if (f) { S.frameId = f.meta.id; V.setMesh('live', { positions: f.verts, indices: f.faces, color: [0.95, 0.6, 0.25], order: 1 }); }
      } catch (e) {} S.frameBusy = false;
    }
  }
  if (st.state === 'done' || st.state === 'error' || st.state === 'cancelled') {
    clearInterval(S.poll); S.poll = null; S.stopping = false; setBusy(false); $('jobBar').hidden = true; $('loadBox').hidden = true;
    if (st.kind === 'remesh' && S.remeshWait) { const w = S.remeshWait; S.remeshWait = null; setTimeout(() => w(st.state), 0); }
    if (st.kind === 'remesh' && st.state === 'done') S.dirty = false;
    if (st.kind === 'optimize') S.dirty = false;
    bar.style.width = '0%';
    if (st.state === 'cancelled') {
      toast('Cancelled.', 'warn'); $('progTxt').textContent = 'Cancelled.';
      if (st.kind === 'optimize') { V.remove('live'); if (!S.res.optimize) show('original'); else show('optimize'); }
      if (st.kind === 'remesh' && S.res.optimize) preview();   // Vorschau der Reglerstellung bleibt

      return;
    }
    if (st.state === 'error') { toast(st.error, 'err'); if (st.kind === 'optimize' || st.kind === 'remesh') show(S.res.optimize ? 'optimize' : 'original'); return; }
    $('progTxt').textContent = 'Loading result …';
    try { await fetchResult(st.kind === 'remesh' ? 'optimize' : st.kind); }
    catch (err) {
      $('progTxt').textContent = 'The result could not be displayed.';
      logLine('ERROR: The result could not be displayed – ' + err.message);
      toast('The result could not be displayed: ' + err.message, 'err');
      return;
    }
    if (st.kind !== 'remesh') updateFeEstimate();       // Zeitschätzung hat dazugelernt
    $('progTxt').textContent = `Finished after ${fmtDur(st.elapsed)}.`;
    toast(st.stopped ? 'Stopped – result from the last state.' : { analyze: 'Analysis finished.', optimize: 'Optimization finished.', remesh: 'Result updated.' }[st.kind], 'ok');
  }
}
async function fetchResult(kind) {
  const r = await api('/api/result?what=' + kind);
  S.res[kind] = r; delete S.checks[kind];
  $('dispWhat').querySelector(`[value=${kind}]`).disabled = false;
  if (kind === 'optimize') {
    const m = r.meta;
    $('optRes').hidden = false; $('itSlider').max = m.n_it; $('itSlider').value = m.it + 1; $('itVal').textContent = m.it + 1;
    if (m.vol_ratio) { $('volSlider').value = Math.round(m.vol_ratio * 100); $('volVal').textContent = Math.round(m.vol_ratio * 100); }
    $('volInfo').textContent = `${fmt(m.mass_g)} g · ${((1 - (m.vol_ratio || 0)) * 100).toFixed(0)} % lighter than the solid part`
      + (m.print_mass_g != null ? ` · print mass ≈ ${fmt(m.print_mass_g)} g` : '');
    S.previewing = false;
    liveReset(); liveField(m.it);
    setK({ level: +m.level.toFixed(2) });
    drawPlot(m.hist, m.it);
    V.remove('live');
  }
  if (r.meta.warning) toast(r.meta.warning, 'warn');
  if (kind === 'optimize' && r.ovh) {
    // Überhangprüfung des Rechenkerns: Darstellung „Druckprüfung“ sofort nutzbar
    S.checks.optimize = r.ovh; delete S.checks._optimize;
    if (r.meta.ovh_txt) toast(`Overhang: ${r.meta.ovh_txt} flatter than ${r.meta.ovh_deg}° – not printable without supports (see log, display “Print check”).`, 'warn');
  }
  fillCases(r.meta);
  show(kind);
  updateExportFormats();
}

// ====================================================================== Anzeige
$('dispWhat').onchange = () => show($('dispWhat').value);
['dispMode', 'dispCase'].forEach(id => $(id).onchange = () => { $('sclAuto').checked = true; applyColors(); });
$('sclMax').oninput = () => { $('sclAuto').checked = false; applyColors(); };
$('sclAuto').onchange = () => applyColors();
$('ghost').onchange = () => show(S.view);
$('defScale').oninput = () => { stopAnim(); V.dispScale = parseFloat($('defScale').value) || 0; V.redraw(); };
$('btnAnim').onclick = () => {
  if (S.anim) return stopAnim();
  const f = parseFloat($('defScale').value) || autoDefScale(); $('defScale').value = +f.toPrecision(3);
  const t0 = performance.now();
  S.anim = setInterval(() => { V.dispScale = f * (0.5 - 0.5 * Math.cos((performance.now() - t0) / 400)); V.redraw(); }, 30);
  $('btnAnim').textContent = '■';
};
function stopAnim() { if (S.anim) clearInterval(S.anim); S.anim = null; $('btnAnim').textContent = '▶'; V.dispScale = parseFloat($('defScale').value) || 0; V.redraw(); }
function autoDefScale() {
  const r = S.res[S.view]; if (!r?.meta?.umax) return 0;
  return 0.06 * S.mesh.diag * unitScale() / r.meta.umax;
}
function fillCases(meta) {
  const s = $('dispCase'), cur = s.value; s.innerHTML = '';
  s.append(el('option', { value: 'env', textContent: 'Envelope (maximum)' }));
  (meta.case_ids || []).forEach((id, k) => s.append(el('option', { value: k, textContent: S.cases.find(c => c.id === id)?.name || 'Load case ' + id })));
  if ([...s.options].some(o => o.value === cur)) s.value = cur;
}

function show(view) {
  S.view = view; $('dispWhat').value = view; stopAnim();
  const ghost = $('ghost').checked;
  const part = V.get('part');
  V.remove('res');
  if (view !== 'live') V.remove('live');
  const hasFEA = view === 'analyze' || view === 'optimize';
  document.querySelectorAll('.res-only').forEach(e => e.style.display = (view === 'original' || view === 'live') ? 'none' : '');
  const dm = $('dispMode'), rv = S.res[view];
  for (const o of dm.options) {
    o.disabled = !hasFEA && ['stress', 'disp', 'safety', 'layer', 'infill'].includes(o.value);
    if (o.value === 'layer') { o.disabled = !(hasFEA && rv?.lay); o.hidden = !(rv?.lay); }
    if (o.value === 'infill') { o.disabled = !(view === 'optimize' && rv?.inf_v); o.hidden = !(rv?.inf_v); }
  }
  if (dm.selectedOptions[0]?.disabled) dm.value = 'shape';
  if (view === 'analyze' && dm.value === 'shape') dm.value = 'stress';
  if (part) {
    if (view === 'original' || view === 'analyze') V.set('part', { visible: view === 'original', alpha: 1, order: 0 });
    else V.set('part', { visible: ghost, alpha: 0.13, order: 9 });
  }
  V.remove('infill'); V.remove('core');
  if (view === 'analyze') {
    V.setMesh('res', { positions: S.mesh.pos, color: LIME, order: 1 });
  } else if (view === 'optimize') {
    const r = S.res[view];
    V.setMesh('res', { positions: r.verts, indices: r.faces, color: LIME, order: 1 });
  }
  if (view === 'original' && dm.value === 'check' && !S.checks.original) dm.value = 'shape';
  applyColors(); updateStats(); redrawOverlays();
}
function scalarsFor(view, mode) {
  const r = S.res[view]; if (!r) return null;
  const m = r.meta, nc = (m.case_ids || []).length || 1, cs = $('dispCase').value, nv = r.env.length;
  const out = new Float32Array(nv);
  if (mode === 'stress' || mode === 'safety') {
    if (cs === 'env') out.set(r.env); else { const k = +cs; for (let i = 0; i < nv; i++) out[i] = r.stress[i * nc + k]; }
    if (mode === 'safety') for (let i = 0; i < nv; i++) out[i] = out[i] > 0 ? Math.min(m.yield_ / out[i], 100) : 100;
  } else if (mode === 'layer') {
    if (!r.lay) return null;
    if (cs === 'env') out.set(r.lay_env); else { const k = +cs; for (let i = 0; i < nv; i++) out[i] = r.lay[i * nc + k]; }
    for (let i = 0; i < nv; i++) out[i] = out[i] > 0 ? Math.min(1 / out[i], 100) : 100;
  } else if (mode === 'disp') {
    for (let k = 0; k < nc; k++) {
      if (cs !== 'env' && +cs !== k) continue;
      const o = k * nv * 3;
      for (let i = 0; i < nv; i++) { const u = Math.hypot(r.disp[o + 3 * i], r.disp[o + 3 * i + 1], r.disp[o + 3 * i + 2]); if (u > out[i]) out[i] = u; }
    }
  }
  return out;
}
function percentile(a, p) {
  const n = a.length; if (!n) return 0; const step = Math.max(1, Math.floor(n / 20000)), s = [];
  for (let i = 0; i < n; i += step) s.push(a[i]); s.sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p * s.length))];
}
function applyColors() {
  const view = S.view, mode = $('dispMode').value, id = view === 'original' ? 'part' : view === 'live' ? 'live' : 'res';
  const lg = $('legend'); lg.hidden = true;
  if (!V.get(id)) return;
  if (id === 'res') {
    if (mode === 'infill' && S.res[view]?.inf_v) {
      // Form + Wände & Infill: ohne Schnitt Form halbdurchsichtig mit Infill darin, mit Schnitt gefüllte
      // Schnittflächen wie im Slicer (Wände gelbgrün, Infill-Bereich hell, Infill-Muster orange)
      const r = S.res[view], cut = !!V.clip;
      V.setFlat('res'); V.set('res', { alpha: cut ? 1 : 0.25, order: cut ? 1 : 8, cap: [0.70, 0.82, 0.05] }); setDeform(null);
      if (!V.get('infill')) V.setMesh('infill', { positions: r.inf_v, indices: r.inf_f, color: INF_COL, order: 3, cap: [0.93, 0.47, 0.06] });
      if (r.core_v && !V.get('core')) V.setMesh('core', { positions: r.core_v, indices: r.core_f, color: CORE_COL, order: 2, capOnly: true, cap: CORE_COL });
      lg.hidden = false; $('legTitle').textContent = 'Walls & infill';
      drawLegend(null, cut ? ['Walls (section)', 'Infill region', 'Infill pattern'] : ['Shape (transparent)', 'Infill (schematic)'],
        cut ? [[0.70, 0.82, 0.05], CORE_COL, INF_COL] : [LIME, INF_COL]);
      return;
    }
    V.remove('infill'); V.remove('core'); V.set('res', { alpha: 1, order: 1, cap: null });
  }
  if (mode === 'check') {
    const f = S.checks[view === 'analyze' ? 'original' : view];
    if (!f) { V.setFlat(id); toast('Please run the print check in the “Export” tab.', 'warn'); return; }
    const c = new Float32Array(f.length * 3), P = [[0.62, 0.66, 0.72], [0.98, 0.55, 0.1], [0.9, 0.12, 0.15], [0.8, 0.2, 0.75]];
    for (let i = 0; i < f.length; i++) c.set(P[f[i] & 3], i * 3);
    V.setColors(id, c);
    lg.hidden = false; $('legTitle').textContent = 'Print check';
    drawLegend(null, ['Overhang', 'thin wall', 'beides'], [P[1], P[2], P[3]]);
    return;
  }
  const s = (mode === 'shape') ? null : scalarsFor(view, mode);
  if (!s) { V.setFlat(id); setDeform(null); return; }
  const r = S.res[view];
  let mx;
  if ($('sclAuto').checked) {
    mx = (mode === 'safety' || mode === 'layer') ? 5 : percentile(s, 0.995) || 1;
    $('sclMax').value = +mx.toPrecision(3);
  } else mx = parseFloat($('sclMax').value) || 1;
  const rev = mode === 'safety' || mode === 'layer';
  V.setScalars(id, s, 0, mx, rev);
  lg.hidden = false;
  $('legTitle').textContent = { stress: 'Stress [MPa]', disp: `Displacement [mm]`, safety: 'Safety factor', layer: 'Layer-adhesion safety' }[mode];
  drawLegend([0, mx], null, null, rev);
  setDeform(r);
}
function setDeform(r) {
  if (!r || !r.disp) return;
  const id = 'res', nc = (r.meta.case_ids || []).length || 1, nv = r.env.length, cs = $('dispCase').value;
  let k = cs === 'env' ? 0 : +cs;
  if (cs === 'env') { let best = -1; r.meta.cases.forEach((c, i) => { if (c.umax > best) { best = c.umax; k = i; } }); }
  const d = r.disp.subarray(k * nv * 3, (k + 1) * nv * 3), sc = 1 / unitScale(), out = new Float32Array(d.length);
  for (let i = 0; i < d.length; i++) out[i] = d[i] * sc;
  V.setDisp(id, out); V.dispScale = parseFloat($('defScale').value) || 0;
}
function drawLegend(range, labels, colors, rev) {
  const cv = $('legCv'), x = cv.getContext('2d'), L = $('legLbl'); L.innerHTML = '';
  x.clearRect(0, 0, cv.width, cv.height);
  if (range) {
    const cm = t => { const c = [[0.18, 0.30, 0.78], [0.10, 0.72, 0.90], [0.30, 0.80, 0.35], [0.98, 0.85, 0.20], [0.88, 0.18, 0.15]];
      t = Math.max(0, Math.min(1, t)); const s = Math.min(3, Math.floor(t * 4)), f = t * 4 - s;
      return c[s].map((v, i) => v + (c[s + 1][i] - v) * f); };
    for (let y = 0; y < cv.height; y++) {
      let t = 1 - y / (cv.height - 1); if (rev) t = 1 - t;
      x.fillStyle = CSSC(cm(t)); x.fillRect(0, y, cv.width, 1);
    }
    for (let i = 4; i >= 0; i--) L.append(el('div', { textContent: fmt(range[0] + (range[1] - range[0]) * i / 4, 3) }));
  } else {
    const n = colors.length, gap = n > 1 ? (cv.height - 40) / (n - 1) : 0;
    colors.forEach((c, i) => { x.fillStyle = CSSC(c); x.fillRect(0, i * gap, cv.width, 40); L.append(el('div', { textContent: labels[i] })); });
  }
}

// ====================================================================== Statistik & Diagramm
function updateStats() {
  const v = S.view, r = S.res[v], st = $('stats');
  if (!r) { st.innerHTML = S.mesh ? `<div class="muted small">Mass of solid part: ${fmt(origMass())} g · volume ${fmt(S.mesh.volume * unitScale() ** 3)} mm³</div>` : ''; return; }
  const m = r.meta; let h = '<table>';
  const sft = Math.max(0, getK().safety_target || 0);        // Vorgabe aus Reiter 1
  const sf = m.safety, sfc = sf == null ? '' : sf < Math.max(1, sft) ? 'badc' : (!sft && sf < 1.5) ? 'warnc' : 'good';
  if (v === 'analyze' || v === 'optimize') {
    if (v === 'optimize') {
      h += `<tr><td>Mass</td><td>${fmt(m.mass_g)} g (before ${fmt(m.orig_mass_g)} g)</td></tr>`;
      h += `<tr><td>Weight saving</td><td>${((1 - m.vol_ratio) * 100).toFixed(0)} %</td></tr>`;
    } else h += `<tr><td>Mass</td><td>${fmt(m.mass_g)} g</td></tr>`;
    h += `<tr><td>Max. displacement</td><td>${fmt(m.umax)} mm</td></tr>`;
    h += `<tr><td>Max. stress (von Mises)</td><td>${fmt(m.vm_max)} MPa</td></tr>`;
    h += `<tr><td>Min. safety factor</td><td class="${sfc}">${sf == null ? '–' : sf.toFixed(2)}${sft ? ` (required ${sft})` : ''}</td></tr>`;
    if (m.layer) {
      const ls = m.layer_safety, lsc = ls == null ? '' : ls < 1 ? 'badc' : ls < 1.5 ? 'warnc' : 'good';
      h += `<tr><td>Min. layer-adhesion safety</td><td class="${lsc}">${ls == null ? '–' : ls.toFixed(2)}</td></tr>`;
    }
    if (m.print_mass_g != null) {
      h += `<tr><td>Print mass (walls + infill)</td><td>${fmt(m.print_mass_g)} g${m.orig_print_mass_g ? ` (full part printed ${fmt(m.orig_print_mass_g)} g)` : ''}</td></tr>`;
      if (m.v_shell != null) h += `<tr><td class="muted">Shells / infill region</td><td class="muted">${fmt(m.v_shell / 1000)} cm³ / ${fmt(m.v_core / 1000)} cm³</td></tr>`;
    }
    if (m.ovh_txt) h += `<tr><td class="warnc">Overhang (without supports)</td><td class="warnc">${m.ovh_txt}</td></tr>`;
    if (m.levels) h += `<tr><td>Depth levels</td><td>${m.levels.map(z => z.toFixed(1)).join(' / ')} mm</td></tr>`;
    if (m.prism_axes) for (const A of m.prism_axes) h += `<tr><td>Depth levels ${A.axis}</td><td>${A.levels.map(z => z.toFixed(1)).join(' / ')} mm</td></tr>`;
    if (m.cases.length > 1) for (const c of m.cases)
      h += `<tr><td class="muted">${S.cases.find(k => k.id === c.case)?.name || 'LC ' + c.case}</td><td class="muted">σ ${fmt(c.vm_max)} MPa · u ${fmt(c.umax)} mm</td></tr>`;
    h += '</table>';
    if (m.warning) h += `<div class="warnc">⚠ ${m.warning}</div>`;
    h += `<div class="muted small">Voxel FEM, linear elastic: guide values, stress peaks at edges are overestimated. Solver: ${m.solver || '–'}</div>`;
  }
  const ck = S.checks['_' + (v === 'analyze' ? 'original' : v)];
  if (ck) h += `<div class="small">Check: overhang ${ck.overhang_area_pct.toFixed(1)} % of the surface · thin walls ${ck.thin_pct.toFixed(1)} % of the points</div>`;
  st.innerHTML = h;
}
function drawPlot(hist, mark) {
  const cv = $('plot'), w = cv.clientWidth, ht = cv.clientHeight, dpr = devicePixelRatio || 1;
  cv.width = w * dpr; cv.height = ht * dpr; const x = cv.getContext('2d'); x.scale(dpr, dpr); x.clearRect(0, 0, w, ht);
  x.strokeStyle = '#3a4150'; x.strokeRect(44.5, 4.5, w - 50, ht - 22);
  if (!hist || hist.length < 2) return;
  const mx = Math.max(...hist), mn = Math.min(...hist), rg = (mx - mn) || 1;
  const X = i => 45 + (w - 51) * i / (hist.length - 1), Y = v => 5 + (ht - 24) * (1 - (v - mn) / rg);
  x.strokeStyle = '#D3F300'; x.lineWidth = 1.6; x.beginPath();
  hist.forEach((v, i) => i ? x.lineTo(X(i), Y(v)) : x.moveTo(X(i), Y(v))); x.stroke();
  if (mark !== undefined && mark !== null) { x.fillStyle = '#ffd43b'; x.beginPath(); x.arc(X(mark), Y(hist[mark]), 4, 0, 7); x.fill(); }
  x.fillStyle = '#9aa3b4'; x.font = '10px sans-serif';
  x.fillText(fmt(mx), 2, 12); x.fillText(fmt(mn), 2, ht - 18); x.fillText('Iteration 1 … ' + hist.length, 48, ht - 4);
}

// ====================================================================== Iterationsverlauf
function remeshParams() {
  const K = getK(), it = parseInt($('itSlider').value) - 1;
  const p = { it, level: K.level || 0, sigma: K.sigma ?? 0.7, refine: K.refine, detail_mm: K.detail_mm || 0, allow_split: !!K.allow_split };
  if (S.volTarget && !K.level) p.vol = S.volTarget;      // gewünschtes Endvolumen (Anteil)
  return p;
}
// Fertiges Netz (Feinnetz + Analyse) als Auftrag mit Fortschrittsanzeige
async function remesh() {
  if (!S.res.optimize) return null;
  if (S.poll) { toast('Please wait until the running computation has finished.', 'warn'); return null; }
  // sofort sichtbar reagieren – eine noch laufende Vorschau (bei großen Bauteilen einige Sekunden) wird abgewartet
  setBusy(true); $('volInfo').textContent = 'Regenerating the result …';
  LIVE.stamp++; PV.again = false;                                  // offene Vorschau-Antworten verwerfen
  while (PV.busy) await new Promise(r => setTimeout(r, 30));
  try { await post('/api/remesh', remeshParams()); } catch (e) { setBusy(false); toast(e.message, 'err'); return null; }
  const done = new Promise(r => { S.remeshWait = r; });
  S.jobKind = 'remesh'; S.stopping = false; S.logN = 0;
  $('progTxt').textContent = 'Starting …';
  jobBar('remesh', null); setBusy(true);
  S.poll = setInterval(poll, 400);
  return done;
}
// Schnelle Grobvorschau beim Ziehen (Volumen oder Iteration)
const PV = { busy: false, again: false, seq: 0 };
// final = true (beim Loslassen): wie das fertige Ergebnis bereinigt (lose Teile und unbelastete
// Stummel entfernt) – dauert etwas länger, zeigt dafür genau die Form, die später entsteht.
async function preview(final = false) {
  if (!S.res.optimize || S.poll) return;
  if (PV.busy) { PV.again = true; PV.final = PV.final || final; return; }
  PV.busy = true; PV.again = false; PV.final = false;
  const stamp = LIVE.stamp;
  if (final) $('volInfo').textContent = liveText() + ' – being cleaned up …';
  try {
    const r = await post('/api/preview', { ...remeshParams(), seq: ++PV.seq, prune: final });
    // inzwischen weitergezogen: die Live-Vorschau ist neuer als diese Antwort
    if (stamp !== LIVE.stamp) { PV.busy = false; if (PV.again) preview(PV.final); return; }
    if (!S.previewing) { $('dispMode').value = 'shape'; S.previewing = true; }
    if (S.view !== 'optimize') show('optimize');
    V.remove('infill'); V.remove('core');
    V.setMesh('res', { positions: r.verts, indices: r.faces, color: LIME, order: 1 });
    V.setFlat('res'); $('legend').hidden = true;
    let txt = `≈ ${fmt(r.meta.mass_g)} g` + (r.meta.print_mass_g != null ? ` (print mass ≈ ${fmt(r.meta.print_mass_g)} g)` : '')
      + ` · ${((1 - (r.meta.vol_ratio || 0)) * 100).toFixed(0)} % lighter (preview – fine mesh and stresses via “Regenerate mesh & analyze”, automatically before export)`;
    if (final && S.volTarget && r.meta.vol_ratio && S.volTarget - r.meta.vol_ratio > 0.03)
      txt += ` · More volume only adds loose or unloaded parts for this result – load-bearing ≈ ${Math.round(r.meta.vol_ratio * 100)} %.`;
    if (final && S.volTarget && r.meta.vol_ratio && r.meta.vol_ratio - S.volTarget > 0.03)
      txt += ` · With less volume supports and loads would no longer be connected – the smallest connected part has ≈ ${Math.round(r.meta.vol_ratio * 100)} %.`;
    $('volInfo').textContent = txt;
  } catch (e) { if (!/läuft/.test(e.message)) toast(e.message, 'err'); }
  PV.busy = false;
  if (PV.again) preview(PV.final);
}
// Regler: zeigen live, wie das Bauteil mit mehr oder weniger Volumen wächst – ohne Neuberechnung.
// Feinnetz und Spannungen entstehen erst auf Knopfdruck („Netz neu erzeugen & analysieren“) bzw.
// automatisch vor Druckprüfung und Export.
// Die Fläche entsteht beim Ziehen direkt im Browser aus dem Dichtefeld der Iteration (kein Warten auf den
// Rechenkern, in beide Richtungen); beim Loslassen liefert der Rechenkern die bereinigte Form nach.
const LIVE = { fields: new Map(), loading: new Set(), stamp: 0, gen: 0 };
function liveReset() { LIVE.fields.clear(); LIVE.loading.clear(); LIVE.stamp++; LIVE.gen++; LIVE.want = null; if (LIVE.raf) { cancelAnimationFrame(LIVE.raf); LIVE.raf = 0; } }
async function liveField(it) {
  if (LIVE.fields.has(it) || LIVE.loading.has(it)) return;
  LIVE.loading.add(it);
  const gen = LIVE.gen;
  try {
    const r = await post('/api/field', { it, sigma: getK().sigma ?? 0.7 });
    if (gen !== LIVE.gen) return;                      // inzwischen neues Ergebnis
    {
      if (LIVE.fields.size >= 12) LIVE.fields.delete(LIVE.fields.keys().next().value);   // Speicher begrenzen
      LIVE.fields.set(it, r);
    }
  } catch (e) { /* Vorschau des Rechenkerns folgt beim Loslassen */ }
  if (gen !== LIVE.gen) return;
  LIVE.loading.delete(it);
  if (LIVE.want === it) liveDraw();
}
function liveText() {
  const v = $('volSlider').value / 100, m0 = S.res.optimize?.meta?.orig_mass_g;
  return (m0 ? `≈ ${fmt(v * m0)} g · ` : '') + `${Math.round((1 - v) * 100)} % lighter (live preview)`;
}
// höchstens eine Neuberechnung je Bild – schnelles Ziehen staut nichts auf
function liveSoon() { LIVE.stamp++; $('volInfo').textContent = liveText(); if (!LIVE.raf) LIVE.raf = requestAnimationFrame(() => { LIVE.raf = 0; liveDraw(); }); }
function liveDraw() {
  if (!S.res.optimize || S.poll) return;
  const it = parseInt($('itSlider').value) - 1, F = LIVE.fields.get(it);
  LIVE.want = it; LIVE.stamp++;
  $('volInfo').textContent = liveText();
  if (!F) { liveField(it); return; }
  const vol = Math.min(99, Math.max(1, parseInt($('volSlider').value)));
  const lev = S.volTarget ? F.levels[vol - 1] : 255 * (getK().level || 0.5);
  const m = isoSurface(F.field, F.meta.dims, F.meta.lo, F.meta.h, lev);
  if (!S.previewing) { $('dispMode').value = 'shape'; S.previewing = true; }
  if (S.view !== 'optimize') show('optimize');
  V.remove('infill'); V.remove('core');
  V.setMesh('res', { positions: m.positions, normals: m.normals, color: LIME, order: 1 });
  V.setFlat('res'); $('legend').hidden = true;
}
$('volSlider').oninput = () => { $('volVal').textContent = $('volSlider').value; S.volTarget = $('volSlider').value / 100; if (getK().level) setK({ level: 0 }); S.dirty = true; liveSoon(); };
$('volSlider').onchange = () => preview(true);
$('itSlider').oninput = () => { $('itVal').textContent = $('itSlider').value; S.dirty = true; liveSoon(); };
$('itSlider').onchange = () => preview(true);
$('btnRemesh').onclick = () => remesh();
// Vor Prüfung/Export: geänderte Vorschau zuerst in ein fertiges Ergebnis umwandeln
async function ensureFinal(what) {
  if (what !== 'optimize' || !S.dirty) return true;
  toast('Creating the result for the selected setting …');
  const st = await remesh();
  return st === 'done';
}

// ====================================================================== Prüfung & Export
// STEP und DXF nur für prismatisch gefräste Ergebnisse
function updateExportFormats() {
  const ok = $('expWhat').value === 'optimize' && !!S.res.optimize?.meta?.prism, f = $('expFmt');
  for (const o of f.options) if (o.value === 'step' || o.value === 'dxf') o.disabled = !ok;
  if (f.selectedOptions[0]?.disabled) f.value = 'stl';
  $('expHint').textContent = ok
    ? 'Prismatically milled: STEP contains a solid body made of planar faces (usable directly in Fusion 360 and CAM), DXF the contours of each depth level (layers named with their height in mm).'
    : 'In Fusion 360: Insert › Insert Mesh. For further design work convert the mesh into a body there or remodel it.';
}
$('expWhat').addEventListener('change', updateExportFormats);
$('btnCheck').onclick = async () => {
  const K = getK(), what = K.exp_what;
  if (what !== 'original' && !S.res[what]) return toast('There is no result for this selection yet.', 'warn');
  if (!(await ensureFinal(what))) return;
  try {
    toast('Checking …');
    const r = await post('/api/check', { what, build_dir: K.build_dir, overhang_deg: K.overhang_deg, min_wall_mm: K.min_wall_mm, unit_len: K.unit_len });
    S.checks[what] = r.flag; S.checks['_' + what] = r.meta;
    $('checkRes').innerHTML = `Overhangs: <b>${r.meta.overhang_area_pct.toFixed(1)} %</b> of the surface (orange)<br>` +
      `Walls thinner than ${r.meta.min_wall_mm} mm: <b>${r.meta.thin_pct.toFixed(1)} %</b> of the points (red)`;
    show(what); $('dispMode').value = 'check'; applyColors(); updateStats();
  } catch (e) { toast(e.message, 'err'); }
};
$('btnExport').onclick = async () => {
  const K = getK(), what = K.exp_what;
  if (what !== 'original' && !S.res[what]) return toast('There is no result for this selection yet.', 'warn');
  if (!(await ensureFinal(what))) return;
  try {
    const r = await fetch(`/api/export?what=${what}&fmt=${K.exp_fmt}&unit=${K.unit_len}`);
    if (!r.ok) throw new Error((await r.json()).error);
    const name = decodeURIComponent(r.headers.get('X-Filename') || 'export.' + K.exp_fmt);
    await saveBlob(await r.blob(), name, K.exp_fmt);
  } catch (e) { if (e.name !== 'AbortError') toast(e.message, 'err'); }
};
async function saveBlob(blob, name, ext) {
  if (window.showSaveFilePicker) {
    try {
      const h = await window.showSaveFilePicker({ suggestedName: name, types: [{ description: ext.toUpperCase(), accept: { 'application/octet-stream': ['.' + ext] } }] });
      const w = await h.createWritable(); await w.write(blob); await w.close(); toast('Saved: ' + h.name, 'ok'); return;
    } catch (e) { if (e.name === 'AbortError') return; }
  }
  const a = el('a', { href: URL.createObjectURL(blob), download: name }); document.body.append(a); a.click(); a.remove();
  toast('Downloaded: ' + name, 'ok');
}

// ====================================================================== Projekt
$('btnProjSave').onclick = async () => {
  if (!S.fileBytes) return toast('Please load a part first.', 'warn');
  // Je Fläche zusätzlich die Dreiecke (Eckpunkte) speichern: Wird die Datei später anders vernetzt
  // (andere OpenCASCADE-Version), lassen sich die Flächen darüber wiederfinden.
  const P = S.mesh.pos, ecken = t => Array.from(P.subarray(t * 9, t * 9 + 9), v => +v.toFixed(5));
  const strip = c => { const o = { ...c }; delete o.info; if (c.tris) o.geo = c.tris.flatMap(ecken); return o; };
  const proj = { app: 'diotopo', version: 3, file: { name: S.fileName, data: b64(S.fileBytes) }, settings: getK(),
    ntri: S.mesh.n, conds: S.conds.map(strip), cases: S.cases, nextId: S.nextId, holeSel: [...S.holeSel], view: { up: V.up } };
  const base = (S.fileName || 'project').replace(/\.[^.]+$/, '');
  await saveBlob(new Blob([JSON.stringify(proj)], { type: 'application/json' }), base + '.topo', 'topo');
};
$('btnProjOpen').onclick = () => $('projIn').click();
$('projIn').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) await loadProject(f); };
// Gespeicherte Dreiecke (Eckpunkte) -> ganze Flächen des aktuellen Netzes: ein neues Dreieck gehört zur
// Auswahl, wenn sein Mittelpunkt auf einem der gespeicherten Dreiecke liegt; Flächen, die überwiegend
// so getroffen werden, werden komplett übernommen.
function closestDist2(p, A, B, C) {
  const ab = sub(B, A), ac = sub(C, A), ap = sub(p, A), d1 = dot(ab, ap), d2 = dot(ac, ap);
  let q;
  if (d1 <= 0 && d2 <= 0) q = A;
  else {
    const bp = sub(p, B), d3 = dot(ab, bp), d4 = dot(ac, bp);
    if (d3 >= 0 && d4 <= d3) q = B;
    else {
      const vc = d1 * d4 - d3 * d2;
      if (vc <= 0 && d1 >= 0 && d3 <= 0) q = add(A, mul(ab, d1 / (d1 - d3)));
      else {
        const cp = sub(p, C), d5 = dot(ab, cp), d6 = dot(ac, cp);
        if (d6 >= 0 && d5 <= d6) q = C;
        else {
          const vb = d5 * d2 - d1 * d6;
          if (vb <= 0 && d2 >= 0 && d6 <= 0) q = add(A, mul(ac, d2 / (d2 - d6)));
          else {
            const va = d3 * d6 - d5 * d4;
            if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) q = add(B, mul(sub(C, B), (d4 - d3) / ((d4 - d3) + (d5 - d6))));
            else { const den = 1 / (va + vb + vc); q = add(A, add(mul(ab, vb * den), mul(ac, vc * den))); }
          }
        }
      }
    }
  }
  const d = sub(p, q); return dot(d, d);
}
function remapTris(geo) {
  const P = S.mesh.pos, n = S.mesh.n, m = Math.floor(geo.length / 9);
  if (!m) return null;
  const tol = 0.005 * S.mesh.diag, tol2 = tol * tol, h = Math.max(S.mesh.diag / 80, 2 * tol);
  const T = j => [[geo[j * 9], geo[j * 9 + 1], geo[j * 9 + 2]], [geo[j * 9 + 3], geo[j * 9 + 4], geo[j * 9 + 5]],
                  [geo[j * 9 + 6], geo[j * 9 + 7], geo[j * 9 + 8]]];
  const grid = new Map(), big = [];
  for (let j = 0; j < m; j++) {
    const [A, B, C] = T(j), lo = [0, 1, 2].map(a => Math.floor((Math.min(A[a], B[a], C[a]) - tol) / h)),
      hi = [0, 1, 2].map(a => Math.floor((Math.max(A[a], B[a], C[a]) + tol) / h));
    if ((hi[0] - lo[0] + 1) * (hi[1] - lo[1] + 1) * (hi[2] - lo[2] + 1) > 4000) { big.push(j); continue; }
    for (let x = lo[0]; x <= hi[0]; x++) for (let y = lo[1]; y <= hi[1]; y++) for (let z = lo[2]; z <= hi[2]; z++) {
      const k = x + ',' + y + ',' + z; let l = grid.get(k); if (!l) grid.set(k, l = []); l.push(j);
    }
  }
  const hit = new Map(), tot = new Map();
  for (let t = 0; t < n; t++) {
    const f = S.mesh.fid[t]; tot.set(f, (tot.get(f) || 0) + 1);
    const c = [0, 1, 2].map(a => (P[t * 9 + a] + P[t * 9 + 3 + a] + P[t * 9 + 6 + a]) / 3);
    const cand = (grid.get(Math.floor(c[0] / h) + ',' + Math.floor(c[1] / h) + ',' + Math.floor(c[2] / h)) || []).concat(big);
    for (const j of cand) {
      const [A, B, C] = T(j);
      if (closestDist2(c, A, B, C) <= tol2) { hit.set(f, (hit.get(f) || 0) + 1); break; }
    }
  }
  const faces = new Set([...hit].filter(([f, k]) => k >= 0.5 * tot.get(f)).map(([f]) => f));
  if (!faces.size) return null;
  const out = [];
  for (let t = 0; t < n; t++) if (faces.has(S.mesh.fid[t])) out.push(t);
  return out;
}

async function loadProject(f) {
  try {
    const p = JSON.parse(await f.text());
    if (p.app !== 'diotopo' && p.app !== 'top' + 'oopt') throw new Error('This is not a Diotopo project file.');
    await loadBytes(unb64(p.file.data), p.file.name, true);
    const st = { ...(p.settings || {}) };
    if (st.E_z === undefined) {                // Projekt aus Version 1.0: Werte aus der Materialliste
      const m = S.info.materials[st.material];
      Object.assign(st, m ? { E_z: m.E_z, S_z: m.S_z, S_zs: m.S_zs } : { E_z: st.E, S_z: st.yield_, S_zs: +(st.yield_ / Math.sqrt(3)).toPrecision(3) });
    }
    // Einstellungen, die es in älteren Projekten noch nicht gab: Standardwerte statt des Stands der laufenden Sitzung
    for (const [k, v] of Object.entries({ allow_split: false, layer_opt: true, safety_target: 0 })) if (st[k] === undefined) st[k] = v;
    if (st.ps_zp === undefined && st.mfg !== 'cnc_prism') for (const [k] of PRISM_SIDES) st[k] = true;
    if (st.ps_zp === undefined && st.mfg === 'cnc_prism') {   // Projekt vor dem 6-Seiten-Fräsen: Werkzeugrichtung (+ Gegenseite)
      const d = st.mfg_dir || 'z+', o = d[0] + (d[1] === '+' ? '-' : '+');
      for (const [k, sd] of PRISM_SIDES) st[k] = sd === d || (parseInt(st.cnc_setups) >= 2 && sd === o);
    }
    setK(st);
    if (p.view?.up) { V.up = p.view.up; $('upAxis').value = p.view.up; }
    S.cases = p.cases || S.cases; S.conds = (p.conds || []).filter(c => c.type !== 'open');   // Flächentyp „Offen“ älterer Versionen entfällt
    const anders = (p.ntri && p.ntri !== S.mesh.n) || S.conds.some(c => c.tris && c.tris.some(t => t >= S.mesh.n));
    let weg = 0;
    if (anders) {
      // Bauteil wurde anders vernetzt: Flächen über die gespeicherten Dreiecke wiederfinden
      const keep = [];
      for (const c of S.conds) {
        if (!c.tris) { keep.push(c); continue; }
        const t = c.geo ? remapTris(c.geo) : null;
        if (t && t.length) { c.tris = t; keep.push(c); } else weg++;
      }
      S.conds = keep;
    }
    for (const c of S.conds) delete c.geo;
    S.holeSel = new Set(anders ? [] : (p.holeSel || []));
    S.nextId = p.nextId || (Math.max(0, ...S.conds.map(c => c.id)) + 1);
    for (const c of S.conds) if (c.tris && ['pin', 'moment', 'bearing'].includes(c.type === 'load' ? c.kind : c.type)) {
      try { c.info = await post('/api/faceinfo', { tris: c.tris }); } catch (err) {}
    }
    renderCases(); renderConds(); redrawOverlays(); setMassDefault(); setK({ mass_g: p.settings.mass_g });
    if (weg) toast(`${weg} supports/loads no longer matched the re-imported part and were removed – please assign them again.`, 'warn');
    else toast('Project loaded.', 'ok');
  } catch (err) { toast(err.message, 'err'); }
}

// ====================================================================== Start
async function init() {
  try { S.info = await api('/api/info'); } catch (e) { toast('Computing core not reachable: ' + e.message, 'err'); return; }
  fillMaterials(); initSliders(); refreshVis(); renderCases(); renderConds();
  logLine(`© 2026 ${S.info.holder || 'Diotopo'} – License terms: LICENSE.txt · Third-party components: “Licenses” folder.`);
  if (!S.info.step) logLine('Note: The package “cadquery-ocp-novtk” (OpenCASCADE) is missing – STEP files can only be opened after running “Install packages.bat” (Browser Version). STL, 3MF, OBJ and PLY always work.');
  logLine(S.info.gpus && S.info.gpus.length
    ? `Solver: combined on CPU (${S.info.threads} Threads) + ${S.info.gpus.join(' + ')}.`
    : `Solver: multigrid CG on all CPU cores (${S.info.threads} threads) – no graphics card found via OpenCL.`);
  logLine(`Diotopo ${S.info.version} ready.`);
  setInterval(() => fetch('/api/ping').catch(() => {}), 2000);
  // Fenster wird geschlossen: Rechenkern sofort Bescheid geben (bei Neuladen meldet sich das Fenster gleich wieder)
  window.addEventListener('pagehide', () => { try { navigator.sendBeacon('/api/bye', ''); } catch (e) {} });
  window.__ready = true;
}
// Dio-Wasserzeichen immer knapp unter die (je nach Fensterbreite ein- oder zweizeilige) Werkzeugleiste
function placeDio() {
  const tb = $('toolbar'), d = $('dioMark');
  if (tb && d) d.style.top = (tb.offsetTop + tb.offsetHeight + 12) + 'px';
}
window.addEventListener('resize', placeDio);
new ResizeObserver(placeDio).observe($('toolbar'));
placeDio();
// Spenden: im Diotopo-Programmfenster über den Standardbrowser öffnen, in der Browser Version als neuer Tab
const DONATE_URL = 'https://paypal.me/diotopo';
$('btnDonate').onclick = async () => {
  if (new URLSearchParams(location.search).has('fenster')) {
    try { const r = await fetch('/api/open', { method: 'POST', body: JSON.stringify({ url: DONATE_URL }) }); if (r.ok) return; } catch (e) {}
  }
  window.open(DONATE_URL, '_blank', 'noopener');
};
window.__S = S; window.__V = V; window.__api = { addCond, setSel, startJob, show, loadBytes, setTab, getK, setK, post, loadProject };
init();
