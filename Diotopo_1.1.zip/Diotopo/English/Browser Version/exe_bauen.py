# -*- coding: utf-8 -*-
"""
Baut Diotopo.exe (Windows) aus diesem Quellcode-Ordner mit PyInstaller.
Das Ergebnis läuft ohne installiertes Python: Diotopo.exe + Ordner _internal.

  python exe_bauen.py --ziel <Ordner> [--portable]

--portable legt zusätzlich „portable.txt“ ab: Daten bleiben dann neben der .exe (USB-Stick).
Wird vom Bau-Assistenten (bau_assistent.py) aufgerufen – „Installer erstellen.pyw“ bzw. „Portable erstellen.pyw“.
"""

import argparse
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))


def version():
    s = open(os.path.join(HERE, "diotopo", "server.py"), encoding="utf-8").read()
    return re.search(r'VERSION = "([^"]+)"', s).group(1)


def holder():
    sys.path.insert(0, HERE)
    from diotopo import rechteinhaber
    return rechteinhaber()


def version_file(path, ver):
    nums = [int(x) for x in re.findall(r"\d+", ver)][:4]
    nums += [0] * (4 - len(nums))
    t = tuple(nums)
    vs = ".".join(str(x) for x in t)
    h = holder()
    copy = f"© 2026 {h}" if h else "© 2026"
    txt = f"""VSVersionInfo(
  ffi=FixedFileInfo(filevers={t}, prodvers={t}, mask=0x3f, flags=0x0, OS=0x40004, fileType=0x1,
                    subtype=0x0, date=(0, 0)),
  kids=[
    StringFileInfo([StringTable('040904B0', [
      StringStruct('CompanyName', 'Diotopo'),
      StringStruct('FileDescription', 'Diotopo'),
      StringStruct('FileVersion', '{vs}'),
      StringStruct('InternalName', 'Diotopo'),
      StringStruct('OriginalFilename', 'Diotopo.exe'),
      StringStruct('ProductName', 'Diotopo'),
      StringStruct('ProductVersion', '{vs}'),
      StringStruct('LegalCopyright', {copy!r})])]),
    VarFileInfo([VarStruct('Translation', [0x0409, 0x04B0])])
  ]
)
"""
    with open(path, "w", encoding="utf-8") as f:
        f.write(txt)


# Distributionen, die in Diotopo.exe landen können – ihre Lizenztexte werden mitgeliefert
LIZENZ_PAKETE = ("numpy", "scipy", "cadquery-ocp-novtk", "cadquery-ocp", "pyopencl", "pytools", "platformdirs",
                 "siphash24", "typing_extensions", "pyinstaller")


def lizenzen(ziel):
    """LIZENZ.txt, Übersicht und alle Lizenztexte der mitgelieferten Komponenten neben Diotopo.exe."""
    import importlib.metadata as md
    out = os.path.join(ziel, "Licenses")
    if os.path.isdir(out):
        shutil.rmtree(out)
    shutil.copytree(os.path.join(HERE, "Licenses"), out)
    shutil.copy2(os.path.join(HERE, "LICENSE.txt"), os.path.join(ziel, "LICENSE.txt"))
    pl = os.path.join(sys.base_prefix, "LICENSE.txt")
    if os.path.isfile(pl):
        os.makedirs(os.path.join(out, "Python"), exist_ok=True)
        shutil.copy2(pl, os.path.join(out, "Python", "LICENSE.txt"))
    pat = re.compile(r"(LICEN[CS]E|COPYING|NOTICE|AUTHORS|COPYRIGHT)", re.I)
    for name in LIZENZ_PAKETE:
        try:
            dist = md.distribution(name)
        except md.PackageNotFoundError:
            continue
        files = [f for f in (dist.files or []) if pat.search(f.name) or "licenses" in (p.lower() for p in f.parts)]
        if not files:
            continue
        d = os.path.join(out, f"{name}-{dist.version}")
        os.makedirs(d, exist_ok=True)
        for f in files:
            src = f.locate()
            if os.path.isfile(src):
                dst = os.path.join(d, f.name)
                if os.path.exists(dst):
                    dst = os.path.join(d, "_".join(f.parts[-2:]))
                shutil.copy2(src, dst)
    print("License texts stored in", out)


def have(mod):
    return importlib.util.find_spec(mod) is not None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ziel", required=True, help="Target folder for Diotopo.exe and _internal")
    ap.add_argument("--portable", action="store_true")
    ap.add_argument("--iss-version", help="File for Inno Setup: #define MyAppVersion …")
    a = ap.parse_args()
    if os.name != "nt":
        print("Note: A Windows .exe can only be built on Windows.")
    if not have("PyInstaller"):
        print("Installing PyInstaller …")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    ver = version()
    ziel = os.path.abspath(a.ziel)
    tmp = tempfile.mkdtemp(prefix="diotopo_bau_")
    try:
        vf = os.path.join(tmp, "version.txt")
        version_file(vf, ver)
        sep = ";" if os.name == "nt" else ":"
        cmd = [sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--windowed",
               "--name", "Diotopo", "--icon", os.path.join(HERE, "icon.ico"), "--version-file", vf,
               "--add-data", f"{os.path.join(HERE, 'web')}{sep}web",
               "--distpath", os.path.join(tmp, "dist"), "--workpath", os.path.join(tmp, "work"),
               "--specpath", tmp, "--paths", HERE,
               "--collect-submodules", "diotopo",
               "--exclude-module", "cupy", "--exclude-module", "cupyx", "--exclude-module", "tkinter",
               "--exclude-module", "matplotlib", "--exclude-module", "PIL"]
        for mod in ("OCP", "pyopencl", "pytools"):               # optionale Pakete mitnehmen, falls installiert
            if have(mod):
                cmd += ["--collect-all", mod]
        # Nie mitliefern: gmsh (GPL – würde Diotopo selbst unter die GPL zwingen), Intel MKL/Pardiso
        # (groß, eigene Lizenzauflagen), CUDA/CuPy
        for mod in ("gmsh", "pypardiso", "mkl"):
            cmd += ["--exclude-module", mod]
        cmd.append(os.path.join(HERE, "Diotopo.pyw"))
        print(f"Building Diotopo {ver} …")
        subprocess.check_call(cmd, cwd=HERE)
        out = os.path.join(tmp, "dist", "Diotopo")
        os.makedirs(ziel, exist_ok=True)
        for old in ("Diotopo.exe", "_internal"):                 # nur das alte Programm ersetzen
            p = os.path.join(ziel, old)
            if os.path.isdir(p):
                shutil.rmtree(p)
            elif os.path.isfile(p):
                os.remove(p)
        for name in os.listdir(out):
            shutil.move(os.path.join(out, name), os.path.join(ziel, name))
        lizenzen(ziel)
        pt = os.path.join(ziel, "portable.txt")
        if a.portable:
            with open(pt, "w", encoding="utf-8") as f:
                f.write("Diotopo runs portably in this folder: settings and log are stored in the "
                        "“Data” folder next to it.\n")
        elif os.path.isfile(pt):
            os.remove(pt)
        if a.iss_version:
            os.makedirs(os.path.dirname(os.path.abspath(a.iss_version)), exist_ok=True)
            with open(a.iss_version, "w", encoding="utf-8") as f:
                f.write(f'#define MyAppVersion "{ver}"\n')
        print(f"Done: {os.path.join(ziel, 'Diotopo.exe')}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
