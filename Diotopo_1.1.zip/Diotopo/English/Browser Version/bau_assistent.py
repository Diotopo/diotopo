# -*- coding: utf-8 -*-
"""
Diotopo – Bau-Assistent (Fenster statt Konsole).

Erzeugt den Windows-Installer (Diotopo-Setup-<Version>.exe) oder die Portable-Version.
Die Oberfläche ist ein kleines App-Fenster (Edge/Chrome im App-Modus) mit Schritten,
Fortschritt und Details; alle Werkzeuge laufen unsichtbar im Hintergrund.

Aufruf über „Browser Version\\entwicklung\\setup-exe\\Installer erstellen.pyw“ bzw. „Portable Version\\Portable erstellen.pyw“.
Gebaut wird in einem temporären Ordner (Virenscanner/OneDrive sperren frisch geschriebene .exe-Dateien
auf dem Desktop gern kurz) und das Ergebnis danach mit Wiederholungen in den Zielordner kopiert.
"""

import glob
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))           # Ordner „Browser Version“ (Quellcode)
NOWIN = 0x08000000 if os.name == "nt" else 0                # CREATE_NO_WINDOW: keine Konsolenfenster
DRY = os.environ.get("DIOTOPO_BAU_PROBE") == "1"            # nur zum Testen der Oberfläche
OPTIONAL = ("cadquery-ocp-novtk", "pyopencl")


def python_exe():
    """python.exe (nicht pythonw) für die Werkzeuge – Ausgaben lassen sich so mitlesen."""
    d = os.path.dirname(sys.executable)
    for n in ("python.exe", "python3", "python"):
        p = os.path.join(d, n)
        if os.path.isfile(p):
            return p
    return sys.executable


def version():
    sys.path.insert(0, HERE)
    import exe_bauen
    return exe_bauen.version()


# ================================================================ Ablauf

class Build:
    def __init__(self, mode, target):
        self.mode, self.target = mode, os.path.abspath(target)
        names = ["Check Python packages", "Build Diotopo.exe"]
        if mode == "installer":
            names += ["Provide Inno Setup", "Create setup file"]
        else:
            names += ["Set up portable folder"]
        self.steps = [dict(name=n, state="wait") for n in names]
        self.state, self.cur, self.detail, self.error, self.result = "idle", -1, "", "", ""
        self.log = []
        self.lock = threading.Lock()
        self.proc = None
        self.cancelled = False
        self.tmp = os.path.join(os.environ.get("TEMP") or "/tmp", "diotopo_bau")

    # ---------------- Hilfen
    def say(self, line):
        line = line.rstrip()
        if not line:
            return
        with self.lock:
            self.log.append(line)
            if len(self.log) > 4000:
                del self.log[:1000]
            self.detail = line[-160:]

    def run(self, cmd, ok_codes=(0,)):
        self.say("> " + " ".join(f'"{c}"' if " " in c else c for c in cmd))
        if DRY:
            time.sleep(0.6)
            self.say("(test run)")
            return 0
        env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                     text=True, encoding="utf-8", errors="replace", creationflags=NOWIN, env=env,
                                     cwd=HERE)
        for line in self.proc.stdout:
            self.say(line)
        rc = self.proc.wait()
        self.proc = None
        if self.cancelled:
            raise RuntimeError("abgebrochen")
        return rc

    def step(self, i):
        with self.lock:
            if self.cur >= 0:
                self.steps[self.cur]["state"] = "done"
            self.cur = i
            self.steps[i]["state"] = "run"
            self.detail = ""

    # ---------------- Schritte
    def s_packages(self, optional):
        py = python_exe()
        self.run([py, "-m", "pip", "install", "--disable-pip-version-check", "--upgrade", "pip"])
        rc = self.run([py, "-m", "pip", "install", "--disable-pip-version-check", "--only-binary=:all:",
                       "-r", os.path.join(HERE, "requirements.txt"), "pyinstaller"])
        if rc != 0:
            raise RuntimeError("The required packages (numpy, scipy, PyInstaller) could not be installed. "
                               "Is there an internet connection? For very new Python versions there are sometimes "
                               "no ready-made packages yet – in that case install Python 3.13.")
        if optional:
            for p in OPTIONAL:
                if self.run([py, "-m", "pip", "install", "--disable-pip-version-check", "--only-binary=:all:", p]):
                    self.say(f"Note: {p} not available – will not be included.")

    def s_exe(self, ziel, portable=False):
        args = [python_exe(), os.path.join(HERE, "exe_bauen.py"), "--ziel", ziel]
        if portable:
            args.append("--portable")
        if self.run(args) != 0:
            raise RuntimeError("Diotopo.exe could not be built – show details.")

    @staticmethod
    def find_iscc():
        cands = [os.path.join(os.environ.get(v, ""), "Inno Setup 6", "ISCC.exe")
                 for v in ("ProgramFiles(x86)", "ProgramFiles")]
        cands.append(os.path.join(os.environ.get("LOCALAPPDATA", ""), "Programs", "Inno Setup 6", "ISCC.exe"))
        for c in cands:
            if os.path.isfile(c):
                return c
        return shutil.which("ISCC")

    def s_inno(self):
        if DRY:
            self.run(["ISCC", "/?"])
            return "ISCC"
        iscc = self.find_iscc()
        if iscc:
            self.say("Inno Setup found: " + iscc)
            return iscc
        self.say("Installing Inno Setup (free tool for creating installers) …")
        self.run(["winget", "install", "--id", "JRSoftware.InnoSetup", "-e", "--source", "winget", "--silent",
                  "--accept-package-agreements", "--accept-source-agreements"])
        iscc = self.find_iscc()
        if not iscc:
            raise RuntimeError("Inno Setup could not be installed automatically. Please install it from "
                               "https://jrsoftware.org/isdl.php and then click “Try again”.")
        return iscc

    def s_setup(self, iscc, ver):
        out = os.path.join(self.tmp, "ausgabe")
        shutil.rmtree(out, ignore_errors=True)
        os.makedirs(out, exist_ok=True)
        iss = os.path.join(self.target, "Diotopo.iss")
        cmd = [iscc, "/Q", f"/DBuildDir={self.tmp}", f"/DMyAppVersion={ver}", f"/O{out}", iss]
        for attempt in range(1, 5):                          # Virenscanner sperren die Datei manchmal kurz
            if self.run(cmd) == 0:
                break
            if attempt == 4:
                raise RuntimeError("Inno Setup could not write the setup file. Usually the virus scanner is just "
                                   "checking the new file – please wait a moment and click “Try again”.")
            self.say(f"New attempt in {3 * attempt} s …")
            time.sleep(3 * attempt)
        files = glob.glob(os.path.join(out, "Diotopo-Setup-*.exe")) or (["Diotopo-Setup-probe.exe"] if DRY else [])
        if not files:
            raise RuntimeError("The setup file was not found.")
        src = files[0]
        dst = os.path.join(self.target, os.path.basename(src))
        if DRY:
            return dst
        for attempt in range(1, 6):
            try:
                shutil.copy2(src, dst)
                return dst
            except OSError as e:
                if attempt == 5:
                    raise RuntimeError(f"The setup file is ready in {src}, but could not be copied to the "
                                       f"installer folder ({e}).")
                time.sleep(2 * attempt)

    def go(self, optional):
        with self.lock:
            self.state, self.error, self.result, self.cancelled = "running", "", "", False
            self.cur = -1
            for s in self.steps:
                s["state"] = "wait"
        try:
            ver = version()
            self.say(f"Diotopo {ver} – create {'installer' if self.mode == 'installer' else 'portable version'}")
            self.step(0)
            self.s_packages(optional)
            self.step(1)
            if self.mode == "installer":
                shutil.rmtree(self.tmp, ignore_errors=True)
                os.makedirs(self.tmp, exist_ok=True)
                self.s_exe(os.path.join(self.tmp, "Diotopo"))
                self.step(2)
                iscc = self.s_inno()
                self.step(3)
                self.result = self.s_setup(iscc, ver)
            else:
                self.s_exe(self.target, portable=True)
                self.step(2)
                self.say("Data stays in the “Data” folder next to Diotopo.exe (portable.txt).")
                self.result = os.path.join(self.target, "Diotopo.exe")
            with self.lock:
                self.steps[self.cur]["state"] = "done"
                self.state = "done"
            if self.mode == "installer" and not DRY:
                shutil.rmtree(self.tmp, ignore_errors=True)
        except Exception as e:  # noqa
            self.say(traceback.format_exc())
            with self.lock:
                if self.cur >= 0:
                    self.steps[self.cur]["state"] = "error"
                self.error, self.state = str(e), "error"

    def status(self, frm):
        with self.lock:
            done = sum(1 for s in self.steps if s["state"] == "done")
            return dict(mode=self.mode, state=self.state, steps=self.steps, detail=self.detail, error=self.error,
                        result=self.result, log=self.log[frm:], log_n=len(self.log),
                        progress=done / len(self.steps), version=version())

    def stop(self):
        self.cancelled = True
        p = self.proc
        if p is not None and p.poll() is None:
            try:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True, creationflags=NOWIN)
                else:
                    p.kill()
            except Exception:  # noqa
                pass


# ================================================================ Fenster (HTML)

PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Diotopo – __TITLE__</title>
<link rel="icon" href="dio.png">
<style>
:root{--bg:#1b1f27;--p:#232833;--p2:#2b3140;--line:#373e4d;--txt:#e6e9ef;--mut:#98a1b3;--acc:#D3F300;--err:#e05a4f}
*{box-sizing:border-box}html,body{margin:0;height:100%;background:var(--bg);color:var(--txt);
font:14px/1.45 "Segoe UI",system-ui,sans-serif}
.wrap{display:grid;grid-template-columns:200px 1fr;height:100%}
.side{background:linear-gradient(180deg,#232a37,#171a21);border-right:1px solid var(--line);display:flex;
flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:20px}
.side img{width:150px;filter:drop-shadow(0 6px 14px rgba(0,0,0,.45))}.side b{font-size:22px;letter-spacing:.5px}
.side span{color:var(--mut);font-size:12px;text-align:center}
.main{display:flex;flex-direction:column;padding:26px 30px 18px;min-width:0}
h1{margin:0 0 6px;font-size:21px;font-weight:600}p{margin:6px 0;color:#cdd3de}
.page{flex:1;display:none;flex-direction:column;min-height:0}.page.on{display:flex}
.foot{display:flex;justify-content:flex-end;gap:10px;padding-top:14px;border-top:1px solid var(--line);margin-top:12px}
button{background:var(--p2);color:var(--txt);border:1px solid var(--line);border-radius:6px;padding:8px 18px;
font:inherit;cursor:pointer}button:hover{border-color:#566078}button.pri{background:var(--acc);border-color:var(--acc);
color:#1A1F00;font-weight:600}button:disabled{opacity:.45;cursor:default}
label.opt{display:flex;gap:10px;align-items:flex-start;background:var(--p);border:1px solid var(--line);border-radius:8px;
padding:12px 14px;margin-top:14px;cursor:pointer}label.opt input{margin-top:3px;accent-color:var(--acc)}
.small{font-size:12px;color:var(--mut)}
ol.steps{list-style:none;padding:0;margin:14px 0 8px}ol.steps li{display:flex;gap:10px;align-items:center;padding:6px 0;color:var(--mut)}
ol.steps li i{width:22px;height:22px;border-radius:50%;border:2px solid var(--line);display:inline-flex;align-items:center;
justify-content:center;font-style:normal;font-size:12px;flex:none}
ol.steps li.run{color:var(--txt)}ol.steps li.run i{border-color:var(--acc);border-top-color:transparent;animation:sp 1s linear infinite}
ol.steps li.done{color:var(--txt)}ol.steps li.done i{background:var(--acc);border-color:var(--acc);color:#1A1F00}
ol.steps li.error{color:var(--err)}ol.steps li.error i{border-color:var(--err);color:var(--err)}
@keyframes sp{to{transform:rotate(360deg)}}
.bar{height:8px;background:#141820;border-radius:5px;overflow:hidden;margin:8px 0 4px}.bar div{height:100%;width:0;
background:var(--acc);transition:width .5s}
#detail{font-size:12px;color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-height:18px}
details{margin-top:8px;min-height:0;display:flex;flex-direction:column}summary{cursor:pointer;color:var(--mut);font-size:12px}
pre{background:#11141a;border:1px solid var(--line);border-radius:6px;padding:8px;font-size:11px;line-height:1.35;
max-height:180px;overflow:auto;white-space:pre-wrap;word-break:break-all;margin:6px 0 0}
.box{background:var(--p);border:1px solid var(--line);border-radius:8px;padding:12px 14px;margin-top:12px;word-break:break-all}
.err{border-color:var(--err);color:#f2c3bf}.ok{font-size:40px;color:var(--acc);line-height:1}
</style></head><body><div class="wrap">
<div class="side"><img src="dio.png" alt=""><b>Diotopo</b><span id="ver"></span></div>
<div class="main">
 <div class="page on" id="p0">
  <h1>__HEADLINE__</h1>
  <p>__INTRO__</p>
  <label class="opt"><input type="checkbox" id="optional" checked>
   <span>Include additional features<br><span class="small">STEP import (OpenCASCADE), graphics card acceleration (pyopencl)
   – if available for this Python version.</span></span></label>
  <p class="small" style="margin-top:14px">Takes a few minutes and needs an internet connection once.</p>
  <div style="flex:1"></div>
  <div class="foot"><button onclick="window.close()">Cancel</button><button class="pri" onclick="start()">Next &gt;</button></div>
 </div>
 <div class="page" id="p1">
  <h1>__WORKING__</h1>
  <ol class="steps" id="steps"></ol>
  <div class="bar"><div id="bar"></div></div>
  <div id="detail"></div>
  <details id="det"><summary>Show details</summary><pre id="log"></pre></details>
  <div style="flex:1"></div>
  <div class="foot"><button id="btnCancel" onclick="cancel()">Cancel</button></div>
 </div>
 <div class="page" id="p2">
  <div class="ok">✓</div>
  <h1>__DONE__</h1>
  <p>__DONE_TEXT__</p>
  <div class="box" id="result"></div>
  <div style="flex:1"></div>
  <div class="foot">
   <button onclick="act('folder')">Open folder</button>
   __DONE_BUTTON__
   <button onclick="window.close()">Finish</button></div>
 </div>
 <div class="page" id="p3">
  <h1>That did not work</h1>
  <div class="box err" id="error"></div>
  <details open><summary>Details</summary><pre id="log2"></pre></details>
  <div style="flex:1"></div>
  <div class="foot"><button onclick="window.close()">Close</button><button class="pri" onclick="start()">Try again</button></div>
 </div>
</div></div>
<script>
let logN = 0, timer = null, logAll = [];
const $ = id => document.getElementById(id);
function show(i){ for (let k = 0; k < 4; k++) $('p' + k).classList.toggle('on', k === i); }
async function post(u, b){ return fetch(u, {method:'POST', body: JSON.stringify(b || {})}); }
async function start(){ logN = 0; logAll = []; $('log').textContent = ''; show(1);
  await post('/start', {optional: $('optional').checked}); if (!timer) timer = setInterval(poll, 400); poll(); }
async function cancel(){ if (confirm('Cancel building?')) { await post('/cancel'); window.close(); } }
async function act(w){ await post('/action', {what: w}); }
function esc(s){ return s.replace(/[&<>]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;'}[c])); }
async function poll(){
  let s; try { s = await (await fetch('/status?from=' + logN)).json(); } catch (e) { return; }
  $('ver').textContent = 'Version ' + s.version;
  $('steps').innerHTML = s.steps.map(t => `<li class="${t.state}"><i>${t.state==='done'?'✓':t.state==='error'?'!':''}</i>${esc(t.name)}</li>`).join('');
  $('bar').style.width = Math.round(s.progress * 100) + '%';
  $('detail').textContent = s.detail || '';
  if (s.log.length) { logAll.push(...s.log); logN = s.log_n; const L = $('log'); const end = L.scrollTop + L.clientHeight >= L.scrollHeight - 4;
    L.textContent = logAll.slice(-1500).join('\n'); if (end) L.scrollTop = L.scrollHeight; }
  if (s.state === 'done') { clearInterval(timer); timer = null; $('result').textContent = s.result; show(2); }
  if (s.state === 'error') { clearInterval(timer); timer = null; $('error').textContent = s.error;
    $('log2').textContent = logAll.slice(-300).join('\n'); $('log2').scrollTop = 1e9; show(3); }
}
setInterval(() => fetch('/ping').catch(() => {}), 2000);
window.addEventListener('pagehide', () => navigator.sendBeacon('/bye', ''));
fetch('/status?from=0').then(r => r.json()).then(s => { $('ver').textContent = 'Version ' + s.version;
  if (s.state === 'running') { show(1); timer = setInterval(poll, 400); } });
</script></body></html>"""

TEXTS = {
    "installer": dict(
        TITLE="Create installer", HEADLINE="Create Windows installer",
        INTRO="This wizard builds the file <b>Diotopo-Setup.exe</b> from the program code. It lets you "
              "install Diotopo on any Windows 10/11 PC – with an installation wizard, a selectable target folder "
              "and an optional desktop shortcut. No Python is needed on the target PCs.",
        WORKING="Creating installer …", DONE="Installer created",
        DONE_TEXT="The setup file is in the folder “Browser Version\\entwicklung\\setup-exe”. It can be copied to any Windows PC.",
        DONE_BUTTON='<button class="pri" onclick="act(\'run\')">Install Diotopo now</button>'),
    "portable": dict(
        TITLE="Create portable version", HEADLINE="Create portable version",
        INTRO="This wizard builds <b>Diotopo.exe</b> from the program code directly into the folder "
              "“Portable Version”. Copy the whole folder to a USB stick and start it there – no "
              "installation, no Python; settings stay on the stick.",
        WORKING="Creating portable version …", DONE="Portable version created",
        DONE_TEXT="Copy the whole “Portable Version” folder to the USB stick and start Diotopo.exe there.",
        DONE_BUTTON='<button class="pri" onclick="act(\'run\')">Start Diotopo</button>'),
}


class App:
    def __init__(self, mode, target):
        self.b = Build(mode, target)
        self.mode, self.target = mode, target
        self.last_seen = time.time()
        self.bye_at = 0.0
        t = TEXTS[mode]
        html = PAGE
        for k, v in t.items():
            html = html.replace("__" + k + "__", v)
        self.html = html.encode("utf-8")

    def handler(self):
        app = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def send(self, code, body, ctype="application/json"):
                if not isinstance(body, (bytes, bytearray)):
                    body = json.dumps(body).encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(body)

            def body(self):
                n = int(self.headers.get("Content-Length") or 0)
                try:
                    return json.loads(self.rfile.read(n) or b"{}")
                except ValueError:
                    return {}

            def do_GET(self):
                app.last_seen = time.time()
                p = self.path.split("?")[0]
                if p == "/":
                    return self.send(200, app.html, "text/html; charset=utf-8")
                if p == "/dio.png":
                    with open(os.path.join(HERE, "web", "dio.png"), "rb") as f:
                        return self.send(200, f.read(), "image/png")
                if p == "/status":
                    frm = int(self.path.split("from=")[-1]) if "from=" in self.path else 0
                    return self.send(200, app.b.status(frm))
                if p == "/ping":
                    return self.send(200, {"ok": True})
                return self.send(404, {"error": "not found"})

            def do_POST(self):
                p = self.path.split("?")[0]
                if p == "/bye":
                    app.bye_at = time.time()
                    return self.send(200, {"ok": True})
                app.last_seen = time.time()
                j = self.body()
                if p == "/start":
                    if app.b.state != "running":
                        threading.Thread(target=app.b.go, args=(bool(j.get("optional", True)),), daemon=True).start()
                    return self.send(200, {"ok": True})
                if p == "/cancel":
                    app.b.stop()
                    return self.send(200, {"ok": True})
                if p == "/action":
                    w = j.get("what")
                    try:
                        if w == "folder":
                            open_path(app.target)
                        elif w == "run" and app.b.result and os.path.isfile(app.b.result):
                            open_path(app.b.result)
                    except Exception as e:  # noqa
                        return self.send(500, {"error": str(e)})
                    return self.send(200, {"ok": True})
                return self.send(404, {"error": "not found"})
        return H


def open_path(p):
    if os.name == "nt":
        os.startfile(p)  # noqa
    else:
        subprocess.Popen(["xdg-open", p])


def find_browser():
    for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
        if base:
            for c in (os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                      os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")):
                if os.path.isfile(c):
                    return c
    return None


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def main(mode, target, port=None, open_window=True):
    app = App(mode, target)
    port = port or free_port()
    srv = ThreadingHTTPServer(("127.0.0.1", port), app.handler())
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    proc = None
    if open_window:
        br = find_browser()
        if br:
            prof = os.path.join(os.environ.get("TEMP") or "/tmp", "diotopo_assistent_fenster")
            proc = subprocess.Popen([br, f"--app={url}", f"--user-data-dir={prof}", "--no-first-run",
                                     "--no-default-browser-check", "--disable-background-mode",
                                     "--disable-background-timer-throttling", "--disable-renderer-backgrounding",
                                     "--window-size=860,600"], creationflags=NOWIN)
        else:
            webbrowser.open(url)
    t0 = time.time()
    while True:                                           # wie Diotopo: Fenster zu → Assistent beendet
        time.sleep(0.5)
        now = time.time()
        if app.bye_at and now - app.bye_at > 3 and app.last_seen < app.bye_at:
            break
        if now - app.last_seen > 20 and now - t0 > 30:
            break
    app.b.stop()
    srv.shutdown()
    if proc is not None and proc.poll() is None and os.name == "nt":
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, creationflags=NOWIN)
    os._exit(0)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "installer",
         sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "entwicklung", "setup-exe"))
