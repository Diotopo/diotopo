@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Diotopo Web

set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY goto nopython

rem Use the own program file "Diotopo Web.exe" so that Task Manager shows "Diotopo Web"
set "EXE="
for /f "usebackq delims=" %%E in (`%PY% "%~dp0diotopo_web.py" --programmdatei`) do set "EXE=%%E"
if not defined EXE goto plain
"%EXE%" "%~dp0diotopo_web.py" %*
goto finished
:plain
%PY% "%~dp0diotopo_web.py" %*
:finished
if errorlevel 1 pause
exit /b 0

:nopython
echo.
echo Python was not found.
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo and tick "Add python.exe to PATH". Then start this file again.
pause
exit /b 1
