@echo off
rem Install Diotopo: starts the installation wizard (window, no administrator rights needed)
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command "try { & '%~dp0app\setup\installer.ps1' } catch { Add-Type -AssemblyName System.Windows.Forms; [void][System.Windows.Forms.MessageBox]::Show($_.ToString(), 'Diotopo') }"
