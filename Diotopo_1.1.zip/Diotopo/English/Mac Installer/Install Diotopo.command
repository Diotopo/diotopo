#!/bin/bash
# Diotopo – installation wizard for macOS (11 Big Sur or newer, Intel and Apple silicon)
# Start: double-click in Finder (the first time: right-click → “Open”).
# Steps: 1. target folder  2. detect and install everything needed  3. desktop shortcut?  4. start?
# Unattended in a terminal:  bash "Install Diotopo.command" --yes [--target FOLDER] [--no-desktop] [--offline]
set -u

T_TITEL="Install Diotopo"
T_ZIEL_FRAGE="Where should Diotopo be installed?"
T_LIZENZ_HINWEIS="By clicking 'Install' you accept the license terms."
T_ZIEL_ALLE="Applications (for all users, administrator password needed)"
T_ZIEL_ICH="My Applications (~/Applications, only for me)"
T_ZIEL_ANDERER="Other folder …"
T_LIZENZ_ZEIGEN="Show license terms"
T_ZIEL_WAEHLEN="Choose a folder for Diotopo"
T_INSTALLIEREN="Install"
T_ABBRECHEN="Cancel"
T_ZIEL_UNGUELTIG="This folder is not writable:"
T_JA="Yes"
T_NEIN="No"
T_BITTE_WARTEN="Installing Diotopo … setting up Python, numpy, scipy, pyopencl and OpenCASCADE. This can take a few minutes. This Terminal window shows the progress."
T_PYTHON_LADEN="Python 3.10 or newer is missing and will now be installed from python.org. macOS will ask for the administrator password."
T_KEIN_PYTHON="Python could not be installed.\n\nPlease install Python from python.org (“macOS 64-bit universal2 installer”) and then start the wizard again."
T_PYTHON_OEFFNEN="Open python.org"
T_PIP_FEHLER="The required packages numpy and scipy could not be installed (no internet connection?). Please check the internet connection and start the wizard again."
T_OPT_FEHLER="Note: this additional feature could not be installed (Diotopo still works):"
T_KEIN_PROGRAMM="The program files were not found. The “app” folder must be next to this wizard."
T_FERTIG="Diotopo has been installed:"
T_FERTIG_HINWEIS="You can find Diotopo in Finder under Applications, in Launchpad and in Spotlight."
T_FRAGE_DESKTOP="Should a shortcut be created on the desktop?"
T_FRAGE_START="Should Diotopo be started now?"
T_KEIN_BROWSER="Note: For a separate program window Google Chrome, Microsoft Edge or Brave is recommended. Without them Diotopo opens in Safari."
T_ABBRUCH="Installation cancelled."
T_DEINST_FRAGE="Really remove Diotopo? Your settings are kept."
T_DEINST_FERTIG="Diotopo has been removed."
T_DEINST_NICHT="Diotopo was not found."
T_DEFEKT="Diotopo needs to be reinstalled (the Python environment is missing or Python was updated). Please run “Install Diotopo.command” again."
T_ENTFERNEN="Remove"

HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="Diotopo"
BUNDLE_ID="de.diotopo.app"
PY_VERSIONEN="3.13.16 3.13.15 3.13.14 3.13.12"

AUTO=0; ZIEL=""; DESKTOP=""; OFFLINE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --ja|--yes) AUTO=1 ;;
    --ziel|--target) shift; ZIEL="${1:-}" ;;
    --ohne-desktop|--no-desktop) DESKTOP=0 ;;
    --offline) OFFLINE=1 ;;
  esac
  shift
done
GUI=0
[ "$AUTO" != 1 ] && [ "$(uname)" = "Darwin" ] && command -v osascript >/dev/null 2>&1 && GUI=1

# ---------------------------------------------------------------- Dialoge (AppleScript)
as_text() { printf '%b' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'; }
knopf() {  # knopf TEXT KNOPF1(Abbruch) KNOPF2(Standard) -> gibt gedrückten Knopf aus, leer bei Abbruch
  if [ "$GUI" = 1 ]; then
    osascript -e "button returned of (display dialog \"$(as_text "$1")\" with title \"$T_TITEL\" buttons {\"$2\", \"$3\"} default button \"$3\" cancel button \"$2\" with icon note)" 2>/dev/null
  else
    if [ "$AUTO" = 1 ]; then echo "$3"; return; fi
    printf '\n%b\n  1) %s   2) %s  > ' "$1" "$2" "$3" >&2
    read -r a; [ "$a" = 1 ] && echo "$2" || echo "$3"
  fi
}
info() {
  if [ "$GUI" = 1 ]; then
    osascript -e "display dialog \"$(as_text "$1")\" with title \"$T_TITEL\" buttons {\"OK\"} default button \"OK\" with icon note" >/dev/null 2>&1
  else printf '\n%b\n' "$1"; fi
}
fehler() {
  if [ "$GUI" = 1 ]; then
    osascript -e "display dialog \"$(as_text "$1")\" with title \"$T_TITEL\" buttons {\"OK\"} default button \"OK\" with icon stop" >/dev/null 2>&1
  else printf '\n%b\n' "$1" >&2; fi
  exit 1
}
janein() {  # janein FRAGE STANDARD(1/0) -> 0 = ja
  if [ "$AUTO" = 1 ]; then [ "$2" = 1 ]; return; fi
  if [ "$GUI" = 1 ]; then
    d="$T_NEIN"; [ "$2" = 1 ] && d="$T_JA"
    r="$(osascript -e "button returned of (display dialog \"$(as_text "$1")\" with title \"$T_TITEL\" buttons {\"$T_NEIN\", \"$T_JA\"} default button \"$d\" with icon note)" 2>/dev/null)"
    [ "$r" = "$T_JA" ]
  else
    printf '\n%b [%s/%s] ' "$1" "$T_JA" "$T_NEIN"; read -r a
    case "$a" in "") [ "$2" = 1 ] ;; [jJyY]*) return 0 ;; *) return 1 ;; esac
  fi
}
admin() {  # admin BEFEHL – mit Administratorrechten ausführen
  if [ "$(id -u)" = 0 ]; then sh -c "$1"
  elif [ "$GUI" = 1 ]; then osascript -e "do shell script \"$(as_text "$1")\" with administrator privileges" >/dev/null 2>&1
  else sudo sh -c "$1"; fi
}

# ---------------------------------------------------------------- Deinstallation
case "$(basename "$0")" in *deinstallieren*|*[Uu]ninstall*) DEINST=1 ;; *) DEINST=0 ;; esac
if [ "$DEINST" = 1 ]; then
  APPS=()
  for d in "/Applications/$APP.app" "$HOME/Applications/$APP.app"; do [ -d "$d" ] && APPS+=("$d"); done
  # Aufruf aus dem Programmpaket heraus: genau dieses entfernen
  case "$HIER" in */"$APP.app"/Contents/Resources) APPS=("$(cd "$HIER/../.." && pwd)") ;; esac
  [ ${#APPS[@]} -gt 0 ] || fehler "$T_DEINST_NICHT"
  r="$(knopf "$T_DEINST_FRAGE\n\n${APPS[*]}" "$T_ABBRECHEN" "$T_ENTFERNEN")"; [ "$r" = "$T_ENTFERNEN" ] || exit 0
  for a in "${APPS[@]}"; do
    case "$a" in */"$APP.app") ;; *) continue ;; esac
    if [ -w "$(dirname "$a")" ]; then rm -rf "$a"; else admin "rm -rf '$a'"; fi
  done
  for l in "$HOME/Desktop/$APP" "$HOME/Desktop/$APP.app"; do
    if [ -L "$l" ] || [ -f "$l" ]; then rm -f "$l"; fi
  done
  info "$T_DEINST_FERTIG"
  exit 0
fi

# ---------------------------------------------------------------- Programmdateien
if [ -f "$HIER/app/Diotopo.pyw" ]; then QUELLE="$HIER/app"
elif [ -f "$HIER/../Browser Version/Diotopo.pyw" ]; then QUELLE="$(cd "$HIER/../Browser Version" && pwd)"
else fehler "$T_KEIN_PROGRAMM"; fi
VERSION="$(sed -n 's/^VERSION *= *"\([^"]*\)".*/\1/p' "$QUELLE/diotopo/server.py" | head -n1)"
LIZ="$QUELLE/LIZENZ.txt"; [ -f "$LIZ" ] || LIZ="$QUELLE/LICENSE.txt"

# ================================================================ 1. Zielordner
if [ -z "$ZIEL" ]; then
  ZIEL="/Applications"
  if [ "$AUTO" != 1 ]; then
    if [ "$GUI" = 1 ]; then
      while :; do
        w="$(osascript -e "choose from list {\"$T_ZIEL_ALLE\", \"$T_ZIEL_ICH\", \"$T_ZIEL_ANDERER\", \"$T_LIZENZ_ZEIGEN\"} with title \"$T_TITEL\" with prompt \"$T_ZIEL_FRAGE

$T_LIZENZ_HINWEIS\" default items {\"$T_ZIEL_ALLE\"} OK button name \"$T_INSTALLIEREN\" cancel button name \"$T_ABBRECHEN\"" 2>/dev/null)"
        case "$w" in
          "$T_ZIEL_ALLE") ZIEL="/Applications"; break ;;
          "$T_ZIEL_ICH") ZIEL="$HOME/Applications"; break ;;
          "$T_ZIEL_ANDERER")
            ZIEL="$(osascript -e "POSIX path of (choose folder with prompt \"$T_ZIEL_WAEHLEN\" default location (path to applications folder))" 2>/dev/null)" || fehler "$T_ABBRUCH"
            ZIEL="${ZIEL%/}"; break ;;
          "$T_LIZENZ_ZEIGEN") open -e "$LIZ" 2>/dev/null ;;
          *) fehler "$T_ABBRUCH" ;;
        esac
      done
    else
      printf '\n%s\n%s\n%s [%s]: ' "$T_TITEL" "$T_LIZENZ_HINWEIS ($LIZ)" "$T_ZIEL_FRAGE" "$ZIEL"; read -r w
      [ -n "$w" ] && ZIEL="${w/#\~/$HOME}"
    fi
  fi
fi
mkdir -p "$ZIEL" 2>/dev/null || [ -d "$ZIEL" ] || admin "mkdir -p '$ZIEL'"
ZIEL="$(cd "$ZIEL" 2>/dev/null && pwd)" || fehler "$T_ZIEL_UNGUELTIG\n$ZIEL"
ZAPP="$ZIEL/$APP.app"
if [ ! -w "$ZIEL" ] && { [ ! -d "$ZAPP" ] || [ ! -w "$ZAPP" ]; }; then
  # Schreibrecht nur für das Programmpaket holen (einmal Kennwort), danach gehört es dem Benutzer
  admin "mkdir -p '$ZAPP' && chown -R $(id -u):$(id -g) '$ZAPP'" || fehler "$T_ZIEL_UNGUELTIG\n$ZIEL"
  [ -w "$ZAPP" ] || fehler "$T_ZIEL_UNGUELTIG\n$ZIEL"
fi

# ================================================================ 2. Alles Benötigte feststellen und installieren
printf '\n%b\n\n' "$T_BITTE_WARTEN"
[ "$GUI" = 1 ] && osascript -e "display notification \"$(as_text "$T_BITTE_WARTEN")\" with title \"$T_TITEL\"" >/dev/null 2>&1

# Python suchen (das /usr/bin/python3 von Apple ist oft 3.9 oder nur ein Platzhalter)
finde_python() {
  PY=""
  local k=()
  for v in 3.14 3.13 3.12 3.11 3.10; do k+=("/Library/Frameworks/Python.framework/Versions/$v/bin/python3"); done
  k+=(/opt/homebrew/bin/python3 /usr/local/bin/python3 "$(command -v python3 2>/dev/null)")
  for p in "${k[@]}"; do
    [ -n "$p" ] && [ -x "$p" ] || continue
    if "$p" -c 'import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then PY="$p"; return 0; fi
  done
  return 1
}
if ! finde_python; then
  [ "$OFFLINE" = 1 ] && fehler "$T_KEIN_PYTHON"
  info "$T_PYTHON_LADEN"
  PKG="${TMPDIR:-/tmp}/diotopo_python.pkg"
  for v in $PY_VERSIONEN; do
    echo "python.org: Python $v …"
    if curl -fL --retry 2 -o "$PKG" "https://www.python.org/ftp/python/$v/python-$v-macos11.pkg"; then
      admin "installer -pkg '$PKG' -target /" && break
    fi
  done
  rm -f "$PKG"
  if ! finde_python; then
    if [ "$GUI" = 1 ]; then
      r="$(knopf "$T_KEIN_PYTHON" "$T_ABBRECHEN" "$T_PYTHON_OEFFNEN")"
      [ "$r" = "$T_PYTHON_OEFFNEN" ] && open "https://www.python.org/downloads/macos/"
      exit 1
    fi
    fehler "$T_KEIN_PYTHON"
  fi
fi

# Programmpaket Diotopo.app zuerst in einem Arbeitsordner bauen
ARBEIT="$(mktemp -d "${TMPDIR:-/tmp}/diotopo_inst.XXXXXX")"
trap 'rm -rf "$ARBEIT"' EXIT
NEU="$ARBEIT/$APP.app"
C="$NEU/Contents"
R="$C/Resources"
mkdir -p "$C/MacOS" "$R/app"
for f in diotopo web Lizenzen Licenses Diotopo.pyw diotopo_web.py gpu_test.py LIZENZ.txt LICENSE.txt requirements.txt; do
  [ -e "$QUELLE/$f" ] && cp -R "$QUELLE/$f" "$R/app/"
done
find "$R/app" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null
for i in "$QUELLE/Diotopo.icns" "$HIER/Diotopo.icns"; do [ -f "$i" ] && cp "$i" "$R/Diotopo.icns" && break; done
cp "$0" "$R/Uninstall Diotopo.command"; chmod +x "$R/Uninstall Diotopo.command"

cat > "$C/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>Diotopo</string>
  <key>CFBundleDisplayName</key><string>Diotopo</string>
  <key>CFBundleIdentifier</key><string>$BUNDLE_ID</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleSignature</key><string>DTPO</string>
  <key>CFBundleExecutable</key><string>Diotopo</string>
  <key>CFBundleIconFile</key><string>Diotopo</string>
  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>LSApplicationCategoryType</key><string>public.app-category.graphics-design</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSHumanReadableCopyright</key><string>Diotopo</string>
</dict>
</plist>
EOF

# Startprogramm im Paket: findet seine Python-Umgebung relativ zum Paket
cat > "$C/MacOS/Diotopo" <<'EOF'
#!/bin/bash
R="$(cd "$(dirname "$0")/../Resources" && pwd)"
PY="$R/venv/bin/python3"
if ! "$PY" -c 'import numpy, scipy' >/dev/null 2>&1; then
  osascript -e "display dialog \"$(cat "$R/defekt.txt")\" with title \"Diotopo\" buttons {\"OK\"} default button \"OK\" with icon stop" >/dev/null 2>&1
  exit 1
fi
exec "$PY" "$R/app/Diotopo.pyw" "$@"
EOF
chmod +x "$C/MacOS/Diotopo"
printf '%s' "$T_DEFEKT" > "$R/defekt.txt"

# Python-Umgebung direkt am Zielort anlegen (venv enthält absolute Pfade)
LOG="$ARBEIT/installation.log"
installieren() {
  set -e
  mkdir -p "$ZAPP"
  local V="$ZAPP/Contents/Resources/venv"
  if [ -d "$V" ] && "$V/bin/python3" -c 'import numpy, scipy' 2>/dev/null; then
    mv "$V" "$R/venv"                                     # vorhandene Umgebung bei Aktualisierung übernehmen
  fi
  rm -rf "$ZAPP/Contents"
  mv "$C" "$ZAPP/Contents"
  if [ ! -x "$V/bin/python3" ]; then
    if [ "$OFFLINE" = 1 ]; then "$PY" -m venv --system-site-packages "$V"; else "$PY" -m venv "$V"; fi
  fi
  set +e
  if [ "$OFFLINE" != 1 ]; then
    "$V/bin/python3" -m pip install --disable-pip-version-check --upgrade -r "$ZAPP/Contents/Resources/app/requirements.txt"
    "$V/bin/python3" -m pip install --disable-pip-version-check pyopencl || echo "OPT_FEHLT pyopencl"
    "$V/bin/python3" -m pip install --disable-pip-version-check cadquery-ocp-novtk || echo "OPT_FEHLT cadquery-ocp-novtk"
  fi
  "$V/bin/python3" -c 'import numpy, scipy' || echo "PIP_FEHLER"
  "$V/bin/python3" -m compileall -q "$ZAPP/Contents/Resources/app/diotopo" >/dev/null 2>&1
  xattr -dr com.apple.quarantine "$ZAPP" 2>/dev/null
  touch "$ZAPP"
  return 0
}
installieren 2>&1 | tee "$LOG"
cp "$LOG" "$ZAPP/Contents/Resources/installation.log" 2>/dev/null
grep -q '^PIP_FEHLER' "$LOG" && fehler "$T_PIP_FEHLER"
[ -x "$ZAPP/Contents/MacOS/Diotopo" ] || fehler "$T_PIP_FEHLER"

TXT="$T_FERTIG\n$ZAPP\n\n$T_FERTIG_HINWEIS"
OPT="$(sed -n 's/^OPT_FEHLT //p' "$LOG" | xargs)"
[ -n "$OPT" ] && TXT="$TXT\n\n$T_OPT_FEHLER $OPT"
B=0
for b in "Google Chrome" "Microsoft Edge" "Chromium" "Brave Browser"; do
  [ -d "/Applications/$b.app" ] || [ -d "$HOME/Applications/$b.app" ] && B=1
done
[ "$B" = 0 ] && TXT="$TXT\n\n$T_KEIN_BROWSER"

# ================================================================ 3. Desktop-Verknüpfung?
[ "$AUTO" = 1 ] && printf '\n%b\n' "$TXT"
if [ -z "$DESKTOP" ]; then
  if janein "$TXT\n\n$T_FRAGE_DESKTOP" 1; then DESKTOP=1; else DESKTOP=0; fi
fi
if [ "$DESKTOP" = 1 ]; then
  mkdir -p "$HOME/Desktop" 2>/dev/null
  rm -f "$HOME/Desktop/$APP" "$HOME/Desktop/$APP.app" 2>/dev/null
  if [ "$GUI" = 1 ]; then
    osascript -e "tell application \"Finder\" to make alias file to POSIX file \"$ZAPP\" at desktop" >/dev/null 2>&1 \
      || ln -s "$ZAPP" "$HOME/Desktop/$APP"
  else
    ln -s "$ZAPP" "$HOME/Desktop/$APP"
  fi
fi

# ================================================================ 4. Jetzt starten?
[ "$AUTO" = 1 ] && exit 0
if janein "$T_FRAGE_START" 1; then
  if [ "$(uname)" = "Darwin" ]; then open "$ZAPP"; else nohup "$ZAPP/Contents/MacOS/Diotopo" >/dev/null 2>&1 & fi
fi
if [ "$GUI" = 1 ]; then
  # Terminalfenster des Doppelklicks schließen
  osascript -e 'tell application "Terminal" to close (every window whose name contains "Install Diotopo")' >/dev/null 2>&1 &
fi
exit 0
