﻿# Diotopo – Installationsassistent für Windows 10/11 (PowerShell + Windows Forms, ohne Administratorrechte)
# Start über „Diotopo installieren.cmd“. Ablauf:
#   1. Zielordner wählen   2. alles Benötigte feststellen und installieren (eigenes Python, numpy, scipy,
#   pyopencl, OpenCASCADE)   3. Desktop-Verknüpfung?   4. Diotopo starten?
# Deinstallation: Windows-Einstellungen > Apps > Diotopo (ruft dieses Skript mit -Deinstallieren auf).
param([switch]$Deinstallieren, [string]$Ziel = "", [switch]$Kopie)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
trap {
    $m = ($_ | Out-String)
    try { Set-Content -LiteralPath (Join-Path $env:TEMP "diotopo_installer_fehler.txt") -Value $m -Encoding UTF8 } catch {}
    [void][System.Windows.Forms.MessageBox]::Show($m, "Diotopo", "OK", "Error")
    exit 1
}
[System.Windows.Forms.Application]::EnableVisualStyles()
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$T = @{
    Titel          = "Diotopo installieren"
    Untertitel     = "Topologieoptimierung"
    ZielFrage      = "Wohin soll Diotopo installiert werden?"
    Durchsuchen    = "Durchsuchen …"
    OrdnerWaehlen  = "Ordner für Diotopo wählen"
    LizenzHinweis  = "Mit »Installieren« akzeptieren Sie die Lizenzbedingungen."
    LizenzLink     = "Lizenzbedingungen anzeigen"
    Installieren   = "Installieren"
    Abbrechen      = "Abbrechen"
    Ja             = "Ja"
    Nein           = "Nein"
    Schliessen     = "Schließen"
    Wiederholen    = "Erneut versuchen"
    Details        = "Details"
    Wird           = "Diotopo wird installiert …"
    Kopieren       = "Programmdateien kopieren"
    PythonPruefen  = "Python prüfen"
    PythonLaden    = "Python herunterladen"
    PythonEntpacken= "Python einrichten"
    PipLaden       = "Paketverwaltung (pip) einrichten"
    Pakete         = "Rechenpakete installieren: numpy, scipy"
    PaketGpu       = "Grafikkarten-Unterstützung installieren: pyopencl"
    PaketStep      = "STEP-Import installieren: OpenCASCADE (größerer Download)"
    Pruefen        = "Installation prüfen"
    Verknuepfung   = "Startmenü-Eintrag anlegen"
    Fertig         = "Diotopo wurde installiert in:"
    FrageDesktop   = "Soll eine Verknüpfung auf dem Desktop erstellt werden?"
    FrageStart     = "Soll Diotopo jetzt gestartet werden?"
    OptFehlt       = "Hinweis: Diese Zusatzfunktion ließ sich nicht installieren (Diotopo läuft trotzdem):"
    NichtSchreibbar= "In diesen Ordner kann nicht geschrieben werden. Bitte einen Ordner im eigenen Benutzerbereich wählen oder den Installer mit Rechtsklick »Als Administrator ausführen« starten."
    Fehler         = "Die Installation ist fehlgeschlagen:"
    KeinInternet   = "Python konnte nicht heruntergeladen werden. Besteht eine Internetverbindung?"
    PipFehler      = "Die Rechenpakete numpy und scipy konnten nicht installiert werden. Besteht eine Internetverbindung?"
    Architektur    = "Diotopo braucht ein 64-Bit-Windows (x64 oder ARM64)."
    KeineDateien   = "Die Programmdateien wurden nicht gefunden (Ordner »app« neben »Diotopo installieren.cmd«)."
    DeinstTitel    = "Diotopo deinstallieren"
    DeinstFrage    = "Diotopo wirklich entfernen? Ihre Einstellungen und Projekte bleiben erhalten."
    DeinstFertig   = "Diotopo wurde entfernt."
    Startmenue     = "Diotopo"
    Kommentar      = "Topologieoptimierung"
}

$APP = "Diotopo"
$REGKEY = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Diotopo"
$PY_VERSIONEN = @("3.13.16", "3.13.15", "3.13.14", "3.13.12", "3.13.11")
$HIER = $PSScriptRoot                           # …\app\setup bzw. <Installationsordner>\setup
$QUELLE = Split-Path -Parent $HIER              # …\app bzw. <Installationsordner>

function Read-Version {
    try {
        $m = Select-String -Path (Join-Path $QUELLE "diotopo\server.py") -Pattern '^VERSION\s*=\s*"([^"]+)"' | Select-Object -First 1
        return $m.Matches[0].Groups[1].Value
    } catch { return "" }
}
$VERSION = Read-Version

function New-Font([float]$size, [System.Drawing.FontStyle]$style = [System.Drawing.FontStyle]::Regular) {
    return New-Object System.Drawing.Font("Segoe UI", $size, $style)
}

function Stop-Diotopo([string]$dir) {
    # laufende Programme aus diesem Ordner beenden (Aktualisierung/Deinstallation)
    try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($dir.TrimEnd("\") + "\", [StringComparison]::OrdinalIgnoreCase) } |
            ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue } catch {} }
    } catch {}
}

function Msg([string]$text, [string]$icon = "Information") {
    [void][System.Windows.Forms.MessageBox]::Show($text, $T.Titel, "OK", $icon)
}

# ============================================================================ Deinstallation
if ($Deinstallieren) {
    if (-not $Ziel) { $Ziel = Split-Path -Parent $PSScriptRoot }
    if (-not $Kopie) {
        # aus einer Kopie in %TEMP% laufen, damit der Installationsordner gelöscht werden kann
        $tmp = Join-Path $env:TEMP "diotopo_deinstallieren.ps1"
        Copy-Item -LiteralPath $PSCommandPath -Destination $tmp -Force
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass",
            "-File", "`"$tmp`"", "-Deinstallieren", "-Kopie", "-Ziel", "`"$Ziel`"")
        exit 0
    }
    $r = [System.Windows.Forms.MessageBox]::Show($T.DeinstFrage + "`n`n" + $Ziel, $T.DeinstTitel, "YesNo", "Question")
    if ($r -ne "Yes") { exit 0 }
    Stop-Diotopo $Ziel
    Start-Sleep -Milliseconds 500
    foreach ($lnk in @((Join-Path ([Environment]::GetFolderPath("Programs")) "$APP.lnk"),
                       (Join-Path ([Environment]::GetFolderPath("Desktop")) "$APP.lnk"))) {
        if (Test-Path -LiteralPath $lnk) { Remove-Item -LiteralPath $lnk -Force -ErrorAction SilentlyContinue }
    }
    Remove-Item -Path $REGKEY -Recurse -Force -ErrorAction SilentlyContinue
    # nur Diotopo-Ordner löschen (Sicherheitsprüfung: dort muss Diotopo.pyw liegen)
    if ((Test-Path -LiteralPath (Join-Path $Ziel "Diotopo.pyw")) -and (Split-Path -Leaf $Ziel) -ieq $APP) {
        Remove-Item -LiteralPath $Ziel -Recurse -Force -ErrorAction SilentlyContinue
    }
    Msg $T.DeinstFertig
    exit 0
}

# ============================================================================ Fenster
$form = New-Object System.Windows.Forms.Form
$form.Text = $T.Titel
$form.ClientSize = New-Object System.Drawing.Size(640, 400)
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.StartPosition = "CenterScreen"
$form.Font = New-Font 9.5
$form.BackColor = [System.Drawing.Color]::White
$ico = Join-Path $QUELLE "icon.ico"
if (Test-Path -LiteralPath $ico) { try { $form.Icon = New-Object System.Drawing.Icon($ico) } catch {} }

# linke Leiste mit Dio
$side = New-Object System.Windows.Forms.Panel
$side.SetBounds(0, 0, 180, 400)
$side.BackColor = [System.Drawing.Color]::FromArgb(27, 31, 39)
$form.Controls.Add($side)
$dio = Join-Path $QUELLE "web\dio.png"
if (Test-Path -LiteralPath $dio) {
    $pic = New-Object System.Windows.Forms.PictureBox
    $pic.SetBounds(25, 90, 130, 130)
    $pic.SizeMode = "Zoom"
    $pic.BackColor = [System.Drawing.Color]::Transparent
    try { $pic.Image = [System.Drawing.Image]::FromFile($dio) } catch {}
    $side.Controls.Add($pic)
}
$lblApp = New-Object System.Windows.Forms.Label
$lblApp.Text = "Diotopo"
$lblApp.Font = New-Font 16 ([System.Drawing.FontStyle]::Bold)
$lblApp.ForeColor = [System.Drawing.Color]::FromArgb(230, 233, 239)
$lblApp.TextAlign = "MiddleCenter"
$lblApp.SetBounds(0, 230, 180, 34)
$side.Controls.Add($lblApp)
$lblSub = New-Object System.Windows.Forms.Label
$lblSub.Text = $T.Untertitel + $(if ($VERSION) { "`n" + $VERSION } else { "" })
$lblSub.ForeColor = [System.Drawing.Color]::FromArgb(152, 161, 179)
$lblSub.TextAlign = "TopCenter"
$lblSub.SetBounds(0, 266, 180, 40)
$side.Controls.Add($lblSub)

# Inhalt rechts
$head = New-Object System.Windows.Forms.Label
$head.Font = New-Font 13 ([System.Drawing.FontStyle]::Bold)
$head.SetBounds(200, 20, 420, 30)
$form.Controls.Add($head)
$text = New-Object System.Windows.Forms.Label
$text.SetBounds(200, 58, 420, 60)
$form.Controls.Add($text)

$box = New-Object System.Windows.Forms.TextBox
$box.SetBounds(200, 120, 300, 26)
$form.Controls.Add($box)
$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = $T.Durchsuchen
$btnBrowse.SetBounds(508, 119, 112, 28)
$form.Controls.Add($btnBrowse)
$lic = New-Object System.Windows.Forms.Label
$lic.Text = $T.LizenzHinweis
$lic.SetBounds(200, 168, 420, 22)
$form.Controls.Add($lic)
$link = New-Object System.Windows.Forms.LinkLabel
$link.Text = $T.LizenzLink
$link.SetBounds(200, 192, 420, 22)
$form.Controls.Add($link)

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.SetBounds(200, 124, 420, 20)
$bar.Minimum = 0
$bar.Maximum = 100
$form.Controls.Add($bar)
$log = New-Object System.Windows.Forms.TextBox
$log.Multiline = $true
$log.ScrollBars = "Vertical"
$log.ReadOnly = $true
$log.Font = New-Object System.Drawing.Font("Consolas", 8.5)
$log.SetBounds(200, 156, 420, 180)
$form.Controls.Add($log)

$btn1 = New-Object System.Windows.Forms.Button
$btn1.SetBounds(400, 352, 105, 32)
$form.Controls.Add($btn1)
$btn2 = New-Object System.Windows.Forms.Button
$btn2.SetBounds(515, 352, 105, 32)
$form.Controls.Add($btn2)

$script:aktion = ""
$script:busy = $false
$btn1.Add_Click({ $script:aktion = "1" })
$btn2.Add_Click({ $script:aktion = "2" })
$form.Add_FormClosing({
    if ($script:busy) { $_.Cancel = $true; return }          # während der Installation nicht schließen
    if ($script:aktion -eq "") { $script:aktion = "x" }
})

function Show-Page([string]$page) {
    $isZiel = $page -eq "ziel"
    $isArbeit = $page -eq "arbeit"
    foreach ($c in @($box, $btnBrowse, $lic, $link)) { $c.Visible = $isZiel }
    $bar.Visible = $isArbeit -or $page -eq "fehler"
    $log.Visible = $isArbeit -or $page -eq "fehler"
    $btn1.Visible = $true
    $btn2.Visible = $true
    $btn1.Enabled = -not $isArbeit
    $btn2.Enabled = -not $isArbeit
    [System.Windows.Forms.Application]::DoEvents()
}

function Wait-Action {
    $script:aktion = ""
    while ($script:aktion -eq "") {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 30
    }
    return $script:aktion
}

function Log([string]$s) {
    if ($null -eq $s) { return }
    $s = $s.TrimEnd()
    if ($s -eq "") { return }
    $log.AppendText(($s -replace "`r?`n", "`r`n") + "`r`n")
    [System.Windows.Forms.Application]::DoEvents()
}

function Step([string]$s, [int]$pct) {
    $text.Text = $s
    $bar.Value = [Math]::Min(100, [Math]::Max(0, $pct))
    Log ("» " + $s)
}

function Run-Proc([string]$exe, [string[]]$argList) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.Arguments = ($argList | ForEach-Object { if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ } }) -join " "
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.EnvironmentVariables["PYTHONNOUSERSITE"] = "1"
    $psi.EnvironmentVariables["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    $p = [System.Diagnostics.Process]::Start($psi)
    $o = $p.StandardOutput.ReadToEndAsync()
    $e = $p.StandardError.ReadToEndAsync()
    while (-not $p.HasExited) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 50
    }
    $p.WaitForExit()
    $out = ($o.Result + "`n" + $e.Result).Trim()
    if ($out) {
        $lines = $out -split "`r?`n" | Where-Object { $_ -notmatch "^\s*(Downloading|Collecting|Using cached|━|\|)" }
        Log (($lines | Select-Object -Last 12) -join "`n")
    }
    return $p.ExitCode
}

function Get-File([string]$url, [string]$dest) {
    $wc = New-Object System.Net.WebClient
    $wc.Headers.Add("User-Agent", "Diotopo-Installer")
    $task = $wc.DownloadFileTaskAsync($url, $dest)
    while (-not $task.IsCompleted) {
        [System.Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 50
    }
    if ($task.IsFaulted) { throw $task.Exception.GetBaseException() }
}

# ============================================================================ 1. Zielordner
$standard = Join-Path $env:LOCALAPPDATA "Programs\$APP"
if (Test-Path -LiteralPath $REGKEY) {
    try { $alt = (Get-ItemProperty -Path $REGKEY).InstallLocation; if ($alt) { $standard = $alt } } catch {}
}
$box.Text = $standard
$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = $T.OrdnerWaehlen
    $dlg.ShowNewFolderButton = $true
    if ($dlg.ShowDialog($form) -eq "OK") {
        $p = $dlg.SelectedPath
        if ((Split-Path -Leaf $p) -ine $APP) { $p = Join-Path $p $APP }
        $box.Text = $p
    }
})
$link.Add_LinkClicked({
    $lf = @("LIZENZ.txt", "LICENSE.txt") | ForEach-Object { Join-Path $QUELLE $_ } | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
    if ($lf) { Start-Process notepad.exe -ArgumentList "`"$lf`"" }
})

if (-not (Test-Path -LiteralPath (Join-Path $QUELLE "Diotopo.pyw"))) { Msg $T.KeineDateien "Error"; exit 1 }

$form.Show()
$head.Text = $T.Titel
$text.Text = $T.ZielFrage
$btn1.Text = $T.Installieren
$btn2.Text = $T.Abbrechen
$form.AcceptButton = $btn1
Show-Page "ziel"
$a = Wait-Action
if ($a -ne "1") { $form.Close(); exit 0 }
$ZIEL = $box.Text.Trim().TrimEnd("\")
if ((Split-Path -Leaf $ZIEL) -ine $APP) { $ZIEL = Join-Path $ZIEL $APP }

# ============================================================================ 2. Installieren
$OPTFEHLT = @()
function Install-All {
    $script:OPTFEHLT = @()
    $arch = $env:PROCESSOR_ARCHITECTURE
    if ($env:PROCESSOR_ARCHITEW6432) { $arch = $env:PROCESSOR_ARCHITEW6432 }
    switch ($arch) { "AMD64" { $parch = "amd64" } "ARM64" { $parch = "arm64" } default { throw $T.Architektur } }

    # Zielordner prüfen
    try {
        New-Item -ItemType Directory -Force -Path $ZIEL | Out-Null
        $probe = Join-Path $ZIEL ".schreibtest"
        Set-Content -LiteralPath $probe -Value "x"
        Remove-Item -LiteralPath $probe -Force
    } catch { throw $T.NichtSchreibbar }

    # laufendes Diotopo aus diesem Ordner beenden (Aktualisierung)
    Stop-Diotopo $ZIEL

    Step $T.Kopieren 5
    if ($QUELLE -ine $ZIEL) {
        Get-ChildItem -LiteralPath $QUELLE -Force | ForEach-Object {
            $alteDatei = Join-Path $ZIEL $_.Name
            if (Test-Path -LiteralPath $alteDatei) { Remove-Item -LiteralPath $alteDatei -Recurse -Force }   # alte Fassung ersetzen
            Copy-Item -LiteralPath $_.FullName -Destination $ZIEL -Recurse -Force
        }
    }

    # eigenes Python (Windows-„embeddable“-Paket von python.org) im Unterordner python
    $PYDIR = Join-Path $ZIEL "python"
    $PY = Join-Path $PYDIR "python.exe"
    Step $T.PythonPruefen 10
    $ok = $false
    if (Test-Path -LiteralPath $PY) {
        $ok = (Run-Proc $PY @("-c", "import sys; assert sys.version_info >= (3, 10)")) -eq 0
    }
    if (-not $ok) {
        if (Test-Path -LiteralPath $PYDIR) { Remove-Item -LiteralPath $PYDIR -Recurse -Force }
        $zip = Join-Path $env:TEMP "diotopo_python.zip"
        $geladen = $false
        foreach ($v in $PY_VERSIONEN) {
            $url = "https://www.python.org/ftp/python/$v/python-$v-embed-$parch.zip"
            Step "$($T.PythonLaden) $v" 15
            try { Get-File $url $zip; $geladen = $true; break } catch { Log $_.Exception.Message }
        }
        if (-not $geladen) { throw $T.KeinInternet }
        Step $T.PythonEntpacken 25
        Expand-Archive -LiteralPath $zip -DestinationPath $PYDIR -Force
        Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
        # ._pth: Paketordner Lib\site-packages einbinden und „import site“ aktivieren
        $pth = Get-ChildItem -LiteralPath $PYDIR -Filter "python3*._pth" | Select-Object -First 1
        if ($pth) {
            $lines = Get-Content -LiteralPath $pth.FullName | ForEach-Object { if ($_ -match "^\s*#\s*import site") { "import site" } else { $_ } }
            if (-not ($lines -contains "Lib\site-packages")) { $lines = @($lines) + "Lib\site-packages" }
            if (-not ($lines -contains "import site")) { $lines = @($lines) + "import site" }
            Set-Content -LiteralPath $pth.FullName -Value $lines -Encoding ASCII
        }
        New-Item -ItemType Directory -Force -Path (Join-Path $PYDIR "Lib\site-packages") | Out-Null
        Step $T.PipLaden 30
        $gp = Join-Path $env:TEMP "diotopo_get-pip.py"
        try { Get-File "https://bootstrap.pypa.io/get-pip.py" $gp } catch { throw $T.KeinInternet }
        if ((Run-Proc $PY @($gp, "--no-warn-script-location")) -ne 0) { throw $T.PipFehler }
        Remove-Item -LiteralPath $gp -Force -ErrorAction SilentlyContinue
    }

    Step $T.Pakete 40
    $req = Join-Path $ZIEL "requirements.txt"
    $rc = Run-Proc $PY @("-m", "pip", "install", "--upgrade", "--no-warn-script-location", "--only-binary=:all:", "-r", $req)
    if ((Run-Proc $PY @("-c", "import numpy, scipy")) -ne 0) { throw $T.PipFehler }

    Step $T.PaketGpu 60
    if ((Run-Proc $PY @("-m", "pip", "install", "--upgrade", "--no-warn-script-location", "--only-binary=:all:", "pyopencl")) -ne 0) {
        $script:OPTFEHLT += "pyopencl"
    }
    Step $T.PaketStep 70
    if ((Run-Proc $PY @("-m", "pip", "install", "--upgrade", "--no-warn-script-location", "--only-binary=:all:", "cadquery-ocp-novtk")) -ne 0) {
        $script:OPTFEHLT += "cadquery-ocp-novtk"
    }

    # Diotopo.exe = Kopie von pythonw.exe mit Dio-Symbol (Task-Manager zeigt „Diotopo“)
    Step $T.Pruefen 90
    $EXE = Join-Path $PYDIR "Diotopo.exe"
    Copy-Item -LiteralPath (Join-Path $PYDIR "pythonw.exe") -Destination $EXE -Force
    $patch = "import sys; sys.path.insert(0, sys.argv[1]); from diotopo import runtime as R; R._patch_resources(sys.argv[2], sys.argv[3], 'Diotopo')"
    [void](Run-Proc $PY @("-c", $patch, $ZIEL, $EXE, (Join-Path $ZIEL "icon.ico")))
    [void](Run-Proc $PY @("-m", "compileall", "-q", (Join-Path $ZIEL "diotopo")))

    Step $T.Verknuepfung 95
    New-Shortcut (Join-Path ([Environment]::GetFolderPath("Programs")) "$APP.lnk")

    # Eintrag unter „Apps“ zum Deinstallieren
    New-Item -Path $REGKEY -Force | Out-Null
    $ps = Join-Path $env:SystemRoot "System32\WindowsPowerShell\v1.0\powershell.exe"
    $un = "`"$ps`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ZIEL\setup\installer.ps1`" -Deinstallieren"
    $size = [int]((Get-ChildItem -LiteralPath $ZIEL -Recurse -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum / 1KB)
    $props = @{ DisplayName = $APP; DisplayVersion = $VERSION; Publisher = $APP; DisplayIcon = "$ZIEL\icon.ico";
                InstallLocation = $ZIEL; UninstallString = $un; QuietUninstallString = $un }
    foreach ($k in $props.Keys) { Set-ItemProperty -Path $REGKEY -Name $k -Value $props[$k] }
    New-ItemProperty -Path $REGKEY -Name "NoModify" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $REGKEY -Name "NoRepair" -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $REGKEY -Name "EstimatedSize" -Value $size -PropertyType DWord -Force | Out-Null
    Step ($T.Fertig + " " + $ZIEL) 100
}

function New-Shortcut([string]$lnk) {
    $sh = New-Object -ComObject WScript.Shell
    $s = $sh.CreateShortcut($lnk)
    $s.TargetPath = Join-Path $ZIEL "python\Diotopo.exe"
    $s.Arguments = "`"" + (Join-Path $ZIEL "Diotopo.pyw") + "`""
    $s.WorkingDirectory = $ZIEL
    $s.IconLocation = (Join-Path $ZIEL "icon.ico") + ",0"
    $s.Description = $T.Kommentar
    $s.Save()
}

while ($true) {
    $head.Text = $T.Wird
    $log.Clear()
    Show-Page "arbeit"
    $btn1.Text = $T.Installieren
    $btn2.Text = $T.Abbrechen
    try {
        $script:busy = $true
        Install-All
        $script:busy = $false
        break
    } catch {
        $script:busy = $false
        $head.Text = $T.Fehler
        $text.Text = $_.Exception.Message
        Log ($_ | Out-String)
        Show-Page "fehler"
        $btn1.Text = $T.Wiederholen
        $btn2.Text = $T.Schliessen
        if ((Wait-Action) -ne "1") { $form.Close(); exit 1 }
    }
}

# ============================================================================ 3. Desktop-Verknüpfung?
$hinweis = ""
if ($OPTFEHLT.Count -gt 0) { $hinweis = "`n`n" + $T.OptFehlt + " " + ($OPTFEHLT -join ", ") }
$head.Text = $T.FrageDesktop
$text.Text = $T.Fertig + "`n" + $ZIEL + $hinweis
$text.Height = 120
Show-Page "frage"
$bar.Visible = $false
$log.Visible = $false
$btn1.Text = $T.Ja
$btn2.Text = $T.Nein
if ((Wait-Action) -eq "1") {
    try { New-Shortcut (Join-Path ([Environment]::GetFolderPath("Desktop")) "$APP.lnk") } catch { Msg $_.Exception.Message "Warning" }
} elseif ($script:aktion -eq "x") { exit 0 }

# ============================================================================ 4. Jetzt starten?
$head.Text = $T.FrageStart
Show-Page "frage"
$bar.Visible = $false
$log.Visible = $false
$btn1.Text = $T.Ja
$btn2.Text = $T.Nein
$a = Wait-Action
$form.Close()
if ($a -eq "1") {
    Start-Process -FilePath (Join-Path $ZIEL "python\Diotopo.exe") -ArgumentList "`"$(Join-Path $ZIEL 'Diotopo.pyw')`"" -WorkingDirectory $ZIEL
}
exit 0
