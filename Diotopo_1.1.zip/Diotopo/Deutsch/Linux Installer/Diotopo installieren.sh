#!/usr/bin/env bash
# Diotopo – Installationsassistent für Linux
# Start: Doppelklick (»Als Programm ausführen«) oder im Terminal:  bash "Diotopo installieren.sh"
# Ablauf: 1. Zielordner  2. alles Benötigte feststellen und installieren  3. Desktop-Verknüpfung?  4. Starten?
# Ohne Fenster (z. B. per SSH):  bash "Diotopo installieren.sh" --terminal
# Unbeaufsichtigt:               bash "Diotopo installieren.sh" --ja [--ziel ORDNER] [--ohne-desktop] [--offline]
set -u

T_TITEL="Diotopo installieren"
T_ZIEL_FRAGE="Wohin soll Diotopo installiert werden?"
T_LIZENZ_HINWEIS="Mit »Installieren« akzeptieren Sie die Lizenzbedingungen (LIZENZ.txt)."
T_INSTALLIEREN="Installieren"
T_ANDERER="Anderer Ordner …"
T_LIZENZ_ZEIGEN="Lizenz anzeigen"
T_ABBRECHEN="Abbrechen"
T_ZIEL_WAEHLEN="Ordner für Diotopo wählen"
T_ZIEL_UNGUELTIG="In diesen Ordner kann nicht geschrieben werden:"
T_BITTE_WARTEN="Diotopo wird installiert … Python, numpy, scipy, pyopencl und OpenCASCADE werden eingerichtet. Das kann einige Minuten dauern."
T_PYTHON_FEHLT="Python 3.10 oder neuer (mit venv) fehlt und wird jetzt über die Paketverwaltung installiert. Dafür wird gleich Ihr Passwort abgefragt."
T_KEIN_PYTHON="Python 3.10 oder neuer konnte nicht installiert werden.\n\nBitte von Hand installieren, z. B.:\n  Ubuntu/Debian:  sudo apt install python3 python3-venv\n  Fedora:         sudo dnf install python3\n  Arch:           sudo pacman -S python\nund den Assistenten erneut starten."
T_PIP_FEHLER="Die benötigten Pakete numpy und scipy konnten nicht installiert werden (keine Internetverbindung?).\n\nBitte Internetverbindung prüfen und den Assistenten erneut starten."
T_OPT_FEHLER="Hinweis: Diese Zusatzfunktion ließ sich nicht installieren (Diotopo läuft trotzdem):"
T_KEIN_PROGRAMM="Die Programmdateien wurden nicht gefunden. Der Ordner »app« muss neben diesem Assistenten liegen."
T_FERTIG="Diotopo wurde installiert in:"
T_FERTIG_MENUE="Diotopo steht jetzt im Anwendungsmenü und startet im Terminal mit »diotopo«."
T_FRAGE_DESKTOP="Soll eine Verknüpfung auf dem Desktop erstellt werden?"
T_FRAGE_START="Soll Diotopo jetzt gestartet werden?"
T_JA="Ja"
T_NEIN="Nein"
T_KEIN_BROWSER="Hinweis: Für ein eigenes Programmfenster wird Chromium, Google Chrome, Microsoft Edge oder Brave empfohlen. Ohne diese öffnet sich Diotopo im Standardbrowser."
T_ABBRUCH="Installation abgebrochen."
T_JA_NEIN="[j/n]"
T_DEINST_FRAGE="Diotopo wirklich entfernen? Ihre Projekte und Einstellungen bleiben erhalten."
T_DEINST_FERTIG="Diotopo wurde entfernt."
T_KOMMENTAR="Topologieoptimierung für 3D-Druck, Guss und Fräsen"
T_GENERISCH="Topologieoptimierung"
T_DEINST_NAME="Diotopo deinstallieren"

HIER="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="Diotopo"

# ---------------------------------------------------------------- Argumente
MODUS=""; AUTO=0; ZIEL=""; DESKTOP=""; OFFLINE=0; START=""
while [ $# -gt 0 ]; do
  case "$1" in
    --terminal) MODUS="terminal" ;;
    --ja|--yes) AUTO=1 ;;
    --ziel|--target) shift; ZIEL="${1:-}" ;;
    --ohne-desktop|--no-desktop) DESKTOP=0 ;;
    --offline) OFFLINE=1 ;;
  esac
  shift
done

# ---------------------------------------------------------------- Dialoge
if [ -z "$MODUS" ]; then
  if [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && command -v zenity >/dev/null 2>&1; then MODUS="zenity"
  elif [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ] && command -v kdialog >/dev/null 2>&1; then MODUS="kdialog"
  elif [ -t 0 ]; then MODUS="terminal"
  elif [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
    # Doppelklick ohne Dialogprogramm: im Terminalfenster neu starten
    for t in x-terminal-emulator gnome-terminal konsole xfce4-terminal mate-terminal xterm; do
      if command -v "$t" >/dev/null 2>&1; then
        case "$t" in
          gnome-terminal) exec "$t" -- bash "$0" --terminal ;;
          *) exec "$t" -e bash "$0" --terminal ;;
        esac
      fi
    done
    MODUS="terminal"
  else MODUS="terminal"
  fi
fi
[ "$AUTO" = 1 ] && MODUS="terminal"

info() {
  case "$MODUS" in
    zenity)  zenity --info --title="$T_TITEL" --width=460 --text="$(printf '%b' "$1")" 2>/dev/null ;;
    kdialog) kdialog --title "$T_TITEL" --msgbox "$(printf '%b' "$1")" ;;
    *)       printf '\n%b\n' "$1" ;;
  esac
}
fehler() {
  case "$MODUS" in
    zenity)  zenity --error --title="$T_TITEL" --width=460 --text="$(printf '%b' "$1")" 2>/dev/null ;;
    kdialog) kdialog --title "$T_TITEL" --error "$(printf '%b' "$1")" ;;
    *)       printf '\n%b\n' "$1" >&2 ;;
  esac
  exit 1
}
frage() {   # frage TEXT [STANDARD 1/0] -> 0 = ja
  if [ "$AUTO" = 1 ]; then [ "${2:-1}" = 1 ]; return; fi
  case "$MODUS" in
    zenity)  zenity --question --title="$T_TITEL" --width=460 --ok-label="$T_JA" --cancel-label="$T_NEIN" \
               --text="$(printf '%b' "$1")" 2>/dev/null ;;
    kdialog) kdialog --title "$T_TITEL" --yes-label "$T_JA" --no-label "$T_NEIN" --yesno "$(printf '%b' "$1")" ;;
    *)       printf '\n%b %s ' "$1" "$T_JA_NEIN"; read -r a
             case "$a" in "") [ "${2:-1}" = 1 ] ;; [jJyY]*) return 0 ;; *) return 1 ;; esac ;;
  esac
}

# ---------------------------------------------------------------- Deinstallation
# (wird als »deinstallieren.sh« in den Installationsordner kopiert und von dort aufgerufen)
case "$(basename "$0")" in *deinstallieren*|*[Uu]ninstall*) DEINST=1 ;; *) DEINST=0 ;; esac
if [ "$DEINST" = 1 ]; then
  frage "$T_DEINST_FRAGE" 1 || exit 0
  rm -f "$HOME/.local/share/applications/diotopo.desktop" "$HOME/.local/share/applications/diotopo-deinstallieren.desktop"
  if [ -L "$HOME/.local/bin/diotopo" ]; then rm -f "$HOME/.local/bin/diotopo"; fi
  if [ -f "$HIER/.desktop-verknuepfung" ]; then rm -f "$(cat "$HIER/.desktop-verknuepfung")"; fi
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" 2>/dev/null
  # nur die eigenen Programmdateien entfernen (Projekte/Einstellungen bleiben, auch wenn sie im selben Ordner liegen)
  cd / || exit 1
  for f in diotopo web Lizenzen Licenses venv Diotopo.pyw diotopo_web.py gpu_test.py LIZENZ.txt LICENSE.txt requirements.txt \
           icon.ico icon.png diotopo-starten installation.log .optional-fehlt .desktop-verknuepfung deinstallieren.sh; do
    [ -e "$HIER/$f" ] && rm -rf "${HIER:?}/$f"
  done
  rmdir "$HIER" 2>/dev/null
  info "$T_DEINST_FERTIG"
  exit 0
fi

# ---------------------------------------------------------------- Programmdateien
if [ -f "$HIER/app/Diotopo.pyw" ]; then QUELLE="$HIER/app"
elif [ -f "$HIER/../Browser Version/Diotopo.pyw" ]; then QUELLE="$(cd "$HIER/../Browser Version" && pwd)"
else fehler "$T_KEIN_PROGRAMM"; fi
LIZ="$QUELLE/LIZENZ.txt"; [ -f "$LIZ" ] || LIZ="$QUELLE/LICENSE.txt"

# ================================================================ 1. Zielordner
if [ -z "$ZIEL" ]; then
  if [ "$(id -u)" = 0 ]; then ZIEL="/opt/$APP"; else ZIEL="$HOME/.local/opt/$APP"; fi
  if [ "$AUTO" != 1 ]; then
    while :; do
      case "$MODUS" in
        zenity)
          w="$(zenity --question --title="$T_TITEL" --width=520 --ok-label="$T_INSTALLIEREN" --cancel-label="$T_ABBRECHEN" \
                 --extra-button="$T_ANDERER" --extra-button="$T_LIZENZ_ZEIGEN" \
                 --text="$T_ZIEL_FRAGE\n\n<b>$ZIEL</b>\n\n$T_LIZENZ_HINWEIS" 2>/dev/null)"; rc=$?
          if [ "$rc" = 0 ]; then break; fi
          case "$w" in
            "$T_ANDERER")
              n="$(zenity --file-selection --directory --title="$T_ZIEL_WAEHLEN" --filename="$(dirname "$ZIEL")/" 2>/dev/null)" \
                && ZIEL="${n%/}/$APP" ;;
            "$T_LIZENZ_ZEIGEN")
              zenity --text-info --title="$T_TITEL" --filename="$LIZ" --width=700 --height=560 2>/dev/null ;;
            *) fehler "$T_ABBRUCH" ;;
          esac ;;
        kdialog)
          kdialog --title "$T_TITEL" --yes-label "$T_INSTALLIEREN" --no-label "$T_ANDERER" --cancel-label "$T_ABBRECHEN" \
                  --yesnocancel "$T_ZIEL_FRAGE\n\n$ZIEL\n\n$T_LIZENZ_HINWEIS\n$LIZ"; rc=$?
          case "$rc" in
            0) break ;;
            1) n="$(kdialog --title "$T_ZIEL_WAEHLEN" --getexistingdirectory "$(dirname "$ZIEL")")" && ZIEL="${n%/}/$APP" ;;
            *) fehler "$T_ABBRUCH" ;;
          esac ;;
        *)
          printf '\n%s\n%s\n%s [%s]: ' "$T_TITEL" "$T_LIZENZ_HINWEIS ($LIZ)" "$T_ZIEL_FRAGE" "$ZIEL"; read -r w
          [ -n "$w" ] && ZIEL="${w/#\~/$HOME}"
          break ;;
      esac
    done
  fi
fi
case "$(basename "$ZIEL")" in Diotopo|diotopo) ;; *) ZIEL="${ZIEL%/}/$APP" ;; esac
mkdir -p "$ZIEL" 2>/dev/null && [ -w "$ZIEL" ] || fehler "$T_ZIEL_UNGUELTIG\n$ZIEL"
ZIEL="$(cd "$ZIEL" && pwd)"

# ================================================================ 2. Alles Benötigte feststellen und installieren
finde_python() {
  PY=""
  for p in python3.14 python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$p" >/dev/null 2>&1 && "$p" -c 'import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
      PY="$(command -v "$p")"; return 0
    fi
  done
  return 1
}
if ! finde_python; then
  [ "$OFFLINE" = 1 ] && fehler "$T_KEIN_PYTHON"
  info "$T_PYTHON_FEHLT"
  ALS=""
  if [ "$(id -u)" = 0 ]; then ALS=""
  elif [ "$MODUS" != terminal ] && command -v pkexec >/dev/null 2>&1; then ALS="pkexec"
  else ALS="sudo"; fi
  if command -v apt-get >/dev/null 2>&1; then
    V="$(python3 -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")' 2>/dev/null)"
    $ALS sh -c "apt-get update -q; apt-get install -y python3 python3-venv python3-pip ${V:+python$V-venv}" || true
  elif command -v dnf >/dev/null 2>&1; then $ALS dnf install -y python3 python3-pip || true
  elif command -v zypper >/dev/null 2>&1; then $ALS zypper --non-interactive install python3 python3-pip || true
  elif command -v pacman >/dev/null 2>&1; then $ALS pacman -S --noconfirm --needed python python-pip || true
  fi
  finde_python || fehler "$T_KEIN_PYTHON"
fi

LOG="$ZIEL/installation.log"
installieren() {
  set -e
  echo "# Dateien kopieren"
  for f in diotopo web Lizenzen Licenses Diotopo.pyw diotopo_web.py gpu_test.py LIZENZ.txt LICENSE.txt requirements.txt icon.ico; do
    rm -rf "${ZIEL:?}/$f"
    [ -e "$QUELLE/$f" ] && cp -R "$QUELLE/$f" "$ZIEL/"
  done
  find "$ZIEL" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
  cp "$QUELLE/web/icon.png" "$ZIEL/icon.png"

  echo "# Python-Umgebung anlegen"
  if [ ! -x "$ZIEL/venv/bin/python" ]; then
    if [ "$OFFLINE" = 1 ]; then "$PY" -m venv --system-site-packages "$ZIEL/venv"; else "$PY" -m venv "$ZIEL/venv"; fi
  fi
  VPY="$ZIEL/venv/bin/python"
  set +e
  echo "# numpy, scipy"
  if [ "$OFFLINE" != 1 ]; then
    "$VPY" -m pip install --disable-pip-version-check -q --upgrade -r "$ZIEL/requirements.txt" || true
  fi
  "$VPY" -c 'import numpy, scipy' || { echo "PIP_FEHLER"; return 3; }
  OPTFEHLT=""
  if [ "$OFFLINE" != 1 ]; then
    echo "# pyopencl"
    "$VPY" -m pip install --disable-pip-version-check -q pyopencl || OPTFEHLT="$OPTFEHLT pyopencl"
    echo "# OpenCASCADE"
    "$VPY" -m pip install --disable-pip-version-check -q cadquery-ocp-novtk || OPTFEHLT="$OPTFEHLT cadquery-ocp-novtk"
  fi
  echo "$OPTFEHLT" > "$ZIEL/.optional-fehlt"
  "$VPY" -m compileall -q "$ZIEL/diotopo" >/dev/null 2>&1
  return 0
}

case "$MODUS" in
  zenity)
    ( installieren 2>&1 | tee "$LOG" ) | zenity --progress --pulsate --auto-close --no-cancel --title="$T_TITEL" \
        --width=460 --text="$T_BITTE_WARTEN" 2>/dev/null ;;
  kdialog)
    kdialog --title "$T_TITEL" --passivepopup "$T_BITTE_WARTEN" 8 2>/dev/null &
    printf '%b\n' "$T_BITTE_WARTEN"
    installieren > "$LOG" 2>&1 ;;
  *)
    printf '\n%b\n' "$T_BITTE_WARTEN"
    installieren 2>&1 | tee "$LOG" | sed -n 's/^# /  … /p' ;;
esac
grep -q '^PIP_FEHLER' "$LOG" 2>/dev/null && fehler "$T_PIP_FEHLER\n\n$LOG"
[ -x "$ZIEL/venv/bin/python" ] || fehler "$T_PIP_FEHLER\n\n$LOG"

# Startprogramm, Befehl »diotopo«, Menüeintrag, Deinstallation
cat > "$ZIEL/diotopo-starten" <<EOF
#!/bin/sh
# Startet Diotopo
exec "$ZIEL/venv/bin/python" "$ZIEL/Diotopo.pyw" "\$@"
EOF
chmod +x "$ZIEL/diotopo-starten"
cp "$HIER/$(basename "$0")" "$ZIEL/deinstallieren.sh" 2>/dev/null || cp "$0" "$ZIEL/deinstallieren.sh"
chmod +x "$ZIEL/deinstallieren.sh"
mkdir -p "$HOME/.local/bin"
[ -e "$HOME/.local/bin/diotopo" ] && [ ! -L "$HOME/.local/bin/diotopo" ] || ln -sf "$ZIEL/diotopo-starten" "$HOME/.local/bin/diotopo"

desktop_datei() {  # desktop_datei ZIELDATEI
  cat > "$1" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=Diotopo
GenericName=$T_GENERISCH
Comment=$T_KOMMENTAR
Exec="$ZIEL/diotopo-starten"
Icon=$ZIEL/icon.png
Terminal=false
Categories=Graphics;Engineering;Science;
Keywords=Topology;Optimization;CAD;STL;3D;
StartupWMClass=Diotopo
EOF
  chmod +x "$1"
}
APPS="$HOME/.local/share/applications"
mkdir -p "$APPS"
desktop_datei "$APPS/diotopo.desktop"
cat > "$APPS/diotopo-deinstallieren.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=$T_DEINST_NAME
Exec=bash "$ZIEL/deinstallieren.sh"
Icon=$ZIEL/icon.png
Terminal=false
NoDisplay=true
EOF
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPS" 2>/dev/null

TXT="$T_FERTIG\n$ZIEL\n\n$T_FERTIG_MENUE"
OPT="$(cat "$ZIEL/.optional-fehlt" 2>/dev/null | xargs)"
[ -n "$OPT" ] && TXT="$TXT\n\n$T_OPT_FEHLER $OPT"
B=""
for b in google-chrome google-chrome-stable chromium chromium-browser microsoft-edge microsoft-edge-stable brave-browser; do
  command -v "$b" >/dev/null 2>&1 && B="$b" && break
done
[ -z "$B" ] && TXT="$TXT\n\n$T_KEIN_BROWSER"

# ================================================================ 3. Desktop-Verknüpfung?
rm -f "$ZIEL/.desktop-verknuepfung"
[ "$AUTO" = 1 ] && printf '%b\n' "$TXT"
if [ -z "$DESKTOP" ]; then
  if frage "$TXT\n\n$T_FRAGE_DESKTOP" 1; then DESKTOP=1; else DESKTOP=0; fi
fi
if [ "$DESKTOP" = 1 ]; then
  SD="$(xdg-user-dir DESKTOP 2>/dev/null || true)"
  [ -n "$SD" ] && [ "$SD" != "$HOME" ] || SD="$HOME/Desktop"
  mkdir -p "$SD" 2>/dev/null
  if [ -d "$SD" ]; then
    desktop_datei "$SD/Diotopo.desktop"
    command -v gio >/dev/null 2>&1 && gio set "$SD/Diotopo.desktop" metadata::trusted true 2>/dev/null
    echo "$SD/Diotopo.desktop" > "$ZIEL/.desktop-verknuepfung"
  fi
fi

# ================================================================ 4. Jetzt starten?
[ "$AUTO" = 1 ] && exit 0
if frage "$T_FRAGE_START" 1; then
  nohup "$ZIEL/diotopo-starten" >/dev/null 2>&1 &
fi
exit 0
