#!/bin/sh
# Diotopo (Browser Version) unter Linux/macOS:  ./start.sh   (im Netzwerk: ./start.sh --netzwerk)
cd "$(dirname "$0")"
exec python3 diotopo_web.py "$@"
