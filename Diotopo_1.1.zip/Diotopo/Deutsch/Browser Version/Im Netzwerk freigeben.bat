@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Diotopo Web - im Netzwerk

set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY goto nopython

rem Eigene Programmdatei "Diotopo Web.exe" verwenden, damit der Task-Manager "Diotopo Web" zeigt
set "EXE="
for /f "usebackq delims=" %%E in (`%PY% "%~dp0diotopo_web.py" --programmdatei`) do set "EXE=%%E"
if not defined EXE goto ohne
"%EXE%" "%~dp0diotopo_web.py" --netzwerk %*
goto ende
:ohne
%PY% "%~dp0diotopo_web.py" --netzwerk %*
:ende
if errorlevel 1 pause
exit /b 0

:nopython
echo.
echo Python wurde nicht gefunden.
echo Bitte Python 3.10 oder neuer von https://www.python.org/downloads/ installieren
echo und dabei "Add python.exe to PATH" anhaken. Danach diese Datei erneut starten.
pause
exit /b 1
