"""Findet Textliterale in Python-, JavaScript- und HTML-Dateien (mit Position) – Grundlage für uebersetzen.py."""
import ast
import io
import re
import tokenize

FSTRING_MIDDLE = getattr(tokenize, "FSTRING_MIDDLE", None)


def _linestarts(src):
    st = [0]
    for m in re.finditer("\n", src):
        st.append(m.end())
    return st


def py_spans(src):
    """(start, end, body) für jedes Textliteral außer Docstrings; body = Quelltext zwischen den Anführungszeichen."""
    ls = _linestarts(src)
    try:
        tree = ast.parse(src)
    except SyntaxError:
        tree = None
    doc = set()
    if tree:
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)) and node.body:
                b = node.body[0]
                if isinstance(b, ast.Expr) and isinstance(b.value, ast.Constant) and isinstance(b.value.value, str):
                    doc.add(b.lineno)
    out = []
    for t in tokenize.generate_tokens(io.StringIO(src).readline):
        if t.type == tokenize.STRING and t.start[0] not in doc:
            m = re.match(r"^([rbfuRBFU]*)('''|\"\"\"|'|\")", t.string)
            q = m.group(2)
            a = ls[t.start[0] - 1] + t.start[1] + len(m.group(0))
            e = ls[t.end[0] - 1] + t.end[1] - len(q)
            out.append((a, e, src[a:e]))
        elif FSTRING_MIDDLE is not None and t.type == FSTRING_MIDDLE:
            if "{" in t.string or "}" in t.string:
                continue
            a = ls[t.start[0] - 1] + t.start[1]
            e = a + len(t.string)
            if src[a:e] == t.string:
                out.append((a, e, t.string))
    return out


def js_spans(src, base=0):
    """(start, end, body) für '…', "…" und die Textteile von `…${}…`."""
    out = []
    i, n, prev = 0, len(src), ""

    def scan_template(j):
        a = j
        while j < n and src[j] != "`":
            if src[j] == "\\":
                j += 2
                continue
            if src[j] == "$" and j + 1 < n and src[j + 1] == "{":
                out.append((base + a, base + j, src[a:j]))
                j = scan_expr(j + 2)
                a = j
                continue
            j += 1
        out.append((base + a, base + j, src[a:j]))
        return j + 1

    def scan_expr(j):
        depth = 1
        while j < n and depth:
            c = src[j]
            if c in "'\"":
                k = j + 1
                while k < n and src[k] != c:
                    k += 2 if src[k] == "\\" else 1
                out.append((base + j + 1, base + k, src[j + 1:k]))
                j = k + 1
                continue
            if c == "`":
                j = scan_template(j + 1)
                continue
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
            j += 1
        return j

    while i < n:
        c = src[i]
        if c == "/" and src[i + 1:i + 2] == "/":
            j = src.find("\n", i)
            i = n if j < 0 else j
            continue
        if c == "/" and src[i + 1:i + 2] == "*":
            j = src.find("*/", i + 2)
            i = n if j < 0 else j + 2
            continue
        if c in "'\"":
            j = i + 1
            while j < n and src[j] != c and src[j] != "\n":
                j += 2 if src[j] == "\\" else 1
            out.append((base + i + 1, base + j, src[i + 1:j]))
            i, prev = j + 1, "s"
            continue
        if c == "`":
            i, prev = scan_template(i + 1), "s"
            continue
        if c == "/" and (prev == "" or prev in "(,=:[!&|?{};+-*%<>~^"):
            j, inc = i + 1, False
            while j < n and src[j] != "\n":
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == "[":
                    inc = True
                elif src[j] == "]":
                    inc = False
                elif src[j] == "/" and not inc:
                    break
                j += 1
            i, prev = j + 1, "s"
            continue
        if not c.isspace():
            prev = "a" if (c.isalnum() or c in "_)]$") else c
        i += 1
    return out


ATTRS = ("title", "placeholder", "alt", "aria-label", "label")


def html_spans(src):
    """Textknoten, übersetzbare Attribute und Inline-Skripte."""
    out = []
    skip = []
    for m in re.finditer(r"<(script|style)\b[^>]*>(.*?)</\1>", src, re.S | re.I):
        skip.append((m.start(2), m.end(2)))
        if m.group(1).lower() == "script":
            out += js_spans(m.group(2), m.start(2))
    def inside_skip(p):
        return any(a <= p < b for a, b in skip)
    for m in re.finditer(r">([^<>]+)<", src):
        if inside_skip(m.start(1)):
            continue
        t = m.group(1)
        s = t.strip()
        if s:
            a = m.start(1) + t.index(s)
            out.append((a, a + len(s), s))
    for m in re.finditer(r"<[a-zA-Z][^<>]*>", src):
        if inside_skip(m.start()):
            continue
        for am in re.finditer(r'\s(%s)="([^"]*)"' % "|".join(ATTRS), m.group(0)):
            if am.group(2).strip():
                a = m.start() + am.start(2)
                out.append((a, a + len(am.group(2)), am.group(2)))
    return out


def spans(path, src):
    if path.endswith((".py", ".pyw")):
        return py_spans(src)
    if path.endswith(".js"):
        return js_spans(src)
    if path.endswith((".html", ".htm")):
        return html_spans(src)
    return []
