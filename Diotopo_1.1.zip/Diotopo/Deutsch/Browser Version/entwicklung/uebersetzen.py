# -*- coding: utf-8 -*-
"""Erzeugt aus der deutschen Diotopo-Fassung die englische.

Aufruf (aus dem Ordner »Deutsch«, der Browser Version, Portable Version, … enthält):
    python "Browser Version/entwicklung/uebersetzen.py"  <Ordner Deutsch>  <Ordner English>

Ablauf je Datei (Programmkopien in den Installer-Ordnern »app« werden danach aus der
englischen Browser Version neu verteilt, siehe programm_verteilen.py):
  1. Anpassungen aus en/anpassungen.txt (Textstellen, die als Ganzes ersetzt werden – z. B. Sätze,
     deren Wortstellung im Englischen anders ist, Skripte, Inno-Setup-Datei),
  2. in .py/.pyw/.js/.html: jedes Textliteral, das wörtlich in en/texte.txt steht, wird ersetzt
     (nur innerhalb von Anführungszeichen bzw. HTML-Text – Programmcode bleibt unberührt),
  3. Umbenennen nach UMBENENNEN, ganze Dateien aus en/dateien/ (LIESMICH → README, Lizenz …).
Am Ende listet das Werkzeug alle Texte, die noch deutsch aussehen. Kommentare im Code bleiben deutsch.
"""
import fnmatch
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from textscan import spans  # noqa: E402
from programm_verteilen import PROGRAMM, INSTALLER, verteilen  # noqa: E402

EN = os.path.join(HERE, "en")

# Deutscher Pfad (relativ zum Ordner »Deutsch«) -> englischer Pfad; Ordnernamen bleiben gleich
UMBENENNEN = {
    "Browser Version/LIESMICH.txt": "Browser Version/README.txt",
    "Browser Version/LIZENZ.txt": "Browser Version/LICENSE.txt",
    "Browser Version/Lizenzen/Lizenzen Dritter.txt": "Browser Version/Licenses/Third-party licenses.txt",
    "Browser Version/Lizenzen/LGPL-2.1.txt": "Browser Version/Licenses/LGPL-2.1.txt",
    "Browser Version/Lizenzen/Apache-2.0.txt": "Browser Version/Licenses/Apache-2.0.txt",
    "Browser Version/Diotopo im Browser starten.bat": "Browser Version/Start Diotopo in browser.bat",
    "Browser Version/Im Netzwerk freigeben.bat": "Browser Version/Share on network.bat",
    "Browser Version/Pakete installieren.bat": "Browser Version/Install packages.bat",
    "Browser Version/GPU testen.bat": "Browser Version/Test GPU.bat",
    "Portable Version/LIESMICH.txt": "Portable Version/README.txt",
    "Portable Version/Portable erstellen.pyw": "Portable Version/Create portable version.pyw",
    "Windows Installer/LIESMICH.txt": "Windows Installer/README.txt",
    "Windows Installer/Diotopo installieren.cmd": "Windows Installer/Install Diotopo.cmd",
    "Linux Installer/LIESMICH.txt": "Linux Installer/README.txt",
    "Linux Installer/Diotopo installieren.sh": "Linux Installer/Install Diotopo.sh",
    "Mac Installer/LIESMICH.txt": "Mac Installer/README.txt",
    "Mac Installer/Diotopo installieren.command": "Mac Installer/Install Diotopo.command",
}
AUSLASSEN = ("*/__pycache__/*", "*/entwicklung/*", "*.pyc", "*.tar.gz", "*.zip", "*/build/*", "*/_internal/*",
             "*/Diotopo-Setup-*.exe", "*/Diotopo.exe", "*/Daten/*")
CODE = (".py", ".pyw", ".js", ".html")
TEXT = CODE + (".sh", ".command", ".bat", ".cmd", ".ps1", ".iss", ".txt", ".css", ".plist")


def lade_texte():
    m, de = {}, None
    for line in open(os.path.join(EN, "texte.txt"), encoding="utf-8"):
        line = line.rstrip("\n")
        if line.startswith("de: "):
            de = line[4:]
        elif line.startswith("en: ") and de is not None:
            m[de] = line[4:]
            de = None
    return m


def lade_anpassungen():
    """Blöcke:  @@@ <Dateimuster>  /  <<<  alt  ===  neu  >>>   (alle Vorkommen werden ersetzt)."""
    out, muster, mode, alt, neu = [], None, None, [], []
    for line in open(os.path.join(EN, "anpassungen.txt"), encoding="utf-8"):
        line = line.rstrip("\n")
        if mode is None:
            if line.startswith("@@@ "):
                muster = line[4:].strip()
            elif line == "<<<":
                mode, alt, neu = "alt", [], []
        elif mode == "alt":
            if line == "===":
                mode = "neu"
            else:
                alt.append(line)
        elif mode == "neu":
            if line == ">>>":
                out.append([muster, "\n".join(alt), "\n".join(neu), 0])
                mode = None
            else:
                neu.append(line)
    return out


def ersetze_literale(rel, src, texte, benutzt):
    sp = spans(rel, src)
    sp.sort(key=lambda t: t[0])
    teile, pos = [], 0
    for a, e, body in sp:
        if a < pos:
            continue
        neu = texte.get(body)
        if neu is None:
            continue
        benutzt.add(body)
        teile.append(src[pos:a])
        teile.append(neu)
        pos = e
    teile.append(src[pos:])
    return "".join(teile)


DEUTSCH = """der die das den dem des und nicht ist sind mit für oder ein eine einen einer kein keine keinen bitte
wird werden bei auf aus zum zur noch nur von bis je als wie ohne sich kann alle über unter neben wurde wurden
Fehler Datei Dateien Bauteil Bauteile Lager Kraft Netz Gitter Ergebnis Fläche Flächen Hinweis Ordner Lastfall Lastfälle
Auflösung Rechne Rechnen Speicher Bereich Bereiche Massive Nachgiebigkeit Löser Dreiecke Knoten Elemente Ebenen
Richtung Achse Verschiebung Spannung Schwelle Werkzeug Fräser Stand Zeit Vorschau Lasten Teil Teile Grafikkarte
erstellen installieren starten fehlgeschlagen gefunden geladen gespeichert prüfen entfernt ergänzt""".split()
GER = re.compile(r"[äöüÄÖÜß„»«]|\b(" + "|".join(DEUTSCH) + r")\b")


def main(src_root, dst_root):
    texte = lade_texte()
    anp = lade_anpassungen()
    benutzt = set()
    if os.path.isdir(dst_root):
        shutil.rmtree(dst_root)
    rest = []
    for dp, dn, fn in os.walk(src_root):
        dn.sort()
        for f in sorted(fn):
            p = os.path.join(dp, f)
            rel = os.path.relpath(p, src_root).replace(os.sep, "/")
            if any(fnmatch.fnmatch("/" + rel, pat) for pat in AUSLASSEN):
                continue
            teile = rel.split("/")
            if len(teile) > 2 and teile[0] in INSTALLER and teile[1] == "app" and teile[2] in PROGRAMM:
                continue                                   # Programmkopie – wird unten aus der Browser Version verteilt
            ziel_rel = UMBENENNEN.get(rel, rel)
            ziel = os.path.join(dst_root, *ziel_rel.split("/"))
            os.makedirs(os.path.dirname(ziel), exist_ok=True)
            ganz = os.path.join(EN, "dateien", *ziel_rel.split("/"))
            if os.path.isfile(ganz):                      # komplett übersetzte Datei
                shutil.copy2(ganz, ziel)
                continue
            if not f.endswith(TEXT):
                shutil.copy2(p, ziel)
                continue
            raw = open(p, "rb").read()
            bom = raw.startswith(b"\xef\xbb\xbf")
            s = raw.decode("utf-8-sig")
            crlf = "\r\n" in s
            if crlf:
                s = s.replace("\r\n", "\n")
            for a in anp:
                if fnmatch.fnmatch(rel, a[0]) and a[1] in s:
                    s = s.replace(a[1], a[2])
                    a[3] += 1
            if f.endswith(CODE):
                s = ersetze_literale(rel, s, texte, benutzt)
                for a, e, body in spans(rel, s):
                    if GER.search(body) and "\n" not in body:
                        rest.append(f"{ziel_rel}: {body[:110]}")
            elif not f.endswith(".txt"):
                for i, line in enumerate(s.split("\n"), 1):
                    if GER.search(line) and not line.lstrip().startswith(("#", ";", "rem ", "::")):
                        rest.append(f"{ziel_rel}:{i}: {line.strip()[:110]}")
            if crlf:
                s = s.replace("\n", "\r\n")
            with open(ziel, "wb") as fh:
                fh.write((b"\xef\xbb\xbf" if bom else b"") + s.encode("utf-8"))
            shutil.copystat(p, ziel)
    # komplett übersetzte Dateien, die es nur auf Englisch gibt
    for dp, dn, fn in os.walk(os.path.join(EN, "dateien")):
        for f in fn:
            q = os.path.join(dp, f)
            rel = os.path.relpath(q, os.path.join(EN, "dateien"))
            z = os.path.join(dst_root, rel)
            if not os.path.exists(z):
                os.makedirs(os.path.dirname(z), exist_ok=True)
                shutil.copy2(q, z)
    verteilen(dst_root, log=lambda m: None)              # übersetzte Programmdateien in die Installer
    fehl = [a for a in anp if a[3] == 0]
    for a in fehl:
        print(f"FEHLER: Anpassung für {a[0]} passt nicht mehr:\n  {a[1][:200]}")
    unbenutzt = [k for k in texte if k not in benutzt]
    print(f"{len(texte)} Texte, {len(texte) - len(unbenutzt)} verwendet; {len(anp)} Anpassungen.")
    if rest:
        print(f"\n{len(rest)} Stellen sehen noch deutsch aus:")
        for r in rest:
            print("  " + r)
    return 1 if fehl else 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1], sys.argv[2]))
