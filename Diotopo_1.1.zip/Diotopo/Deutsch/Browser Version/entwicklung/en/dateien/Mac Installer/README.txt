Diotopo 1.1 - Topology optimization
======================================================================

THE "DIOTOPO" FOLDER CONTAINS FIVE VERSIONS
  Browser Version    runs in the browser - on this PC or for other devices in the home network.
                     Needs an installed Python (Windows, Linux, macOS). Also contains the
                     program code from which all other versions are built.
  Portable Version   for USB sticks (Windows): starts directly without installation, leaves
                     nothing behind on the PC. Is created once on a Windows PC with Python
                     (one double-click, a wizard guides you).
  Windows Installer  ready-to-use installation wizard for Windows 10/11:
                     double-click "Install Diotopo.cmd".
  Linux Installer    ready-to-use installation wizard for Linux: "Install Diotopo.sh".
  Mac Installer      ready-to-use installation wizard for macOS: "Install Diotopo.command".
  All three installers first ask where to install, then set up everything needed by
  themselves (Python and computing packages - an internet connection is required), then ask
  about a desktop shortcut and whether Diotopo should be started right away. Every installer
  folder is complete and can be passed on on its own.
  Details: README in each folder.

MAC INSTALLER
----------------------------------------------------------------------
Ready-to-use installation wizard for macOS 11 Big Sur or newer (Intel and Apple silicon).
Creates Diotopo as an application (Diotopo.app); it appears in Finder, Launchpad and
Spotlight and runs in its own program window.

INSTALLING
  Double-click "Install Diotopo.command". The wizard guides you with windows, a Terminal
  window shows the progress:
    1. Where? - "Applications" (all users, administrator password), "My Applications"
       (~/Applications) or another folder. By clicking "Install" you accept the license
       terms ("Show license terms").
    2. The wizard detects what is missing and installs everything itself: if Python 3.10+
       is missing, it is installed from python.org (administrator password); then numpy,
       scipy, pyopencl (graphics cards) and OpenCASCADE (STEP import) into a separate
       environment inside Diotopo.app. Needs an internet connection.
    3. Question: create a shortcut on the desktop?
    4. Question: start Diotopo now?
  Recommended for a separate window: Google Chrome, Microsoft Edge or Brave (otherwise Safari).

  If macOS reports "cannot be opened because it is from an unidentified developer"
  (the script is not signed by Apple):
    - macOS 11-14:  right-click the file -> "Open" -> "Open".
    - macOS 15 and newer:  double-click once, then System Settings -> Privacy & Security ->
      at the very bottom "Open Anyway".
    - Or in Terminal:  xattr -dr com.apple.quarantine "Mac Installer"

  Unattended in Terminal (e.g. via SSH):
      bash "Install Diotopo.command" --yes [--target ~/Applications] [--no-desktop]

STARTING
  Applications -> Diotopo, Launchpad, Spotlight or the shortcut on the desktop.
  When the window is closed, Diotopo exits completely.
  Settings and log: ~/Library/Application Support/Diotopo

UPDATING
  Run the wizard of the new version again - the existing Python environment is reused.

UNINSTALLING
  Drag Diotopo.app to the Trash - the application contains everything it needs.
  Or run Diotopo.app/Contents/Resources/"Uninstall Diotopo.command" (also removes the
  desktop shortcut).
  Note: do not move Diotopo.app to another folder after the installation - otherwise
  please reinstall.

PASSING IT ON
  Copy the whole "Mac Installer" folder (with the "app" subfolder) or pass it on as a ZIP.

NOTE
  This installer was checked on Linux for syntax, package structure (Info.plist,
  Diotopo.app), sequence and start-up; the Mac windows (AppleScript), the Python
  installation from python.org and Gatekeeper can only be tested on a real Mac.
