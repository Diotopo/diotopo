Diotopo 1.1 - Topology optimization
======================================================================

THE "DIOTOPO" FOLDER CONTAINS FIVE VERSIONS
  Browser Version    runs in the browser - on this PC or for other devices in the home network.
                     Needs an installed Python (Windows, Linux, macOS). Also contains the
                     program code from which all other versions are built.
  Portable Version   for USB sticks (Windows): starts directly without installation, leaves
                     nothing behind on the PC. Is created once on a Windows PC with Python
                     (one double-click, a wizard guides you).
  Windows Installer  ready-to-use installation wizard for Windows 10/11:
                     double-click "Install Diotopo.cmd".
  Linux Installer    ready-to-use installation wizard for Linux: "Install Diotopo.sh".
  Mac Installer      ready-to-use installation wizard for macOS: "Install Diotopo.command".
  All three installers first ask where to install, then set up everything needed by
  themselves (Python and computing packages - an internet connection is required), then ask
  about a desktop shortcut and whether Diotopo should be started right away. Every installer
  folder is complete and can be passed on on its own.
  Details: README in each folder.

LINUX INSTALLER
----------------------------------------------------------------------
Ready-to-use installation wizard for Linux (Ubuntu, Debian, Mint, Fedora, openSUSE, Arch, ...).
Diotopo then runs in its own program window.

INSTALLING
  Double-click "Install Diotopo.sh" (if needed right-click -> "Run as a Program")
  or in a terminal:   bash "Install Diotopo.sh"
    1. Where? - target folder (default: ~/.local/opt/Diotopo, as root: /opt/Diotopo) or
       "Other folder ...". By clicking "Install" you accept the license terms ("Show license").
    2. The wizard detects what is missing and installs everything itself: if Python 3.10+
       with venv is missing, it is installed via the package manager (password prompt); then
       numpy, scipy, pyopencl (graphics cards) and OpenCASCADE (STEP import) into a separate
       environment in the Diotopo folder. Needs an internet connection.
    3. Question: create a shortcut on the desktop?
    4. Question: start Diotopo now?
  An entry in the application menu and the terminal command "diotopo" are always created.
  Windows are shown with zenity (GNOME, Xfce, Cinnamon, MATE) or kdialog (KDE); otherwise
  the wizard asks in the terminal. Recommended for a separate window: Chromium, Google
  Chrome, Microsoft Edge or Brave (otherwise the default browser opens).

  Additionally in a terminal:
      --terminal         without windows
      --yes              unattended with default values
      --target FOLDER    set the target folder
      --no-desktop       no desktop shortcut
      --offline          download nothing, only use system packages
                         (first: sudo apt install python3-numpy python3-scipy)

STARTING
  Application menu -> Diotopo, the desktop shortcut or in a terminal:  diotopo
  (if the command is missing, add ~/.local/bin to PATH or log in again).
  When the window is closed, Diotopo exits completely.
  Settings and log are stored in ~/.local/share/Diotopo.

UNINSTALLING
  In the installation folder:  bash uninstall.sh
  Removes the program, menu entry, shortcut and the "diotopo" command.
  Settings in ~/.local/share/Diotopo are kept.

PASSING IT ON
  Copy the whole "Linux Installer" folder (with the "app" subfolder) or pass it on as a
  ZIP/tar.gz.
