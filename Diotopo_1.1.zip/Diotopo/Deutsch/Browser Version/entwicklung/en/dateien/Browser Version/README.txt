Diotopo 1.1 - Topology optimization
======================================================================

THE "DIOTOPO" FOLDER CONTAINS FIVE VERSIONS
  Browser Version    runs in the browser - on this PC or for other devices in the home network.
                     Needs an installed Python (Windows, Linux, macOS). Also contains the
                     program code from which all other versions are built.
  Portable Version   for USB sticks (Windows): starts directly without installation, leaves
                     nothing behind on the PC. Is created once on a Windows PC with Python
                     (one double-click, a wizard guides you).
  Windows Installer  ready-to-use installation wizard for Windows 10/11:
                     double-click "Install Diotopo.cmd".
  Linux Installer    ready-to-use installation wizard for Linux: "Install Diotopo.sh".
  Mac Installer      ready-to-use installation wizard for macOS: "Install Diotopo.command".
  All three installers first ask where to install, then set up everything needed by
  themselves (Python and computing packages - an internet connection is required), then ask
  about a desktop shortcut and whether Diotopo should be started right away. Every installer
  folder is complete and can be passed on on its own.
  Details: README in each folder.

SETTING UP THE WEB VERSION (once)
  1. Install Python 3.10 or newer from https://www.python.org/downloads/
     and tick "Add python.exe to PATH".
  2. Double-click "Install packages.bat" (numpy, scipy; optionally cadquery-ocp-novtk
     (OpenCASCADE) for STEP and pyopencl for graphics cards).
  Linux/macOS:  python3 -m pip install -r requirements.txt cadquery-ocp-novtk pyopencl

STARTING
  "Start Diotopo in browser.bat"    Diotopo opens in the default browser
                                    (http://127.0.0.1:8765/). Only reachable on this PC.
  "Share on network.bat"            additionally for other devices on the same network (tablet,
                                    second PC): open the displayed address in the browser there.
                                    CAUTION: no password - anyone on the network can use Diotopo.
                                    Only in trusted networks, not on public Wi-Fi.
                                    Windows may ask for a firewall permission.
  Linux/macOS:  ./start.sh   or  ./start.sh --network
  Quit: close the black window (or press Ctrl+C).
  In Task Manager the browser version appears as "Diotopo Web".
  Everything is computed on the PC the browser version runs on - nothing goes to the internet.

WORKFLOW
  1 Prepare       Open STEP/STL/3MF/OBJ/PLY/ZIP, choose the material,
                  click faces (Ctrl+click = several) and assign them as support,
                  load, solid/empty zone; create load cases.
                  Minimum safety factor (card "Safety" below Material & Units): the
                  optimization keeps this safety factor. If the target volume is not
                  enough, the result is reinforced and, if necessary, optimized again with
                  more material (the log states the volume needed). 0 = none.
  2 Simulate      Analyze the solid part (stress, displacement, safety factor)
                  and optimize the topology (objective volume or mass) - optionally
                  suited to the manufacturing method (see below).
                  All numeric values of the optimization can be set with sliders from the
                  smallest to the largest possible value (target mass up to the solid
                  mass, wall thicknesses up to half the part thickness, milling depth up to
                  the part height in tool direction); type exact values into the field next to it.
                  After the optimization the sliders "Part volume" and "Iteration" show
                  the shape live while dragging (both directions, no waiting); on release
                  it is cleaned up (loose parts removed, everything connected).
                  During the computation the hardware load (CPU/GPU/RAM) is shown in the
                  box at the bottom right.
    Allow separate parts
                  unchecked (default), the result always stays ONE part: supports, loads
                  and solid zones (e.g. holes) are connected to the rest along the shortest
                  path - in all manufacturing methods. Checked, separate pieces may occur
                  (each needs a support; pieces without a support are removed).
  3 Export        Print check (overhang, thin walls), export STL/3MF/OBJ,
                  with "Milling prismatic" also STEP and DXF.
                  In Fusion 360: Insert > Insert Mesh.

MANUFACTURING METHODS (tab 2, "Manufacturing & Symmetry")
  Unrestricted            free shape (e.g. for 3D printing with supports).
  Casting                 one demolding direction, no undercuts.
  3D printing simple      no overhangs flatter than 45 or 63 degrees in build direction.
                          The material is computed as printed: softer in build direction (across
                          the layers, "Young's modulus in build direction") and with limited
                          layer adhesion (tension across the layers, shear in the layer bond).
                          The values are in tab 1 under "Material" (guide values for every
                          material, freely editable).
    Consider layer adhesion in optimization
                          load paths across weakly bonded layers are avoided: across the layers
                          the optimization counts the stiffness at most in the ratio
                          (bond strength / strength)^2. The analysis uses the real values. If the
                          bond strength is hardly lower than the strength (e.g. ASA-CF), the
                          shape hardly changes.
                          Display: "Layer adhesion (safety)".
    Overhang check        after the optimization the log reports as WARNING every region that is
                          flatter than the maximum overhang angle and therefore cannot be
                          printed as optimized without supports (with location, e.g. at
                          holes/solid zones); "Print check" shows them in orange.
  3D printing advanced    like simple, plus the way the slicer prints:
    Shell top / bottom / walls
                          solid top layers, bottom layers and walls (perimeters) in mm.
    Infill [%], infill pattern
                          the core is infill (grid, lines, triangles, cubic, gyroid, honeycomb)
                          with its own direction-dependent stiffness (guide values).
                          "Target mass" then refers to the print mass (walls + infill).
                          Display: "Walls & infill" - shape transparent with shells and
                          infill; with "Section" the cut faces are filled: walls green,
                          infill region beige with pattern.
  Milling prismatic       for conventional milling and CAM (3+2): no organic shapes, only
                          pockets and steps with flat floors and walls parallel to the cutter
                          axis - from up to 6 sides (the part is re-clamped).
    Milling sides         Z+ Z- Y+ Y- X+ X-: milling is done from these sides, uncheck = not
                          from this side. With a single axis only (e.g. Z+ and Z-) the result
                          is an exact 2.5D stepped body if the part itself has no shapes across
                          the axis. Otherwise cross holes and slopes of the part are kept as in
                          the original (note in the log).
                          Solid zones count as whole depth levels; the threshold is adjusted so
                          that the stepped body meets the target volume as long as no
                          load-bearing structure is lost.
    Depth levels per axis number of equally high levels (or a fixed level height in mm).
                          Cutter diameter and milling depth as below.
                          Additional export as STEP (solid body of planar faces, directly in
                          Fusion 360/CAM) and DXF (contours per side and level, layers named by height).
  Milling organic         the result can be produced on a 3-axis milling machine (free form):
    Tool comes from       direction from which the cutter engages (e.g. z+ = from above).
    Setups                1 = only from this side; 2 = the part is flipped and also milled
                          from the opposite side. Regions the cutter cannot reach
                          (undercuts) stay material.
    Cutter diameter       smallest cutter: pockets and slots do not get narrower,
                          inner corners get at least this radius.
    Max. milling depth    stick-out length from the stock surface (bounding box of the
                          part); deeper material remains. 0 = unlimited.
  Tip: the cutter diameter only takes effect once it is at least about 1.5 voxels -
  increase the resolution for fine cutters. The minimum wall thickness (webs) is set
  as usual via "Minimum wall thickness".
  Projects from version 1.0: "3D printing without supports" opens as "3D printing simple",
  "3-axis milling" as "Milling organic". Earlier 1.1 projects with "Milling prismatic" take
  the tool direction (and with 2 setups the opposite side) as milling sides.

LIMITATIONS
  Voxel FEM, linear elastic: results are guide values and should be verified in
  Fusion 360 (Simulation). The result is a mesh, not a parametric body.
  No thermal, flow or nonlinear FEM.

PROBLEMS
  Error messages are written to %LOCALAPPDATA%\Diotopo\diotopo.log
  (Linux: ~/.local/share/Diotopo/diotopo.log, macOS: ~/Library/Application Support/Diotopo/diotopo.log)

COMBINED COMPUTING: CPU + GRAPHICS CARD(S) + MEMORY
  The equation solver does not pick a single compute unit but lets all of them compute
  at the same time (equation solver "Combined", default):
  - Every level of the multigrid method is split into sections: every graphics card
    (NVIDIA, AMD, Intel, also integrated graphics - also several at once) and the CPU with
    all cores compute their section at the same time. Only the boundary values between the
    sections are exchanged (a few percent).
  - The section sizes follow the measured wall time (incl. waiting and data exchange) and
    are readjusted after every solve so that all finish as simultaneously as possible. The
    current split and the actual CPU utilization (average threads) are shown in the log
    ("Solver: ...").
  - If the share of a graphics card does not fit into its memory, it gets as much as fits;
    the rest stays in RAM and is computed by the CPU. Large models therefore keep using the
    graphics card instead of switching completely to the CPU.
  - Coarse levels and very small models (below approx. 30,000 unknowns) are computed by the
    CPU, where the data exchange would cost more than the computation.
  - Without a graphics card the same solver runs on all CPU cores.
  - Everything around the solver also uses all cores: assembly of the stiffness matrix,
    coarse-grid matrices (Galerkin products), density filter. The live 3D view is created
    on the side; the optimization does not wait for it.
  - Processors with cores of different speeds (e.g. Intel Core Ultra / 12th-14th gen. with
    P, E and LP cores) are fully used: the work is split into many small pieces, every free
    core takes the next one.
  Accuracy: the outer method computes in double precision on all CPU cores, the
  preconditioner (most of the work) in single precision distributed over all compute
  units. Results and step count as with the pure CPU solver.
  Note on integrated graphics: it shares the memory with the CPU. The computation is mainly
  limited by its speed, so integrated graphics in addition to the CPU usually gives only a
  smaller gain. A dedicated graphics card gives much more.
  Selectable by hand: "Graphics card only", "CPU only (all cores)", "Direct (small)".
  Setup: "Install packages.bat" (package pyopencl; already included in the installer/portable
  version; the graphics driver provides OpenCL).
  "Test GPU.bat" (in the "Browser Version" folder) shows the graphics cards found and compares
  combined / GPU only / CPU only.
  Environment variables: DIOTOPO_OPENCL_DEVICE=<number or part of name>[,...] limits the
  graphics cards used, DIOTOPO_THREADS=<number> the CPU threads, DIOTOPO_NO_GPU=1 turns the
  graphics cards off.

RESOLUTION, MEMORY AND COMPUTING TIME
  The highest resolution depends on the free memory (approx. 15 KB per voxel element).
  Under "Simulate & Optimize" the element count, memory requirement, estimated computing
  time and the highest possible resolution are shown before starting.
  During every computation a progress bar in the 3D view shows phase, progress, elapsed
  and remaining time, below it the current utilization of CPU, graphics card and memory as
  bars 0-100 % (system-wide, as in Task Manager; RAM turns orange from 80 %, red from 92 %).
  The time estimate learns the speed of this computer (stored in
  %LOCALAPPDATA%\Diotopo\speed.json).

PART VOLUME AFTER THE OPTIMIZATION
  In the "Optimization result" box the "Part volume" slider sets the volume of the
  finished part: live preview while dragging, final mesh + analysis on release.
  The result is always one connected part: floating regions, broken struts and unloaded
  appendages are removed or prevented.

LICENSE AND THIRD-PARTY COMPONENTS
  Diotopo: see LICENSE.txt (in the "Browser Version" folder; shipped with the installer and the
  portable version and shown in the installation wizard).
  Third-party components (Python, NumPy, SciPy, OpenCASCADE, PyOpenCL ...): "Licenses"
  folder - the license texts are placed next to Diotopo.exe automatically when building.
  Before publishing, fill in the placeholders [enter name or company] and
  [enter e-mail address] in LICENSE.txt and Licenses\Third-party licenses.txt.
  The copyright holder then appears automatically in the file properties of Diotopo.exe.
  Note: the "Browser Version" folder contains the source code - for a closed-source release
  only pass on the generated setup file or the portable version.
