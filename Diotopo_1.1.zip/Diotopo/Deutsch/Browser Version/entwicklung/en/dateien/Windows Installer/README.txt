Diotopo 1.1 - Topology optimization
======================================================================

THE "DIOTOPO" FOLDER CONTAINS FIVE VERSIONS
  Browser Version    runs in the browser - on this PC or for other devices in the home network.
                     Needs an installed Python (Windows, Linux, macOS). Also contains the
                     program code from which all other versions are built.
  Portable Version   for USB sticks (Windows): starts directly without installation, leaves
                     nothing behind on the PC. Is created once on a Windows PC with Python
                     (one double-click, a wizard guides you).
  Windows Installer  ready-to-use installation wizard for Windows 10/11:
                     double-click "Install Diotopo.cmd".
  Linux Installer    ready-to-use installation wizard for Linux: "Install Diotopo.sh".
  Mac Installer      ready-to-use installation wizard for macOS: "Install Diotopo.command".
  All three installers first ask where to install, then set up everything needed by
  themselves (Python and computing packages - an internet connection is required), then ask
  about a desktop shortcut and whether Diotopo should be started right away. Every installer
  folder is complete and can be passed on on its own.
  Details: README in each folder.

WINDOWS INSTALLER
----------------------------------------------------------------------
Ready-to-use installation wizard for Windows 10 and 11 (64 bit, x64 or ARM).
Nothing has to be created or installed beforehand - not even Python.

INSTALLING
  Double-click "Install Diotopo.cmd". A wizard window opens:
    1. Where? - choose the target folder (suggestion: %LOCALAPPDATA%\Programs\Diotopo, needs no
       administrator rights). By clicking "Install" you accept the license terms
       (link "Show license terms").
    2. The wizard detects what is missing and installs everything itself - with progress:
       its own Python (from python.org, only inside the Diotopo folder, changes nothing on
       the system), numpy and scipy, pyopencl for graphics cards and OpenCASCADE for STEP
       import. Takes a few minutes and needs an internet connection (approx. 250 MB).
    3. Question: create a shortcut on the desktop?
    4. Question: start Diotopo now?
  A Start menu entry is always created. In Task Manager the program appears as "Diotopo".
  If Windows reports "Windows protected your PC": "More info" -> "Run anyway"
  (the file is not signed).

UPDATING
  Start the wizard of the new version and choose the same folder - the existing Python is
  reused, only the program and packages are renewed.

UNINSTALLING
  Windows Settings > Apps > Installed apps > Diotopo > Uninstall.
  Removes the program folder, Start menu and desktop shortcuts. Settings and log in
  %LOCALAPPDATA%\Diotopo are kept.

PASSING IT ON
  Copy the whole "Windows Installer" folder (with the "app" subfolder) or pass it on as a
  ZIP. The "app" subfolder contains the program files and the wizard (app\setup\installer.ps1).

LICENSE AND THIRD-PARTY COMPONENTS
  Diotopo: see app\LICENSE.txt. Third-party components: app\Licenses. Python, numpy, scipy,
  pyopencl and OpenCASCADE are downloaded by the wizard under their own licenses from
  python.org and the Python Package Index (PyPI).
  Note: the "app" folder contains the program code in plain text.
