﻿; Diotopo - Windows-Installer (Inno Setup 6)
; Optional: klassische Setup-Datei (Diotopo.exe mit PyInstaller). Wird vom Assistenten "Installer erstellen.pyw" uebersetzt (BuildDir und MyAppVersion kommen von dort).
#ifndef BuildDir
  #define BuildDir "build"
#endif
#ifndef MyAppVersion
  #define MyAppVersion "0.0"
#endif
#define MyAppName "Diotopo"
#define MyAppExe "Diotopo.exe"

[Setup]
AppId={{A738EB6A-4A6E-4263-9111-BDC943B22F6B}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher=Diotopo
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
; Installationsordner frei waehlbar
DisableDirPage=no
DisableProgramGroupPage=yes
; "Fuer alle Benutzer" (Programme, Administrator) oder "Nur fuer mich" (ohne Administrator)
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=.
OutputBaseFilename=Diotopo-Setup-{#MyAppVersion}
SetupIconFile=..\..\icon.ico
; Lizenzbedingungen im Assistenten anzeigen (müssen akzeptiert werden)
LicenseFile=..\..\LIZENZ.txt
AppCopyright=Copyright (C) 2026
UninstallDisplayIcon={app}\{#MyAppExe}
UninstallDisplayName={#MyAppName}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
; Installations-Assistent mit Willkommensseite und Dio
DisableWelcomePage=no
WizardImageFile=assistent.bmp,assistent_200.bmp
WizardSmallImageFile=assistent_klein.bmp,assistent_klein_200.bmp
CloseApplications=yes

[Languages]
Name: "de"; MessagesFile: "compiler:Languages\German.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[InstallDelete]
; alte Programmdateien bei einem Update entfernen
Type: filesandordirs; Name: "{app}\_internal"

[Files]
Source: "{#BuildDir}\Diotopo\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "{cm:LaunchProgram,{#MyAppName}}"; Flags: nowait postinstall skipifsilent runasoriginaluser
