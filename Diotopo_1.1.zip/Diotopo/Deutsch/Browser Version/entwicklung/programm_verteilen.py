# -*- coding: utf-8 -*-
"""Kopiert die Programmdateien aus »Browser Version« in den Ordner »app« der drei Installer
(Windows, Linux, Mac), damit jeder Installer-Ordner fertig ist und für sich allein weitergegeben
werden kann.

Aufruf nach jeder Programmänderung (im Ordner »Deutsch« bzw. »English«):
    python "Browser Version/entwicklung/programm_verteilen.py" .
Dateien in »app«, die nicht zum Programm gehören (z. B. app/setup/installer.ps1, app/Diotopo.icns),
bleiben unverändert.
"""
import os
import shutil
import sys

PROGRAMM = ("diotopo", "web", "Diotopo.pyw", "diotopo_web.py", "gpu_test.py", "requirements.txt", "icon.ico",
            "LIZENZ.txt", "LICENSE.txt", "Lizenzen", "Licenses")
INSTALLER = ("Windows Installer", "Linux Installer", "Mac Installer")


def verteilen(root, log=print):
    web = os.path.join(root, "Browser Version")
    for inst in INSTALLER:
        d = os.path.join(root, inst)
        if not os.path.isdir(d):
            continue
        app = os.path.join(d, "app")
        os.makedirs(app, exist_ok=True)
        for name in PROGRAMM:
            dst = os.path.join(app, name)
            if os.path.isdir(dst):
                shutil.rmtree(dst)
            elif os.path.exists(dst):
                os.remove(dst)
            src = os.path.join(web, name)
            if os.path.isdir(src):
                shutil.copytree(src, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            elif os.path.isfile(src):
                shutil.copy2(src, dst)
        log(f"Programmdateien -> {inst}/app")


if __name__ == "__main__":
    verteilen(os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else "."))
