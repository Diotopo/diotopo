@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Diotopo Web - Pakete installieren

set PY=
py -3 --version >nul 2>nul && set PY=py -3
if not defined PY python --version >nul 2>nul && set PY=python
if not defined PY goto nopython

echo [1/2] Pflichtpakete installieren: numpy, scipy ...
%PY% -m pip install --upgrade pip >nul
%PY% -m pip install --only-binary=:all: -r requirements.txt
if errorlevel 1 goto fehler
echo [2/2] Optionale Pakete: cadquery-ocp-novtk fuer STEP (OpenCASCADE), pyopencl fuer Grafikkarten ...
for %%P in (cadquery-ocp-novtk pyopencl) do %PY% -m pip install --only-binary=:all: %%P >nul 2>nul || echo    Hinweis: %%P nicht verfuegbar - Diotopo laeuft trotzdem, nur ohne diese Zusatzfunktion.
echo.
echo Fertig. Start mit "Diotopo im Browser starten.bat".
pause
exit /b 0
:fehler
echo.
echo Installation fehlgeschlagen. Evtl. gibt es fuer diese Python-Version noch keine fertigen Pakete -
echo dann Python 3.13 installieren und diese Datei erneut starten.
pause
exit /b 1

:nopython
echo.
echo Python wurde nicht gefunden.
echo Bitte Python 3.10 oder neuer von https://www.python.org/downloads/ installieren
echo und dabei "Add python.exe to PATH" anhaken. Danach diese Datei erneut starten.
pause
exit /b 1
