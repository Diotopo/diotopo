# -*- coding: utf-8 -*-
"""
Mehrkern-Rechnen auf der CPU.

* run_tasks(): ein schlankes, dauerhaft laufendes Arbeiterteam mit so vielen Threads wie
  Prozessorkerne (DIOTOPO_THREADS=<Zahl> legt die Anzahl fest). Der aufrufende Thread rechnet mit,
  geweckt werden nur so viele Arbeiter, wie es Stücke gibt. (Ein ThreadPoolExecutor kostete bei
  22 Threads > 1 ms Verwaltung je Aufruf – bei ~100 Aufrufen je CG-Schritt mehr als die Rechnung.)
* Stücke werden so groß gewählt, dass die Rechnung den Verwaltungsaufwand klar überwiegt;
  kleine Operationen laufen ohne Aufteilung.
* Arbeit wird in mehr Stücke geteilt, als es Threads gibt (OVERSPLIT); jeder freie Kern holt
  sich das nächste Stück. So bremsen langsame Kerne (Effizienz-/Niedrigenergiekerne, z. B. Intel
  Core Ultra, Arm big.LITTLE) die schnellen nicht aus, und andere Programme stören weniger.
* ThreadedCSR: dünne Matrix, deren Matrix-Vektor-Produkt auf alle Kerne verteilt wird.
  scipy gibt beim Produkt den GIL frei, die Threads rechnen also wirklich gleichzeitig.
  Die Zeilenblöcke werden nach Anzahl der Einträge gleich groß gewählt; es wird nichts kopiert.
"""

import os
import threading

import numpy as np
import scipy.sparse as sp

try:
    from scipy.sparse._sparsetools import csr_matvec as _csr_matvec, csr_matvecs as _csr_matvecs
except Exception:  # noqa – ältere/neuere scipy ohne diese Funktionen: Kopien je Block
    _csr_matvec = _csr_matvecs = None

PAR_NNZ = 300_000      # ab so vielen Einträgen lohnt das Aufteilen eines Produkts
PAR_N = 200_000        # ab so vielen Werten lohnt das Aufteilen einer Vektoroperation


OVERSPLIT = 2          # Stücke je Thread (dynamische Lastverteilung auf ungleich schnelle Kerne)


def n_threads():
    v = os.environ.get("DIOTOPO_THREADS", "").strip()
    if v.isdigit() and int(v) > 0:
        return int(v)
    return max(1, os.cpu_count() or 1)


class _Team:
    """Dauerhafte Arbeiter-Threads. run(k, fn) führt fn(0) … fn(k−1) aus; der Aufrufer rechnet mit.
    Stücke werden der Reihe nach vergeben (schnelle Kerne holen sich mehr)."""

    def __init__(self, T):
        self.T = T
        self.cv = threading.Condition(threading.Lock())
        self.job = None                 # [fn, k, nächstes, fertig, Fehler, Ereignis]
        self.gen = 0
        self.run_lock = threading.Lock()
        for i in range(T - 1):
            threading.Thread(target=self._worker, name=f"diotopo-{i}", daemon=True).start()

    def _grab(self):
        with self.cv:
            j = self.job
            if j is None or j[2] >= j[1]:
                return None, None
            i = j[2]
            j[2] += 1
            return j, i

    def _work(self):
        while True:
            j, i = self._grab()
            if j is None:
                return
            try:
                j[0](i)
            except BaseException as e:  # noqa
                j[4] = e
            with self.cv:
                j[3] += 1
                if j[3] == j[1]:
                    j[5].set()

    def _worker(self):
        seen = 0
        while True:
            with self.cv:
                while self.gen == seen:
                    self.cv.wait()
                seen = self.gen
            self._work()

    def run(self, k, fn):
        if k <= 1 or self.T <= 1:
            for i in range(k):
                fn(i)
            return
        with self.run_lock:            # ein Auftrag zur Zeit (andere Aufrufer warten kurz)
            j = [fn, k, 0, 0, None, threading.Event()]
            with self.cv:
                self.job = j
                self.gen += 1
                self.cv.notify(min(k - 1, self.T - 1))
            _TL.busy = True            # rechnet der Aufrufer selbst mit, darf er nicht erneut verteilen
            try:
                self._work()
            finally:
                _TL.busy = False
            j[5].wait()
            with self.cv:
                self.job = None
            if j[4] is not None:
                raise j[4]


_TEAM = {}
_LOCK = threading.Lock()
_TL = threading.local()


def team():
    with _LOCK:
        if "t" not in _TEAM:
            _TEAM["t"] = _Team(n_threads())
        return _TEAM["t"]


def run_tasks(k, fn):
    """fn(i) für i = 0 … k−1 auf allen Kernen."""
    if threading.current_thread().name.startswith("diotopo-") or getattr(_TL, "busy", False):
        # schon in einem Arbeiter oder im mitrechnenden Aufrufer: nicht verschachteln (sonst wartet
        # der Aufrufer auf seine eigene Sperre und das Programm hängt)
        for i in range(k):
            fn(i)
        return
    team().run(k, fn)


def run_chunks(n, fn, threads=None, minsize=PAR_N):
    """fn(a, b) für Teilbereiche von [0, n) – parallel, wenn n groß genug ist."""
    if n <= 0:
        return
    T = threads or n_threads()
    k = min(T * OVERSPLIT if T > 1 else 1, max(1, n // max(minsize // 2, 1)))
    if k <= 1:
        fn(0, n)
        return
    e = np.linspace(0, n, k + 1).astype(np.int64)
    run_tasks(k, lambda i: fn(int(e[i]), int(e[i + 1])))


class ThreadedCSR:
    """CSR-Matrix mit Produkt auf allen Kernen. Unterstützt A @ x für Vektoren und Matrizen."""

    def __init__(self, A, threads=None):
        A = A.tocsr()
        if A.indptr.dtype != A.indices.dtype:
            A.indptr = A.indptr.astype(A.indices.dtype)
        self.A = A
        self.shape = A.shape
        self.dtype = A.dtype
        self.nnz = A.nnz
        T = threads or n_threads()
        n = A.shape[0]
        if T > 1 and A.nnz >= PAR_NNZ and n >= 2 * T:
            k = min(T * OVERSPLIT, max(1, A.nnz // (PAR_NNZ // 2)))
            e = np.searchsorted(A.indptr, np.linspace(0, A.nnz, k + 1)).astype(np.int64)
            e[0], e[-1] = 0, n
            self.edges = np.unique(e)
        else:
            self.edges = np.array([0, n])
        self.blocks = None
        if len(self.edges) > 2 and _csr_matvec is None:
            self.blocks = [A[int(a):int(b)] for a, b in zip(self.edges[:-1], self.edges[1:])]

    def diagonal(self):
        return self.A.diagonal()

    def tocsr(self):
        return self.A

    def matvec(self, x, out=None):
        A = self.A
        x = np.ascontiguousarray(x, dtype=A.dtype)
        n, m = A.shape
        if len(self.edges) <= 2:
            r = A @ x
            if out is None:
                return r
            out[...] = r
            return out
        if out is None:
            out = np.empty((n,) + x.shape[1:], dtype=A.dtype)
        e = self.edges

        def blk(i):
            a, b = int(e[i]), int(e[i + 1])
            o = out[a:b]
            if self.blocks is not None:
                o[...] = self.blocks[i] @ x
                return
            o[...] = 0
            ip = A.indptr[a:b + 1]
            if x.ndim == 1:
                _csr_matvec(b - a, m, ip, A.indices, A.data, x, o)
            else:
                _csr_matvecs(b - a, m, x.shape[1], ip, A.indices, A.data, x.ravel(), o.reshape(-1))

        run_tasks(len(e) - 1, blk)
        return out

    def __matmul__(self, x):
        if sp.issparse(x):
            return self.A @ x
        return self.matvec(x)


# ================================================================ Spaltenweise Vektoroperationen (alle Kerne)

def coldot(X, Y):
    """Skalarprodukte je Spalte von X und Y (n×k)."""
    k = X.shape[1]
    parts = []

    def f(a, b):
        parts.append(np.einsum("ij,ij->j", X[a:b], Y[a:b]))
    run_chunks(X.shape[0], f)
    return np.sum(parts, axis=0) if parts else np.zeros(k)


def axpy(Y, X, a):
    """Y += X * a   (a: Zahl oder je Spalte)"""
    def f(s, e):
        Y[s:e] += X[s:e] * a
    run_chunks(Y.shape[0], f)


def xpby(out, X, Y, b):
    """out = X + Y * b   (out darf Y sein)"""
    def f(s, e):
        t = Y[s:e] * b
        np.add(X[s:e], t, out=out[s:e])
    run_chunks(out.shape[0], f)


def sub(out, X, Y):
    """out = X − Y"""
    def f(s, e):
        np.subtract(X[s:e], Y[s:e], out=out[s:e])
    run_chunks(out.shape[0], f)


def pcg(A, B, prec, X0=None, tol=1e-8, maxit=500, cancel=None, stopped=Exception):
    """Flexibles vorkonditioniertes CG in float64 für mehrere rechte Seiten (n×k), alle
    Vektoroperationen und Produkte auf allen Kernen. A: ThreadedCSR, prec(R) -> Z."""
    B = np.ascontiguousarray(B[:, None] if B.ndim == 1 else B, dtype=np.float64)
    X = np.zeros_like(B) if X0 is None else np.ascontiguousarray(X0, dtype=np.float64).reshape(B.shape).copy()
    R = np.empty_like(B)
    sub(R, B, A @ X)
    bn = np.sqrt(np.maximum(coldot(B, B), 1e-300 ** 2))
    bn = np.maximum(bn, 1e-300)
    Z = prec(R)
    Pd = Z.copy()
    rz = coldot(R, Z)
    it, resmax = 0, float("inf")
    for it in range(1, maxit + 1):
        AP = A @ Pd
        pap = coldot(Pd, AP)
        alpha = np.where(pap > 0, rz / np.where(pap > 0, pap, 1.0), 0.0)
        axpy(X, Pd, alpha)
        axpy(R, AP, -alpha)
        res = np.sqrt(np.maximum(coldot(R, R), 0.0)) / bn
        resmax = float(res.max())
        if resmax < tol:
            break
        if cancel is not None and cancel():
            raise stopped()
        Zn = prec(R)
        rz_new = coldot(R, Zn)
        rz_pr = rz_new - coldot(R, Z)                     # Polak-Ribière
        beta = np.where(rz > 0, np.maximum(rz_pr, 0.0) / np.where(rz > 0, rz, 1.0), 0.0)
        xpby(Pd, Zn, Pd, beta)
        Z, rz = Zn, rz_new
    return X, it, resmax


# ================================================================ Matrixaufbau auf allen Kernen

try:
    from scipy.sparse._sparsetools import csr_matmat as _csr_matmat, csr_matmat_maxnnz as _csr_maxnnz
except Exception:  # noqa
    _csr_matmat = _csr_maxnnz = None


def spmm(A, B, threads=None):
    """C = A @ B (beide CSR), zeilenblockweise auf allen Kernen. Ergebnis CSR (Spalten je Zeile
    nicht unbedingt sortiert – wie bei scipy)."""
    A, B = A.tocsr(), B.tocsr()
    T = threads or n_threads()
    n, m = A.shape[0], B.shape[1]
    if _csr_matmat is None or T <= 1 or A.nnz < PAR_NNZ:
        return (A @ B).tocsr()
    idt = np.int64 if max(A.nnz, B.nnz, n, m) > 2**31 - 2 else np.int32
    Ap, Aj = A.indptr.astype(idt, copy=False), A.indices.astype(idt, copy=False)
    Bp, Bj = B.indptr.astype(idt, copy=False), B.indices.astype(idt, copy=False)
    dt = np.result_type(A.dtype, B.dtype)
    Ax, Bx = A.data.astype(dt, copy=False), B.data.astype(dt, copy=False)
    k = min(T * OVERSPLIT, max(1, A.nnz // (PAR_NNZ // 2)))
    e = np.unique(np.searchsorted(Ap, np.linspace(0, A.nnz, k + 1)).astype(np.int64))
    e[0], e[-1] = 0, n
    e = np.unique(e)

    def blk(i):
        a, b = int(e[i]), int(e[i + 1])
        ap = Ap[a:b + 1]
        nnz = int(_csr_maxnnz(b - a, m, ap, Aj, Bp, Bj))
        cp = np.empty(b - a + 1, dtype=idt)
        cj = np.empty(nnz, dtype=idt)
        cx = np.empty(nnz, dtype=dt)
        _csr_matmat(b - a, m, ap, Aj, Ax, Bp, Bj, Bx, cp, cj, cx)
        k_ = int(cp[-1])
        return cp, cj[:k_], cx[:k_]
    parts = [None] * (len(e) - 1)

    def blk2(i):
        parts[i] = blk(i)
    run_tasks(len(e) - 1, blk2)
    tot = sum(len(p[1]) for p in parts)
    idt2 = np.int64 if tot > 2**31 - 2 else np.int32
    indptr = np.empty(n + 1, dtype=idt2)
    indices = np.empty(tot, dtype=idt2)
    data = np.empty(tot, dtype=dt)
    offs = np.concatenate([[0], np.cumsum([len(p[1]) for p in parts])]).astype(np.int64)
    indptr[0] = 0

    def put(i):
        a, b = int(e[i]), int(e[i + 1])
        cp, cj, cx = parts[i]
        o = offs[i]
        indptr[a + 1:b + 1] = cp[1:] + o
        indices[o:o + len(cj)] = cj
        data[o:o + len(cx)] = cx
    run_tasks(len(parts), put)
    return sp.csr_matrix((data, indices, indptr), shape=(n, m))


def astype_csr(A, dtype):
    """Typumwandlung der Werte auf allen Kernen; Indexfelder werden geteilt (keine Kopie)."""
    A = A.tocsr()
    if A.dtype == dtype:
        return A
    d = np.empty(A.nnz, dtype=dtype)
    src = A.data

    def f(a, b):
        d[a:b] = src[a:b]
    run_chunks(A.nnz, f)
    M = sp.csr_matrix((d, A.indices, A.indptr), shape=A.shape, copy=False)
    M.has_sorted_indices = A.has_sorted_indices
    return M


def row_abs_sum(A):
    """Zeilensummen der Beträge (für die Gershgorin-Schranke) auf allen Kernen."""
    A = A.tocsr()
    n = A.shape[0]
    out = np.zeros(n)
    ip, dat = A.indptr, A.data

    def f(r0, r1):
        s, e = int(ip[r0]), int(ip[r1])
        if e <= s:
            return
        cs = np.empty(e - s + 1)
        cs[0] = 0.0
        np.cumsum(np.abs(dat[s:e]), out=cs[1:])
        out[r0:r1] = cs[ip[r0 + 1:r1 + 1] - s] - cs[ip[r0:r1] - s]
    run_chunks(n, f, minsize=8000)
    return out


def take(src, idx, out=None):
    """out = src[idx] auf allen Kernen."""
    if out is None:
        out = np.empty(len(idx), dtype=src.dtype)

    def f(a, b):
        np.take(src, idx[a:b], out=out[a:b])
    run_chunks(len(idx), f)
    return out
