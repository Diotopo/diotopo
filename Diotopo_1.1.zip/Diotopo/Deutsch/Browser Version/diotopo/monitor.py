# -*- coding: utf-8 -*-
"""
Aktuelle Auslastung von CPU, Grafikkarte und Arbeitsspeicher (systemweit, wie im Task-Manager).

* CPU: Windows GetSystemTimes, Linux /proc/stat, sonst psutil.
* GPU: Windows-Leistungsindikator „GPU Engine\\Utilization Percentage“ (dieselbe Quelle wie der
  Task-Manager, alle Hersteller; je Engine über alle Prozesse summiert, Maximum der Engines);
  Linux: AMD-sysfs gpu_busy_percent; sonst nvidia-smi, falls vorhanden. Sonst None (nicht messbar).
* RAM: belegter Anteil des physischen Arbeitsspeichers.

Ein Hintergrund-Thread misst etwa alle 0,7 s; snapshot() liefert den letzten Stand ohne zu warten.
"""

import glob
import os
import shutil
import subprocess
import threading
import time

from . import perf as PF

INTERVAL = 0.7


# ================================================================ CPU

class _CPUWin:
    def __init__(self):
        import ctypes
        from ctypes import wintypes
        self.ct, self.k32 = ctypes, ctypes.windll.kernel32
        self.FT = wintypes.FILETIME
        self.last = self._read()

    def _read(self):
        i, k, u = self.FT(), self.FT(), self.FT()
        self.k32.GetSystemTimes(self.ct.byref(i), self.ct.byref(k), self.ct.byref(u))
        v = lambda f: (f.dwHighDateTime << 32) | f.dwLowDateTime  # noqa: E731
        return v(i), v(k), v(u)                     # Kernelzeit enthält die Leerlaufzeit

    def sample(self):
        i, k, u = self._read()
        i0, k0, u0 = self.last
        self.last = (i, k, u)
        tot = (k - k0) + (u - u0)
        return None if tot <= 0 else max(0.0, min(100.0, 100.0 * (1.0 - (i - i0) / tot)))


class _CPULinux:
    def __init__(self):
        self.last = self._read()

    @staticmethod
    def _read():
        with open("/proc/stat") as f:
            v = [int(x) for x in f.readline().split()[1:]]
        idle = v[3] + (v[4] if len(v) > 4 else 0)
        return idle, sum(v[:8])

    def sample(self):
        i, t = self._read()
        i0, t0 = self.last
        self.last = (i, t)
        return None if t <= t0 else max(0.0, min(100.0, 100.0 * (1.0 - (i - i0) / (t - t0))))


class _CPUPsutil:
    def __init__(self):
        import psutil
        self.p = psutil
        psutil.cpu_percent(None)

    def sample(self):
        return float(self.p.cpu_percent(None))


def _cpu_reader():
    for cls in ((_CPUWin,) if os.name == "nt" else (_CPULinux,)) + (_CPUPsutil,):
        try:
            return cls()
        except Exception:  # noqa
            pass
    return None


# ================================================================ GPU

class _GPUWinPdh:
    """Windows-Leistungsindikatoren (PDH), wie der Task-Manager."""

    def __init__(self):
        import ctypes
        from ctypes import wintypes
        ct = ctypes
        self.ct = ct
        self.pdh = ct.windll.pdh
        for fn in ("PdhOpenQueryW", "PdhAddEnglishCounterW", "PdhCollectQueryData", "PdhGetFormattedCounterArrayW"):
            getattr(self.pdh, fn).restype = ct.c_ulong          # PDH-Statuscodes sind vorzeichenlos

        class FMTVAL(ct.Structure):
            _fields_ = [("CStatus", wintypes.DWORD), ("doubleValue", ct.c_double)]

        class ITEM(ct.Structure):
            _fields_ = [("szName", ct.c_wchar_p), ("FmtValue", FMTVAL)]
        self.ITEM = ITEM
        self.q = ct.c_void_p()
        self.c = ct.c_void_p()
        if self.pdh.PdhOpenQueryW(None, None, ct.byref(self.q)) != 0:
            raise OSError("PdhOpenQuery")
        r = self.pdh.PdhAddEnglishCounterW(self.q, ct.c_wchar_p(r"\GPU Engine(*)\Utilization Percentage"),
                                           None, ct.byref(self.c))
        if r != 0:
            raise OSError(f"PdhAddEnglishCounter {r:#x}")
        self.pdh.PdhCollectQueryData(self.q)

    def sample(self):
        ct, pdh = self.ct, self.pdh
        if pdh.PdhCollectQueryData(self.q) != 0:
            return None
        size, count = ct.c_ulong(0), ct.c_ulong(0)
        PDH_FMT_DOUBLE, PDH_MORE_DATA = 0x200, 0x800007D2
        r = pdh.PdhGetFormattedCounterArrayW(self.c, PDH_FMT_DOUBLE, ct.byref(size), ct.byref(count), None)
        if r != PDH_MORE_DATA or size.value == 0:
            return None
        buf = ct.create_string_buffer(size.value)
        r = pdh.PdhGetFormattedCounterArrayW(self.c, PDH_FMT_DOUBLE, ct.byref(size), ct.byref(count), buf)
        if r != 0:
            return None
        items = ct.cast(buf, ct.POINTER(self.ITEM * count.value)).contents
        eng = {}
        for it in items:
            if it.FmtValue.CStatus not in (0, 1) or not it.szName:
                continue
            nm = it.szName
            k = nm.find("luid_")
            key = nm[k:] if k >= 0 else nm             # gleiche Engine über alle Prozesse
            eng[key] = eng.get(key, 0.0) + it.FmtValue.doubleValue
        if not eng:
            return 0.0
        return max(0.0, min(100.0, max(eng.values())))


class _GPUAmdSysfs:
    def __init__(self):
        self.files = glob.glob("/sys/class/drm/card*/device/gpu_busy_percent")
        if not self.files:
            raise OSError("kein gpu_busy_percent")

    def sample(self):
        v = []
        for f in self.files:
            try:
                v.append(float(open(f).read().strip()))
            except Exception:  # noqa
                pass
        return max(v) if v else None


class _GPUNvidiaSmi:
    def __init__(self):
        self.exe = shutil.which("nvidia-smi")
        if not self.exe:
            raise OSError("kein nvidia-smi")
        if self.sample() is None:
            raise OSError("nvidia-smi liefert nichts")

    def sample(self):
        try:
            kw = dict(creationflags=0x08000000) if os.name == "nt" else {}     # kein Konsolenfenster
            out = subprocess.run([self.exe, "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=2, **kw).stdout
            v = [float(x) for x in out.split() if x.strip().replace(".", "", 1).isdigit()]
            return max(v) if v else None
        except Exception:  # noqa
            return None


def _gpu_reader():
    cands = (_GPUWinPdh, _GPUNvidiaSmi) if os.name == "nt" else (_GPUAmdSysfs, _GPUNvidiaSmi)
    for cls in cands:
        try:
            return cls()
        except Exception:  # noqa
            pass
    return None


# ================================================================ Messthread

class Monitor:
    def __init__(self):
        self.lock = threading.Lock()
        self.data = dict(cpu=None, gpu=None, ram=None, t=0.0)
        self.started = False
        self.last_ask = 0.0

    def _ram(self):
        avail, total = PF.ram()
        if not total:
            return None
        return max(0.0, min(100.0, 100.0 * (1.0 - (avail or 0) / total)))

    def _run(self):
        cpu, gpu = _cpu_reader(), _gpu_reader()
        while True:
            if time.time() - self.last_ask > 30:          # niemand schaut zu: Pause
                time.sleep(INTERVAL)
                continue
            d = dict(t=time.time())
            for k, r in (("cpu", cpu), ("gpu", gpu)):
                try:
                    d[k] = r.sample() if r is not None else None
                except Exception:  # noqa
                    d[k] = None
            try:
                d["ram"] = self._ram()
            except Exception:  # noqa
                d["ram"] = None
            with self.lock:
                self.data = d
            time.sleep(INTERVAL)

    def snapshot(self):
        self.last_ask = time.time()
        if not self.started:
            self.started = True
            threading.Thread(target=self._run, name="diotopo-monitor", daemon=True).start()
        with self.lock:
            return {k: (None if v is None else round(float(v), 1)) for k, v in self.data.items() if k != "t"}


MON = Monitor()


def snapshot():
    return MON.snapshot()

