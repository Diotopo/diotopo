"""Diotopo – Topologieoptimierung."""

import os as _os
import sys as _sys

# Datenordner je System (Einstellungen, Protokoll, Fensterprofil): Windows %LOCALAPPDATA%,
# Linux ~/.local/share, macOS ~/Library/Application Support
if _os.name != "nt" and not _os.environ.get("LOCALAPPDATA"):
    _os.environ["LOCALAPPDATA"] = (_os.path.expanduser("~/Library/Application Support") if _sys.platform == "darwin"
                                  else _os.environ.get("XDG_DATA_HOME") or _os.path.expanduser("~/.local/share"))



def rechteinhaber():
    """Rechteinhaber aus LIZENZ.txt (Zeile „Rechteinhaber: …“) – einzige Stelle, an der er gepflegt wird.
    Gesucht neben Diotopo.exe, im Programmordner und im Quellcode-Ordner."""
    import os
    import sys
    here = os.path.dirname(os.path.abspath(__file__))
    for d in (os.path.dirname(sys.executable), getattr(sys, "_MEIPASS", ""), os.path.dirname(here)):
        for name in ("LIZENZ.txt", "LICENSE.txt"):
            p = os.path.join(d, name)
            if not (d and os.path.isfile(p)):
                continue
            try:
                for line in open(p, encoding="utf-8-sig"):
                    if line.lower().startswith(("rechteinhaber:", "copyright holder:")):
                        v = line.split(":", 1)[1].strip()
                        return "" if v.startswith("[") else v
            except OSError:
                pass
    return ""

