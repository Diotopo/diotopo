# -*- coding: utf-8 -*-
"""Lokaler HTTP-Server: verbindet Oberfläche (web/) und Rechenkern."""

import json
import math
import os
import socket
import struct
import threading
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import numpy as np

from . import aniso as AN
from . import engine as E
from . import geom as G
from . import prisma as PZ
from . import solver as SV
from . import support_check as SC
from . import par as PR
from . import monitor as MO
from . import perf as PF

VERSION = "1.1"
ALLOWED_LINKS = ("https://paypal.me/diotopo",)
WEB = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web")
MIME = {".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8", ".png": "image/png", ".ico": "image/x-icon",
        ".svg": "image/svg+xml"}


def pack(meta, arrays):
    """Binärpaket: uint32 Länge + JSON + Arrays (4-Byte-ausgerichtet)."""
    blobs, desc, off = [], [], 0
    for name, a in arrays.items():
        a = np.ascontiguousarray(a)
        b = a.tobytes()
        desc.append(dict(name=name, dtype=a.dtype.name, shape=list(a.shape), offset=off, bytes=len(b)))
        pad = (-len(b)) % 4
        blobs.append(b + b"\0" * pad)
        off += len(b) + pad
    head = json.dumps(dict(meta=meta, arrays=desc), default=_jsonable).encode("utf-8")
    head += b" " * ((-len(head)) % 4)
    return struct.pack("<I", len(head)) + head + b"".join(blobs)


def _jsonable(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


class Project:
    def __init__(self):
        self.lock = threading.Lock()
        self.calc_lock = threading.Lock()   # Feinnetz/Vorschau nicht gleichzeitig (gemeinsamer Modellzustand)
        self.mesh = None
        self.name = "Bauteil"
        self.kind = None
        self.unit_hint = None
        self.job = None
        self.results = {}       # analyze | optimize
        self.last_seen = time.time()
        self.bye_at = 0.0       # Fenster meldet „wird geschlossen“ (pagehide)


P = Project()


class Job:
    def __init__(self, kind, fn):
        self.kind = kind
        self.state = "running"
        self.logs = []
        self.progress = 0.0
        self.info = {}
        self.hist = []
        self.frame = None
        self.frame_id = 0
        self.error = None
        self.stop = False
        self.stop_finish = False            # Optimierung: zweiter Stopp bricht auch das Ergebnisnetz ab
        self.t0 = time.time()
        self.pg = PF.Progress()
        self.thread = threading.Thread(target=self._run, args=(fn,), daemon=True)
        self.thread.start()

    def log(self, m):
        self.logs.append(str(m))

    def _run(self, fn):
        try:
            fn(self)
            self.progress = 1.0
            self.state = "done"
        except E.Stopped:
            self.log("Auftrag abgebrochen.")
            self.state = "cancelled"
        except Exception as e:  # noqa
            traceback.print_exc()
            self.error = str(e)
            self.log("FEHLER: " + str(e))
            self.state = "error"


# ===================================================================== Aufträge

def _model(job, settings, conds):
    return E.Model(P.mesh, settings, conds, log=job.log)


# ---------------------------------------------------------------- Aufwandsschätzung

def _elements_estimate(settings):
    m = P.mesh
    ext = m.hi - m.lo
    h = float(ext.max()) / int(settings.get("resolution", 50))
    vol = abs(float(getattr(m, "volume", 0.0)))
    if vol <= 0:
        vol = float(np.prod(ext)) * 0.5
    ne = int(vol / h ** 3 * 1.06) + 1
    return ne, h


def _gpu_names():
    try:
        from . import hybrid as HY
        return [p.name for p in HY.gpu_parts()]
    except Exception:  # noqa
        return []


def _solver_key(ndof, settings):
    return "iter_" + SV.planned_kind(int(ndof), settings.get("solver", "auto"))


FILTER_LIMIT = 4e7          # wie engine.Optimizer: 4/3·π·R³·Elemente
MAX_FINE_VOXELS = 16_000_000


def _fits(S, res, refine):
    """Passt eine Rechnung mit dieser Auflösung in den Speicher und in die Grenzen des Rechenkerns?"""
    S = dict(S, resolution=int(res))
    ne, h = _elements_estimate(S)
    scale = E.LEN_MM[S.get("unit_len", "mm")]
    mw = float(S.get("minwall_mm") or 0)
    R = min(10.0, max(1.5, mw / (h * scale)) if mw > 0 else 1.5)
    if 4 / 3 * math.pi * R ** 3 * ne > 0.9 * FILTER_LIMIT:      # Reserve: echte Elementzahl schwankt
        return False
    avail, _ = PF.ram()
    if not avail:
        return ne <= 250_000
    return PF.fe_memory(ne, dict(S, _h_mm=h * scale), refine=refine) <= avail * PF.RAM_USE


def capacity_limits(kind, settings):
    """Größte bzw. kleinste Werte der Schieberegler, die auf diesem Rechner berechnet werden können."""
    S = dict(E.DEFAULTS, **settings)
    refine = bool(S.get("refine", True)) and kind == "optimize"
    if kind != "optimize":
        S["minwall_mm"] = 0                   # die Analyse filtert nicht
    lo, hi = 16, 800
    if not _fits(S, lo, refine):
        res_max = lo
    else:
        while hi - lo > 1:                    # größte passende Auflösung (monoton in der Auflösung)
            mid = (lo + hi) // 2
            if _fits(S, mid, refine):
                lo = mid
            else:
                hi = mid
        res_max = lo if not _fits(S, hi, refine) else hi
    res = min(int(S.get("resolution", 50)), res_max)
    ne, h = _elements_estimate(dict(S, resolution=res))
    scale = E.LEN_MM[S.get("unit_len", "mm")]
    h_mm = h * scale
    # Mindestwandstärke: Filterradius höchstens 10 Voxel, Filter muss in Speicher und Grenze passen
    r_err = (0.9 * FILTER_LIMIT / (4 / 3 * math.pi * max(ne, 1))) ** (1 / 3)
    avail, _ = PF.ram()
    r_mem = 10.0
    if avail:
        spare = avail * PF.RAM_USE - PF.fe_memory(ne, None, refine=refine)
        if spare > 0:
            r_mem = max(1.5, ((spare / 40 + 20 * ne) / (4 / 3 * math.pi * max(ne, 1))) ** (1 / 3))
        else:
            r_mem = 1.5
    minwall_max = h_mm * max(1.5, min(10.0, r_err, r_mem))
    ext_mm = (P.mesh.hi - P.mesh.lo) * scale
    detail_min = max((float(np.prod(np.abs(ext_mm) + 1e-12)) / MAX_FINE_VOXELS) ** (1 / 3), h_mm / 8)
    return dict(resolution_max=int(res_max), minwall_max_mm=float(minwall_max),
                cnc_tool_max_mm=float(16 * h_mm), detail_min_mm=float(detail_min), voxel_mm=float(h_mm))


def fe_estimate(kind, settings):
    """Elemente, Speicher und Zeit vor dem Start (Zeiten lernen aus früheren Rechnungen)."""
    S = dict(E.DEFAULTS, **settings)
    ne, h = _elements_estimate(S)
    scale = E.LEN_MM[S.get("unit_len", "mm")]
    ndof = 3.1 * ne
    refine = bool(S.get("refine", True)) and kind == "optimize"
    need = PF.fe_memory(ne, dict(S, _h_mm=h * scale), refine=refine)
    avail, total = PF.ram()
    mx, _ = PF.max_elements(dict(S, _h_mm=h * scale), refine=refine)
    res = int(S.get("resolution", 50))
    rmax = max(16, int(res * (mx / max(ne, 1)) ** (1 / 3)))
    sk = _solver_key(ndof, S)
    sp = PF.SPEED
    tb = sp.get("build") * ne
    ta = sp.get("analyze") * ne
    out = dict(elements=ne, dofs=int(ndof), memory_mb=need / 2**20, avail_mb=(avail or 0) / 2**20,
               total_mb=(total or 0) / 2**20, too_big=bool(avail) and need > avail * PF.RAM_USE,
               max_resolution=rmax, solver=sk[5:], voxel_mm=h * scale)
    try:
        lim = capacity_limits(kind, settings)
        out["limits"] = lim
        out["max_resolution"] = lim["resolution_max"]
        out["too_big"] = out["too_big"] or int(S.get("resolution", 50)) > lim["resolution_max"]
    except Exception:  # noqa
        pass
    if kind == "analyze":
        out.update(seconds=tb + ta, plan=[["Modell aufbauen", tb], ["Analyse rechnen", ta]])
    else:
        ti = sp.get(sk) * ne * _iter_factor(S)
        it = int(S.get("max_iter", 80))
        tm = sp.get("finish") * ne * 0.3 + (sp.get("refine") if refine else 0.0)
        plan = [["Modell aufbauen", tb], ["Lagerung prüfen", 1.3 * ti], ["Optimierung", ti * it],
                ["Ergebnisnetz", tm], ["Ergebnis analysieren", ta]]
        out.update(seconds=sum(p[1] for p in plan), seconds_iter=ti, iterations=it, plan=plan)
    return out


def _iter_factor(S):
    """Mehraufwand je Iteration: Schichthaftung (adjungierte Rechnung), Randschichten."""
    f = 1.0
    if S.get("mfg") == "am_adv":
        f *= 1.1
    return f


def _learn_iter(M, n_iter, seconds):
    kind = (M.solver_info or "mg").split()[0]
    if n_iter > 0 and M.ne:
        PF.SPEED.learn("iter_" + kind, seconds / n_iter / M.ne / max(len(M.groups), 1) / _iter_factor(M.S))


# ---------------------------------------------------------------- Aufträge

def job_analyze(settings, conds):
    def run(job):
        est = fe_estimate("analyze", settings)
        job.pg.set_plan(est["plan"])
        t = time.time()
        M = _model(job, settings, conds)
        PF.SPEED.learn("build", (time.time() - t) / M.ne)
        job.pg.expect("Analyse rechnen", PF.SPEED.get("analyze") * M.ne)
        job.pg.phase("Analyse rechnen")
        job.log("Analysiere Vollteil …")
        t = time.time()
        verts = P.mesh.tris.reshape(-1, 3)
        M.cancel = lambda: job.stop
        A = E.analyze(M, np.ones(M.ne), verts)
        M.cancel = None
        PF.SPEED.learn("analyze", (time.time() - t) / M.ne)
        job.log(f"Löser: {M.solver_info}")
        P.results["analyze"] = dict(model=M, A=A, verts=None, faces=None, settings=settings)
    return run


def job_optimize(settings, conds):
    def run(job):
        est = fe_estimate("optimize", settings)
        pg = job.pg
        pg.set_plan(est["plan"])
        t = time.time()
        M = _model(job, settings, conds)
        PF.SPEED.learn("build", (time.time() - t) / M.ne)
        # Plan mit der echten Elementzahl und den Lastfall-Gruppen nachschärfen
        ti = PF.SPEED.get(_solver_key(M.nfree, M.S)) * M.ne * max(len(M.groups), 1) * _iter_factor(M.S)
        max_it = max(int(M.S["max_iter"]), 1)
        pg.expect("Lagerung prüfen", 1.3 * ti)
        pg.expect("Optimierung", ti * max_it)
        pg.expect("Ergebnis analysieren", PF.SPEED.get("analyze") * M.ne)
        tl = {"t": None, "n": 0}
        live = {"busy": False}

        def on_phase(name):
            if name == "check":
                pg.phase("Lagerung prüfen")
            elif name == "loop":
                pg.phase("Optimierung")
                tl["t"] = time.time()

        def on_frame(it, xp, info):
            tl["n"] = it
            pg.set_frac(it / max_it, f"Iteration {it} von höchstens {max_it}")
            if job.stop:                     # nach Stopp kein Live-Netz mehr erzeugen
                return
            job.info = info
            job.hist.append(info["c"])
            # Live-Netz nebenher erzeugen: die Optimierung wartet nicht darauf (ist eins noch in Arbeit,
            # wird dieses Bild übersprungen).
            if live["busy"]:
                return
            live["busy"] = True
            xs = np.array(xp, copy=True)

            def make():
                try:
                    v, f, _, _, _ = E.result_mesh(M, xs, level=0.0, sigma=0.6, prune=False)
                    job.frame = (v.astype(np.float32), f.astype(np.uint32))
                    job.frame_id = it
                except Exception:
                    pass
                finally:
                    live["busy"] = False
            threading.Thread(target=make, name="diotopo-live", daemon=True).start()

        def optimiere():
            O = E.Optimizer(M, log=job.log, on_frame=on_frame, stop=lambda: job.stop, on_phase=on_phase)
            snaps = O.run()
            if tl["t"] and tl["n"]:
                _learn_iter(M, tl["n"], time.time() - tl["t"])
            if not snaps:
                if job.stop:
                    raise E.Stopped()
                raise ValueError("Keine Iteration berechnet.")
            res = dict(model=M, snaps=snaps, hist=O.hist, settings=settings,
                       bands=(True if O.prism is not None else None), layer_hist=getattr(O, "layer_hist", None))
            P.results["optimize"] = res
            job.log(f"Löser: {M.solver_info}")
            return res

        res = optimiere()
        snaps = res["snaps"]
        if job.stop:
            # Abgebrochen: schnelles Grobnetz statt der langwierigen Feinvernetzung
            M.S["refine"] = False
            pg.expect("Ergebnisnetz", PF.SPEED.get("finish") * M.ne * 0.3)
            job.log("Erzeuge Grobnetz aus dem aktuellen Stand – Feinnetz bei Bedarf über "
                    "„Netz neu erzeugen & analysieren“.")
        try:
            with P.calc_lock:
                _finish_opt(res, len(snaps) - 1, float(settings.get("level", 0) or 0),
                            float(settings.get("sigma", 0.7)), job.log, pg=pg,
                            stop=lambda: job.stop_finish)
                if not job.stop:
                    _reach_safety(res, settings, job, pg, optimiere)
        except E.Stopped:
            P.results.pop("optimize", None)
            raise
        except ValueError:
            if not job.stop:
                raise
            # früh abgebrochen: Zwischenstand ist noch keine tragfähige Struktur
            P.results.pop("optimize", None)
            job.log(f"Der Stand nach {len(snaps)} Iteration(en) ist noch nicht tragfähig – kein Ergebnis übernommen.")
            raise E.Stopped()
    return run


def _safety(A):
    """Maßgebliche Sicherheit eines Ergebnisses: Werkstoff (von Mises) und – beim 3D-Druck – Schichthaftung."""
    vals = [x for x in (A.get("safety"), A.get("layer_safety")) if x is not None]
    return min(vals) if vals else None


def _reach_safety(res, settings, job, pg, optimiere):
    """Mindestsicherheit (Reiter 1): Erreicht das Ergebnis mit dem eingestellten Zielvolumen die Vorgabe nicht,
    bekommt es mehr Material – zuerst durch Verstärken der gefundenen Struktur (Schwelle senken, mehrere
    Prüfrechnungen), reicht das nicht, durch erneutes Optimieren mit höherem Zielvolumen (höchstens zweimal)."""
    tgt = float(settings.get("safety_target", 0) or 0)
    if tgt <= 0:
        return
    M, log = res["model"], job.log
    stop = lambda: job.stop_finish or job.stop                  # noqa: E731
    sigma = float(settings.get("sigma", 0.7))
    sf = _safety(res["A"])
    if sf is None:
        return
    if sf >= tgt:
        log(f"Mindestsicherheit {tgt:g}: erreicht (Sicherheit {sf:.2f}).")
        return
    log(f"Mindestsicherheit {tgt:g}: mit dem Zielvolumen wird nur {sf:.2f} erreicht – das Ergebnis bekommt mehr Material.")

    def rechne(xb, v):
        M.cancel = stop
        try:
            return _safety(E.analyze(M, xb, v))
        finally:
            M.cancel = None

    # Obergrenze: Was schafft das Vollteil?
    pg.phase("Ergebnis analysieren")
    pg.set_detail("Mindestsicherheit: Vollteil prüfen")
    full = rechne(np.ones(M.ne), P.mesh.tris.reshape(-1, 3))
    if full is not None and full < tgt:
        log(f"WARNUNG: Die Mindestsicherheit {tgt:g} ist mit diesem Bauteil nicht erreichbar – selbst das Vollteil "
            f"hat nur {full:.2f}. Lasten verringern, festeren Werkstoff wählen oder das Bauteil verstärken. Das "
            "Ergebnis bleibt beim eingestellten Zielvolumen.")
        res["sf_note"] = "unreachable"
        return
    vf0 = float(M.S["volfrac"])
    for runde in range(3):
        it = len(res["snaps"]) - 1
        xp = res["snaps"][it].astype(np.float64)

        def probe(t):
            if stop():
                raise E.Stopped()
            v, _, xb, _, _ = E.result_mesh(M, xp, level=0.0, sigma=sigma, target=float(t))
            return rechne(xb, v) or 0.0, float(xb.mean())

        # Verstärken: kleinster Elementanteil, mit dem die Vorgabe erreicht wird
        lo_t, hi_t, best = float(M.S["volfrac"]), 0.95, None
        M.clean_log = None
        try:
            s_hi, e_hi = probe(hi_t)
            if s_hi >= tgt:
                best = hi_t
                for k in range(6):
                    pg.set_detail(f"Mindestsicherheit: Struktur verstärken (Prüfrechnung {k + 2})")
                    mid = 0.5 * (lo_t + hi_t)
                    s_mid, _ = probe(mid)
                    if s_mid >= tgt:
                        best = hi_t = mid
                    else:
                        lo_t = mid
                    if hi_t - lo_t < 0.02:
                        break
        except ValueError:
            pass
        if best is not None:
            for _ in range(3):                                   # fertiges Netz; knapp darunter → etwas nachlegen
                _finish_opt(res, it, 0.0, sigma, log, target=best, pg=pg, stop=lambda: job.stop_finish)
                sf = _safety(res["A"]) or 0.0
                if sf >= tgt or best >= 0.95:
                    break
                best = min(0.95, best * 1.08)
            if sf >= tgt:
                orig = abs(P.mesh.volume)
                log(f"Mindestsicherheit {tgt:g} erreicht: Sicherheit {sf:.2f} mit {res['vol'] / orig * 100:.0f} % des "
                    f"Bauteils (eingestelltes Zielvolumen {vf0 * 100:.0f} %).")
                return
        if runde == 2 or float(M.S["volfrac"]) >= 0.9 or job.stop:
            break
        # Neu optimieren mit mehr Material
        sf_now = _safety(res["A"]) or sf
        vf = min(0.9, float(M.S["volfrac"]) * min(2.5, max(1.3, tgt / max(sf_now, 1e-6))))
        log(f"Verstärken allein reicht nicht (Sicherheit {sf_now:.2f}) – optimiere neu mit Zielvolumen {vf * 100:.0f} %.")
        M.S["volfrac"] = vf
        res = optimiere()
        if job.stop:
            return
        _finish_opt(res, len(res["snaps"]) - 1, float(settings.get("level", 0) or 0), sigma, log, pg=pg,
                    stop=lambda: job.stop_finish)
        sf = _safety(res["A"]) or 0.0
        if sf >= tgt:
            log(f"Mindestsicherheit {tgt:g} erreicht: Sicherheit {sf:.2f} mit Zielvolumen {vf * 100:.0f} % "
                f"(eingestellt waren {vf0 * 100:.0f} %).")
            return
    sf = _safety(P.results["optimize"]["A"]) or 0.0
    log(f"WARNUNG: Die Mindestsicherheit {tgt:g} wurde nicht erreicht (Sicherheit {sf:.2f}). Zielvolumen oder "
        "Auflösung erhöhen, Lasten verringern oder festeren Werkstoff wählen.")


def job_remesh(j):
    def run(job):
        r = P.results.get("optimize")
        if not r:
            raise RuntimeError("Noch keine Optimierung.")
        M = r["model"]
        it = int(j.get("it", r["it"]))
        it = max(0, min(it, len(r["snaps"]) - 1))
        M.S["refine"] = bool(j.get("refine", M.S.get("refine", True)))
        M.S["detail_mm"] = float(j.get("detail_mm", M.S.get("detail_mm", 0)) or 0)
        if "allow_split" in j:
            M.S["allow_split"] = bool(j["allow_split"])
        tm = PF.SPEED.get("finish") * M.ne * 0.3 + (PF.SPEED.get("refine") if M.S["refine"] else 0.0)
        job.pg.set_plan([["Ergebnisnetz", tm], ["Ergebnis analysieren", PF.SPEED.get("analyze") * M.ne]])
        with P.calc_lock:
            target = _vol_to_target(r, j)
            _finish_opt(r, it, float(j.get("level", 0) or 0), float(j.get("sigma", 0.7)), job.log,
                        target=target, pg=job.pg, stop=lambda: job.stop)

    return run


def _finish_opt(res, it, level, sigma, log, target=None, pg=None, stop=None):
    M = res["model"]
    M.clean_log = log
    stop = stop or (lambda: False)
    if pg:
        pg.phase("Ergebnisnetz")
    t0 = time.time()
    def sf(f, t):
        if stop():
            raise E.Stopped()
        if pg:
            pg.set_frac(f, t)
    sf(0.0, "Grobnetz und Zusammenhang prüfen")
    xp = res["snaps"][it].astype(np.float64)
    v, f, xb, lev, vol = E.result_mesh(M, xp, level=level, sigma=sigma, target=target)
    ci = M.last_clean
    if ci["lowered"]:
        log(f"Schwelle von {ci['level0']:.2f} auf {lev:.2f} gesenkt, damit alle Lastflächen mit den "
            "Lagern verbunden sind.")
    if ci["islands"] or ci["removed"]:
        log(f"{max(ci['islands'], 1)} schwebende(r) Bereich(e) ohne Verbindung zum Lager entfernt "
            f"({ci['removed']} Voxel) – das Ergebnis ist ein zusammenhängendes Teil.")
    if ci["bridges"]:
        log(f"{ci['bridges']} Voxel ergänzt, wo Bereiche sich nur an Kanten/Ecken berührten.")
    if ci.get("pruned"):
        log(f"{ci['pruned']} Voxel unbelasteter Anhängsel (frei endende Stummel ohne Kraftfluss) entfernt.")
    xp = ci["xp"]
    field = None
    coarse_vol = vol
    t_c = time.time() - t0
    res["prism"] = None
    if res.get("bands") is not None:
        # Fräsen prismatisch: ebene Böden, senkrechte Wände (Netz + Flächenmodell für STEP/DXF)
        t1 = time.time()
        def stufen(xq, lq, lg):
            return PZ.build_any(M, xq, lq, sigma, float(M.S.get("cnc_tool_mm", 0) or 0),
                                float(M.S.get("detail_mm", 0) or 0), log=lg, progress=lambda q, t: sf(0.2 + 0.8 * q, t))
        buf = []
        Pz = stufen(xp, lev, buf.append)
        PF.SPEED.learn("refine", time.time() - t1)
        # Ganze Stufen brauchen mehr Material als die Dichteverteilung: bei automatischer Schwelle nachregeln,
        # bis der Stufenkörper das Zielvolumen trifft (höchstens zwei Durchgänge)
        orig0 = abs(P.mesh.volume) if P.mesh is not None else 0.0
        goal = float(M.S["volfrac"])
        erst = None                                   # erstes Ergebnis, falls das Nachregeln zu viel Tragkraft kostet
        if (level is None or level <= 0) and target is None and orig0 > 0:
            first, tcur, hist = Pz.volume / orig0, goal, []
            start = (Pz, ci, xp, lev, coarse_vol, buf)
            for _ in range(2):
                r_now = Pz.volume / orig0
                if r_now <= goal * 1.08:
                    break
                hist.append((tcur, r_now))
                if len(hist) >= 2 and abs(hist[-1][1] - hist[-2][1]) > 1e-6:
                    (ta, ra), (tb, rb) = hist[-2:]
                    tnew = tb + (goal - rb) * (tb - ta) / (rb - ra)
                else:
                    tnew = tcur * goal / r_now
                tnew = min(max(tnew, 0.4 * tcur), 0.97 * tcur)
                buf2 = []
                M.clean_log = None
                try:
                    _, _, _, lev2, vol2 = E.result_mesh(M, res["snaps"][it].astype(np.float64), level=0.0, sigma=sigma,
                                                        target=tnew)
                    ci2 = M.last_clean
                    P2 = stufen(ci2["xp"], lev2, buf2.append)
                except E.Stopped:
                    raise
                except Exception:  # noqa – z. B. kein Material mehr: bisheriges Ergebnis behalten
                    break
                finally:
                    M.clean_log = log
                if P2.pieces > Pz.pieces or P2.volume >= Pz.volume:
                    break
                Pz, ci, xp, lev, coarse_vol, tcur, buf = P2, ci2, ci2["xp"], lev2, vol2, tnew, buf2
            M.last_clean = ci
            if tcur != goal:
                erst = start
                kal_txt = (f"Schwelle auf {lev:.2f} angehoben, damit der Stufenkörper das Zielvolumen trifft "
                           f"({first * 100:.0f} % → {Pz.volume / orig0 * 100:.0f} % des Bauteils, Ziel {goal * 100:.0f} %).")
        if erst is not None:
            # Nachgeregeltes Ergebnis nur übernehmen, wenn es die Last noch ähnlich gut trägt
            M.cancel = stop
            try:
                A0 = E.analyze(M, erst[0].xb, erst[0].verts)
                A1 = E.analyze(M, Pz.xb, Pz.verts)
            finally:
                M.cancel = None
            if A1.get("parts", 1) > A0.get("parts", 1) or A1["umax"] > 2.0 * A0["umax"]:
                Pz, ci, xp, lev, coarse_vol, buf = erst
                M.last_clean = ci
                log(f"Hinweis: Der Stufenkörper braucht {first * 100:.0f} % statt {goal * 100:.0f} % des Bauteils – mit "
                    "weniger Material ginge tragende Struktur verloren. Für ein leichteres Teil mehr Tiefenstufen "
                    "oder weitere Frässeiten wählen oder das Volumen mit dem Regler verringern.")
            else:
                log(kal_txt)
        for m in buf:
            log(m)
        if getattr(Pz, "cross", False):
            log("Hinweis: Das Bauteil hat Formen quer zur Fräsachse (z. B. Querbohrungen oder Schrägen). Sie bleiben wie "
                "im Original erhalten, lassen sich von der gewählten Seite aber nicht fräsen (eigene Aufspannung bzw. "
                "bohren) – oder weitere Frässeiten wählen.")
        # Anzeige: Eckpunkte je Dreieck getrennt (scharfe Kanten, flach schattiert); Export bleibt indiziert
        v, f = Pz.verts[Pz.tri].reshape(-1, 3), np.arange(3 * len(Pz.tri)).reshape(-1, 3)
        vol, xb, field = Pz.volume, Pz.xb, PZ.fine_field(Pz)
        res["prism"] = Pz
    elif M.S.get("refine", True):
        t1 = time.time()
        v, f, vol, field = E.refined_mesh(M, xp, lev, sigma, float(M.S.get("detail_mm", 0) or 0), log=log,
                                          excl=ci["excl"], skeleton=ci["xb"],
                                          progress=lambda q, t: sf(0.2 + 0.8 * q, t))
        PF.SPEED.learn("refine", time.time() - t1)
    PF.SPEED.learn("finish", t_c / M.ne / 0.3)
    log(f"Netz aus Iteration {it + 1}: Schwelle {lev:.2f}, {len(f)} Dreiecke – analysiere Ergebnis …")
    if pg:
        pg.phase("Ergebnis analysieren")
        pg.set_detail(f"Spannungen im Ergebnis berechnen ({len(f)} Dreiecke)")
    t1 = time.time()
    if stop():
        raise E.Stopped()
    M.cancel = stop                       # Löser prüft den Abbruch auch während der Rechnung
    try:
        A = E.analyze(M, xb, v)
    finally:
        M.cancel = None
        M.clean_log = None
    res["ovh"] = None
    if M.S.get("mfg") in AN.AM_KINDS:
        _overhang_report(res, M, v, f, log)
    res["wi"] = None
    if M.shell is not None:
        # 3D-Druck Erweitert: Randschichten und Infill im fertigen Teil (Masse, Anzeige)
        if field is None:
            g = E.density_grid(M, xb)
            field = (g - 0.5, M.lo, M.h)
        try:
            wi = AN.walls_infill(field, M.S, M.scale)
            phi = float(M.S.get("infill_pct", 20)) / 100.0
            wi["mass_g"] = (wi["v_shell"] + phi * wi["v_core"]) * M.S["rho"] * 1e-3
            res["wi"] = wi
            log(f"Druckmasse mit Wänden und Infill ≈ {wi['mass_g']:.1f} g (Randschichten {wi['v_shell'] / 1000:.1f} cm³, "
                f"Infill-Bereich {wi['v_core'] / 1000:.1f} cm³ mit {phi * 100:.0f} %)")
        except Exception as e:  # noqa
            log(f"Hinweis: Wände/Infill konnten nicht dargestellt werden ({e}).")
    PF.SPEED.learn("analyze", (time.time() - t1) / M.ne)
    if res.get("prism") is not None:
        A["pieces"] = res["prism"].pieces
    if A["warning"]:
        log("WARNUNG: " + A["warning"])
    elif A.get("pieces", 1) > 1:
        A["warning"] = (f"Das Ergebnis besteht aus {A['pieces']} getrennten Stücken, die jeweils nur an einem Lager "
                        "hängen – mit diesem Volumen reicht das Material nicht für eine Verbindung. Volumen erhöhen"
                        + (", mehr Tiefenstufen wählen oder andere Frässeiten wählen." if res.get("bands") is not None
                           else " oder Lager prüfen."))
        log("WARNUNG: " + A["warning"])
    if M.layer is not None and A.get("layer_safety") is not None and A["layer_safety"] < 1.0:
        log(f"WARNUNG: Die Schichthaftung hält die Last nicht (Sicherheit {A['layer_safety']:.2f} < 1). Andere "
            "Aufbaurichtung, mehr Volumen oder geringere Lasten wählen.")
    # Kalibrierung für den Volumen-Schieberegler: Endvolumen ↔ Elementanteil ↔ Grobnetz
    orig = abs(P.mesh.volume) if P.mesh is not None else 0.0
    if orig > 0 and xb.mean() > 0 and coarse_vol > 0:
        res["cal"] = (vol / orig) / float(xb.mean())
        res["mesh_cal"] = vol / coarse_vol
        # Stützpunkte Elementanteil ↔ Endvolumen (je Iteration) für Schieberegler und Vorschau
        pts = res.setdefault("calpts", {}).setdefault(it, [])
        pts.append((float(xb.mean()), float(vol / orig)))
    res.update(verts=v.astype(np.float32), faces=f.astype(np.uint32), A=A, it=it, level=lev,
               sigma=sigma, vol=vol, xp=xp, field=field, target=target)


def _overhang_report(res, M, v, f, log):
    """3D-Druck: Bereiche, die flacher als der maximale Überhangwinkel sind, als Fehler melden (mit Ort).
    Meist massive Zonen, Bohrungen quer zur Aufbaurichtung oder übernommene Originalflächen – die
    Optimierung selbst hält den Winkel ein."""
    ang = float(M.S.get("overhang", 45) or 45)
    regs, flag = SC.overhang_regions(v, f.astype(np.int64), M.S["mfg_dir"], ang, M.scale,
                                     min_area_mm2=max(2.0, 0.5 * M.h_mm ** 2))
    res["ovh"] = flag
    if not regs:
        log(f"Überhangprüfung: keine Bereiche flacher als der maximale Überhangwinkel ({ang:g}°).")
        return
    pas = np.zeros(M.shape, dtype=bool)
    pas[M.ei[M.passive], M.ej[M.passive], M.ek[M.passive]] = True
    parts = []
    for r in regs[:5]:
        c = r["center"]
        i = np.clip(np.floor((c - M.lo) / M.h).astype(int), 0, np.array(M.shape) - 1)
        lo_, hi_ = np.maximum(i - 1, 0), np.minimum(i + 2, np.array(M.shape))
        near = pas[lo_[0]:hi_[0], lo_[1]:hi_[1], lo_[2]:hi_[2]].any()
        p = c * M.scale
        parts.append(f"{p[0]:.1f} / {p[1]:.1f} / {p[2]:.1f} mm ({r['area']:.0f} mm²"
                     + (", massive Zone/Bohrung" if near else "") + ")")
    tot = sum(r["area"] for r in regs)
    log(f"WARNUNG: {len(regs)} Bereich(e) mit zusammen {tot:.0f} mm² sind flacher als der maximale Überhangwinkel "
        f"({ang:g}° in Aufbaurichtung {M.S['mfg_dir']}) und lassen sich ohne Stützen nicht optimiert drucken – bei "
        + "; ".join(parts) + (" und weitere" if len(regs) > 5 else "")
        + ". Die Darstellung „Druckprüfung“ zeigt sie orange. Abhilfe: Aufbaurichtung ändern, massive Zonen bzw. "
          "Bohrungen anpassen oder dort Stützen im Slicer vorsehen.")
    res["ovh_txt"] = f"{len(regs)} Überhangbereich(e), {tot:.0f} mm²"


def _calpts(r, it):
    pts = sorted(set((r.get("calpts") or {}).get(it, [])))
    return pts if len({p[0] for p in pts}) >= 2 else None


def _target_curve(r, it):
    """Vorgabe für die Schwellwertsuche ↔ tatsächlicher Elementanteil nach dem Entfernen loser
    Bereiche (wird einmal je Iteration berechnet und zwischengespeichert)."""
    cache = r.setdefault("curve", {})
    if it not in cache:
        M = r["model"]
        xp = r["snaps"][it].astype(np.float64)
        ts = np.linspace(0.02, 0.98, 25)
        got = []
        for t in ts:
            try:
                _, _, xb, _, _ = E.result_mesh(M, xp, level=0.0, sigma=0.7, target=float(t), prune=False)
                got.append(float(xb.mean()))
            except Exception:  # noqa
                got.append(got[-1] if got else 0.0)
        cache[it] = (ts, np.maximum.accumulate(np.asarray(got)))
    return cache[it]


def _vol_to_target(r, j):
    """Gewünschtes Endvolumen (Anteil am Bauteil) -> Vorgabe für die Schwellwertsuche."""
    e = _vol_to_elements(r, j)
    if e is None:
        t = j.get("target")
        return float(t) if t else None
    it = max(0, min(int(j.get("it", r.get("it", 0))), len(r["snaps"]) - 1))
    ts, got = _target_curve(r, it)
    if e >= got[-1]:
        return float(ts[-1])
    return float(np.interp(e, got, ts))


def _vol_to_elements(r, j):
    """Gewünschtes Endvolumen -> benötigter Elementanteil (über die Kalibrierung mit fertigen Netzen)."""
    vol = j.get("vol")
    if vol:
        it = int(j.get("it", r.get("it", 0)))
        pts = _calpts(r, it)
        if pts:                               # aus gemessenen Endnetzen inter-/extrapolieren
            pts = sorted(pts, key=lambda p: p[1])
            xs, ys = zip(*pts)
            v = float(vol)
            if ys[0] <= v <= ys[-1]:
                t = float(np.interp(v, ys, xs))
            else:                             # linear über die zwei nächstgelegenen Stützpunkte
                a, b = (pts[0], pts[1]) if v < ys[0] else (pts[-2], pts[-1])
                t = a[0] + (v - a[1]) * (b[0] - a[0]) / max(b[1] - a[1], 1e-9)
            return float(min(0.98, max(0.01, t)))
        return float(min(0.98, max(0.01, float(vol) / r.get("cal", 1.0))))
    return None


def preview_payload(j):
    """Schnelle Grobvorschau des Ergebnisses für den Volumen-Schieberegler (ohne Feinnetz/Analyse)."""
    r = P.results.get("optimize")
    if not r:
        raise RuntimeError("Noch keine Optimierung.")
    M = r["model"]
    if "allow_split" in j:
        M.S["allow_split"] = bool(j["allow_split"])
    it = max(0, min(int(j.get("it", r["it"])), len(r["snaps"]) - 1))
    xp = r["snaps"][it].astype(np.float64)
    target = _vol_to_target(r, j)
    if not P.calc_lock.acquire(timeout=0.05):
        raise RuntimeError("Es läuft gerade ein Auftrag.")
    try:
        sig = float(j.get("sigma", 0.7))
        v, f, xb, lev, vol = E.result_mesh(M, xp, level=float(j.get("level", 0) or 0),
                                           sigma=sig, target=target,
                                           prune=bool(j.get("prune", False)))
        pz = None
        if r.get("bands") is not None:
            # prismatisch: Vorschau gleich als Stufenkörper (gröberes Raster)
            ci = M.last_clean
            pz = PZ.build_any(M, ci["xp"], lev, sig, float(M.S.get("cnc_tool_mm", 0) or 0), M.h_mm / 2.0,
                              log=lambda m: None, coarse=True)
            v, f = pz.verts[pz.tri].reshape(-1, 3), np.arange(3 * len(pz.tri)).reshape(-1, 3)
            vol, xb = pz.volume, pz.xb
    finally:
        P.calc_lock.release()
    orig = abs(P.mesh.volume) * M.scale ** 3
    pts = _calpts(r, it)
    if pz is not None:
        vol_mm3 = vol * M.scale ** 3
    elif pts and pts[0][0] <= float(xb.mean()) <= pts[-1][0]:
        xs, ys = zip(*pts)
        vol_mm3 = float(np.interp(float(xb.mean()), xs, ys)) * orig
    elif "cal" in r:                            # erwartetes Volumen des fertigen (Fein-)Netzes
        vol_mm3 = float(xb.mean()) * r["cal"] * orig
    else:
        vol_mm3 = vol * M.scale ** 3
    meta = dict(level=lev, mass_g=vol_mm3 * M.S["rho"] * 1e-3, vol_ratio=vol_mm3 / orig if orig else None,
                orig_mass_g=orig * M.S["rho"] * 1e-3, seq=j.get("seq"))
    wi = r.get("wi")
    if wi and r.get("vol"):
        # Druckmasse (Wände + Infill) im Verhältnis wie beim letzten fertigen Ergebnis
        meta["print_mass_g"] = meta["mass_g"] * wi["mass_g"] / (r["vol"] * M.scale ** 3 * M.S["rho"] * 1e-3)
    return pack(meta, dict(verts=v.astype(np.float32), faces=f.astype(np.uint32)))


def field_payload(j):
    """Dichtefeld einer Iteration für die Live-Vorschau im Browser: Beim Ziehen des Volumen-Reglers entsteht
    die Oberfläche dort direkt aus diesem Feld (ohne Anfrage an den Rechenkern). Dazu je Reglerstellung
    (Endvolumen 1…99 %) die passende Schwelle."""
    r = P.results.get("optimize")
    if not r:
        raise RuntimeError("Noch keine Optimierung.")
    M = r["model"]
    it = max(0, min(int(j.get("it", r["it"])), len(r["snaps"]) - 1))
    field = E._smoothed_field(M, r["snaps"][it].astype(np.float64), float(j.get("sigma", 0.7)))
    srt = np.sort(field, axis=None)
    n = len(srt)
    levels = np.zeros(99, dtype=np.float32)
    for v in range(1, 100):
        e = _vol_to_elements(r, {"vol": v / 100.0, "it": it}) or v / 100.0
        k = min(max(int(round(e * M.ne)), 1), n - 1)
        levels[v - 1] = 255.0 * min(0.95, max(0.02, float(srt[n - k - 1])))
    orig = abs(P.mesh.volume) * M.scale ** 3
    meta = dict(it=it, dims=list(field.shape), lo=M.lo.tolist(), h=float(M.h), orig_mass_g=orig * M.S["rho"] * 1e-3)
    return pack(meta, dict(field=np.clip(np.rint(field * 255.0), 0, 255).astype(np.uint8), levels=levels))


def start_job(kind, settings, conds):
    with P.lock:
        if P.job and P.job.state == "running":
            raise RuntimeError("Es läuft bereits ein Auftrag.")
        if P.mesh is None:
            raise RuntimeError("Bitte zuerst ein Bauteil laden.")
        if kind == "remesh":
            fn = job_remesh(settings)
        else:
            fn = dict(analyze=job_analyze, optimize=job_optimize)[kind](settings, conds)
        P.job = Job(kind, fn)


# ===================================================================== Ergebnisse

def _layer_meta(A, M):
    return dict(layer=M.layer is not None, layer_safety=A.get("layer_safety"))


def _layer_arrays(A):
    if A.get("vlayer") is None:
        return {}
    return dict(lay=A["vlayer"], lay_env=A["vlayer_env"])


def result_payload(what):
    r = P.results.get(what)
    if r is None:
        raise RuntimeError("Noch kein Ergebnis vorhanden.")
    if what == "analyze":
        A, M = r["A"], r["model"]
        full = abs(P.mesh.volume) * M.scale ** 3 * M.S["rho"] * 1e-3
        meta = dict(kind="analyze", cases=A["cases"], vm_max=A["vm_max"], umax=A["umax"],
                    safety=A["safety"], yield_=A["yield_"], warning=A["warning"], solver=A["solver"],
                    mass_g=full, case_ids=M.cases, mfg=M.S.get("mfg"), **_layer_meta(A, M))
        if M.shell is not None:
            meta["print_mass_g"] = full * E.print_mass_frac(M, np.ones(M.ne))
        return pack(meta, dict(stress=A["vstress"], env=A["venv"], disp=A["vdisp"], **_layer_arrays(A)))
    if what == "optimize":
        A, M = r["A"], r["model"]
        S = M.S
        vol_mm3 = r["vol"] * M.scale ** 3
        orig = abs(P.mesh.volume) * M.scale ** 3
        meta = dict(kind="optimize", cases=A["cases"], vm_max=A["vm_max"], umax=A["umax"],
                    safety=A["safety"], yield_=A["yield_"], warning=A["warning"], solver=A["solver"],
                    mass_g=vol_mm3 * S["rho"] * 1e-3, orig_mass_g=orig * S["rho"] * 1e-3,
                    vol_ratio=vol_mm3 / orig if orig else None, hist=r["hist"], it=r["it"],
                    n_it=len(r["snaps"]), level=r["level"], sigma=r["sigma"], parts=A["parts"],
                    case_ids=M.cases, mfg=S.get("mfg"), prism=r.get("prism") is not None,
                    layer_hist=r.get("layer_hist"), **_layer_meta(A, M))
        arrays = dict(verts=r["verts"], faces=r["faces"], stress=A["vstress"], env=A["venv"], disp=A["vdisp"],
                      **_layer_arrays(A))
        wi = r.get("wi")
        if wi:
            meta.update(print_mass_g=wi["mass_g"], v_shell=wi["v_shell"], v_core=wi["v_core"],
                        orig_print_mass_g=orig * S["rho"] * 1e-3 * E.print_mass_frac(M, np.ones(M.ne)))
            if wi.get("verts") is not None:
                arrays.update(inf_v=wi["verts"], inf_f=wi["faces"])
            if wi.get("core_v") is not None:
                arrays.update(core_v=wi["core_v"], core_f=wi["core_f"])
        if r.get("ovh") is not None:
            arrays["ovh"] = r["ovh"].astype(np.uint8)
            meta["ovh_txt"] = r.get("ovh_txt")
            meta["ovh_deg"] = float(S.get("overhang", 45) or 45)
        Pz = r.get("prism")
        if Pz is not None:
            if getattr(Pz, "multi", False):
                meta["prism_axes"] = [dict(axis="XYZ"[A["axis"]], levels=[(z - A["z"][0]) * M.scale for z in A["z"]])
                                      for A in Pz.axes]
            else:
                meta["levels"] = [(z - Pz.z[0]) * M.scale for z in Pz.z]
        return pack(meta, arrays)
    raise RuntimeError("Unbekanntes Ergebnis.")


def export_mesh(what, fmt, unit="mm"):
    if what == "original":
        v = P.mesh.tris.reshape(-1, 3)
        f = np.arange(len(v)).reshape(-1, 3)
    else:
        r = P.results.get(what)
        if r is None or r.get("verts") is None:
            raise RuntimeError("Noch kein Ergebnis zum Exportieren.")
        v, f = r["verts"].astype(np.float64), r["faces"].astype(np.int64)
        if r.get("prism") is not None:              # prismatisch: indiziertes, wasserdichtes Netz
            v, f = r["prism"].verts, r["prism"].tri
    name = P.name + {"optimize": "_optimiert", "original": ""}[what]
    if fmt == "stl":
        return G.stl_bytes(v, f), name + ".stl", "model/stl"
    if fmt == "3mf":
        scale = E.LEN_MM.get(unit, 1.0)   # 3MF wird immer in mm geschrieben
        return G.threemf_bytes(v * scale, f, P.name), name + ".3mf", "model/3mf"
    if fmt == "obj":
        return G.obj_bytes(v, f), name + ".obj", "text/plain"
    if fmt in ("step", "dxf"):
        Pz = (P.results.get(what) or {}).get("prism") if what != "original" else None
        if Pz is None:
            raise RuntimeError("STEP und DXF gibt es für prismatisch gefräste Ergebnisse "
                               "(Fertigungsverfahren „Fräsen prismatisch“).")
        scale = E.LEN_MM.get(unit, 1.0)           # beide Formate in mm
        if fmt == "step":
            return PZ.step_bytes(Pz, scale, P.name), name + ".step", "application/step"
        return PZ.dxf_bytes(Pz, scale), name + ".dxf", "application/dxf"
    raise RuntimeError("Unbekanntes Format.")


def check_payload(what, S):
    if what == "original":
        v = P.mesh.tris.reshape(-1, 3).astype(np.float32)
        f = np.arange(len(v), dtype=np.int64).reshape(-1, 3)
        h = max(float(S.get("min_wall_mm", 0.6)) / 3 / S["scale"], P.mesh.diag / 400)
        lo, shape = G.grid_for(P.mesh.lo, P.mesh.hi, h, pad=2)
        if np.prod(shape) > 4e7:
            h = P.mesh.diag / 300
            lo, shape = G.grid_for(P.mesh.lo, P.mesh.hi, h, pad=2)
        solid = (G.voxelize(P.mesh.tris, lo, h, shape, robust=not P.mesh.watertight)[0], lo, h)
    else:
        r = P.results["optimize"]
        M = r["model"]
        v, f = r["verts"], r["faces"].astype(np.int64)
        if r.get("field") is not None:
            solid = r["field"]
        else:
            g = E.density_grid(M, r["xp"])
            from scipy.ndimage import gaussian_filter
            solid = (gaussian_filter(g, r["sigma"]) > r["level"], M.lo, M.h)
    flag, stats = SC.check_mesh(v, f, solid, S)
    return pack(stats, dict(flag=flag))


# ===================================================================== HTTP

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, default=_jsonable).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n else b""

    def _json(self):
        raw = self._body()
        return json.loads(raw.decode("utf-8")) if raw else {}

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        P.last_seen = time.time()
        try:
            path = u.path
            if path == "/":
                path = "/index.html"
            if not path.startswith("/api/"):
                fp = os.path.normpath(os.path.join(WEB, path.lstrip("/")))
                if not fp.startswith(WEB) or not os.path.isfile(fp):
                    return self._send(404, {"error": "nicht gefunden"})
                with open(fp, "rb") as f:
                    return self._send(200, f.read(), MIME.get(os.path.splitext(fp)[1], "application/octet-stream"))
            if path == "/api/info":
                return self._send(200, dict(
                    version=VERSION, step=G.step_available(), holder=__import__("diotopo").rechteinhaber(), pardiso=SV.HAVE_PARDISO,
                    gpus=_gpu_names(), threads=PR.n_threads(),
                    materials={k: dict(E=v[0], nu=v[1], rho=v[2], yield_=v[3], E_z=v[4], S_z=v[5], S_zs=v[6])
                               for k, v in E.MATERIALS.items()},
                    patterns={k: v[0] for k, v in AN.PATTERNS.items()},
                    units=E.UNIT_LABELS))
            if path == "/api/ping":
                return self._send(200, {"ok": True})
            if path == "/api/status":
                j = P.job
                if j is None:
                    return self._send(200, dict(state="idle"))
                frm = int(q.get("log_from", ["0"])[0])
                ps = j.pg.status()
                if j.state != "running":
                    ps.update(progress=1.0, eta=0.0)
                return self._send(200, dict(kind=j.kind, state=j.state, error=j.error, logs=j.logs[frm:],
                                            log_n=len(j.logs), progress=ps["progress"], eta=ps["eta"],
                                            phase=ps["phase"], detail=ps["detail"], info=j.info,
                                            hist=j.hist, frame_id=j.frame_id, stopped=j.stop,
                                            elapsed=time.time() - j.t0, load=MO.snapshot()))
            if path == "/api/frame":
                j = P.job
                if not j or j.frame is None:
                    return self._send(204, b"")
                v, f = j.frame
                return self._send(200, pack(dict(id=j.frame_id), dict(verts=v, faces=f)),
                                  "application/octet-stream")
            if path == "/api/result":
                return self._send(200, result_payload(q.get("what", [""])[0]), "application/octet-stream")
            if path == "/api/export":
                data, fn, ct = export_mesh(q.get("what", ["optimize"])[0], q.get("fmt", ["stl"])[0],
                                           q.get("unit", ["mm"])[0])
                return self._send(200, data, ct, {"Content-Disposition": f'attachment; filename="{fn}"',
                                                  "X-Filename": urllib.parse.quote(fn)})
            return self._send(404, {"error": "nicht gefunden"})
        except Exception as e:  # noqa
            traceback.print_exc()
            self._send(400, {"error": str(e)})

    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        if u.path == "/api/open":                 # nur fest hinterlegte Links im Standardbrowser öffnen
            url = (self._json() or {}).get("url", "")
            if url not in ALLOWED_LINKS:
                return self._send(403, {"error": "Link nicht erlaubt"})
            import webbrowser
            webbrowser.open(url)
            return self._send(200, {"ok": True})
        if u.path == "/api/bye":                  # Fenster wird geschlossen (oder neu geladen)
            P.bye_at = time.time()
            return self._send(200, {"ok": True})
        P.last_seen = time.time()
        try:
            if u.path == "/api/load":
                name = q.get("name", ["bauteil.stl"])[0]
                data = self._body()
                logs = []
                tris, fids, unit, kind = G.read_any(name, data, log=logs.append)
                mesh = G.MeshData(tris, fids, log=logs.append)
                with P.lock:
                    P.mesh, P.kind, P.unit_hint = mesh, kind, unit
                    P.name = os.path.splitext(os.path.basename(name))[0]
                    P.results = {}
                    P.job = None
                meta = dict(name=P.name, kind=kind, unit=unit, n=int(len(mesh.tris)), lo=mesh.lo, hi=mesh.hi,
                            volume=abs(mesh.volume), area=float(mesh.area.sum()), watertight=mesh.watertight,
                            open_edges=mesh.open_edges, components=mesh.components,
                            n_faces=mesh.n_faces, cad_faces=mesh.has_cad_faces, logs=logs,
                            holes=[dict(d=2 * h["radius"], tris=np.asarray(h["tris"]).tolist(), axis=h["axis"],
                                        point=h["point"]) for h in G.find_holes(mesh)])
                return self._send(200, pack(meta, dict(pos=mesh.tris.astype(np.float32),
                                                       fid=mesh.face_ids.astype(np.int32))),
                                  "application/octet-stream")
            if u.path == "/api/pick":
                j = self._json()
                if P.mesh is None:
                    raise RuntimeError("Kein Bauteil geladen.")
                t = int(j["tri"])
                if j.get("mode") == "grow":
                    tris = P.mesh.grow(t, float(j.get("angle", 20)), bool(j.get("smooth")))
                else:
                    tris = P.mesh.face_triangles(int(P.mesh.face_ids[t]))
                return self._send(200, dict(tris=np.asarray(tris).tolist()))
            if u.path == "/api/faceinfo":
                j = self._json()
                return self._send(200, P.mesh.face_summary(j["tris"]))
            if u.path == "/api/job":
                j = self._json()
                start_job(j["kind"], j.get("settings", {}), j.get("conditions", []))
                return self._send(200, {"ok": True})
            if u.path == "/api/stop":
                if P.job:
                    if P.job.kind == "optimize" and P.job.stop:
                        P.job.stop_finish = True
                    P.job.stop = True
                return self._send(200, {"ok": True})
            if u.path == "/api/remesh":
                j = self._json()
                if not P.results.get("optimize"):
                    raise RuntimeError("Noch keine Optimierung.")
                start_job("remesh", j, [])
                return self._send(200, {"ok": True})
            if u.path == "/api/preview":
                if P.job and P.job.state == "running":
                    return self._send(409, {"error": "Es läuft gerade ein Auftrag."})
                return self._send(200, preview_payload(self._json()), "application/octet-stream")
            if u.path == "/api/field":
                return self._send(200, field_payload(self._json()), "application/octet-stream")
            if u.path == "/api/fe_estimate":
                j = self._json()
                if P.mesh is None:
                    raise RuntimeError("Kein Bauteil geladen.")
                return self._send(200, fe_estimate(j.get("kind", "optimize"), j.get("settings", {})))
            if u.path == "/api/check":
                j = self._json()
                S = dict(j)
                S["scale"] = E.LEN_MM[S.get("unit_len", "mm")]
                return self._send(200, check_payload(j.get("what", "optimize"), S), "application/octet-stream")
            if u.path == "/api/shutdown":
                self._send(200, {"ok": True})
                threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            return self._send(404, {"error": "nicht gefunden"})
        except Exception as e:  # noqa
            traceback.print_exc()
            self._send(400, {"error": str(e)})


def find_port(start=8765):
    for p in range(start, start + 50):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    raise RuntimeError("Kein freier Port gefunden.")


def make_server(port=None, host="127.0.0.1"):
    port = port or find_port()
    srv = ThreadingHTTPServer((host, port), Handler)
    srv.daemon_threads = True
    return srv, port
