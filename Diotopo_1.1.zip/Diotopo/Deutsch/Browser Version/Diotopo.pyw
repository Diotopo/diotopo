# -*- coding: utf-8 -*-
"""
Diotopo – Startprogramm (Windows, Linux, macOS).

Startet den Rechenkern im Hintergrund und öffnet die Oberfläche in einem eigenen
Anwendungsfenster (Edge/Chrome/Chromium/Brave im App-Modus; sonst im Standardbrowser).
Wird das Fenster geschlossen, beendet sich das Programm.
"""

import importlib.util
import os
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser

HERE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
# USB-/Portable-Version: liegt „portable.txt“ neben Diotopo.exe, bleiben alle Daten (Einstellungen,
# Protokoll, Fensterprofil) im Ordner „Daten“ daneben – auf dem fremden PC wird nichts hinterlassen.
_EXE_DIR = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
PORTABLE = os.path.isfile(os.path.join(_EXE_DIR, "portable.txt"))
if PORTABLE:
    os.environ["LOCALAPPDATA"] = os.path.join(_EXE_DIR, "Daten")
# Datenordner je System (Einstellungen, Protokoll, Fensterprofil): Windows %LOCALAPPDATA%,
# Linux ~/.local/share, macOS ~/Library/Application Support
if os.name != "nt" and not os.environ.get("LOCALAPPDATA"):
    os.environ["LOCALAPPDATA"] = (os.path.expanduser("~/Library/Application Support") if sys.platform == "darwin"
                                  else os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"))
APPDATA = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Diotopo")
os.makedirs(APPDATA, exist_ok=True)
LOGFILE = os.path.join(APPDATA, "diotopo.log")

# Ohne Konsole (pythonw/EXE) Ausgaben in eine Logdatei umleiten
if sys.stdout is None or not sys.stdout.isatty():
    try:
        _log = open(LOGFILE, "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stderr = _log
    except OSError:
        pass


def relaunch_as_diotopo():
    """Unter Windows über die eigene Programmdatei Diotopo.exe neu starten, damit der Task-Manager
    „Diotopo“ (mit Dio-Symbol) statt „Python“ anzeigt. Klappt das nicht, läuft alles wie bisher."""
    if os.name != "nt" or getattr(sys, "frozen", False) or os.environ.get("DIOTOPO_RELAUNCHED"):
        return
    try:
        from diotopo import runtime as RT
        if RT.running_as_diotopo():
            return
        exe = RT.ensure(os.path.join(HERE, "icon.ico"), log=print)
        if exe:
            env = dict(os.environ, DIOTOPO_RELAUNCHED="1")
            subprocess.Popen([exe, os.path.abspath(__file__)] + sys.argv[1:], env=env, cwd=HERE)
            sys.exit(0)
    except SystemExit:
        raise
    except Exception:  # noqa
        traceback.print_exc()


def message(title, text, error=False):
    try:
        if os.name == "nt":
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, title, 0x10 if error else 0x40)
        elif sys.platform == "darwin":
            t = text.replace('"', "'")
            subprocess.run(["osascript", "-e", f'display dialog "{t}" with title "{title}" buttons {{"OK"}} '
                            f'with icon {"stop" if error else "note"}'], timeout=600)
        else:
            import shutil
            if shutil.which("zenity"):
                subprocess.run(["zenity", "--error" if error else "--info", "--title", title, "--text", text], timeout=600)
            elif shutil.which("kdialog"):
                subprocess.run(["kdialog", "--title", title, "--error" if error else "--msgbox", text], timeout=600)
            else:
                print(title + ": " + text)
    except Exception:
        print(title + ": " + text)


def check_packages():
    need = {"numpy": "numpy", "scipy": "scipy"}
    missing = [p for m, p in need.items() if importlib.util.find_spec(m) is None]
    if missing:
        message("Diotopo", "Es fehlen Python-Pakete: " + ", ".join(missing) +
                ("\n\nBitte „Pakete installieren.bat“ im Ordner „Browser Version“ ausführen."
                 if os.name == "nt" and not os.path.isdir(os.path.join(HERE, "setup")) else
                 "\n\nBitte Diotopo mit dem Installer neu installieren oder\n"
                 "python3 -m pip install -r requirements.txt ausführen."), error=True)
        sys.exit(1)


def find_browser():
    """Browser mit App-Modus (eigenes Fenster ohne Adressleiste): Edge, Chrome, Chromium, Brave."""
    import shutil
    cands = []
    if os.name == "nt":
        for base in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")):
            if base:
                cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                          os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    elif sys.platform == "darwin":
        for root in ("/Applications", os.path.expanduser("~/Applications")):
            for app, exe in (("Google Chrome", "Google Chrome"), ("Microsoft Edge", "Microsoft Edge"),
                             ("Chromium", "Chromium"), ("Brave Browser", "Brave Browser")):
                cands.append(os.path.join(root, app + ".app", "Contents", "MacOS", exe))
    else:
        for exe in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge",
                    "microsoft-edge-stable", "brave-browser"):
            p = shutil.which(exe)
            if p:
                cands.append(p)
    for c in cands:
        if os.path.isfile(c):
            return c
    return None


def remove_old_package():
    """Alter Programmordner aus frühen Vorversionen (beim Drüberkopieren übrig geblieben)."""
    old = os.path.join(HERE, "topo" + "opt")
    if (os.path.isdir(os.path.join(HERE, "diotopo")) and os.path.isfile(os.path.join(old, "solver.py"))
            and os.path.isfile(os.path.join(old, "engine.py"))):
        import shutil
        shutil.rmtree(old, ignore_errors=True)


def main():
    remove_old_package()
    relaunch_as_diotopo()
    try:
        from diotopo import runtime as RT
        if RT.running_as_diotopo():
            RT.add_user_site()
    except Exception:  # noqa
        pass
    check_packages()
    from diotopo.server import make_server, P

    srv, port = make_server()
    url = f"http://127.0.0.1:{port}/?fenster=1"
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(time.strftime("%Y-%m-%d %H:%M:%S"), "Diotopo läuft auf", url, flush=True)
    # warten bis der Server antwortet
    for _ in range(50):
        try:
            urllib.request.urlopen(url + "api/ping", timeout=1)
            break
        except Exception:
            time.sleep(0.1)

    browser = find_browser()
    proc = None
    if browser and "--browser" not in sys.argv:
        prof = os.path.join(APPDATA, "fenster")
        # Snap-Browser (Ubuntu) dürfen nicht in versteckte Ordner schreiben → dann ohne eigenes Profil
        snap = "/snap/" in os.path.realpath(browser)
        args = [browser, f"--app={url}"] + ([] if snap else [f"--user-data-dir={prof}"]) + ["--no-first-run",
                "--no-default-browser-check", "--disable-features=Translate,msEdgeSidebarV2,msStartupBoost",
                # Herzschlag auch bei minimiertem/verdecktem Fenster nicht drosseln; nach dem Schließen
                # nicht im Hintergrund weiterlaufen
                "--disable-background-timer-throttling", "--disable-renderer-backgrounding",
                "--disable-backgrounding-occluded-windows", "--disable-background-mode",
                "--window-size=1500,950"]
        flags = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW
        proc = subprocess.Popen(args, creationflags=flags)
    else:
        webbrowser.open(url)

    t_start = time.time()
    handoff = False   # Edge hat das Fenster an eine bereits laufende Instanz übergeben
    reason = ""
    try:
        while True:
            time.sleep(0.5)
            now = time.time()
            idle = now - P.last_seen
            if P.bye_at and now - P.bye_at > 3 and P.last_seen < P.bye_at:
                reason = "Fenster geschlossen"
                break
            if proc is not None and not handoff and proc.poll() is not None:
                if now - t_start < 5:
                    handoff = True
                elif idle > 3:
                    reason = "Fensterprozess beendet"
                    break
            # Herzschlag alle 2 s; ohne Fenster bleibt er aus (auch während einer Berechnung)
            if idle > 20 and now - t_start > 30:
                reason = "kein Fenster mehr offen"
                break
    except KeyboardInterrupt:
        reason = "abgebrochen"
    print(time.strftime("%Y-%m-%d %H:%M:%S"), "Diotopo wird beendet:", reason, flush=True)
    try:
        if P.job is not None and P.job.state == "running":
            P.job.stop = True                     # laufende Berechnung abbrechen
    except Exception:  # noqa
        pass
    try:
        srv.shutdown()
    except Exception:  # noqa
        pass
    if proc is not None and proc.poll() is None:
        # Reste des Diotopo-Fensters (eigenes Browserprofil) beenden – andere Browserfenster bleiben unberührt
        if os.name == "nt":
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True, creationflags=0x08000000)
        else:
            try:
                proc.terminate()
            except Exception:  # noqa
                pass
    print("Diotopo beendet.", flush=True)
    os._exit(0)                                   # sofort beenden, auch wenn noch gerechnet wird


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        message("Diotopo – Fehler", "Diotopo konnte nicht gestartet werden.\n\nDetails stehen in:\n" + LOGFILE,
                error=True)
