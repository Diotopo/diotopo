# -*- coding: utf-8 -*-
"""Prüft, ob die Grafikkarten genutzt werden können, und vergleicht gemeinsames Rechnen mit nur GPU / nur CPU."""
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from diotopo import engine as E, geom as G, solver as SO  # noqa: E402


def box_model(res):
    L, W, H = 100.0, 20.0, 20.0
    v = np.array([[x, y, z] for x in (0, L) for y in (0, W) for z in (0, H)])
    quads = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    tris = []
    for a, b, c, d in quads:
        tris += [[v[a], v[b], v[c]], [v[a], v[c], v[d]]]
    mesh = G.MeshData(np.array(tris), log=lambda m: None)
    t = mesh.tris
    x0 = [i for i in range(len(t)) if np.allclose(t[i][:, 0], 0)]
    x1 = [i for i in range(len(t)) if np.allclose(t[i][:, 0], L)]
    conds = [dict(type="fixed", tris=x0, dofs=[1, 1, 1]),
             dict(type="load", kind="force", tris=x1, value=1000, dir="z-", case=1)]
    return mesh, conds


def run(method, res, iters):
    mesh, conds = box_model(res)
    M = E.Model(mesh, dict(resolution=res, max_iter=iters, solver=method), conds, log=lambda m: None)
    O = E.Optimizer(M, log=lambda m: None)
    t0 = time.time()
    O.run()
    return time.time() - t0, O.hist[-1], M.solver_info, M.nfree


def main():
    print("Diotopo – GPU-Test")
    print("==================")
    from diotopo import gpu_ocl as GO
    cu = SO.gpu_status()
    print("CUDA (NVIDIA, CuPy):   " + (cu["device"] if cu["available"] else "nicht nutzbar – " + cu["reason"]))
    oc = GO.status()
    if oc["available"]:
        kind = "eingebaute Grafik" if oc["unified"] else "eigene Grafikkarte"
        print(f"OpenCL (alle GPUs):    {oc['device']} ({kind}, {oc['memory_gb']:.1f} GB)")
        try:
            import pyopencl as cl
            alle = [d.name.strip() for p in cl.get_platforms() for d in p.get_devices(device_type=cl.device_type.GPU)]
            if len(alle) > 1:
                print("  weitere Grafikkarten: " + ", ".join(alle) + "  (Auswahl: Umgebungsvariable DIOTOPO_OPENCL_DEVICE)")
        except Exception:
            pass
        r = GO.benchmark()
        print(f"  Matrix-Vektor-Produkt: GPU {r:.2g}× so schnell wie ein CPU-Kern")
    else:
        print("OpenCL (alle GPUs):    nicht nutzbar – " + oc["reason"])
    if not cu["available"] and not oc["available"]:
        print("\nAbhilfe: Grafiktreiber aktualisieren und  py -3 -m pip install pyopencl")
        print("(NVIDIA zusätzlich, optional schneller:  py -3 -m pip install \"cupy-cuda12x[ctk]\")")
        return
    from diotopo import hybrid as HY, par as PR
    parts = HY.gpu_parts()
    print(f"\nGemeinsames Rechnen: CPU ({PR.n_threads()} Threads)"
          + "".join(" + " + p.name for p in parts))
    res = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    print(f"\nTestbalken, Auflösung {res}, 6 Iterationen – bitte warten …\n")
    th, ch, ih, n = run("auto", res, 6)
    print(f"Gemeinsam:      {th:6.1f} s   ({ih})")
    tg, cg, ig, _ = run("gpu", res, 6)
    print(f"Nur Grafikkarte:{tg:6.1f} s   ({ig})")
    tc, cc, ic, _ = run("mg", res, 6)
    print(f"Nur CPU:        {tc:6.1f} s   ({ic})")
    print(f"\n{n} Unbekannte – gemeinsam {tc / th:.1f}× so schnell wie nur CPU, {tg / th:.1f}× so schnell wie nur GPU.")
    if th > min(tg, tc) * 1.15:
        print("Hinweis: Bei kleinen Modellen kostet der Datenaustausch mehr, als das gemeinsame Rechnen bringt –"
              " mit höherer Auflösung testen (z. B.  py -3 gpu_test.py 160).")
    for name, c in (("GPU", cg), ("CPU", cc)):
        dev = abs(ch - c) / abs(c)
        print(f"Abweichung gemeinsam/{name}: {dev:.1e} " + ("(ok)" if dev < 1e-4 else "(ZU GROSS – bitte melden)"))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa
        import traceback
        traceback.print_exc()
    if os.name == "nt":
        input("\nEnter zum Schließen …")
