# -*- coding: utf-8 -*-
"""Doppelklick: öffnet den Diotopo-Assistenten zum Erstellen der Portable-Version (Fenster, keine Konsole)."""
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
web = os.path.normpath(os.path.join(here, "..", "Browser Version"))
if not os.path.isfile(os.path.join(web, "bau_assistent.py")):
    import ctypes
    ctypes.windll.user32.MessageBoxW(0, "Der Ordner „Browser Version“ muss neben diesem Ordner liegen – "
                                        "er enthält den Programmcode.", "Diotopo", 0x10)
    sys.exit(1)
sys.path.insert(0, web)
import bau_assistent  # noqa: E402

bau_assistent.main("portable", here)
